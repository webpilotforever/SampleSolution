﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace DOTEOversightProgramsListEvntRcvr.EventReceiver5
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventReceiver5 : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }


    }
}