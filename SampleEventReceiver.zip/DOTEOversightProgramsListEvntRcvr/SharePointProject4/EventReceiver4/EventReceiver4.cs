﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace DOTEOversightProgramsListEvntRcvr.EventReceiver4
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventReceiver4 : SPItemEventReceiver
    {
        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            string urlToWeb = properties.WebUrl;
            string activeOnOversightList = "";
            string aStatus = "";
            if (properties.ListTitle == "DOT&E Oversight List")
            {
                activeOnOversightList = properties.ListItem["ActiveonOverSightList"].ToString();
                aStatus = properties.ListItem["Approval Status"].ToString();

                if (aStatus == "0")
                {

                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        var userToken = properties.OriginatingUserToken;
                        using (SPSite oSiteCollection = new SPSite("https://doteint.osd.mil/program_files", userToken))
                        {
                            SPWeb oWebsite = oSiteCollection.RootWeb;

                            SPList oList = oWebsite.Lists["DeputatePrograms"];

                            SPListItemCollection collListItems = oList.Items;
                            DateTime setToNow = DateTime.Now;
                            int itemsToAdd = 0;
                            int counter = 0;
                            foreach (SPListItem oItem in collListItems)
                            {
                                // Active items cannot have a Close Date
                                if (activeOnOversightList == "Yes")
                                {
                                    if (oItem["Close Date"] == null)
                                    {
                                        // do nothing
                                    }
                                    else
                                    {
                                        oItem["Close Date"] = null;
                                        oItem.Update();
                                    }
                                }
                                if (oItem["SourceID"].ToString() == properties.ListItem["ID"].ToString())
                                {
                                    if (oItem["Close Date"] == null && activeOnOversightList == "No" || oItem["ActiveonOverSightList"] != properties.ListItem["ActiveonOverSightList"] || oItem["LongName"] != properties.ListItem["Title"])
                                    {
                                        itemsToAdd = itemsToAdd - 1;

                                        oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                        oItem["LongName"] = properties.ListItem["Title"];
                                        oItem["ShortName"] = properties.ListItem["ShortName"];
                                        oItem["Close Date"] = setToNow;
                                        oItem.Update();
                                    }
                                    break;
                                }
                                else
                                {
                                    itemsToAdd += 1;
                                }
                                counter += 1;
                            }
                            if (itemsToAdd == counter)
                            {
                                SPListItem oItem = collListItems.Add();
                                oItem["SourceID"] = properties.ListItem["ID"];
                                oItem["Title"] = properties.ListItem["ProgramID"];
                                oItem["ShortName"] = properties.ListItem["ShortName"];
                                oItem["LongName"] = properties.ListItem["Title"];
                                oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                oItem.Update();
                            }
                        }

                    });
                }
            }
        }


    }
}