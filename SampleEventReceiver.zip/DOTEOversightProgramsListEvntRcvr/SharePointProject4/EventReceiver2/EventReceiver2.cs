﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace SharePointProject4.EventReceiver2
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventReceiver2 : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being deleted.
        /// </summary>
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            properties.Cancel = true;
            properties.ErrorMessage = "Please set Active on OverSight List to No.";
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            if(properties.ListItem["Approval Status"]=="Approved")
            {
                properties.ListItem["Title"] = "Approved";

            }
            properties.ListItem["Title"] = "Approved";
        }


    }
}