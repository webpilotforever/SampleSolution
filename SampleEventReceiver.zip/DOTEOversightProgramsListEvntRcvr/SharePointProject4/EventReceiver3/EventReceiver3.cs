﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace DOTEOversightProgramsListEvntRcvr.EventReceiver3
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class EventReceiver3 : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
        }

        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
        }

        /// <summary>
        /// An item is being deleted.
        /// </summary>
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);
        }

        /// <summary>
        /// An item is being checked in.
        /// </summary>
        public override void ItemCheckingIn(SPItemEventProperties properties)
        {
            base.ItemCheckingIn(properties);
        }

        /// <summary>
        /// An item is being checked out.
        /// </summary>
        public override void ItemCheckingOut(SPItemEventProperties properties)
        {
            base.ItemCheckingOut(properties);
        }

        /// <summary>
        /// An item is being unchecked out.
        /// </summary>
        public override void ItemUncheckingOut(SPItemEventProperties properties)
        {
            base.ItemUncheckingOut(properties);
        }

        /// <summary>
        /// An attachment is being added to the item.
        /// </summary>
        public override void ItemAttachmentAdding(SPItemEventProperties properties)
        {
            base.ItemAttachmentAdding(properties);
        }

        /// <summary>
        /// An attachment is being removed from the item.
        /// </summary>
        public override void ItemAttachmentDeleting(SPItemEventProperties properties)
        {
            base.ItemAttachmentDeleting(properties);
        }

        /// <summary>
        /// A file is being moved.
        /// </summary>
        public override void ItemFileMoving(SPItemEventProperties properties)
        {
            base.ItemFileMoving(properties);
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
        }

        /// <summary>
        /// An item was deleted.
        /// </summary>
        public override void ItemDeleted(SPItemEventProperties properties)
        {
            base.ItemDeleted(properties);
        }

        /// <summary>
        /// An item was checked in.
        /// </summary>
        public override void ItemCheckedIn(SPItemEventProperties properties)
        {
            base.ItemCheckedIn(properties);
        }

        /// <summary>
        /// An item was checked out.
        /// </summary>
        public override void ItemCheckedOut(SPItemEventProperties properties)
        {
            base.ItemCheckedOut(properties);
        }

        /// <summary>
        /// An item was unchecked out.
        /// </summary>
        public override void ItemUncheckedOut(SPItemEventProperties properties)
        {
            base.ItemUncheckedOut(properties);
        }

        /// <summary>
        /// An attachment was added to the item.
        /// </summary>
        public override void ItemAttachmentAdded(SPItemEventProperties properties)
        {
            base.ItemAttachmentAdded(properties);
        }

        /// <summary>
        /// An attachment was removed from the item.
        /// </summary>
        public override void ItemAttachmentDeleted(SPItemEventProperties properties)
        {
            base.ItemAttachmentDeleted(properties);
        }

        /// <summary>
        /// A file was moved.
        /// </summary>
        public override void ItemFileMoved(SPItemEventProperties properties)
        {
            base.ItemFileMoved(properties);
        }

        /// <summary>
        /// A file was converted.
        /// </summary>
        public override void ItemFileConverted(SPItemEventProperties properties)
        {
            base.ItemFileConverted(properties);
        }

        /// <summary>
        /// The list received a context event.
        /// </summary>
        public override void ContextEvent(SPItemEventProperties properties)
        {
            base.ContextEvent(properties);
        }


    }
}