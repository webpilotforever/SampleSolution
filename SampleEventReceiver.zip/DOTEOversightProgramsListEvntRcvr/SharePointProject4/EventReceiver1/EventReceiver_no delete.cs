﻿using Microsoft.SharePoint;
using System;

namespace DOTEOversightProgramsListEvntRcvr.EventReceiver1
{
    /// <summary>
    /// See https://doteint.osd.mil/sites/IT/Pages/DOTEOversightProgramsListEvntRcvr.aspx for documentation. 
    /// </summary>
    /// 

    

    public class EventReceiver1 : SPItemEventReceiver
    {

        
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
        }

        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);            
        }

        /// <summary>
        /// An item is being deleted.
        /// </summary>
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);

        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        /// <remarks>
        /// When an item is Approved, update the target list. If the LongName has been changed in the source list, the LongName will be updated in the target list. If the Title in the target list equals the ProgramID in the source list, then do not add a similar item in the target list. Instead, check if the ActiveonOverSightList values agree, and update the item in the target list if necessary.
        /// </remarks>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
           
            string urlToWeb = properties.WebUrl;

                    
            string urlDev = "http://dotersrcndapp5";
            string urlProd = "https://doteint.osd.mil";

            string activeOnOversightList = properties.ListItem["ActiveonOverSightList"].ToString();


            string aStatus = properties.ListItem["Approval Status"].ToString(); 

         
            

            if (urlToWeb.Contains(urlDev) || urlToWeb.Contains(urlProd)) // Ensure that this event receiver will not affect non-DOT&E sites
            {
                
                
                
                // If item in DOT&E Oversight List has been updated with Approval Status set to Approved,
                // update DeputatePrograms lists.

                if (aStatus == "0")
                {                    
                    if(properties.ListItem.Web.IsRootWeb)
                    {
                        if (properties.ListTitle == "NDSourceList")
                        { 
                        
                         SPSecurity.RunWithElevatedPrivileges(delegate()
                            {
                                   var userToken = properties.OriginatingUserToken;
                                   if (urlToWeb.Contains(urlDev))
                                   {



                                       try
                                       {






                                           using (SPSite oSiteCollection = new SPSite("http://dotersrcndapp5:15429", userToken))
                                               {
                                                   SPWeb oWebsite = oSiteCollection.RootWeb;

                                                   SPList oList = oWebsite.Lists["NDTargetList"];

                                                   SPListItemCollection collListItems = oList.Items;

                                                   SPListItem oItem = collListItems.Add();

                                                   oItem["Title"] = properties.ListItem["Title"];

                                                   oItem.Update();


                                               }


                                           
                                       }
                                       catch
                                       {

                                           using (SPSite oSiteCollection = new SPSite("http://dotersrcndapp5/sites/LFTE", userToken))
                                           {
                                               SPWeb oWebsite = oSiteCollection.RootWeb;

                                               SPList oList = oWebsite.Lists["NDErrorList"];

                                               SPListItemCollection collListItems = oList.Items;

                                               SPListItem oItem = collListItems.Add();

                                               oItem["Title"] = "Attempted to add item to NDTargetList";

                                               oItem.Update();


                                           }
                                       }














                                   
                                   } else if(urlToWeb.Contains(urlProd))
                                   {

                                       try
                                       {






                                           using (SPSite oSiteCollection = new SPSite("https://doteint.osd.mil/program_files", userToken))
                                           {
                                               SPWeb oWebsite = oSiteCollection.RootWeb;

                                               SPList oList = oWebsite.Lists["NDTargetList"];

                                               SPListItemCollection collListItems = oList.Items;

                                               SPListItem oItem = collListItems.Add();

                                               oItem["Title"] = properties.ListItem["Title"];

                                               oItem.Update();


                                           }



                                       }
                                       catch
                                       {

                                           using (SPSite oSiteCollection = new SPSite("https://doteint.osd.mil/sites/it", userToken))
                                           {
                                               SPWeb oWebsite = oSiteCollection.RootWeb;

                                               SPList oList = oWebsite.Lists["NDErrorList"];

                                               SPListItemCollection collListItems = oList.Items;

                                               SPListItem oItem = collListItems.Add();

                                               oItem["Title"] = "Attempted to add item to target list";

                                               oItem.Update();


                                           }

                                       }
                                   
                                   }
                            });

                        }
                        
                        if(properties.ListTitle == "DOT&E Oversight List")
                        {
                            /// RWEP: ensure the operation is limited by user's permissions

                            SPSecurity.RunWithElevatedPrivileges(delegate()
                            {
                           
                                var userToken = properties.OriginatingUserToken;
                                if (urlToWeb.Contains(urlDev))
                                {
                                    // This proof closely mirrors production.
                                    using (SPSite oSiteCollection = new SPSite("http://dotersrcndapp5:15429", userToken))
                                    {
                                        SPWeb oWebsite = oSiteCollection.RootWeb;

                                        SPList oList = oWebsite.Lists["DeputatePrograms"];

                                        SPListItemCollection collListItems = oList.Items;
                                        DateTime setToNow = DateTime.Now;
                                        int itemsToAdd = 0;
                                        int counter = 0;
                                        foreach (SPListItem oItem in collListItems)
                                        {
                                            // Active items cannot have a Close Date
                                            if (activeOnOversightList == "Yes")
                                            {
                                                if (oItem["Close Date"] == null)
                                                {
                                                    // do nothing
                                                }
                                                else
                                                {
                                                    oItem["Close Date"] = null;
                                                    oItem.Update();
                                                }
                                            }
                                            if (oItem["SourceID"].ToString() == properties.ListItem["ID"].ToString())
                                            {
                                                if (oItem["Close Date"] == null && activeOnOversightList == "No" || oItem["ActiveonOverSightList"] != properties.ListItem["ActiveonOverSightList"] || oItem["LongName"] != properties.ListItem["Title"])
                                                {
                                                    itemsToAdd = itemsToAdd - 1;

                                                    oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                                    oItem["LongName"] = properties.ListItem["Title"];
                                                    oItem["ShortName"] = properties.ListItem["ShortName"];
                                                    oItem["Close Date"] = setToNow;
                                                    oItem.Update();
                                                }
                                                break;
                                            }
                                            else
                                            {
                                                itemsToAdd += 1;
                                            }
                                            counter += 1;
                                        }
                                        if (itemsToAdd == counter)
                                        {
                                            SPListItem oItem = collListItems.Add();
                                            oItem["SourceID"] = properties.ListItem["ID"];
                                            oItem["Title"] = properties.ListItem["ProgramID"];
                                            oItem["ShortName"] = properties.ListItem["ShortName"];
                                            oItem["LongName"] = properties.ListItem["Title"];
                                            oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                            oItem.Update();
                                        }
                                    }
                                }
                                else if (urlToWeb.Contains(urlProd))
                                {
                                    using (SPSite oSiteCollection = new SPSite("https://doteint.osd.mil/program_files", userToken))
                                    {
                                        SPWeb oWebsite = oSiteCollection.RootWeb;

                                        SPList oList = oWebsite.Lists["DeputatePrograms"];

                                        SPListItemCollection collListItems = oList.Items;
                                        DateTime setToNow = DateTime.Now;
                                        int itemsToAdd = 0;
                                        int counter = 0;
                                        foreach (SPListItem oItem in collListItems)
                                        {
                                            // Active items cannot have a Close Date
                                            if (activeOnOversightList == "Yes")
                                            {
                                                //if (oItem["Close Date"] != null)
                                                //{
                                                //    oItem["Close Date"] = null;
                                                //    oItem.Update();
                                                //}
                                                if (oItem["Close Date"] == null)
                                                {
                                                    // do nothing
                                                }
                                                else
                                                {
                                                    oItem["Close Date"] = null;
                                                    oItem.Update();
                                                }
                                            }
                                            if (oItem["SourceID"].ToString() == properties.ListItem["ID"].ToString())
                                            {
                                                if (oItem["Close Date"] == null && activeOnOversightList == "No" || oItem["ActiveonOverSightList"] != properties.ListItem["ActiveonOverSightList"] || oItem["LongName"] != properties.ListItem["Title"])
                                                {
                                                    itemsToAdd = itemsToAdd - 1;

                                                    oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                                    oItem["LongName"] = properties.ListItem["Title"];
                                                    oItem["ShortName"] = properties.ListItem["ShortName"];
                                                    oItem["Close Date"] = setToNow;
                                                    oItem.Update();
                                                }
                                                break;
                                            }
                                            else
                                            {
                                                itemsToAdd += 1;
                                            }
                                            counter += 1;
                                        }
                                        if (itemsToAdd == counter)
                                        {
                                            SPListItem oItem = collListItems.Add();
                                            oItem["SourceID"] = properties.ListItem["ID"];
                                            oItem["Title"] = properties.ListItem["ProgramID"];
                                            oItem["ShortName"] = properties.ListItem["ShortName"];
                                            oItem["LongName"] = properties.ListItem["Title"];
                                            oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                            oItem.Update();
                                        }
                                    }
                                }
                            });
                        }                                    
                    }
                } 
            }


        }

        /// <summary>
        /// An item was deleted.
        /// </summary>
        public override void ItemDeleted(SPItemEventProperties properties)
        {
            base.ItemDeleted(properties);
        }
    }
}