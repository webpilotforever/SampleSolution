﻿using Microsoft.SharePoint;
using System;


namespace DOTEOversightProgramsListEvntRcvr.EventReceiver1
{
    /// <summary>
    /// See https://doteint.osd.mil/sites/IT/Pages/DOTEOversightProgramsListEvntRcvr.aspx for documentation. 
    /// </summary>
    /// 

    

    public class EventReceiver1 : SPItemEventReceiver
    {

        
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
        }

        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);            
        }

        /// <summary>
        /// An item is being deleted.
        /// </summary>
        /// <remarks>Cancel the deletion and present a message stating that the item will be archived when the change has been approved. The ActiveonOverSightList column will then be set to No, and the item will go into a Pending status. Once approved, the ActiveonOverSightList column will be updated in the target list, and the Close Date will be set to DateTime.Now. This method will work with a workflow that is triggered when the item changes. In this case, the workflow should be triggered when the ActiveonOverSightList column changes to No on the source list.</remarks>
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);
            string urlToWeb = properties.WebUrl;
            string urlDev = "http://dotersrcndapp5";
            string urlProd = "https://doteint.osd.mil";
            if (urlToWeb.Contains(urlDev) || urlToWeb.Contains(urlProd) ) // Ensure that this event receiver will not affect non-DOT&E sites
             {     
                if (properties.ListItem.Web.IsRootWeb)
                {
                    if (properties.ListTitle == "DOT&E Oversight List")
                    {
                        properties.Cancel = true;
                        properties.ErrorMessage = "Item will be archived when change has been approved.";
                        properties.ListItem["ActiveonOverSightList"] = "No";
                        properties.ListItem.Update();
                    }
                }
            } 
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        /// <remarks>When an item is Approved, update the target list. If the LongName has been changed in the source list, the LongName will be updated in the target list. If the Title in the target list equals the ProgramID in the source list, then do not add a similar item in the target list. Instead, check if the ActiveonOverSightList values agree, and update the item in the target list if necessary.</remarks>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);

            string activeOnOversightList = properties.ListItem["ActiveonOverSightList"].ToString();
            string aStatus = properties.ListItem["Approval Status"].ToString();
            string urlToWeb = properties.WebUrl;
            string urlDev = "http://dotersrcndapp5";
            string urlProd = "https://doteint.osd.mil";
            if (urlToWeb.Contains(urlDev) || urlToWeb.Contains(urlProd)) // Ensure that this event receiver will not affect non-DOT&E sites
            {
                // If item in DOT&E Oversight List has been updated with Approval Status set to Approved,
                // update DeputatePrograms lists.

                if (aStatus == "0")
                {                    
                    if(properties.ListItem.Web.IsRootWeb)
                    {
                        if(properties.ListTitle == "DOT&E Oversight List")
                        {

                            SPSecurity.RunWithElevatedPrivileges(delegate()
                            {
                           
                                var userToken = properties.OriginatingUserToken;
                                if (urlToWeb.Contains(urlDev))
                                {                                    
                                    // Use the following syntax when target lists are on deputate site collections like sites/AW, sites/LEW, sites/LFTE, sites/NCSMDS, sites/NW
                                    string deputate = properties.ListItem["OTDEPUTATE"].ToString();
                                    using (SPSite oSiteCollection = new SPSite("http://dotersrcndapp5/sites/" + deputate, userToken))
                                    {
                                        SPWeb oWebsite = oSiteCollection.RootWeb;

                                        SPList oList = oWebsite.Lists["DeputatePrograms"];

                                        SPListItemCollection collListItems = oList.Items;
                                        DateTime setToNow = DateTime.Now;
                                        int itemsToAdd = 0;
                                        int counter = 0;
                                        foreach (SPListItem oItem in collListItems)
                                        {
                                            // Active items cannot have a Close Date
                                            if (activeOnOversightList == "Yes")
                                            {
                                                if (oItem["Close Date"] == null)
                                                {
                                                    // do nothing
                                                }
                                                else
                                                {
                                                    oItem["Close Date"] = null;
                                                    oItem.Update();
                                                }
                                            }
                                            if (oItem["SourceID"].ToString() == properties.ListItem["ID"].ToString())
                                            {
                                                if (oItem["Close Date"] == null && activeOnOversightList == "No" || oItem["ActiveonOverSightList"] != properties.ListItem["ActiveonOverSightList"] || oItem["LongName"] != properties.ListItem["Title"])
                                                {
                                                    itemsToAdd = itemsToAdd - 1;

                                                    oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                                    oItem["LongName"] = properties.ListItem["Title"];
                                                    oItem["ShortName"] = properties.ListItem["ShortName"];
                                                    oItem["Close Date"] = setToNow;
                                                    oItem.Update();
                                                }
                                                break;
                                            }
                                            else
                                            {
                                                itemsToAdd += 1;
                                            }
                                            counter += 1;
                                        }
                                        if (itemsToAdd == counter)
                                        {
                                            SPListItem oItem = collListItems.Add();
                                            oItem["SourceID"] = properties.ListItem["ID"];
                                            oItem["Title"] = properties.ListItem["ProgramID"];
                                            oItem["ShortName"] = properties.ListItem["ShortName"];
                                            oItem["LongName"] = properties.ListItem["Title"];
                                            oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                            oItem.Update();
                                        }
                                    }
                                }
                                else if (urlToWeb.Contains(urlProd))
                                {
                                    using (SPSite oSiteCollection = new SPSite("https://doteint.osd.mil/program_files", userToken))
                                    {
                                        SPWeb oWebsite = oSiteCollection.RootWeb;

                                        SPList oList = oWebsite.Lists["DeputatePrograms"];

                                        SPListItemCollection collListItems = oList.Items;
                                        DateTime setToNow = DateTime.Now;
                                        int itemsToAdd = 0;
                                        int counter = 0;
                                        foreach (SPListItem oItem in collListItems)
                                        {
                                            // Active items cannot have a Close Date
                                            if (activeOnOversightList == "Yes")
                                            {
                                                //if (oItem["Close Date"] != null)
                                                //{
                                                //    oItem["Close Date"] = null;
                                                //    oItem.Update();
                                                //}
                                                if (oItem["Close Date"] == null)
                                                {
                                                    // do nothing
                                                }
                                                else
                                                {
                                                    oItem["Close Date"] = null;
                                                    oItem.Update();
                                                }
                                            }
                                            if (oItem["SourceID"].ToString() == properties.ListItem["ID"].ToString())
                                            {
                                                if (oItem["Close Date"] == null && activeOnOversightList == "No" || oItem["ActiveonOverSightList"] != properties.ListItem["ActiveonOverSightList"] || oItem["LongName"] != properties.ListItem["Title"])
                                                {
                                                    itemsToAdd = itemsToAdd - 1;

                                                    oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                                    oItem["LongName"] = properties.ListItem["Title"];
                                                    oItem["ShortName"] = properties.ListItem["ShortName"];
                                                    oItem["Close Date"] = setToNow;
                                                    oItem.Update();
                                                }
                                                break;
                                            }
                                            else
                                            {
                                                itemsToAdd += 1;
                                            }
                                            counter += 1;
                                        }
                                        if (itemsToAdd == counter)
                                        {
                                            SPListItem oItem = collListItems.Add();
                                            oItem["SourceID"] = properties.ListItem["ID"];
                                            oItem["Title"] = properties.ListItem["ProgramID"];
                                            oItem["ShortName"] = properties.ListItem["ShortName"];
                                            oItem["LongName"] = properties.ListItem["Title"];
                                            oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                            oItem.Update();
                                        }
                                    }
                                }
                            });
                        }                                    
                    }
                } 
            }


        }

        /// <summary>
        /// An item was deleted.
        /// </summary>
        public override void ItemDeleted(SPItemEventProperties properties)
        {
            base.ItemDeleted(properties);
        }
    }
}