﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Administration;

namespace DOTEOversightProgramsListEvntRcvr.MasterProgramListEvents
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class MasterProgramListEvents : SPItemEventReceiver
    {
        /// <summary>
        /// An item was updated. See https://doteint.osd.mil/sites/it/pages/doteoversightprogramslistevntrcvr.aspx for documentation.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            var traceInfo = "";
            
            traceInfo = "Absolute Url of Web is: " + properties.WebUrl;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
 
            traceInfo = "Approval Status: " + properties.ListItem.ModerationInformation.Status;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            
            if(properties.ListTitle == "DOT&E Oversight List")
            {
                traceInfo = "Title of list: " + properties.ListTitle;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                if(properties.ListItem.ModerationInformation.Status==SPModerationStatusType.Approved)
                {
                    traceInfo = "Will now attempt to get SPSite RootWeb program_files.";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
           
                    SPSecurity.RunWithElevatedPrivileges(delegate()
                    {
                        var userToken = properties.OriginatingUserToken;                    
                    
                        //using (SPSite oSiteCollection = new SPSite("http://dotersrcndapp5:15429", userToken)) // Dev
                        //using (SPSite oSiteCollection = new SPSite("http://dotersrcndapp2", userToken)) // Dev Test
                        // using (SPSite oSiteCollection = new SPSite("https://doteint.dev.osd.mil/program_files", userToken)) // Production Test
                        using (SPSite oSiteCollection = new SPSite("https://doteint.osd.mil/program_files", userToken)) // Production
                        {
                          
                            SPWeb oWebsite = oSiteCollection.RootWeb;
                        
                            traceInfo = "Got RootWeb: " + oWebsite.Title;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
    
                            SPList oList = oWebsite.Lists["DeputatePrograms"];
                        
                            traceInfo = "Got DeputatePrograms list: " + oList.Title;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);   
                        
                            DateTime setToNow = DateTime.Now;

                            string ActiveonOverSightList = properties.ListItem["ActiveonOverSightList"].ToString();

                       
                            // Query DeputatePrograms for active programs with a Close Date. 

                            traceInfo = "Query DeputatePrograms for active programs with a Close Date.";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsCloseDateQuery", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            SPQuery oQuery = new SPQuery();
                            oQuery.Query = "<Where><And><Eq><FieldRef Name='ActiveonOverSightList'/>" +
                                "<Value Type='Choice'>Yes</Value></Eq>" +
                                "<IsNotNull><FieldRef Name='Close_x0020_Date'/>" +
                                "</IsNotNull></And></Where>";
                            SPListItemCollection collListItems = oList.GetItems(oQuery);
                            foreach (SPListItem oListItem in collListItems)
                            {                          
                            
                                try
                                {
                                    oListItem["Close_x0020_Date"] = null;
                                    oListItem.Update();

                                    traceInfo = "Success. Set Close_x0020_Date to null using internal name.";
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsCloseDateQuery", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                               
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsCloseDateQuery", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                               
                                }
                            
                            }


                            // Query for associated item in DeputatePrograms and update it.

                            string addItem = "Yes";
                            string IDofItem = properties.ListItem["ID"].ToString();

                            traceInfo = "Query for associated item in DeputatePrograms and update it.";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsSourceIDQuery", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPQuery oQuery1 = new SPQuery();
                            oQuery1.Query = "<Where><Eq><FieldRef Name='SourceID'/>" +
                                "<Value Type='Text'>" + IDofItem + "</Value></Eq></Where>";
                            SPListItemCollection collListItems1 = oList.GetItems(oQuery1);
                            foreach (SPListItem oListItem1 in collListItems1)
                            {                           
                                oListItem1["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                oListItem1["LongName"] = properties.ListItem["Title"];
                                oListItem1["ShortName"] = properties.ListItem["ShortName"];
                                if (ActiveonOverSightList == "No")
                                {                             
                                    try
                                    {
                                        oListItem1["Close_x0020_Date"] = setToNow;
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsSourceIDQueryCloseDate", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    
                                    }
                               
                                }
                            
                                oListItem1.Update();
                                addItem = "No";
                                traceInfo = "Updated associated item in DeputatePrograms.";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsSourceIDQuery", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                        
                        
                            // If item is not registered in DeputatePrograms list, then add it.
                        
                            if (addItem == "Yes")
                            {
                                traceInfo = "An associated item does not exist in DeputatePrograms list. Will now attempt to add item to DeputatePrograms list.";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsAddItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
    
                                SPListItem oItem = collListItems.Add();
                                oItem["SourceID"] = properties.ListItem["ID"];
                                oItem["Title"] = properties.ListItem["ProgramID"];
                                oItem["ShortName"] = properties.ListItem["ShortName"];
                                oItem["LongName"] = properties.ListItem["Title"];
                                oItem["ActiveonOverSightList"] = properties.ListItem["ActiveonOverSightList"];
                                if (ActiveonOverSightList == "No")
                                {                              
                                    try
                                    {
                                        oItem["Close_x0020_Date"] = setToNow;
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsAddItemCloseDate", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    
                                    }
                                
                                }
                                oItem.Update();
                                traceInfo = "Added associated item in DeputatePrograms.";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DOTEEventsAddItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                        }

                    });
                }

            }
        }

        /// <summary>
        /// An item was added
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
        }


    }
}