﻿// IAIOPADv2 Cyber-Assessment Database
var ourLocation = window.location.href.toString(); var locationUpToHost = window.location.protocol + "//" + window.location.host; var atLocation = ourLocation.substr(0, ourLocation.indexOf(".aspx") + 5); var siteRelURLtopage = window.location.pathname; var atPage = atLocation.substr(atLocation.lastIndexOf("/") + 1); var wsList = siteRelURLtopage.substr(siteRelURLtopage.lastIndexOf("/") + 1); var OTA = ""; var OTAtitle = ""; wsList = wsList.substr(0, wsList.indexOf(".aspx")); var docRef = window.document.referrer.toString(); docRef = docRef.replace(locationUpToHost, ""); var CurrentFYforAcceptingCONOPS; var ws1; var ws2; var ws3; var ws4; var wsReviewSubmit; var ws1t; var ws2t; var ws3t; var ws4t; if (!window.console) console = { log: function () { } };
$(document).ready(function () {
    var OTAindex = $("table[summary='Program Contacts ']").find("th:contains(OperationalTestAgency)").index();
    if (OTAindex > -1) { OTA += $("table[summary='Program Contacts ']").find("td:eq(" + OTAindex + ")").text();}
    if (OTA == "AFOTEC") { OTAtitle = "Air Force Operational Test and Evaluation Center"; } if (OTA == "ATEC") { OTAtitle = "Army Test and Evaluation Command"; } if (OTA == "COTF") { OTAtitle = "Command Operational Test and Evaluation Force"; } if (OTA == "JITC") { OTAtitle = "Joint Interoperability Test Command"; } if (OTA == "JITC") { OTAtitle = "Marine Corps Operational Test and Evaluation Activity"; } if (getParameterByName("otaTitle") !== "" && OTA == "") { OTAtitle = getParameterByName("otaTitle"); OTA = getParameterByName("ota"); } $("#RibbonContainer").on('click', 'a[title="Edit"]', function () { return false; }); var inDesignMode = $("#MSOSPWebPartManager_DisplayModeName").val();
    if (inDesignMode == "Design") {return false;} else {Home(); MasterCalendar(); CONOPSDevAODashboard(); CONOPSDevelopmentModule(); QuickLaunchMenu(); CONOPSDevWorksheets(); ReviewSubmitWorksheets();} $("#ctl00_onetidHeadbnnr2").attr("src", "/SiteAssets/SitePages/Home/doteseal.gif").css("display", "inline"); $("img[style*='-585px']").css("top", "-607px").css("filter", "alpha(opacity=60)").css("opacity", "0.6"); if (getParameterByName("IsDlg") == "1") { $(".ms-cui-tt-a").css("display", "none"); }
    function QuickLaunchMenu() {if (getParameterByName("IsDlg") == "") {$.getScript('/SiteAssets/IAIOPADv2_QuickLaunchMenu.js', function () { });}}
    function Home() {if (siteRelURLtopage == "/SitePages/Home.aspx") {$.getScript('/SiteAssets/IAIOPADv2_Home.js', function () { });}}
    function CONOPSDevAODashboard() {$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevAODashboard.js', function () { });}
    function CONOPSDevelopmentModule() {if (siteRelURLtopage == "/SitePages/CONOPS%20Development%20Module.aspx") {$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevelopmentModule.js', function () { });}}
    function CONOPSDevWorksheets() {if (getParameterByName("IsDlg") == "1") {if (siteRelURLtopage == "/SitePages/WS1.aspx" || siteRelURLtopage == "/SitePages/WS2.aspx" || siteRelURLtopage == "/SitePages/WS3.aspx" || siteRelURLtopage == "/SitePages/WS4.aspx") {$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevWorksheets.js', function () { });}}}
    function ReviewSubmitWorksheets() {if (getParameterByName("IsDlg") == "1"){if (siteRelURLtopage == "/SitePages/Review%20Submit%20Worksheets.aspx") {$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevReviewSubmit.js', function () { });}}}
});

$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevPositionTable.js', function () { });
$.getScript('/SiteAssets/IAIOPADv2_GetCONOPSDevStatus.js', function () { });
$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevGetItemsGroups.js', function () { });
$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevWSListsUpdate.js', function () { });
$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevDialogs.js', function () { });
$.getScript('/SiteAssets/IAIOPADv2_CalendarDashboard.js', function () { });



function MasterCalendar() {if (siteRelURLtopage == "/Lists/Calendar/calendar.aspx") {$(".IAIOPADPOCs").hide();}}
function AddFeedbackAndComments() { var options = { url: "/Lists/Feedback%20and%20Comments/NewForm.aspx", dialogReturnValueCallback: AddFeedbackAndCommentsThanks }; SP.UI.ModalDialog.showModalDialog(options); }
function AddFeedbackAndCommentsThanks(dialogResult, returnValue) { if (dialogResult == '1') { alert("Thank you. Your feedback and comments will help us improve this site."); } }
function showProgramPOC(id) { var options = { url: "/Lists/Program%20POCs/DispForm.aspx?ID=" + id }; SP.UI.ModalDialog.showModalDialog(options); }

// ----- UTILITIES -----
function numberAsTwoDigits(num) { var Num = num; return (Num < 10 ? '0' : '') + Num; }
function getParameterByName(name) { name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"); var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search); return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
function onQueryFailed(sender, args) { alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }