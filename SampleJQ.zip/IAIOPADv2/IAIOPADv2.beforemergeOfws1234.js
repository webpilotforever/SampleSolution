﻿// IAIOPADv2 Cyber Assessment Database
var ourLocation = window.location.href.toString(); var locationUpToHost = window.location.protocol + "//" + window.location.host; var atLocation = ourLocation.substr(0,ourLocation.indexOf(".aspx")+5); var siteRelURLtopage = window.location.pathname; var atPage = atLocation.substr(atLocation.lastIndexOf("/")+1); var wsList = siteRelURLtopage.substr(siteRelURLtopage.lastIndexOf("/")+1); wsList = wsList.substr(0, wsList.indexOf(".aspx")); var docRef = window.document.referrer.toString(); docRef = docRef.replace(locationUpToHost,""); var ws1; var ws2; var ws3; var ws4; var ps; var ws1t; var ws2t; var ws3t; var ws4t; var pst; if( ! window.console ) console = { log: function(){} }; 
$(document).ready(function()
{
	var OTA = "";  	 	OTA += $("table[summary='Program Contacts ']").find(".ms-vb2").text(); 	var OTAtitle = ""; 	if(OTA == "AFOTEC") 	{ 		OTAtitle = "Air Force Operational Test and Evaluation Center"; 	} 	if(OTA == "ATEC") 	{ 		OTAtitle = "Army Test and Evaluation Command"; 	} 	if(OTA == "COTF") 	{ 		OTAtitle = "Command Operational Test and Evaluation Force"; 	} 	if(OTA == "JITC") 	{ 		OTAtitle = "Joint Interoperability Test Command"; 	} 	if(OTA == "JITC") 	{ 		OTAtitle = "Marine Corps Operational Test and Evaluation Activity"; 	} 	if(getParameterByName("otaTitle") !== "" && OTA =="") 	{ 		OTAtitle = getParameterByName("otaTitle"); 		OTA = getParameterByName("ota"); 	} 	$("#RibbonContainer").on('click', 'a[title="Edit"]', function(){ 		return false; 	}); 	var inDesignMode = $("#MSOSPWebPartManager_DisplayModeName").val(); 	
	if(inDesignMode == "Design") 	
	{ 		
		return false; 	
	} 	
	else 	
	{		 		
		Home(); ProgramContacts(); MasterCalendar(); CONOPSDevelopment(); Configuration(); QuickLaunchMenu(); WS1(); WS2orWS3orWS4();
		
	} 	
	$("#ctl00_onetidHeadbnnr2").attr("src", "/SiteAssets/SitePages/Home/doteseal.gif").css("display","inline"); 	$("img[style*='-585px']").css("top","-607px").css("filter","alpha(opacity=60)").css("opacity","0.6");
	function QuickLaunchMenu() 	{ 		if(getParameterByName("IsDlg") == "")	 		{		 			if($(".IAIOPADv2OwnersAudienceTargeting").text() == "IAIOPADv2OwnersAudienceTargeting") 			{ 				var conopsapprovallink = '<LI class="static"><A class="static menu-item" href="/SitePages/CONOPS%20Approval.aspx"><SPAN class="additional-background"><SPAN class="menu-item-text">CONOPS Approval</SPAN></SPAN></A></LI>'; 				$(".s4-ql UL.root").prepend(conopsapprovallink); 			} 			var WindowHeight; 			WindowHeight = $("#MSO_ContentTable").css("height");	 			WindowHeight = parseInt(WindowHeight.replace("px","")); 			var QuickLaunchHeight = $("#s4-leftpanel-content").css("height"); 			QuickLaunchHeight = parseInt(QuickLaunchHeight.replace("px","")); 			QuickLaunchHeight = QuickLaunchHeight+4; 			var belowQuickLaunchHeight = WindowHeight-QuickLaunchHeight + "px"; 			$(".belowQuickLaunch").css("height",belowQuickLaunchHeight); 			var IAIOPADPOCsTop = (WindowHeight-QuickLaunchHeight)*.69 + "px"; 			if(WindowHeight-QuickLaunchHeight > 250) 				$(".IAIOPADPOCs").css("top",IAIOPADPOCsTop); 		} 	}
	function Home()
	{
		if(siteRelURLtopage == "/SitePages/Home.aspx")
		{
			// Background color for right col
			var firstRowLayoutsTable = $("#layoutsTable").find("tr:first");
			firstRowLayoutsTable.children("td:last").addClass("IAIOPADv2HomeRightCol");
			// Assessment Dashboard ----------------------------------
			// Home.aspx Assessment Dashboard links will open in dialog to the assessment. 
			// A web part that is targeted at the audience IAIOPAD Owners will offer a dropdown menu for admins to pick an OTA. 
			// A hidden web part text field acts as a filter on items shown to ensure that OTAs view their own assessments and cannot enter a query string with another OTA to see others' data.
			// Selecting from the dropdown shows links to admins. 
			// A hidden web part with the Program Contacts list acts as an access control list for the current user. Their OTA must match the value in the Assessment item to be seen. 
			$(".IAIOPADv2AssessmentDashboardAssessment").each(function(){
				$(this).attr("href", "javascript:OpenPopUpPage('/Lists/Assessments/DispForm.aspx?ID="+ $(this).attr("iid") +"');");
			});
			// Legend
			var toggleState = false;
			$(".IAIOPADv2AssessmentDashboardLegend").click(function(){
				if (toggleState==false) 
				{
					// $(this).find("SPAN").text("[-]");
					$(this).find("SPAN").html("<img alt='Collapse Legend' src='/_layouts/images/TPMin2.gif' border='0' class='IAIOPADv2AssessmentDashboardLegendToggleImg'/>");
					$(".IAIOPADv2AssessmentDashboardLegendTable").show("slow", function(){
						toggleState = true;
					});
				}
				else
				{
					// $(this).find("SPAN").text("[+]");
					$(this).find("SPAN").html("<img alt='Expand Legend' src='/_layouts/images/TPMax2.gif' border='0' class='IAIOPADv2AssessmentDashboardLegendToggleImg'/>");
					$(".IAIOPADv2AssessmentDashboardLegendTable").hide("slow", function(){
						toggleState = false;
					});
				}
			});
			// Program POCs -------------------------------------------
			// $("TD[title='IAIOPAD POCs']").parentsUntil("div").hide();
			// Calendar Dashboard -------------------------------------
			// Remove js onclick from a tags in Calendar Dashboard (duplicated in td where it is needed when day is single digit and hard to click on.) 
			$(".ms-datepickerouter").find("A").attr("href","javascript:void(0);");
			// Highlight days on Calendar Dashboard with events.
			highlightDaysWithEvents();
		}
	}
	function ProgramContacts()
	{
		if(siteRelURLtopage == "/Lists/Program%20Contacts/Admin.aspx")
		{	
			//ExecuteOrDelayUntilScriptLoaded(retrieveAllUsersAllGroupsSpecificProperties, "sp.js");
			//ExecuteOrDelayUntilScriptLoaded(retrieveAllUsersInGroup, "sp.js");
			var OTAIndex = $("div[name='OTA']").parent().index();
			var LimitedReadIndex = $("div[name='LimitedRead']").parent().index();
			var LimitedContributeIndex = $("div[name='LimitedContribute']").parent().index();
			//alert(LimitedContributeIndex);
			$("tr[iid]").each(function(){
				var LimitedRead = $(this).children("td:eq(" + LimitedReadIndex + ")").text();
				var LimitedContribute = $(this).children("td:eq(" + LimitedContributeIndex+ ")").text();
				var iid = $(this).attr("iid"); var iidArray = iid.split(",");
				var itemId = iidArray[1];
				// create string for spgroup name
				var OTA = $(this).children("td:eq(" + OTAIndex + ")").text();
				//alert(OTA);
				//addUserToSPGroups(itemId, OTAgroup);
				//var LimitedReadChecked = "";
				//var LimtedContributeChecked = "";
				//if(LimitedRead == "Yes")
				//{
				//	LimitedReadChecked = "checked='checked'";
				//}
				//if(LimitedContribute == "Yes")
				//{
				//	LimtedContributeChecked = "checked='checked'";
				//}
				// -------------------------
				//$(this).children("td:eq(" + LimitedReadIndex + ")").html("<input class='IAIOPADv2Checkbox' type='checkbox' "+ LimitedReadChecked +"/>");
				//$(this).children("td:eq(" + LimitedContributeIndex + ")").html("<input class='IAIOPADv2Checkbox' type='checkbox' "+ LimtedContributeChecked +"/>");
			});
			//$("tr[iid]").on('click', '.IAIOPADv2Checkbox', function(){ // using event delegation for this dynamic content
			//	alert('hello');
			//});
			//$(".IAIOPADv2Checkbox").click(function(){
				//if( $(this).prop("checked"))
				//{
					//alert('checked');
					//$(this).attr("checked","checked");
					//return false;
					//$(this).prop("checked", true);
				//}
				//else
				//{
					//alert('not checked');
					//$(this).removeAttr("checked");
					//return false;
					//$(this).prop("checked", false);
				//}
			//});
		}
	}
	function CONOPSDevelopment()
	{
		if(siteRelURLtopage == "/SitePages/CONOPS%20Development.aspx")
		{						
			var currentFYConfig = "14"; // default is fy 14	
			currentFYConfig = $("table[summary='Configuration ']").find(".ms-vb2").text(); // hidden Configuration web part	
			$(".IAIOPADv2CONOPSDevelopmentChangeFY").text(currentFYConfig);
			var nextFY = parseInt(currentFYConfig)+1;	// alert(nextFY + "|" + currentFYConfig +"|"); return false;
			var previewSubmitLink = $(".ms-rteElement-Callout2").find("a").attr("href");
			$(".ms-rteElement-Callout2").find("a").addClass("IAIOPADv2CONOPSDevPreviewSubmitLink").removeAttr("target").end().prepend("<a class='IAIOPADv2CONOPSDevPreviewSubmitImg' href='" + previewSubmitLink + "'><img src='/SiteAssets/graphics/conopsclipboard.png' style='float:left;clear:right;margin:5px 15px 5px 10px;cursor:pointer;border:none'/></a>");
			$(".ms-asset-icon").closest("a").addClass("IAIOPADv2CONOPSDevWorksheetLink").removeAttr("target");
			var firstWorksheetUrl;
			var firstWorksheetTitle;
			var previewPageLinkTitle = $(".IAIOPADv2CONOPSDevPreviewSubmitLink").text();
			$("#s4-workspace").find("a").each(function(){
				var linkClass = $(this).attr("class");
				var linkTxt = $(this).text();
				var url = "";
				var title = linkTxt;
				if(linkClass == "IAIOPADv2CONOPSDevWorksheetLink" || linkClass == "IAIOPADv2CONOPSDevPreviewSubmitLink" || linkClass == "IAIOPADv2CONOPSDevPreviewSubmitImg")
				{
					// $(this).css("background-color","red");
					if(linkClass == "IAIOPADv2CONOPSDevWorksheetLink")
					{
						title = "FY " + currentFYConfig + " " + linkTxt;
						$(this).text("FY " + currentFYConfig + " " + linkTxt);
						url = $(this).attr("href")+"?currentFY="+currentFYConfig+"&nextFY="+nextFY+"&fy="+currentFYConfig+"&ota="+OTA+"&otaTitle="+OTAtitle;
						if(title.indexOf("Worksheet #1") > -1)
						{
							firstWorksheetUrl = "/SitePages/WS1.aspx" +"?currentFY="+currentFYConfig+"&nextFY="+nextFY+"&fy="+currentFYConfig+"&ota="+OTA+"&otaTitle="+OTAtitle;
							firstWorksheetTitle = title;
							url = firstWorksheetUrl;
							ws1=url; 
							ws1t=title;
						}					
						if(title.indexOf("Worksheet #2") > -1)
						{
							ws2=url; 
							ws2t=title;
						}
						if(title.indexOf("Worksheet #3") > -1)
						{
							ws3=url; 
							ws3t=title;
						}
						if(title.indexOf("Worksheet #4") > -1)
						{
							ws4=url; 
							ws4t=title;
						}
					}
					else if(linkClass == "IAIOPADv2CONOPSDevPreviewSubmitLink" || linkClass == "IAIOPADv2CONOPSDevPreviewSubmitImg")
					{
						url = $(this).attr("href")+"?currentFY="+currentFYConfig+"&nextFY="+nextFY+"&fy="+(nextFY+1)+"&ota="+OTA+"&otaTitle="+OTAtitle;
						if(linkClass == "IAIOPADv2CONOPSDevPreviewSubmitImg")
						{
							title = previewPageLinkTitle;
						}
					}
					$(this).attr("href", "javascript:void(0);");
					$(this).attr("onclick", "openPopUpCONOPSDevPage('" + title + "','" + url + "');");
				}
			});
			ExecuteOrDelayUntilScriptLoaded(openFirstWorksheetOnLoad,"sp.ui.dialog.js");
			function openFirstWorksheetOnLoad()
			{		
					openPopUpCONOPSDevPage(firstWorksheetTitle, firstWorksheetUrl);	
			}
		}
	}
	function Configuration() { if(siteRelURLtopage == "/Lists/Configuration/EditForm.aspx") { if(docRef == "/SitePages/CONOPS%20Development.aspx") { $(window).unload(function(){ 	parent.location.reload(true); }); 	} } }
	function WS1()
	{	
		if(getParameterByName("IsDlg") == "1") // run jquery on page when it is in a dialog. this minimizes chance of html being corrupted with jquery and sizzle junk ids after using html source editor.
		{
			if(siteRelURLtopage == "/SitePages/WS1.aspx")
			{					
				// ----- DEVELOPER NOTES -----
				// Title column of WS1 list may be one of the following: Name [John Smith], AdditionalLineItem: [Title of item], HoursPerYear, HoursPerYearAmount, ContractFeePercentage, ContractFee, ContractTotal, ContractsSubTotal, MilitarySubTotal, Total, GovLaborMonth, GovLaborYear.
				// Each item has the following in common: FY, OTA, Submitted.
				// For WS1, contract items have Contract in common. 
				// For WS2, venue items have Venue in common.			
				// ----- HIDE DIALOG PAGE TAB IN RIBBON -----
				//$(".ms-cui-tt-a").css("display","none");
				// ----- TAG TABLE AND GROUPS WITH CLASSES ----------
				$("#Contract").addClass("IAIOPADv2WSGroupTitle");
				$(".IAIOPADv2WSGroupTitle").closest('tr').addClass("IAIOPADv2WSGroupStartRow").end().closest('table').addClass("IAIOPADv2WSTable");
				// WS1
				$(".IAIOPADv2WSBtnAddGroup").closest('tr').addClass("IAIOPADv2WSGroupEndRow");
				// ----- GET COMMON ROW DATA -----
				var FY = getParameterByName("currentFY"); // get from query string
				var Submitted = "No"; 
				// ----- SET FY AND OTA IN FORM TEXT ELEMENTS -----
				$(".IAIOPADv2WSFY").text(FY);
				$(".IAIOPADv2WSOTA").text(OTAtitle.toUpperCase()); 
				// ----- GROUP TEMPLATE -----
				// snapshot of first Contract when it is initially rendered without data
				//var tbody = $("#Contract").closest('tr').parent(); // this used as reference point, so assumption is there will always be a contract field
				var tbody = $(".IAIOPADv2WSGroupTitle").closest('tr').parent(); // this used as reference point, so assumption is there will always be a contract field
				//var sliceStart = $("#Contract").closest('tr').index();
				var sliceStart = $(".IAIOPADv2WSGroupTitle").closest('tr').index();
				var sliceEnd = $(".IAIOPADv2WSBtnAddGroup").closest('tr').index() + 1;
				var groupTemplate = tbody.children().slice(sliceStart, sliceEnd);
				// ----- REQUIRE CONTRACT FIELD DATA -----
				$("#s4-workspace").on('focusin', 'input:text', function(){ // using event delegation for this dynamic content
					var inxForThisFieldRow = $(this).closest('tr').index();
					var inxForTheClosestContractFieldRow = 0;
					tbody.find("input[title='Contract']").each(function(){
						if($(this).closest('tr').index() < inxForThisFieldRow)
						{
							//$(this).css("background-color","red");
							inxForTheClosestContractFieldRow = $(this).closest('tr').index();
						}
					});
					var inxForNextAddGroupBtn = 0;
					tbody.find(".IAIOPADv2WSBtnAddGroup").each(function(){
						if($(this).closest('tr').index() > inxForThisFieldRow)
						{
							//$(this).css("background-color","red");
							inxForNextAddGroupBtn = $(this).closest('tr').index()+1;
							return false;
						}
					});
					if($(this).attr("id") !== "Contract" && inxForTheClosestContractFieldRow > 0)
					{					
						var thisContract = tbody.children().slice(inxForTheClosestContractFieldRow, inxForNextAddGroupBtn );
						if(thisContract.find("input:text[id='Contract']").val() == "")
						{
							alert("Please enter information for [Contract]");
						}
					}
				});
				// ----- APPEND GROUP ROWS WITH HIDDEN GROUP TITLE FIELD -----
				$("#s4-workspace").on('focusout', '.IAIOPADv2WSGroupTitle', function(){ // using event delegation for this dynamic content
					var groupTitleFieldVal = $(this).val();
					var sliceStartGroup = $(this).closest('tr').index();
					if($(this).attr("id") == "Contract")
					{						
						sliceStartGroup = sliceStartGroup +1;
					}
					var sliceEndGroup = tbody.children().slice(sliceStartGroup).find(".IAIOPADv2WSBtnDeleteGroup").first().closest('tr').index()+1;
					var thisGroupTitleRowSett = tbody.children().slice(sliceStartGroup, sliceEndGroup);
					thisGroupTitleRowSett.each(function(){ // iterate through rows
						//alert(groupTitleFieldVal ); 
						if($(this).find(".IAIOPADv2WSGroupTitle").index() > -1)
						{
							$(this).find(".IAIOPADv2WSGroupTitle").val(groupTitleFieldVal);
						}
						else
						{
							if($(this).find("input:hidden[id='Contract']").length)
							{
								// update hidden Contract fields
								$(this).find("input:hidden[id='Contract']").val(groupTitleFieldVal);
							}
							else
							{
								$(this).find("input:not(#Contract)").last().parent().append("<input type='hidden' value='" + groupTitleFieldVal + "' id='Contract' />");
							}
						}
					});
				});
				// ----- REMARKS FIELD -----
				var remarksWidth = $("#Remarks").css("width");
				$("#s4-workspace").on('focusin', '#Remarks', function(){			
					$(this).css("width","300px");
				});
				$("#s4-workspace").on('focusout', '#Remarks', function(){				
					$(this).css("width",remarksWidth);
				});
				// ----- COLUMN DESCRIPTIONS -----
				$(".IAIOPADv2WSColHeaders").hover(function(){
					$(".IAIOPADv2WSColDesc").slideToggle("fast");
				});
				// ----- HIDDEN FIELDS -----		
				tbody.children().each(function(){ // Append rows with no Title field with a hidden Title field with the value of the last field's id attribute in the last cell
					var foundInput = "No";
					var foundTitle = "No";
					$(this).find("input:text").each(function(){
						//alert( $(this).attr("id") ); 
						foundInput = "Yes";
						if($(this).attr("id") == "Title")
						{
							foundTitle = "Yes";
						}
					});
					if(foundInput == "Yes" && foundTitle == "No")
					{
						var inputId = $(this).find("input:text").last().attr("id");
						$(this).find("input:text").last().parent().append("<input type='hidden' value='" + inputId + "' id='Title' />");
					}
				});
				tbody.find("input:text").each(function(){ // GSLevel and ContractorRate field cells should be appended with a hidden field for Employer
					if($(this).attr("id") == "GSLevel")
					{
						$(this).parent().append("<input type='hidden' value='MilitaryOrGovernmentCivilian' id='Employer' />");
					}
					if($(this).attr("id") == "ContractorRate")
					{
						$(this).parent().append("<input type='hidden' value='Contractor' id='Employer' />");
					}
				});			
				// ----- DELETE ROW BUTTON -----
				$(".IAIOPADv2WSBtnDeleteRow").attr("title","Delete row: disabled for first item").css("background-color","#b0b0b0").css("cursor","arrow"); // mark initial set of delete row buttons as disabled			
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnDeleteRow', function(){ // using event delegation for this dynamic content
					if($(this).attr("title") !== "Delete row: disabled for first item")
					{	
						$(this).closest('tr').remove();				
					}	
				});
				// ----- ADD ROW BUTTON -----
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnAddRow', function(){ // using event delegation for this dynamic content
					var readyToClone = "Yes";
					var invalidFields = "Please enter information for ";
					var thisRow = $(this).closest('tr')[0];
					if($("#Contract").length)
					{
						$("input", thisRow).each(function(){					
							var inputTitle = $(this).attr("title");
							var inputId = $(this).attr("id");	
							var inputVal = $(this).val();	
							if(inputVal.length)
							{
								// do nothing
							}	
							else
							{
								if(inputTitle == "Remarks")
								{
									// do nothing
								}
								else
								{
									invalidFields += "[" + inputTitle + "], ";
									readyToClone = "No";
								}
							}	
						});	
						if(readyToClone == "No")
						{
							var lastComma = invalidFields.lastIndexOf(",");
							if(lastComma > -1)
							{
								invalidFields = invalidFields.substr(0,lastComma);
								lastComma = invalidFields.lastIndexOf(",");
									if(lastComma > -1)
									{
										invalidFields = invalidFields.substring(0,lastComma) + " and" + invalidFields.substring(lastComma + 1);
									}			
								alert(invalidFields); 
							}
						}
						else
						{				
							$(thisRow).clone().insertAfter(thisRow).find('input:text').val('').end().find('.IAIOPADv2WSBtnDeleteRow').attr('title','Delete row').end().find('.IAIOPADv2WSBtnDeleteRow').removeAttr('style'); // clone row and clear inputs
						}
					}
				});				
				// ----- DELETE CONTRACT BUTTON -----
				$(".IAIOPADv2WSBtnDeleteGroup").attr("title","Delete group: disabled for first group").css("background-color","#b0b0b0").css("cursor","arrow"); // mark initial set of delete row buttons as disabled			
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnDeleteGroup', function(){ // using event delegation for this dynamic content
					if($(this).attr("title") !== "Delete group: disabled for first group")
					{	
						var ix = $(this).closest('tr').index();	
						var ii = -1;
						var sliceEndGroupelete = ix+1;
						$(".IAIOPADv2WSGroupStartRow").each(function(){
							if( $(this).index() < ix )
							{
								ii = $(this).index();
							}
						});
						var sliceStartDelete = ii;
						var thisGroupTitleRowSet = tbody.children().slice(sliceStartDelete, sliceEndGroupelete);
						thisGroupTitleRowSet.remove();
					}	
				});
				// ----- ADD CONTRACT BUTTON -----
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnAddGroup', function(){ // using event delegation for this dynamic content
					var thisRow = $(this).closest('tr')[0];
					$(groupTemplate).clone().insertAfter(thisRow).find('#Contract').val('').end().find('input:text').val('').end().find('.IAIOPADv2WSBtnDeleteGroup').attr('title','Delete group').end().find('.IAIOPADv2WSBtnDeleteGroup').removeAttr('style'); // clone row and clear inputs
				});
				// ----- SAVE NEXT BUTTON -----
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnSaveAndNext', function(){ // using event delegation for this dynamic content
					var pleaseWait = SP.UI.ModalDialog.showWaitScreenSize("Saving Worksheet", "Please wait...", pleaseWaitClosed);
					var inputVals = "";
					$(".IAIOPADv2WSTable > tbody > tr:has('input')").each(function(){				
						var row = this;
						var values = "";
						var hasValue = 0;
						$("input", row).each(function(){					
							var inputId = $(this).attr("id");	
							var inputVal = $(this).val();
							if(inputVal.length)
							{							
								hasValue = hasValue + 1;
								values = values + inputId + "," + inputVal + ",";						
							}										
						});	
						if(hasValue > 0)
						{
							inputVals += values + "OTA," + OTA + "," + "FY," + FY + "," + "Submitted," + Submitted + "|||";	
							//alert(inputVals); 
						}											
					});								
					var worksheetRows = inputVals.split("|||");
					wsList = wsList + "CurrentFY" + OTA; // WS1CurrentFYAFOTEC
					saveWorksheet(wsList, worksheetRows);
				});
			}												
		}	
	}
	function WS2orWS3orWS4()
	{	
		if(getParameterByName("IsDlg") == "1") // run jquery on page when it is in a dialog. this minimizes chance of html being corrupted with jquery and sizzle junk ids after using html source editor.
		{
		    if (siteRelURLtopage == "/SitePages/WS2.aspx" || siteRelURLtopage == "/SitePages/WS3.aspx" || siteRelURLtopage == "/SitePages/WS4.aspx")
			{							
				$("#Total").parent().append("<input type='hidden' value='Total' id='Title' />");
		        // Clone Venue row when ready ------------------
				$("#Venue").closest("tr").addClass("IAIOPADv2VenueRow");
				var VenueRow = $(".IAIOPADv2VenueRow")[0];
				var venueRow = $(".IAIOPADv2VenueRow");
		        // ----- HIDE DIALOG PAGE TAB IN RIBBON -----
				//$(".ms-cui-tt-a").css("display","none");
				
				// ----- TAG TABLE WITH CLASS ----------
				$(".IAIOPADv2WSBtnDeleteRow").closest('table').addClass("IAIOPADv2WSTable");
				$("#Venue").addClass("IAIOPADv2WSGroupTitle");
				$(".IAIOPADv2WSGroupTitle").closest('tr').addClass("IAIOPADv2WSGroupStartRow");
				$(".IAIOPADv2WSBtnAddGroup").closest('tr').addClass("IAIOPADv2WSGroupEndRow");
				// ----- GET COMMON ROW DATA -----
				var FY = getParameterByName("currentFY"); // get from query string
				var Submitted = "No"; 
				// ----- SET FY AND OTA IN FORM TEXT ELEMENTS -----
				$(".IAIOPADv2WSFY").text(FY);
				$(".IAIOPADv2WSOTA").text(OTAtitle.toUpperCase()); 
				// ----- TBODY -----
				var tbody = $(".IAIOPADv2WSBtnDeleteRow").closest('tr').parent();
				var sliceStartTemplate = $(".IAIOPADv2WSGroupTitle").closest('tr').index(); // alert(sliceStartTemplate);
				var sliceEndTemplate = $(".IAIOPADv2WSBtnAddGroup").closest('tr').index() + 1; //alert(sliceEndTemplate );
				var groupTemplate = tbody.children().slice(sliceStartTemplate, sliceEndTemplate); // set of row elements
				if (siteRelURLtopage == "/SitePages/WS2.aspx")
				{
				    $("#s4-workspace").on('focusin', 'input:text', function(){ // using event delegation for this dynamic content
					    var sliceStartVenue;
					    var sliceEndVenue;
					    var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
					    $(".IAIOPADv2VenueRow").each(function(){
						    if($(this).index() > thisRowIndex )
				    {
							    return false;
				    }
				    else
				    {				
							    sliceStartVenue = $(this).index();
				    }
				    });	
				        // alert(sliceStartVenue );
					    tbody.children(".IAIOPADv2WSGroupEndRow").each(function(){
						    if($(this).index() > sliceStartVenue )
				    {
							    sliceEndVenue = $(this).index();
							    return false;
				    }
				    });
				        // alert(sliceEndVenue );
					    var thisVenue = tbody.children().slice(sliceStartVenue , sliceEndVenue );
					    if($(this).attr("id") !== "Venue")
				    {
						    if(thisVenue.find("input:text[id='Venue']").val() == "")
				    {						
							    alert("Please enter information for [Venue]");
				    }
				    }					
				    });
		            // ----- APPEND GROUP ROWS WITH HIDDEN GROUP TITLE FIELD -----
                    $("#s4-workspace").on('focusout', '.IAIOPADv2WSGroupTitle', function(){ // using event delegation for this dynamic content
                        // return false;
                        var groupTitleFieldVal = $(this).val();
                        var sliceStartGroup = $(this).closest('tr').index();
                        if($(this).attr("id") == "Venue")
                        {						
                            sliceStartGroup = sliceStartGroup +1;
                        }
                        var sliceEndGroup = tbody.children().slice(sliceStartGroup).find(".IAIOPADv2WSBtnDeleteGroup").first().closest('tr').index()+1;
                        //alert(sliceEndGroup);
                        var thisGroupTitleRowSett = tbody.children().slice(sliceStartGroup, sliceEndGroup);
                        thisGroupTitleRowSett.each(function(){ // iterate through rows
                            //alert(groupTitleFieldVal ); 
                            var lastFieldVal = $(this).find("input:text").last().attr("id");
                            $(this).find("input:hidden[id='Title']").val(lastFieldVal);
												
                            if($(this).find("input:hidden[id='Venue']").length)
                            {
                                // update hidden Venue fields
                                $(this).find("input:hidden[id='Venue']").val(groupTitleFieldVal);
                            }
                            else
                            {
                                $(this).find("input:not(#Venue)").last().parent().append("<input type='hidden' value='" + groupTitleFieldVal + "' id='Venue' />");
                            }
						
                        });
                    });
				    // ----- HIDDEN FIELDS -----		
                    tbody.children().each(function () { // Append rows with no Title field with a hidden Title field with the value of the last field's id attribute in the last cell
                        var foundInput = "No";
                        var foundTitle = "No";
                        $(this).find("input:text").each(function () {
                            //alert( $(this).attr("id") ); 
                            foundInput = "Yes";
                            if ($(this).attr("id") == "Title") {
                                foundTitle = "Yes";
                            }
                        });
                        if (foundInput == "Yes" && foundTitle == "No") {
                            // $(this).css("display","none");
                            var inputId = $(this).find("input:text").last().attr("id");
                            $(this).find("input:text").last().parent().append("<input type='hidden' value='" + inputId + "' id='Title' />");
                        }
                    });
				}
				// ----- REMARKS FIELD -----
				var remarksWidth = $("#Remarks").css("width");
				$("#s4-workspace").on('focusin', '#Remarks', function(){			
					$(this).css("width","300px");
				});
				$("#s4-workspace").on('focusout', '#Remarks', function(){				
					$(this).css("width",remarksWidth);
				});
				// ----- COLUMN DESCRIPTIONS -----
				$(".IAIOPADv2WSColHeaders").hover(function(){
					$(".IAIOPADv2WSColDesc").slideToggle("fast");
				});
		
				// ----- DELETE ROW BUTTON -----
				$(".IAIOPADv2WSBtnDeleteRow").attr("title","Delete row: disabled for first item").css("background-color","#b0b0b0").css("cursor","arrow"); // mark initial set of delete row buttons as disabled			
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnDeleteRow', function(){ // using event delegation for this dynamic content
					if($(this).attr("title") !== "Delete row: disabled for first item")
					{
					    // Get local Venue cell ------------
					    var VenueCell;
					    var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
					    $(".IAIOPADv2VenueRow").each(function () {
					        if ($(this).index() > thisRowIndex) {
					            return false;
					        }
					        else {
					            VenueCell = $(this).children().first();
					        }
					    });
					    // Remove this row ---------------
					    $(this).closest('tr').remove();
					    if (siteRelURLtopage == "/SitePages/WS2.aspx")
					    {
					    // Decrement rowSpan of Venue cell -----------
						var rowSpanDecrement = parseInt(VenueCell.attr("rowSpan"))-1; //alert(rowSpanDecrement );
                        VenueCell.attr("rowSpan", rowSpanDecrement );
					    }
					}	
				});
				// ----- ADD ROW BUTTON -----
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnAddRow', function(){ // using event delegation for this dynamic content
				    var readyToClone = "Yes";
				    var invalidFields = "Please enter information for ";
				    var thisRow = $(this).closest('tr')[0];
				    $("input", thisRow).each(function(){					
				        var inputTitle = $(this).attr("title");
				        var inputId = $(this).attr("id");	
				        var inputVal = $(this).val();	
				        if(inputVal.length)
				        {
				            // do nothing
				        }	
				        else
				        {
				            if(inputTitle == "Remarks")
				            {
				                // do nothing
				            }
				            else
				            {
				                invalidFields += "[" + inputTitle + "], ";
				                readyToClone = "No";
				            }
				        }	
				    });	
				    if(readyToClone == "No")
				    {
				        var lastComma = invalidFields.lastIndexOf(",");
				        if(lastComma > -1)
				        {
				            invalidFields = invalidFields.substr(0,lastComma);
				            lastComma = invalidFields.lastIndexOf(",");
				            if(lastComma > -1)
				            {
				                invalidFields = invalidFields.substring(0,lastComma) + " and" + invalidFields.substring(lastComma + 1);
				            }			
				            alert(invalidFields); 
				        }
				    }
				    else
				    {	
				        if (siteRelURLtopage == "/SitePages/WS2.aspx")
				        {
				            // Get local Venue cell ------------
				            var VenueCell;
				            var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
				            $(".IAIOPADv2VenueRow").each(function () {
				                if ($(this).index() > thisRowIndex) {
				                    return false;
				                }
				                else {
				                    VenueCell = $(this).children().first();
				                }
				                //alert("venueRow index: "+$(this).index());
				            });
				            // Clone Venue row -----------------------		
				            var venueVal = VenueCell.find("#Venue").val();
				            $(VenueRow).clone().insertAfter(thisRow).find("td:last").append("<input type='hidden' id='Venue' value='" + venueVal + "' />").end().find('input:text').val('').end().removeClass("IAIOPADv2VenueRow IAIOPADv2WSGroupStartRow").end().children().first().remove().end().find('.IAIOPADv2WSBtnDeleteRow').attr('title', 'Delete row').end().find('.IAIOPADv2WSBtnDeleteRow').removeAttr('style'); // clone row and clear inputs
				            // Increment rowSpan of Venue cell -----------
				            var rowSpanIncrement = parseInt(VenueCell.attr("rowSpan")) + 1; //alert(rowSpanIncrement );
				            VenueCell.attr("rowSpan", rowSpanIncrement);
				        }
				        else
				        {
				            $(thisRow).clone().insertAfter(thisRow).find('input:text').val('').end().find('.IAIOPADv2WSBtnDeleteRow').attr('title', 'Delete row').end().find('.IAIOPADv2WSBtnDeleteRow').removeAttr('style'); // clone row and clear inputs
				        }
					}
					
				});
		        // ----- DELETE VENUE BUTTON -----
				$(".IAIOPADv2WSBtnDeleteGroup").attr("title", "Delete group: disabled for first group").css("background-color", "#b0b0b0").css("cursor", "arrow"); // mark initial set of delete row buttons as disabled			
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnDeleteGroup', function () { // using event delegation for this dynamic content
				    if ($(this).attr("title") !== "Delete group: disabled for first group") {
				        var ix = $(this).closest('tr').index();
				        var ii = -1;
				        var sliceEndGroupelete = ix + 1;
				        $(".IAIOPADv2WSGroupStartRow").each(function () {
				            if ($(this).index() < ix) {
				                ii = $(this).index();
				            }
				        });
				        var sliceStartDelete = ii;
				        var thisGroupTitleRowSet = tbody.children().slice(sliceStartDelete, sliceEndGroupelete);
				        thisGroupTitleRowSet.remove();
				    }
				});
		        // ----- ADD VENUE BUTTON -----
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnAddGroup', function () { // using event delegation for this dynamic content
				    var thisRow = $(this).closest('tr')[0];
				    $(groupTemplate).clone().insertAfter(thisRow).find("input").val("").end().find('.IAIOPADv2WSBtnDeleteGroup').attr('title', 'Delete group').end().find('.IAIOPADv2WSBtnDeleteGroup').removeAttr('style').end().find(".IAIOPADv2WSGroupTitle").parent().attr("rowSpan", "2");
				});
				// ----- SAVE NEXT BUTTON -----
				$("#s4-workspace").on('click', '.IAIOPADv2WSBtnSaveAndNext', function(){ // using event delegation for this dynamic content
					var pleaseWait = SP.UI.ModalDialog.showWaitScreenSize("Saving Worksheet", "Please wait...", pleaseWaitClosed);
					
					
					var inputVals = "";
					$(".IAIOPADv2WSTable > tbody > tr:has('input')").each(function(){				
						var row = this;
						var values = "";
						var hasValue = 0;
						$("input", row).each(function(){					
							var inputId = $(this).attr("id");	
							var inputVal = $(this).val();
							if(inputVal.length)
							{							
								hasValue = hasValue + 1;
								values = values + inputId + "," + inputVal + ",";						
							}										
						});	
						if(hasValue > 0)
						{
							inputVals += values + "OTA," + OTA + "," + "FY," + FY + "," + "Submitted," + Submitted + "|||";	
							
						}											
					});		
					
					//alert(inputVals); return false;
						
					var worksheetRows = inputVals.split("|||");
					wsList = wsList + "CurrentFY" + OTA; // WS1CurrentFYAFOTEC
					saveWorksheet(wsList, worksheetRows);
				});
			}												
		}	
	}			

});

function retrieveAllUsersInGroup() {     var clientContext = new SP.ClientContext.get_current();     var collGroup = clientContext.get_web().get_siteGroups();     var oGroup = collGroup.getById(20);     this.collUser = oGroup.get_users();     clientContext.load(collUser);     clientContext.executeQueryAsync(Function.createDelegate(this, this.retrieveAllUsersInGroupSucceeded), Function.createDelegate(this, this.retrieveAllUsersInGroupFailed)); }
function retrieveAllUsersInGroupSucceeded() {     var userInfo = '';     var userEnumerator = collUser.getEnumerator();     while (userEnumerator.moveNext()) {         var oUser = userEnumerator.get_current();         userInfo += '\nUser: ' + oUser.get_title() +             '\nID: ' + oUser.get_id() +             '\nEmail: ' + oUser.get_email() +             '\nLogin Name: ' + oUser.get_loginName();                }        alert("hello"+userInfo); }
function retrieveAllUsersInGroupFailed(sender, args) {     alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }
function retrieveAllUsersAllGroupsSpecificProperties() {     var clientContext = new SP.ClientContext.get_current();     this.collGroup = clientContext.get_web().get_siteGroups();     clientContext.load(collGroup, 'Include(Title,Id,Users.Include(Title,LoginName))');     clientContext.executeQueryAsync(Function.createDelegate(this, this.retrieveAllUsersAllGroupsSpecificPropertiesSucceeded), Function.createDelegate(this, this.retrieveAllUsersAllGroupsSpecificPropertiesFailed)); }
function retrieveAllUsersAllGroupsSpecificPropertiesSucceeded() {     var userInfo = '';     var groupEnumerator = collGroup.getEnumerator();     while (groupEnumerator.moveNext()) {         var oGroup = groupEnumerator.get_current();         var collUser = oGroup.get_users();         var userEnumerator = collUser.getEnumerator();         while (userEnumerator.moveNext()) {             var oUser = userEnumerator.get_current();             userInfo += '\nGroup ID: ' + oGroup.get_id() +                 '\nGroup Title: ' + oGroup.get_title() +                 '\nUser: ' + oUser.get_title() +                 '\nLogin Name: ' + oUser.get_loginName();         }     }     alert(userInfo); }
function retrieveAllUsersAllGroupsSpecificPropertiesFailed(sender, args) {     alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }
// ----- CONOPS WORKSHEETS -----
function saveWorksheet(wsList, worksheetRows)
{
	// alert(worksheetRows[0]);
	// iterate through worksheetRows, split the string into an array and ...
	// alert(wsList); return false;
	var i = 0;
	while(worksheetRows[i])
	{
		var rowFieldsAsCommaDelimitedString = worksheetRows[i];	
		var worksheetRow = rowFieldsAsCommaDelimitedString.split(",");		
		updateWSList(wsList, worksheetRow);
		i++;
	}
}
function updateWSList(wsList, worksheetRow) {
    var clientContext = new SP.ClientContext("/");
    var oList = clientContext.get_web().get_lists().getByTitle(wsList);
    var itemCreateInfo = new SP.ListItemCreationInformation();
    this.oListItem = oList.addItem(itemCreateInfo);
	var i = 0;
	while(worksheetRow[i])
	{		
		var column = worksheetRow[i];
		i++;
		var columnValue = worksheetRow[i];
		if(columnValue.length)
		{
			// has value so...
			oListItem.set_item(column, columnValue);
		}
		i++;
	}
    oListItem.update();
    clientContext.load(oListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.updateWSListSucceeded), Function.createDelegate(this, this.updateWSListFailed));
}
function updateWSListSucceeded() {
    // alert('Item created: ' + oListItem.get_id());
    if(oListItem.get_id() > -1)
    {
    	// update of list complete
    	// alert(wsList + ' saved.');
    	//SP.UI.ModalDialog.commonModalDialogClose(null, "Please wait closed"); // closes Please wait message and this worksheet    	
    	SP.UI.ModalDialog.commonModalDialogClose("OK", "Please wait closed"); // closes Please wait message and this worksheet    	
    }
}
function updateWSListFailed(sender, args) {
    alert('Item creation failed. ' + args.get_message() );
}
function openPopUpCONOPSDevPage(title, url)
{
	// alert(title);
	var args = {
		prevWS: title
	};
	var options = {
		width: 1000,
		title: title,
		url: url};
	SP.UI.ModalDialog.commonModalDialogOpen(url, options, nextCONOPSDevPage, args);
}
function pleaseWaitClosed(dialogResult, returnValue, otaTitle) { 	SP.UI.ModalDialog.commonModalDialogClose(null, 1); }
function nextCONOPSDevPage(dialogResult, returnValue)
{
	var args;
	var otaTitle;
	var prevWS;
	//alert("dialogResult" + dialogResult + "\nreturnValue: "+returnValue);
	if(returnValue){
		if(returnValue == 1)
		{
			//alert(returnValue);		
			args = this.get_args();
			otaTitle = args.otaTitle;
			prevWS = args.prevWS;
			//alert(prevWS);
			if(prevWS == ws1t)
			{
				openPopUpCONOPSDevPage(ws2t,ws2);
			}
			if(prevWS == ws2t)
			{
				openPopUpCONOPSDevPage(ws3t,ws3);
			}
			if(prevWS == ws3t)
			{
				openPopUpCONOPSDevPage(ws4t,ws4);
			}
		}
		else if(returnValue.indexOf("Preview") > -1)
		{
			openPopUpCONOPSDevPage("Preview/Submit Worksheets",returnValue);
		}	
		else if(returnValue == "Submitted")
		{
			alert("Thank you for submitting your Worksheets. We will be contacting you shortly.");
		}
		//else if(returnValue == ws1t)
		//{
			//alert(ws1t);
			//SP.UI.ModalDialog.commonModalDialogClose(1, ws1t);
		//}
	}
}

// ----- IAIOPADv2CalendarDashboard -----
function highlightDaysWithEvents()
{
	$(".ms-picker-today").find("A").css("font-weight","bold");
	var currDate = new Date(); 
	var currDateMo = numberAsTwoDigits(currDate.getMonth()+1);
	var linkIds = "";
	var smallCalLinkDate = "";
	$(".ms-picker-table").find("A").each(function (){ // get link ids for current month from the Calendar Dashboard on the home page.
		var smallCalLinkId = $(this).attr("id");
		var smallCalLinkIdMo = smallCalLinkId.substring(4,6);
		var highlightThis = "";
		if(smallCalLinkIdMo == currDateMo)
		{
			var smallCalLinkIdYr = smallCalLinkId.substring(0,4); 
			var smallCalLinkIdDay = smallCalLinkId.substr(6); 
			smallCalLinkDate = smallCalLinkIdMo + "/" + smallCalLinkIdDay  + "/" + smallCalLinkIdYr;
				// alert(smallCalLinkDate);
			highlightThis += IAIOPADv2CalendarDashboard(smallCalLinkDate, true);
			if(highlightThis == "Yes")
			{				
				$(this).parent().attr("onmouseover","this.className='ms-picker-dayselected';").attr("onmouseout","this.className='ms-picker-dayselected';").addClass("ms-picker-dayselected");
			}
		}
	});
}
function IAIOPADv2CalendarDashboard (eventDate, highlight)
{
	highlight = typeof highlight !== 'undefined' ? highlight : false;
	// If only one event on day clicked, then go to event DispForm, 
	// otherwise go to day in calendar. http://dotersrcndapp5:15429/Lists/Calendar/calendar.aspx?CalendarDate=2014-08-11&CalendarPeriod=day for Aug 11, 2014
	var eventDateForLargePopUp = "";
	var eventDateArray = eventDate.split("/"); // 8/7/2014   
	var eventDateMo = numberAsTwoDigits(eventDateArray[0]);
	var eventDateDay = numberAsTwoDigits(eventDateArray[1]);
	var eventDateYr = eventDateArray[2];
	eventDateForLargePopUp = eventDateYr + "-" + eventDateMo + "-" + eventDateDay;
	var eventID = "";
	var eventDateAsDate = new Date(eventDate);
	eventDateAsDate.setHours(0,0,0,0);
	var eventsOnThisDayCount =0;	
	var yesNo = "No";
	$(".IAIOPADv2CalendarDashboardsData").each(function(){
		var startdate = $(this).attr("startdate");
		startdate = startdate.substr(0, startdate.indexOf(" "));
		var startdateStrAsDate = new Date(startdate);
		startdateStrAsDate.setHours(0,0,0,0);
		var enddate = $(this).attr("enddate"); // alert('enddate |'+ enddate + '|');
		enddate = enddate.substr(0, enddate.indexOf(" "));
		var enddateStrAsDate = new Date(enddate);
		enddateStrAsDate.setHours(0,0,0,0);
		if(eventDateAsDate.valueOf() === startdateStrAsDate.valueOf()) // events with same start date
		{
			yesNo = "Yes";
			//alert('events with same start date: true ' + '\neventDateAsDate.toDateString(): ' + eventDateAsDate.toDateString()+ '\nstartdateStrAsDate.toDateString(): ' + startdateStrAsDate.toDateString());
			eventsOnThisDayCount = eventsOnThisDayCount + 1; eventID = $(this).text(); 
		}
		else if (eventDateAsDate.valueOf() === enddateStrAsDate.valueOf()) // events with same end date 
		{
			yesNo = "Yes";
			//alert('events with same end date: true');
			eventsOnThisDayCount = eventsOnThisDayCount + 1; eventID = $(this).text();
		}
		else if (eventDateAsDate > startdateStrAsDate && eventDateAsDate < enddateStrAsDate) // events spanning mult days		
		{
			yesNo = "Yes";
			//alert('events spanning multi days: true');
			eventsOnThisDayCount = eventsOnThisDayCount + 1; eventID = $(this).text();
		}
	});
	// alert(eventsOnThisDayCount);
	if(eventsOnThisDayCount > 0 && highlight == false)
	{
		// alert('greater than zero');
		if(eventsOnThisDayCount > 1)
		{
			// Events on Calendar Dashboard day view open in their own dialog, so open calendar day view in large window.
			OpenPopUpPage('../Lists/Calendar/calendar.aspx?CalendarDate=' + eventDateForLargePopUp + '&CalendarPeriod=day', null, 800, 800); 
		}
		else
		{
			// alert('eventsOnThisDayCount: ' + eventsOnThisDayCount + '\neventID: ' + eventID);
			OpenPopUpPage('../Lists/Calendar/DispForm.aspx?ID=' + eventID);
		}
	}
	if(highlight == false)
	{
		// function is being called as part of onclick event
		return void(0);
	}
	else 
	{
		// alert(yesNo);
		return yesNo;
	}
}

function MasterCalendar()
{
	if(siteRelURLtopage == "/Lists/Calendar/calendar.aspx")
	{
		$(".IAIOPADPOCs").hide();
	}
}
function AddFeedbackAndComments() { 	var options = { 		url: "/Lists/Feedback%20and%20Comments/NewForm.aspx", 		dialogReturnValueCallback: AddFeedbackAndCommentsThanks 	}; 	SP.UI.ModalDialog.showModalDialog(options); }
function AddFeedbackAndCommentsThanks(dialogResult, returnValue) { 	if(dialogResult == '1') 	{ 		alert("Thank you. Your feedback and comments will help us improve this site."); 	}	 }
function showProgramPOC(id) { 	var options = { 		url: "/Lists/Program%20POCs/DispForm.aspx?ID=" + id 	}; 	SP.UI.ModalDialog.showModalDialog(options); }

// ----- UTILITIES -----
function numberAsTwoDigits(num) {	 	var Num = num; 	return (Num < 10 ? '0' : '') + Num; }
function getParameterByName(name) {    name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");     var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),         results = regex.exec(location.search);     return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
function onQueryFailed(sender, args) { 	alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }