﻿	
	var usersPositionInCONOPSDevProcess = "";
	usersPositionInCONOPSDevProcess = "FY 15 Budget Worksheet #3: Non-Assessment Travel";
	

//.IAIOPADv2CONOPSDevCurrentFYWS1a, IAIOPADv2CONOPSDevCurrentFYWS1b, IAIOPADv2CONOPSDevCurrentFYWS2a, IAIOPADv2CONOPSDevCurrentFYWS2b, IAIOPADv2CONOPSDevCurrentFYWS3a, IAIOPADv2CONOPSDevCurrentFYWS3b, IAIOPADv2CONOPSDevCurrentFYWS4a, IAIOPADv2CONOPSDevCurrentFYWS4b, IAIOPADv2CONOPSDevCurrentFYRSa, IAIOPADv2CONOPSDevCurrentFYRSb {
//}
//.IAIOPADv2CONOPSDevNextFYWS1a, IAIOPADv2CONOPSDevNextFYWS1b, IAIOPADv2CONOPSDevNextFYWS2a, IAIOPADv2CONOPSDevNextFYWS2b, IAIOPADv2CONOPSDevNextFYWS3a, IAIOPADv2CONOPSDevNextFYWS3b, IAIOPADv2CONOPSDevNextFYWS4a, IAIOPADv2CONOPSDevNextFYWS4b, IAIOPADv2CONOPSDevNextFYRSa, IAIOPADv2CONOPSDevNextFYRSb {
//}
//.IAIOPADv2CONOPSDevFutureFYWS1a, IAIOPADv2CONOPSDevFutureFYWS1b, IAIOPADv2CONOPSDevFutureFYWS2a, IAIOPADv2CONOPSDevFutureFYWS2b, IAIOPADv2CONOPSDevFutureFYWS3a, IAIOPADv2CONOPSDevFutureFYWS3b, IAIOPADv2CONOPSDevFutureFYWS4a, IAIOPADv2CONOPSDevFutureFYWS4b, IAIOPADv2CONOPSDevFutureFYRSa, IAIOPADv2CONOPSDevFutureFYRSb {
//}

// .IAIOPADv2CONOPSDevProgressRow1a, .IAIOPADv2CONOPSDevProgressRow1b, .IAIOPADv2CONOPSDevProgressRow2a, .IAIOPADv2CONOPSDevProgressRow2b, .IAIOPADv2CONOPSDevProgressRow3a, .IAIOPADv2CONOPSDevProgressRow3b, .IAIOPADv2CONOPSDevProgressRow4a, .IAIOPADv2CONOPSDevProgressRow4b {

	// QUERY POSITION RESULT HERE
	// assuming we are on FY 15 Budget Worksheet #3: Non-Assessment Travel (mark cell In Progress yellow)
	// previous cells should be marked Draft Completed (green)
	// following cells should be marked Not Started (red)
	
	// Find matching cell.
	var cellB = $(".IAIOPADv2CONOPSDevPositionTable").find("td:contains("+usersPositionInCONOPSDevProcess+")");
	var cellBindex = cellB.index();
	// Show the row.
	var rowB = cellB.closest("tr").show();
	var rowAindex = rowB.index()-1; 
	var rowA = $(".IAIOPADv2CONOPSDevPositionTable").find("tr:eq("+rowAindex+")").show();
	rowA.children(":even").each(function(){
		if($(this).index() < cellBindex){
			
			$(this).addClass("IAIOPADv2CONOPSDevPositionDraftCompletea");
			$(this).text("Draft Completed");
			
		} else if($(this).index() == cellBindex){
			
			$(this).addClass("IAIOPADv2CONOPSDevPositionInProgressa");
			$(this).text("In Progress");
			
		} else {
		
			$(this).addClass("IAIOPADv2CONOPSDevPositionNotStarteda");
			$(this).text("Not Started");
		
		}
	
	
	});
	rowB.children(":even").each(function(){
		
		if($(this).index() < cellBindex){
			
			$(this).addClass("IAIOPADv2CONOPSDevPositionDraftCompleteb");
		
		} else if($(this).index() == cellBindex){
			
			$(this).addClass("IAIOPADv2CONOPSDevPositionInProgressb");
		
		} else {
		
			$(this).addClass("IAIOPADv2CONOPSDevPositionNotStartedb");
		
		}
	
	});
	
	
	// var rowB = $(".IAIOPADv2CONOPSDevPositionTable").find("td:contains("+usersPositionInCONOPSDevProcess+")").closest("tr").show();
	
	
	
	// Mark cell In Progress (yellow).
	//var cellB = $(".IAIOPADv2CONOPSDevPositionTable").find("td:contains("+usersPositionInCONOPSDevProcess+")").addClass("IAIOPADv2CONOPSDevPositionInProgressb");
	//var cellA = rowA.children(":eq("+cellB.index()+")").addClass("IAIOPADv2CONOPSDevPositionInProgressa");
	//cellA.text("In Progress");
