﻿				// ----- RETITLE -----
				//SP.UI.UIUtility.setInnerText(parent.document.getElementById("dialogTitleSpan"), "hhhh");
				if(parent.document.getElementById("dialogTitleSpan") !== null){
					parent.document.getElementById("dialogTitleSpan").innerHTML = "CONOPS Development Module";
				}
				
				// -----
				//<table class="IAIOPADv2WSReviewSubmitOTA ms-rteTable-default" cellspacing="0" style="width: 100%; font-size: 1em"><tbody><tr class="ms-rteTableHeaderRow-default"><th class="ms-rteTableHeaderFirstCol-default" colspan="6"><div class="IAIOPADv2WSOTA">OTA​</div></th></tr></tbody></table>

				// ----- SHOW SUBMIT WHEN READY -----
				
				var IAIOPADv2WSReviewCurrentFYCell, IAIOPADv2WSReviewNextFYCell, IAIOPADv2WSReviewFutureFYCell, showSubmit;
				IAIOPADv2WSReviewCurrentFYCell = $(".IAIOPADv2WSReviewCurrentFYCell");
				IAIOPADv2WSReviewNextFYCell = $(".IAIOPADv2WSReviewNextFYCell");
				IAIOPADv2WSReviewFutureFYCell = $(".IAIOPADv2WSReviewFutureFYCell");
				showSubmit = "Yes";
				if(IAIOPADv2WSReviewCurrentFYCell.hasClass("IAIOPADv2WSReviewReviewedCell")){} else {  showSubmit = "No"; }
				if(IAIOPADv2WSReviewNextFYCell.hasClass("IAIOPADv2WSReviewReviewedCell")){} else { showSubmit = "No";  }
				if(IAIOPADv2WSReviewFutureFYCell.hasClass("IAIOPADv2WSReviewReviewedCell")){} else { showSubmit = "No";  }
				if(showSubmit == "Yes"){
					$(".IAIOPADv2WSBtnSubmitReview").show();
				}


            	// ----- GET COMMON ROW DATA -----
            	CurrentFYforAcceptingCONOPS = getCurrentFYforAcceptingCONOPS(); 
                //var FY = parseInt(getParameterByName("currentFY")); // get from query string
                var nextFY = parseInt(CurrentFYforAcceptingCONOPS )+1;
                var nextNextFY = parseInt(CurrentFYforAcceptingCONOPS )+2;
                var ota = OTA;
                //var ota = getParameterByName("ota"); // get from query string
                //var otaTitle = getParameterByName("otaTitle"); // get from query string
                var fy = parseInt(getParameterByName("fy")); // get from query string
                //alert(fy);
                
                //alert(siteRelURLtopage);
                
                var windowlocationhref = window.location.href.toString();
                if(getParameterByName("showTable")!==""){
                      windowlocationhref = windowlocationhref.substr(0,windowlocationhref.indexOf("&showTable"));
                }
                
                var Submitted = "No";
                // ----- SET FY AND OTA IN FORM TEXT ELEMENTS -----IAIOPADv2WSFYNext
                //$(".IAIOPADv2WSFY").text(fy); 
                $(".IAIOPADv2WSFY").text(CurrentFYforAcceptingCONOPS); 
                
                //$(".IAIOPADv2WSFYNext").text(parseInt(fy)+1); 
                $(".IAIOPADv2WSFYNext").text(nextFY); 
                
                
                
                //$(".IAIOPADv2WSFYFuture").text(parseInt(fy)+2);
                $(".IAIOPADv2WSFYFuture").text(nextNextFY);
                
                $(".IAIOPADv2WSOTA").text(OTAtitle.toUpperCase());
                $("IAIOPADv2WSReviewNextFYBlock").closest('td').css("background-color","red");
                
                // ----- COLORS -----
                // .IAIOPADv2WSReviewCurrentFYColor, .IAIOPADv2WSReviewNextFYColor, .IAIOPADv2WSReviewFutureFYColor
                // .IAIOPADv2WSReviewNotStarted, .IAIOPADv2WSReviewInProgress, .IAIOPADv2WSReviewReviewed
                // .IAIOPADv2WSReviewCurrentFYCell, .IAIOPADv2WSReviewNextFYCell, .IAIOPADv2WSReviewFutureFYCell {

                var worksheetsDoneStateCurrentFY = "";
                var worksheetsDoneStateNextFY = "";
                var worksheetsDoneStateFutureFY = "";
                
                // Set above vars here after query
                
                
                worksheetsDoneStateCurrentFY = "Draft Completed";
                worksheetsDoneStateNextFY = "In Progress";
                worksheetsDoneStateFutureFY = "Not Started";
                
                if(worksheetsDoneStateCurrentFY == "Not Started"){applyReviewColor(worksheetsDoneStateCurrentFY,".IAIOPADv2WSReviewCurrentFYColor", "IAIOPADv2WSReviewNotStarted", ".IAIOPADv2WSReviewCurrentFYCell", "IAIOPADv2WSReviewNotStartedCell");}
                if(worksheetsDoneStateCurrentFY == "In Progress"){applyReviewColor(worksheetsDoneStateCurrentFY,".IAIOPADv2WSReviewCurrentFYColor", "IAIOPADv2WSReviewInProgress", ".IAIOPADv2WSReviewCurrentFYCell", "IAIOPADv2WSReviewInProgressCell");}
                if(worksheetsDoneStateCurrentFY == "Draft Completed"){applyReviewColor(worksheetsDoneStateCurrentFY,".IAIOPADv2WSReviewCurrentFYColor", "IAIOPADv2WSReviewReviewed",".IAIOPADv2WSReviewCurrentFYCell", "IAIOPADv2WSReviewReviewedCell");}
                
                if(worksheetsDoneStateNextFY == "Not Started"){applyReviewColor(worksheetsDoneStateNextFY,".IAIOPADv2WSReviewNextFYColor", "IAIOPADv2WSReviewNotStarted",".IAIOPADv2WSReviewNextFYCell", "IAIOPADv2WSReviewNotStartedCell");}
                if(worksheetsDoneStateNextFY == "In Progress"){applyReviewColor(worksheetsDoneStateNextFY,".IAIOPADv2WSReviewNextFYColor", "IAIOPADv2WSReviewInProgress",".IAIOPADv2WSReviewNextFYCell", "IAIOPADv2WSReviewInProgressCell");}
                if(worksheetsDoneStateNextFY == "Draft Completed"){applyReviewColor(worksheetsDoneStateNextFY,".IAIOPADv2WSReviewNextFYColor", "IAIOPADv2WSReviewReviewed",".IAIOPADv2WSReviewNextFYCell", "IAIOPADv2WSReviewReviewedCell");}
                
                if(worksheetsDoneStateFutureFY == "Not Started"){applyReviewColor(worksheetsDoneStateFutureFY,".IAIOPADv2WSReviewFutureFYColor", "IAIOPADv2WSReviewNotStarted",".IAIOPADv2WSReviewFutureFYCell", "IAIOPADv2WSReviewNotStartedCell");}
                if(worksheetsDoneStateFutureFY == "In Progress"){applyReviewColor(worksheetsDoneStateFutureFY,".IAIOPADv2WSReviewFutureFYColor", "IAIOPADv2WSReviewInProgress",".IAIOPADv2WSReviewFutureFYCell", "IAIOPADv2WSReviewInProgressCell");}
                if(worksheetsDoneStateFutureFY == "Draft Completed"){applyReviewColor(worksheetsDoneStateFutureFY,".IAIOPADv2WSReviewFutureFYColor", "IAIOPADv2WSReviewReviewed",".IAIOPADv2WSReviewFutureFYCell", "IAIOPADv2WSReviewReviewedCell");}
                
                
                
                
                
                
                function applyReviewColor(cellText, cellByClass, classToAdd, cellByClass2, classToAdd2){             
                	$(""+ cellByClass +"").text(cellText).addClass(classToAdd);
                	$(""+ cellByClass2 +"").addClass(classToAdd2);
                }
                
                
                
                
                
                
				// ----- IAIOPADv2WSReviewLinks -----
				
				var i=0;
				// ----- REVIEW LINKS -----
				$(".IAIOPADv2WSReviewLinks").children().each(function(){
					var linkUrl = $(this).attr("href");
					$(this).attr("href", "javascript:void(0);");
					var fyReviewLinks = FY + i;
					linkUrl = linkUrl + "?IsDlg=1&currentFY=" + FY.toString() + "&fy=" + fyReviewLinks + "&ota=" + ota + "&otaTitle=" + otaTitle;
					//$(this).attr("onclick","previewLink('" + linkUrl + "','" + OTAtitle.toUpperCase()+ "');");
					$(this).attr("onclick","previewLink('" + linkUrl + "');");
					if(fyReviewLinks == fy){						
						$(this).addClass("ms-rteThemeBackColor-9-1");						
					} else {						
						$(this).removeClass("ms-rteThemeBackColor-9-1");
					}					
					$(this).text("FY "+ fyReviewLinks +" worksheets");
					i=i+1;				
				});
				//$(".IAIOPADv2WSReviewSubmitTable").css("display","inline");
				
				//.IAIOPADv2WSReviewCurrentFYBlock, .IAIOPADv2WSReviewNextFYBlock, .IAIOPADv2WSReviewFutureFYBlock
				if(getParameterByName("showTable") == "1"){
					$(".IAIOPADv2WSReviewFYTable").css("display","inline");
				}
				
				$(".IAIOPADv2WSReviewCurrentFYBlock").click(function(){
				
					if(getParameterByName("showTable") == "1"){
						window.location = windowlocationhref;
					} else {
					//alert('IAIOPADv2WSReviewCurrentFYBlock');
						window.location = windowlocationhref + "&showTable=1";
					}
					//window.location = siteRelURLtopage + "?fy=" + CurrentFYforAcceptingCONOPS + "&IsDlg=1" + "&showTable=1";
					
				});
				$(".IAIOPADv2WSReviewNextFYBlock").click(function(){
					if(getParameterByName("showTable") == "1"){
						window.location = windowlocationhref;
					} else {
					//alert('IAIOPADv2WSReviewCurrentFYBlock');
						window.location = windowlocationhref + "&showTable=1";
					}
				});
				$(".IAIOPADv2WSReviewFutureFYBlock").click(function(){
					if(getParameterByName("showTable") == "1"){
						window.location = windowlocationhref;
					} else {
					//alert('IAIOPADv2WSReviewCurrentFYBlock');
						window.location = windowlocationhref + "&showTable=1";
					}
				});
				
				
				$(".IAIOPADv2WSReviewEdit").click(function(){
            	
            		var previewWSTitle = $(this).closest('tr').children().eq(1).text();
            		
            		alert(previewWSTitle);
            	
            	});

				
				
				
				
				
				// ------------------------------------------------------
				
				// ----- REVIEW SUMMARY QUERY -----
				var wsListNumReview, wsReviewCurrentFY, wsReviewFY, wsReviewOTA;
				wsReviewCurrentFY = CurrentFYforAcceptingCONOPS;
				wsListNumReview = 1;
				wsReviewFY = fy;
				wsReviewOTA = ota;
				
			//	ExecuteOrDelayUntilScriptLoaded(callretrieveListItemsReviewSubmit,"sp.js");
				function callretrieveListItemsReviewSubmit(){
					retrieveListItemsReviewSubmit(wsListNumReview, wsReviewCurrentFY, wsReviewFY, wsReviewOTA);
				
				}
				
				// ----- INIT -----
				// $(".IAIOPADv2WSReviewFYTable").css("display","inline");
				


