﻿            // Background color for right col
            var firstRowLayoutsTable = $("#layoutsTable").find("tr:first");
            firstRowLayoutsTable.children("td:last").addClass("IAIOPADv2HomeRightCol");
            // Assessment Dashboard ----------------------------------
            // Home.aspx Assessment Dashboard links will open in dialog to the assessment. 
            // A web part that is targeted at the audience IAIOPAD Owners will offer a dropdown menu for admins to pick an OTA. 
            // A hidden web part text field acts as a filter on items shown to ensure that OTAs view their own assessments and cannot enter a query string with another OTA to see others' data.
            // Selecting from the dropdown shows links to admins. 
            // A hidden web part with the Program Contacts list acts as an access control list for the current user. Their OTA must match the value in the Assessment item to be seen. 
            $(".IAIOPADv2AssessmentDashboardAssessment").each(function () {
                $(this).attr("href", "javascript:OpenPopUpPage('/Lists/Assessments/DispForm.aspx?ID=" + $(this).attr("iid") + "');");
            });
            // Legend
            var toggleState = false;
            $(".IAIOPADv2AssessmentDashboardLegend").click(function () {
                if (toggleState == false) {
                    // $(this).find("SPAN").text("[-]");
                    $(this).find("SPAN").html("<img alt='Collapse Legend' src='/_layouts/images/TPMin2.gif' border='0' class='IAIOPADv2AssessmentDashboardLegendToggleImg'/>");
                    $(".IAIOPADv2AssessmentDashboardLegendTable").show("slow", function () {
                        toggleState = true;
                    });
                }
                else {
                    // $(this).find("SPAN").text("[+]");
                    $(this).find("SPAN").html("<img alt='Expand Legend' src='/_layouts/images/TPMax2.gif' border='0' class='IAIOPADv2AssessmentDashboardLegendToggleImg'/>");
                    $(".IAIOPADv2AssessmentDashboardLegendTable").hide("slow", function () {
                        toggleState = false;
                    });
                }
            });
            // Program POCs -------------------------------------------
            // $("TD[title='IAIOPAD POCs']").parentsUntil("div").hide();
            // Calendar Dashboard -------------------------------------
            // Remove js onclick from a tags in Calendar Dashboard (duplicated in td where it is needed when day is single digit and hard to click on.) 
            $(".ms-datepickerouter").find("A").attr("href", "javascript:void(0);");
            // Highlight days on Calendar Dashboard with events.
            highlightDaysWithEvents();
