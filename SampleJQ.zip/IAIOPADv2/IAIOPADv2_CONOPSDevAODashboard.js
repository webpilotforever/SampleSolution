﻿// ----- CONOPSDevAODashboard -----
var CONOPSDevAODashboardTableCheck = $(".CONOPSDevAODashboardCurrentFYRow");
if( CONOPSDevAODashboardTableCheck.length  ){	
	$(".CONOPSDevAODashboardCurrentAFOTECWS1Status").attr("title","Draft Completed").attr("alt","Draft Completed").attr("src","/SiteAssets/graphics/CONOPSDevAODashboardGreen.png");
	$(".CONOPSDevAODashboardCurrentAFOTECWS2Status").attr("title","Draft Completed").attr("alt","Draft Completed").attr("src","/SiteAssets/graphics/CONOPSDevAODashboardGreen.png");
	$(".CONOPSDevAODashboardCurrentAFOTECWS3Status").attr("title","In Progress").attr("alt","In Progress").attr("src","/SiteAssets/graphics/CONOPSDevAODashboardYellow.png");
}


