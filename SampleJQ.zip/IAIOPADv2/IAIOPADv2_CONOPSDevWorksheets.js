﻿if(parent.document.getElementById("dialogTitleSpan") !== null){
					parent.document.getElementById("dialogTitleSpan").innerHTML = "CONOPS Development Module";
				}


                
                $("#Total").parent().append("<input type='hidden' value='Total' id='Title' />");
                // Clone Venue row when ready ------------------
                $("#Venue").closest("tr").addClass("IAIOPADv2VenueRow");
                var VenueRow = $(".IAIOPADv2VenueRow")[0];
                var venueRow = $(".IAIOPADv2VenueRow");
                // ----- HIDE DIALOG PAGE TAB IN RIBBON -----
                //$(".ms-cui-tt-a").css("display","none");

                // ----- TAG TABLE WITH CLASS ----------
                $(".IAIOPADv2WSBtnDeleteRow").closest('table').addClass("IAIOPADv2WSTable");
                $("#Venue").addClass("IAIOPADv2WSGroupTitle");
                $("#Contract").addClass("IAIOPADv2WSGroupTitle");
                $(".IAIOPADv2WSGroupTitle").closest('tr').addClass("IAIOPADv2WSGroupStartRow");
                $(".IAIOPADv2WSBtnAddGroup").closest('tr').addClass("IAIOPADv2WSGroupEndRow");
                // ----- GET COMMON ROW DATA -----
                var FY = getParameterByName("currentFY"); // get from query string
                var Submitted = "No";
                // ----- SET FY AND OTA IN FORM TEXT ELEMENTS -----
                $(".IAIOPADv2WSFY").text(FY);  
                $(".IAIOPADv2WSOTA").text(OTAtitle.toUpperCase());
                // ----- TBODY -----
                var tbody = $(".IAIOPADv2WSBtnDeleteRow").closest('tr').parent();
                var sliceStartTemplate = $(".IAIOPADv2WSGroupTitle").closest('tr').index(); // alert(sliceStartTemplate);
                var sliceEndTemplate = $(".IAIOPADv2WSBtnAddGroup").closest('tr').index() + 1; //alert(sliceEndTemplate );
                var groupTemplate = tbody.children().slice(sliceStartTemplate, sliceEndTemplate); // set of row elements
                if (siteRelURLtopage == "/SitePages/WS1.aspx" || siteRelURLtopage == "/SitePages/WS2.aspx") {
                    $("#s4-workspace").on('focusin', 'input:text', function () { // using event delegation for this dynamic content

                        if (siteRelURLtopage == "/SitePages/WS1.aspx") {
                            var inxForThisFieldRow = $(this).closest('tr').index();
                            var inxForTheClosestContractFieldRow = 0;
                            tbody.find("input[title='Contract']").each(function () {
                                if ($(this).closest('tr').index() < inxForThisFieldRow) {
                                    //$(this).css("background-color","red");
                                    inxForTheClosestContractFieldRow = $(this).closest('tr').index();
                                }
                            });
                            var inxForNextAddGroupBtn = 0;
                            tbody.find(".IAIOPADv2WSBtnAddGroup").each(function () {
                                if ($(this).closest('tr').index() > inxForThisFieldRow) {
                                    //$(this).css("background-color","red");
                                    inxForNextAddGroupBtn = $(this).closest('tr').index() + 1;
                                    return false;
                                }
                            });
                            if ($(this).attr("id") !== "Contract" && inxForTheClosestContractFieldRow > 0) {
                                var thisContract = tbody.children().slice(inxForTheClosestContractFieldRow, inxForNextAddGroupBtn);
                                if (thisContract.find("input:text[id='Contract']").val() == "") {
                                    alert("Please enter information for [Contract]");
                                }
                            }
                        } else {
                            var sliceStartVenue;
                            var sliceEndVenue;
                            var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
                            $(".IAIOPADv2VenueRow").each(function () {
                                if ($(this).index() > thisRowIndex) {
                                    return false;
                                } else {
                                    sliceStartVenue = $(this).index();
                                }
                            });
                            // alert(sliceStartVenue );
                            tbody.children(".IAIOPADv2WSGroupEndRow").each(function () {
                                if ($(this).index() > sliceStartVenue) {
                                    sliceEndVenue = $(this).index();
                                    return false;
                                }
                            });
                            // alert(sliceEndVenue );
                            var thisVenue = tbody.children().slice(sliceStartVenue, sliceEndVenue);
                            if ($(this).attr("id") !== "Venue") {
                                if (thisVenue.find("input:text[id='Venue']").val() == "") {
                                    alert("Please enter information for [Venue]");
                                }
                            }
                        }
                    });
                    // ----- APPEND GROUP ROWS WITH HIDDEN GROUP TITLE FIELD -----
                    $("#s4-workspace").on('focusout', '.IAIOPADv2WSGroupTitle', function () { // using event delegation for this dynamic content
                        // return false;
                        var groupTitleFieldVal = $(this).val();
                        var sliceStartGroup = $(this).closest('tr').index();
                        if ($(this).attr("id") == "Venue" || $(this).attr("id") == "Contract") {
                            sliceStartGroup = sliceStartGroup + 1;
                        }
                        var sliceEndGroup = tbody.children().slice(sliceStartGroup).find(".IAIOPADv2WSBtnDeleteGroup").first().closest('tr').index() + 1;

                        var thisGroupTitleRowSett = tbody.children().slice(sliceStartGroup, sliceEndGroup);
                        thisGroupTitleRowSett.each(function () { // iterate through rows
                            //alert(groupTitleFieldVal ); 
                            if (siteRelURLtopage == "/SitePages/WS1.aspx") {
                                if ($(this).find(".IAIOPADv2WSGroupTitle").index() > -1) {
                                    $(this).find(".IAIOPADv2WSGroupTitle").val(groupTitleFieldVal);
                                }
                                else {
                                    if ($(this).find("input:hidden[id='Contract']").length) {
                                        // update hidden Contract fields
                                        $(this).find("input:hidden[id='Contract']").val(groupTitleFieldVal);
                                    }
                                    else {
                                        $(this).find("input:not(#Contract)").last().parent().append("<input type='hidden' value='" + groupTitleFieldVal + "' id='Contract' />");
                                    }
                                }
                            } else {
                                var lastFieldVal = $(this).find("input:text").last().attr("id");
                                $(this).find("input:hidden[id='Title']").val(lastFieldVal);

                                if ($(this).find("input:hidden[id='Venue']").length) {
                                    // update hidden Venue fields
                                    $(this).find("input:hidden[id='Venue']").val(groupTitleFieldVal);
                                }
                                else {
                                    $(this).find("input:not(#Venue)").last().parent().append("<input type='hidden' value='" + groupTitleFieldVal + "' id='Venue' />");
                                }
                            }
                        });
                    });
                    // ----- HIDDEN FIELDS -----		
                    tbody.children().each(function () { // Append rows with no Title field with a hidden Title field with the value of the last field's id attribute in the last cell
                        var foundInput = "No";
                        var foundTitle = "No";
                        // $(this).find("input:text").each(function () {
                        $(this).find("input").each(function () {

                            //alert( $(this).attr("id") ); 
                            foundInput = "Yes";
                            if ($(this).attr("id") == "Title") {
                                foundTitle = "Yes";
                            }
                        });
                        if (foundInput == "Yes" && foundTitle == "No") {
                            // $(this).css("display","none");
                            var inputId = $(this).find("input:text").last().attr("id");
                            $(this).find("input:text").last().parent().append("<input type='hidden' value='" + inputId + "' id='Title' />");
                        }
                    });
                    tbody.find("input:text").each(function () { // GSLevel and ContractorRate field cells should be appended with a hidden field for Employer
                        if ($(this).attr("id") == "GSLevel") {
                            $(this).parent().append("<input type='hidden' value='MilitaryOrGovernmentCivilian' id='Employer' />");
                        }
                        if ($(this).attr("id") == "ContractorRate") {
                            $(this).parent().append("<input type='hidden' value='Contractor' id='Employer' />");
                        }
                    });
                }
                // ----- REMARKS FIELD -----
                var remarksWidth = $("#Remarks").css("width");
                $("#s4-workspace").on('focusin', '#Remarks', function () {
                    $(this).css("width", "300px");
                });
                $("#s4-workspace").on('focusout', '#Remarks', function () {
                    $(this).css("width", remarksWidth);
                });
                // ----- COLUMN DESCRIPTIONS -----
                $(".IAIOPADv2WSColHeaders").hover(function () {
                    $(".IAIOPADv2WSColDesc").slideToggle("fast");
                });

                // ----- DELETE ROW BUTTON -----
                $(".IAIOPADv2WSBtnDeleteRow").attr("title", "Delete row: disabled for first item").css("background-color", "#b0b0b0").css("cursor", "arrow"); // mark initial set of delete row buttons as disabled			
                $("#s4-workspace").on('click', '.IAIOPADv2WSBtnDeleteRow', function () { // using event delegation for this dynamic content
                    if ($(this).attr("title") !== "Delete row: disabled for first item") {
                        // Get local Venue cell ------------
                        var VenueCell;
                        var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
                        $(".IAIOPADv2VenueRow").each(function () {
                            if ($(this).index() > thisRowIndex) {
                                return false;
                            }
                            else {
                                VenueCell = $(this).children().first();
                            }
                        });
                        // Remove this row ---------------
                        $(this).closest('tr').remove();
                        if (siteRelURLtopage == "/SitePages/WS2.aspx") {
                            // Decrement rowSpan of Venue cell -----------
                            var rowSpanDecrement = parseInt(VenueCell.attr("rowSpan")) - 1; //alert(rowSpanDecrement );
                            VenueCell.attr("rowSpan", rowSpanDecrement);
                        }
                    }
                });
                // ----- ADD ROW BUTTON -----
                $("#s4-workspace").on('click', '.IAIOPADv2WSBtnAddRow', function () { // using event delegation for this dynamic content
                    var readyToClone = "Yes";
                    var invalidFields = "Please enter information for ";
                    var thisRow = $(this).closest('tr')[0];
                    $("input", thisRow).each(function () {
                        var inputTitle = $(this).attr("title");
                        var inputId = $(this).attr("id");
                        var inputVal = $(this).val();
                        if (inputVal.length) {
                            // do nothing
                        }
                        else {
                            if (inputTitle == "Remarks") {
                                // do nothing
                            }
                            else {
                                invalidFields += "[" + inputTitle + "], ";
                                readyToClone = "No";
                            }
                        }
                    });
                    if (readyToClone == "No") {
                        var lastComma = invalidFields.lastIndexOf(",");
                        if (lastComma > -1) {
                            invalidFields = invalidFields.substr(0, lastComma);
                            lastComma = invalidFields.lastIndexOf(",");
                            if (lastComma > -1) {
                                invalidFields = invalidFields.substring(0, lastComma) + " and" + invalidFields.substring(lastComma + 1);
                            }
                            alert(invalidFields);
                        }
                    }
                    else {
                        if (siteRelURLtopage == "/SitePages/WS2.aspx") {
                            // Get local Venue cell ------------
                            var VenueCell;
                            var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
                            $(".IAIOPADv2VenueRow").each(function () {
                                if ($(this).index() > thisRowIndex) {
                                    return false;
                                }
                                else {
                                    VenueCell = $(this).children().first();
                                }
                                //alert("venueRow index: "+$(this).index());
                            });
                            // Clone Venue row -----------------------		
                            var venueVal = VenueCell.find("#Venue").val();
                            $(VenueRow).clone().insertAfter(thisRow).find("td:last").append("<input type='hidden' id='Venue' value='" + venueVal + "' />").end().find('input:text').val('').end().removeClass("IAIOPADv2VenueRow IAIOPADv2WSGroupStartRow").end().children().first().remove().end().find('.IAIOPADv2WSBtnDeleteRow').attr('title', 'Delete row').end().find('.IAIOPADv2WSBtnDeleteRow').removeAttr('style'); // clone row and clear inputs
                            // Increment rowSpan of Venue cell -----------
                            var rowSpanIncrement = parseInt(VenueCell.attr("rowSpan")) + 1; //alert(rowSpanIncrement );
                            VenueCell.attr("rowSpan", rowSpanIncrement);
                        }
                        else {
                            $(thisRow).clone().insertAfter(thisRow).find('input:text').val('').end().find('.IAIOPADv2WSBtnDeleteRow').attr('title', 'Delete row').end().find('.IAIOPADv2WSBtnDeleteRow').removeAttr('style'); // clone row and clear inputs
                        }
                    }

                });
                // ----- DELETE VENUE BUTTON -----
                $(".IAIOPADv2WSBtnDeleteGroup").attr("title", "Delete group: disabled for first group").css("background-color", "#b0b0b0").css("cursor", "arrow"); // mark initial set of delete row buttons as disabled			
                $("#s4-workspace").on('click', '.IAIOPADv2WSBtnDeleteGroup', function () { // using event delegation for this dynamic content
                    if ($(this).attr("title") !== "Delete group: disabled for first group") {
                        var ix = $(this).closest('tr').index();
                        var ii = -1;
                        var sliceEndGroupelete = ix + 1;
                        $(".IAIOPADv2WSGroupStartRow").each(function () {
                            if ($(this).index() < ix) {
                                ii = $(this).index();
                            }
                        });
                        var sliceStartDelete = ii;
                        var thisGroupTitleRowSet = tbody.children().slice(sliceStartDelete, sliceEndGroupelete);
                        thisGroupTitleRowSet.remove();
                    }
                });
                // ----- ADD GROUP BUTTON -----
                $("#s4-workspace").on('click', '.IAIOPADv2WSBtnAddGroup', function () { // using event delegation for this dynamic content
                    var thisRow = $(this).closest('tr')[0];
                    if (siteRelURLtopage == "/SitePages/WS1.aspx") {
                        $(groupTemplate).clone().insertAfter(thisRow).find('#Contract').val('').end().find('input:text').val('').end().find('.IAIOPADv2WSBtnDeleteGroup').attr('title', 'Delete group').end().find('.IAIOPADv2WSBtnDeleteGroup').removeAttr('style'); // clone row and clear inputs

                    } else {

                        $(groupTemplate).clone().insertAfter(thisRow).find("input").val("").end().find('.IAIOPADv2WSBtnDeleteGroup').attr('title', 'Delete group').end().find('.IAIOPADv2WSBtnDeleteGroup').removeAttr('style').end().find(".IAIOPADv2WSGroupTitle").parent().attr("rowSpan", "2");

                    }
                });
                // ----- SAVE NEXT BUTTON -----
                $("#s4-workspace").on('click', '.IAIOPADv2WSBtnSaveAndNext', function () { // using event delegation for this dynamic content
                    var pleaseWait = SP.UI.ModalDialog.showWaitScreenSize("Saving Worksheet", "Please wait...", pleaseWaitClosed);


                    var inputVals = "";
                    $(".IAIOPADv2WSTable > tbody > tr:has('input')").each(function () {
                        var row = this;
                        var values = "";
                        var hasValue = 0;
                        $("input", row).each(function () {
                            var inputId = $(this).attr("id");
                            var inputVal = $(this).val();
                            if (inputVal.length) {
                                hasValue = hasValue + 1;
                                values = values + inputId + "," + inputVal + ",";
                            }
                        });
                        if (hasValue > 0) {
                            inputVals += values + "OTA," + OTA + "," + "FY," + FY + "," + "Submitted," + Submitted + "|||";

                        }
                    });

                    //alert(inputVals); return false;

                    var worksheetRows = inputVals.split("|||");
                    wsList = wsList + "CurrentFY" + OTA; // WS1CurrentFYAFOTEC
                    saveWorksheet(wsList, worksheetRows);
                });