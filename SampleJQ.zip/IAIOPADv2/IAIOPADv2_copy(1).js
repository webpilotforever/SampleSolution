﻿// IAIOPADv2 Cyber-Assessment Database
var ourLocation = window.location.href.toString(); var locationUpToHost = window.location.protocol + "//" + window.location.host; var atLocation = ourLocation.substr(0, ourLocation.indexOf(".aspx") + 5); var siteRelURLtopage = window.location.pathname; var atPage = atLocation.substr(atLocation.lastIndexOf("/") + 1); var wsList = siteRelURLtopage.substr(siteRelURLtopage.lastIndexOf("/") + 1); var OTA = ""; var OTAtitle = ""; wsList = wsList.substr(0, wsList.indexOf(".aspx")); var docRef = window.document.referrer.toString(); docRef = docRef.replace(locationUpToHost, ""); var CurrentFYforAcceptingCONOPS; var ws1; var ws2; var ws3; var ws4; var wsReviewSubmit; var ws1t; var ws2t; var ws3t; var ws4t; if (!window.console) console = { log: function () { } };
$(document).ready(function () {
    
    // currently, the OTA for current user is set by javascript only on CONOPSDevelopment page from Program Contacts web part
    var OTAindex = $("table[summary='Program Contacts ']").find("th:contains(OperationalTestAgency)").index();
    if(OTAindex > -1){
    	OTA += $("table[summary='Program Contacts ']").find("td:eq("+OTAindex+")").text(); 
    }
    if (OTA == "AFOTEC") { OTAtitle = "Air Force Operational Test and Evaluation Center"; } if (OTA == "ATEC") { OTAtitle = "Army Test and Evaluation Command"; } if (OTA == "COTF") { OTAtitle = "Command Operational Test and Evaluation Force"; } if (OTA == "JITC") { OTAtitle = "Joint Interoperability Test Command"; } if (OTA == "JITC") { OTAtitle = "Marine Corps Operational Test and Evaluation Activity"; } if (getParameterByName("otaTitle") !== "" && OTA == "") { OTAtitle = getParameterByName("otaTitle"); OTA = getParameterByName("ota"); } $("#RibbonContainer").on('click', 'a[title="Edit"]', function () { return false; }); var inDesignMode = $("#MSOSPWebPartManager_DisplayModeName").val();
    
    // run this javascript only when the page is not being edited
    if (inDesignMode == "Design") {
        return false;
    }
    else {
        Home(); MasterCalendar(); CONOPSDevAODashboard(); CONOPSDevelopmentModule(); QuickLaunchMenu(); CONOPSDevWorksheets(); ReviewSubmitWorksheets();

    }
    
    $("#ctl00_onetidHeadbnnr2").attr("src", "/SiteAssets/SitePages/Home/doteseal.gif").css("display", "inline"); $("img[style*='-585px']").css("top", "-607px").css("filter", "alpha(opacity=60)").css("opacity", "0.6");
    // Hide Page tab in dialogs
    if(getParameterByName("IsDlg") == "1"){ $(".ms-cui-tt-a").css("display","none"); }

    function QuickLaunchMenu() { if (getParameterByName("IsDlg") == "") { if ($(".IAIOPADv2OwnersAudienceTargeting").text() == "IAIOPADv2OwnersAudienceTargeting") { var conopsapprovallink = '<LI class="static"><A class="static menu-item" href="/SitePages/CONOPS%20Approval.aspx"><SPAN class="additional-background"><SPAN class="menu-item-text">CONOPS Approval</SPAN></SPAN></A></LI>'; $(".s4-ql UL.root").prepend(conopsapprovallink); } 
    // blue bg // $(".s4-ql UL.root").closest('div.ms-quickLaunch').prepend("<div style='background:url(/_layouts/images/bgximg.png) #ccebff repeat-x 0px -283px; color:#003759; margin:1px; padding:5px; font-weight:bold; text-align:center;'>Modules</div>");  
    $(".s4-ql UL.root").closest('div.ms-quickLaunch').prepend("<div style='background:url(/_layouts/images/selbg.png) #f6f6f6 repeat-x left top; color:#003759; margin:1px; padding:5px; font-weight:bold; text-align:center;'>Modules</div>");  
    
    
    
    
    
    var s4mainareaHeight = $("#s4-mainarea").css("height"); s4mainareaHeight = parseInt(s4mainareaHeight.replace("px", "")); // alert(s4mainareaHeight ); return false;
    var QuickLaunchHeight = $("#s4-leftpanel-content").css("height"); QuickLaunchHeight = parseInt(QuickLaunchHeight.replace("px", "")); // alert(QuickLaunchHeight ); return false;
    
    var belowQuickLaunchHeight = $(".belowQuickLaunch").css("height"); 
    $(".belowQuickLaunch").css("min-height",belowQuickLaunchHeight); 
    
	$(".s4-ba").css("padding-bottom", 1); $("#s4-leftpanel-content").css("padding-bottom", 1);

    
    var IAIOPADv2HomeRightColHeight;
    if($(".IAIOPADv2HomeRightCol").length){ // for Home //
    
        IAIOPADv2HomeRightColHeight =  $(".IAIOPADv2HomeRightCol").css("height"); IAIOPADv2HomeRightColHeight = parseInt(IAIOPADv2HomeRightColHeight.replace("px",""));
		$(".belowQuickLaunch").css("height", IAIOPADv2HomeRightColHeight - QuickLaunchHeight);
		//$(".s4-ba").css("padding-bottom", 1); $("#s4-leftpanel-content").css("padding-bottom", 1);
    } else {
    	$("#MSO_ContentTable").css("min-height", s4mainareaHeight);
    	$(".belowQuickLaunch").css("height", s4mainareaHeight - QuickLaunchHeight);
    }
   
   	} 
   
   }
    
    
    
    function Home() {
        if (siteRelURLtopage == "/SitePages/Home.aspx") {
        	$.getScript('/SiteAssets/IAIOPADv2_Home.js', function(){});
        }
    }
    function CONOPSDevAODashboard(){
    	$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevAODashboard.js', function(){});
    }
    function CONOPSDevelopmentModule() {
        if (siteRelURLtopage == "/SitePages/CONOPS%20Development%20Module.aspx") {
        	$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevelopmentModule.js', function(){});   
        }
    }
    function CONOPSDevWorksheets() {
        if (getParameterByName("IsDlg") == "1") { // run jquery on page when it is in a dialog. this minimizes chance of html being corrupted with jquery and sizzle junk ids after using html source editor.
            if (siteRelURLtopage == "/SitePages/WS1.aspx" || siteRelURLtopage == "/SitePages/WS2.aspx" || siteRelURLtopage == "/SitePages/WS3.aspx" || siteRelURLtopage == "/SitePages/WS4.aspx") {
            	$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevWorksheets.js', function(){});
            }
        }
    }
    function ReviewSubmitWorksheets() {   
        if (getParameterByName("IsDlg") == "1") // run jquery on page when it is in a dialog. this minimizes chance of html being corrupted with jquery and sizzle junk ids after using html source editor.
        {
            if (siteRelURLtopage == "/SitePages/Review%20Submit%20Worksheets.aspx") {           	
            	$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevReviewSubmit.js', function(){});      	
            }
		}
	}
});

function colorIAIOPADv2CONOPSDevPositionTable(){	
	$.getScript('/SiteAssets/IAIOPADv2_CONOPSDevPositionTable.js', function(){});
}



function getFirstWorksheetCall(i, chartRow){
	//var fy = ""; // fy of the last worksheet items with data   "15"
	//var wsListTitle = ""; // title of the last list for this ota that has data   "WS2CurrentFYAFOTEC"
	
	
	// ----- QUERY OF ITEMS FOR THIS OTA -----
	i = typeof i !== 'undefined' ? i : 0;
	
	//if(i > 0){
	
		//alert("i: "+i); 
	//}
	
	
	chartRow = typeof chartRow !== 'undefined' ? chartRow : 1;	
	var fy = CurrentFYforAcceptingCONOPS;
	
	// wsLists first set of 4 = WS1-4 current fy (15)
	// wsLists second set of 4 = WS1-4 current fy + 1 (16)
	// wsLists third set of 4 = WS1-4 current fy +2 (17)
	// zero indexed, wsListsArray has 11 elements
	var wsLists = "WS1CurrentFY"+OTA+",WS2CurrentFY"+OTA+",WS3CurrentFY"+OTA+",WS4CurrentFY"+OTA+",WS1FutureFYs"+OTA+",WS2FutureFYs"+OTA+",WS3FutureFYs"+OTA+",WS4FutureFYs"+OTA+",WS1FutureFYs"+OTA+",WS2FutureFYs"+OTA+",WS3FutureFYs"+OTA+",WS4FutureFYs"+OTA+"";
	var wsListsArray = wsLists.split(",");
	
	
	if(chartRow == 2 && i < 4){ // skip row
		i = 4;
	}
	if(chartRow == 3 && i < 8){ // skip row
		i = 8;
	}
		
	if(i > 3 && i < 8){ // set fy
		fy = parseInt(CurrentFYforAcceptingCONOPS)+1;
		chartRow = 2;
	}
	if(i > 7 && i < 12){ // set fy
		fy = parseInt(CurrentFYforAcceptingCONOPS)+2;
		chartRow = 3;
	}
	if(i > 11){ // last row
		chartRow = 4;
	}
	if(chartRow == 4){ // user needs only to do final preview submit
		IAIOPADv2CONOPSDevPositionIndicator("CONOPS Not Submitted");
	} else if(chartRow == 0){ // user must have submitted all CONOPS for this cycle
		IAIOPADv2CONOPSDevPositionIndicator("CONOPS Submitted");
	} else {
		
		ExecuteOrDelayUntilScriptLoaded(getFirstWorksheetCall2, "sp.js");
		
		function getFirstWorksheetCall2(){
			//alert('wsListsArray[i], fy, chartRow, i: '+wsListsArray[i]+' | '+fy+' | '+chartRow+' | '+i);
			getFirstWorksheet(wsListsArray[i], fy, chartRow, i);
		
		}
		
		
		

	}
	
	
	
	//IAIOPADv2CONOPSDevPositionIndicator(wsListTitle, fy);
}

function IAIOPADv2CONOPSDevPositionIndicator(lastWSListWithItems, fy, chartRow){

	// lastWSListWithItems is WS1FutureFYsAFOTEC
	// fy is 16
	// chartRow is 2? 
	//alert("IAIOPADv2CONOPSDevPositionIndicator lastWSListWithItems, fy, chartRow " + lastWSListWithItems+' | '+fy+' | '+chartRow); return false;
	

	
	//var t = "FY " + fy + " Budget Worksheet #" + lastWSListWithItems.charAt(2);
	//var td = $(".IAIOPADv2CONOPSDevPositionTable").find("td:contains("'+t+'")");
	//td.hide();
	
	
	var positionString = "Nothing";
	var firstWorksheetUrl;
    var firstWorksheetTitle;

	if(lastWSListWithItems == "CONOPS Not Submitted"){
	
		// set indicator to final Review/Submit on chart and open dialog to final Review/Submit page
		alert("CONOPS not submitted"); return false;
	
	} else if(lastWSListWithItems == "CONOPS Submitted"){
	
		// set indicator to End on chart and do not open dialog and alert that "CONOPS were submitted for this cycle"
		alert("CONOPS were submitted for this cycle"); return false;
	
	} 
	//else {
	
		// set indicator to End on chart and do not open dialog and alert that "CONOPS were submitted for this cycle"
		//alert("HELLO lastWSListWithItems, fy: " + lastWSListWithItems +' | '+ fy); return false;
		
	//}


    
	if(lastWSListWithItems.substr(0,3) == "WS1"){
		firstWorksheetUrl		= 	ws1;
    	firstWorksheetTitle		= 	ws1t;
	}
	if(lastWSListWithItems.substr(0,3) == "WS2"){
		firstWorksheetUrl		= 	ws2;
    	firstWorksheetTitle		= 	ws2t;
	}
	if(lastWSListWithItems.substr(0,3) == "WS3"){
		firstWorksheetUrl		= 	ws3;
    	firstWorksheetTitle		= 	ws3t;
	}
	if(lastWSListWithItems.substr(0,3) == "WS4"){
		firstWorksheetUrl		= 	ws4;
    	firstWorksheetTitle		= 	ws4t;
	}
		
	//alert('HEY! '+firstWorksheetUrl+' | '+firstWorksheetTitle); return false;

	positionString = firstWorksheetTitle.substr(0, firstWorksheetTitle.indexOf(":")); // FY 15 Budget Worksheet #1
	//alert(positionString); 
	
	$(".IAIOPADv2CONOPSDevPositionTable").children().children().each(function(){
		var re = new RegExp(CurrentFYforAcceptingCONOPS);
		var ree = /\d{2}/g;
		if($(this).index() == 1){	
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(0).text(ws1t);
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(1).text(ws2t);
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(2).text(ws3t);
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(3).text(ws4t);
			var prevTxt = $(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(4).text();
			prevTxt = prevTxt.replace(ree,CurrentFYforAcceptingCONOPS);
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(4).text(prevTxt);
		}
		if($(this).index() == 4){	
			var thisfy = parseInt(CurrentFYforAcceptingCONOPS)+1; 
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(0).text(ws1t.replace(re,thisfy));
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(1).text(ws2t.replace(re,thisfy));
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(2).text(ws3t.replace(re,thisfy));
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(3).text(ws4t.replace(re,thisfy));
			var prevTxt = $(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(4).text();
			prevTxt = prevTxt.replace(ree,thisfy);
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(4).text(prevTxt);

		}
		if($(this).index() == 7){	
			var thisfy = parseInt(CurrentFYforAcceptingCONOPS)+2;
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(0).text(ws1t.replace(re,thisfy));
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(1).text(ws2t.replace(re,thisfy));
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(2).text(ws3t.replace(re,thisfy));
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(3).text(ws4t.replace(re,thisfy));
			var prevTxt = $(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(4).text();
			prevTxt = prevTxt.replace(ree,thisfy);
			$(this).find(".IAIOPADv2CONOPSDevPositionTitle").eq(4).text(prevTxt);

		}
		
		var thisRowIndex = $(this).index();				
		var indexOfCell = $(this).find("td:contains('"+positionString+"')").addClass("IAIOPADv2CONOPSDevPositionIndicatorCell").index();			
		if(indexOfCell > -1){
			var prevRowIndex = thisRowIndex -1;
			$(this).parent().children().eq(prevRowIndex).children().eq(indexOfCell).addClass("IAIOPADv2CONOPSDevPositionIndicator");
		}						
	
		
	});
	//.IAIOPADv2CONOPSDevProgressRow1a, .IAIOPADv2CONOPSDevProgressRow1b,.IAIOPADv2CONOPSDevProgressRow2a, .IAIOPADv2CONOPSDevProgressRow2b, .IAIOPADv2CONOPSDevProgressRow3a, .IAIOPADv2CONOPSDevProgressRow3b, .IAIOPADv2CONOPSDevProgressRow4a, .IAIOPADv2CONOPSDevProgressRow4b
	// unhide row with active worksheet as per following example
	$(".IAIOPADv2CONOPSDevProgressRow1a").css("display","inline-table"); // example
	$(".IAIOPADv2CONOPSDevProgressRow1b").css("display","inline-table"); // example
	
	openPopUpCONOPSDevPage(firstWorksheetTitle, firstWorksheetUrl);

}
function getFirstWorksheet(wsListTitle, fy, chartRow, i) {		
	this.wsListTitle = wsListTitle;
	this.fy = fy;
	this.i = i;
    this.chartRow = chartRow;
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle(wsListTitle);      
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View>' + 
				'<Query>' + 
					'<Where>' + 
						'<Eq>' + 
							'<FieldRef Name="FY"/>' + 
							'<Value Type="Text">'+fy+'</Value>' + 
						'</Eq>' + 
					'</Where>' + 
				'</Query>' + 
				'<ViewFields>' + 
					'<FieldRef Name="Submitted"/>' + 
				'</ViewFields>' + 
			'</View>');
    this.collListItem = oList.getItems(camlQuery);       
    clientContext.load(collListItem);      
    clientContext.executeQueryAsync(Function.createDelegate(this, this.getFirstWorksheetSucceeded), Function.createDelegate(this, this.getFirstWorksheetFailed));        
}
function getFirstWorksheetSucceeded(sender, args) {         
    var submitted = '';
    var listItemEnumerator = collListItem.getEnumerator();        
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
		submitted = ''+ oListItem.get_item('Submitted');
		//alert(submitted); return false;
		if(submitted == "Yes"){ // skip to end, CONOPS must have been submitted
			chartRow = 0;
			break;
		} else if(submitted == "Reviewed"){ // skip this row, it must have been previewed
			chartRow = chartRow + 1;
			break;
		} 		
    }
    if(submitted == ''){ // no items found, so this is your position
    	//alert('submitted is empty string: '+wsListTitle+' | '+ fy); return false;
    	IAIOPADv2CONOPSDevPositionIndicator(wsListTitle, fy, chartRow);
    } //else if(submitted == 'Reviewed') {
   		// alert('submitted is Reviewed'); return false;

    //} 
   // else if(submitted == 'Yes') {
    	//alert('submitted is Yes'); return false;
    	//IAIOPADv2CONOPSDevPositionIndicator(wsListTitle, fy);

    //} 
    else {
    	//alert('got here '+submitted); return false;
	 	i = i+1; // i will be 0-11 for the 11 elements in the wsListsArray, so all 12 lists will be queried		
		// call to getFirstWorksheetCall will be here
		getFirstWorksheetCall(i,chartRow);
	    // alert(listItemInfo.toString());
    }


}

 

function getFirstWorksheetFailed(sender, args) {
    alert('Request failed. ' + args.get_message());
}




function getCurrentFYforAcceptingCONOPS(){
	var d = new Date();
	var n = d.getFullYear()+1;
	n = n.toString();
	n = n.substr(2);
	return n;
}

function retrieveListItemsReviewSubmit(wsListNumReview, wsReviewCurrentFY, wsReviewFY, wsReviewOTA) {
    
    var wsReviewFYText = "";
    if(wsReviewCurrentFY == wsReviewFY){
    	wsReviewFYText = "CurrentFY";
    }
    if(wsReviewCurrentFY < wsReviewFY){
    	wsReviewFYText = "FutureFYs";
    }
    var wsListReview = "WS" + wsListNumReview.toString() + wsReviewFYText + wsReviewOTA;
    //alert(wsListReview ); return false;
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle(wsListReview);
    
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml('<View>' + 
				'<Query>' + 
					'<Where>' + 
						'<And>' + 
							'<Eq>' + 
								'<FieldRef Name="Submitted"/>' + 
								'<Value Type="Text">No</Value>' + 
							'</Eq>' + 
							'<Eq>' + 
								'<FieldRef Name="FY"/>' + 
								'<Value Type="Text">15</Value>' + 
							'</Eq>' + 
						'</And>' + 
					'</Where>' + 
				'</Query>' + 
				'<ViewFields>' + 
					'<FieldRef Name="LinkTitle"/>' + 
					'<FieldRef Name="AdditionalLineItem"/>' + 
					'<FieldRef Name="Contract"/>' + 
					'<FieldRef Name="ContractFee"/>' + 
					'<FieldRef Name="ContractFeePercentage"/>' + 
					'<FieldRef Name="ContractorRate"/>' + 
					'<FieldRef Name="ContractsSubTotal"/>' + 
					'<FieldRef Name="ContractTotal"/>' + 
					'<FieldRef Name="DutyTitlePosition"/>' + 
					'<FieldRef Name="Employer"/>' + 
					'<FieldRef Name="Funding"/>' + 
					'<FieldRef Name="FY"/>' + 
					'<FieldRef Name="GovLaborMonth"/>' + 
					'<FieldRef Name="GovLaborYear"/>' + 
					'<FieldRef Name="GSLevel"/>' + 
					'<FieldRef Name="HoursPerYear"/>' + 
					'<FieldRef Name="HoursPerYearAmount"/>' + 
					'<FieldRef Name="MilitarySubTotal"/>' + 
					'<FieldRef Name="OTA"/>' + 
					'<FieldRef Name="Remarks"/>' + 
					'<FieldRef Name="Status"/>' + 
					'<FieldRef Name="Submitted"/>' + 
					'<FieldRef Name="Total"/>' + 
				'</ViewFields>' + 
				'<RowLimit>1000</RowLimit>' + 
			'</View>');

    this.collListItem = oList.getItems(camlQuery);       
    clientContext.load(collListItem);      
    clientContext.executeQueryAsync(Function.createDelegate(this, this.retrieveListItemsReviewSubmitSucceeded), Function.createDelegate(this, this.retrieveListItemsReviewSubmitFailed));
}
function retrieveListItemsReviewSubmitSucceeded(sender, args) {
    var listItemInfo = '';
    var listItemEnumerator = collListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        var oListItem = listItemEnumerator.get_current();
        listItemInfo += '\nID: ' + oListItem.get_id() + 
            '\nTitle: ' + oListItem.get_item('Title'); 
            //'\nBody: ' + oListItem.get_item('Body');
    }
    if(listItemInfo.toString().length){
    	// do nothing
    	alert(listItemInfo.toString());
    } else {
    	alert("No items to preview");
    	
    }
    
}
function retrieveListItemsReviewSubmitFailed(sender, args) {
    alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
}

function previewLink(url){
	window.location = url;
} 
function retrieveAllUsersInGroup() { var clientContext = new SP.ClientContext.get_current(); var collGroup = clientContext.get_web().get_siteGroups(); var oGroup = collGroup.getById(20); this.collUser = oGroup.get_users(); clientContext.load(collUser); clientContext.executeQueryAsync(Function.createDelegate(this, this.retrieveAllUsersInGroupSucceeded), Function.createDelegate(this, this.retrieveAllUsersInGroupFailed)); }
function retrieveAllUsersInGroupSucceeded() { var userInfo = ''; var userEnumerator = collUser.getEnumerator(); while (userEnumerator.moveNext()) { var oUser = userEnumerator.get_current(); userInfo += '\nUser: ' + oUser.get_title() + '\nID: ' + oUser.get_id() + '\nEmail: ' + oUser.get_email() + '\nLogin Name: ' + oUser.get_loginName(); } alert("hello" + userInfo); }
function retrieveAllUsersInGroupFailed(sender, args) { alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }
function retrieveAllUsersAllGroupsSpecificProperties() { var clientContext = new SP.ClientContext.get_current(); this.collGroup = clientContext.get_web().get_siteGroups(); clientContext.load(collGroup, 'Include(Title,Id,Users.Include(Title,LoginName))'); clientContext.executeQueryAsync(Function.createDelegate(this, this.retrieveAllUsersAllGroupsSpecificPropertiesSucceeded), Function.createDelegate(this, this.retrieveAllUsersAllGroupsSpecificPropertiesFailed)); }
function retrieveAllUsersAllGroupsSpecificPropertiesSucceeded() { var userInfo = ''; var groupEnumerator = collGroup.getEnumerator(); while (groupEnumerator.moveNext()) { var oGroup = groupEnumerator.get_current(); var collUser = oGroup.get_users(); var userEnumerator = collUser.getEnumerator(); while (userEnumerator.moveNext()) { var oUser = userEnumerator.get_current(); userInfo += '\nGroup ID: ' + oGroup.get_id() + '\nGroup Title: ' + oGroup.get_title() + '\nUser: ' + oUser.get_title() + '\nLogin Name: ' + oUser.get_loginName(); } } alert(userInfo); }
function retrieveAllUsersAllGroupsSpecificPropertiesFailed(sender, args) { alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }
// ----- CONOPS WORKSHEETS -----
function saveWorksheet(wsList, worksheetRows) {
    // alert(worksheetRows[0]);
    // iterate through worksheetRows, split the string into an array and ...
    // alert(wsList); return false;
    var i = 0;
    while (worksheetRows[i]) {
        var rowFieldsAsCommaDelimitedString = worksheetRows[i];
        var worksheetRow = rowFieldsAsCommaDelimitedString.split(",");
        updateWSList(wsList, worksheetRow);
        i++;
    }
}
function updateWSList(wsList, worksheetRow) {
    var clientContext = new SP.ClientContext("/");
    var oList = clientContext.get_web().get_lists().getByTitle(wsList);
    var itemCreateInfo = new SP.ListItemCreationInformation();
    this.oListItem = oList.addItem(itemCreateInfo);
    var i = 0;
    while (worksheetRow[i]) {
        var column = worksheetRow[i];
        i++;
        var columnValue = worksheetRow[i];
        if (columnValue.length) {
            // has value so...
            oListItem.set_item(column, columnValue);
        }
        i++;
    }
    oListItem.update();
    clientContext.load(oListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.updateWSListSucceeded), Function.createDelegate(this, this.updateWSListFailed));
}
function updateWSListSucceeded() {
    if (oListItem.get_id() > -1) {
        SP.UI.ModalDialog.commonModalDialogClose("OK", "Please wait closed"); // closes Please wait message and this worksheet    	
    }
}
function updateWSListFailed(sender, args) {
    alert('Item creation failed. ' + args.get_message());
}
function openPopUpCONOPSDevPage(title, url) {
    // alert(title);
    var args = {
        prevWS: title
    };
    var options = {
        width: 1000,
        height: 600,
        title: title,
        url: url
    };
    SP.UI.ModalDialog.commonModalDialogOpen(url, options, nextCONOPSDevPage, args);
}
function pleaseWaitClosed(dialogResult, returnValue, otaTitle) { SP.UI.ModalDialog.commonModalDialogClose(null, 1); }
function nextCONOPSDevPage(dialogResult, returnValue) {
    var args;
    var otaTitle;
    var prevWS;
    //alert("dialogResult" + dialogResult + "\nreturnValue: "+returnValue);
    if(dialogResult == 0){
    	$(".IAIOPADv2CONOPSDevReload").css("display","block");
    }
    if (returnValue) {
	
        args = this.get_args();
        otaTitle = args.otaTitle;
        prevWS = args.prevWS;
        if (prevWS == ws1t || prevWS.indexOf("#1")>-1) {
            openPopUpCONOPSDevPage(ws2t, ws2);
        }
        if (prevWS == ws2t || prevWS.indexOf("#2")>-1) {
            openPopUpCONOPSDevPage(ws3t, ws3);
        }
        if (prevWS == ws3t || prevWS.indexOf("#3")>-1) {
            openPopUpCONOPSDevPage(ws4t, ws4);
        }
        if (prevWS == ws4t || prevWS.indexOf("#4")>-1) {
            openPopUpCONOPSDevPage("Review/Submit Worksheets", wsReviewSubmit);
        }
        if (returnValue == "Submitted") {
            alert("Thank you for submitting your Worksheets. We will be contacting you shortly.");
        }	

    }
}

// ----- IAIOPADv2_CalendarDashboard -----
$.getScript('/SiteAssets/IAIOPADv2_CalendarDashboard.js', function(){});



function MasterCalendar() {
    if (siteRelURLtopage == "/Lists/Calendar/calendar.aspx") {
        $(".IAIOPADPOCs").hide();
    }
}
function AddFeedbackAndComments() { var options = { url: "/Lists/Feedback%20and%20Comments/NewForm.aspx", dialogReturnValueCallback: AddFeedbackAndCommentsThanks }; SP.UI.ModalDialog.showModalDialog(options); }
function AddFeedbackAndCommentsThanks(dialogResult, returnValue) { if (dialogResult == '1') { alert("Thank you. Your feedback and comments will help us improve this site."); } }
function showProgramPOC(id) { var options = { url: "/Lists/Program%20POCs/DispForm.aspx?ID=" + id }; SP.UI.ModalDialog.showModalDialog(options); }

// ----- UTILITIES -----
function numberAsTwoDigits(num) { var Num = num; return (Num < 10 ? '0' : '') + Num; }
function getParameterByName(name) { name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"); var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search); return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
function onQueryFailed(sender, args) { alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }