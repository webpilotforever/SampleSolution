﻿//alert(OTA);
		//$(".IAIOPADv2CONOPSDevProgressRow1a").css("display","inline-table"); // example
		//$(".IAIOPADv2CONOPSDevProgressRow1b").css("display","inline-table"); // example

			// ----- SET CHART TITLES TO SAME AS HIDDEN LINKS BECAUSE THEY MUST MATCH -----
			//IAIOPADv2CONOPSDevPositionTitle 
			//return false;
			
			// ----- RELOAD BUTTON -----
			$(".IAIOPADv2CONOPSDevReload").click(function(){
				location.reload();
			});
		
			// ----- HIDE IAIOPADv2DoNotDeleteMessage -----
			$(".IAIOPADv2DoNotDeleteMessage").css("display","none");            
            // ----- SET FISCAL YEAR (for accepting CONOPS) -----
			// setting automatically instead of with button as per requirements
			CurrentFYforAcceptingCONOPS = getCurrentFYforAcceptingCONOPS(); // for example: as of Jan 1, 2014 this would be 15
            
            var nextFY = parseInt(CurrentFYforAcceptingCONOPS) + 1;	            
            wsReviewSubmit = $(".ms-rteElement-Callout2").find("a").attr("href");          
            $(".ms-rteElement-Callout2").find("a").addClass("IAIOPADv2CONOPSDevReviewSubmitLink").removeAttr("target").end().prepend("<a class='IAIOPADv2CONOPSDevReviewSubmitImg' href='" + wsReviewSubmit + "'><img src='/SiteAssets/graphics/conopsclipboard.png' style='float:left;clear:right;margin:5px 15px 5px 10px;cursor:pointer;border:none'/></a>");
            $(".ms-asset-icon").closest("a").addClass("IAIOPADv2CONOPSDevWorksheetLink").removeAttr("target");
            $(".IAIOPADv2CONOPSDevWorksheetLink").parent().css("display","none");
            var previewPageLinkTitle = $(".IAIOPADv2CONOPSDevReviewSubmitLink").text();
           	$("#s4-workspace").find("a").each(function () {
                var linkClass = $(this).attr("class");
                var linkTxt = $(this).text();
                var url = "";
                var title = linkTxt;
                if (linkClass == "IAIOPADv2CONOPSDevWorksheetLink" || linkClass == "IAIOPADv2CONOPSDevReviewSubmitLink" || linkClass == "IAIOPADv2CONOPSDevReviewSubmitImg") {
                    if (linkClass == "IAIOPADv2CONOPSDevWorksheetLink") {
                        title = "FY " + CurrentFYforAcceptingCONOPS + " " + linkTxt;
                        $(this).text("FY " + CurrentFYforAcceptingCONOPS + " " + linkTxt);
                        url = $(this).attr("href") + "?currentFY=" + CurrentFYforAcceptingCONOPS + "&nextFY=" + nextFY + "&fy=" + CurrentFYforAcceptingCONOPS + "&ota=" + OTA + "&otaTitle=" + OTAtitle;
                        
                        if (title.indexOf("Worksheet #1") > -1) {
                            ws1 = url;
                            ws1t = title;
                            
                           
                        }
                        if (title.indexOf("Worksheet #2") > -1) {
                            ws2 = url;
                            ws2t = title;
                        }
                        if (title.indexOf("Worksheet #3") > -1) {
                            ws3 = url;
                            ws3t = title;
                        }
                        if (title.indexOf("Worksheet #4") > -1) {
                            ws4 = url;
                            ws4t = title;
                        }
                    }
                    else if (linkClass == "IAIOPADv2CONOPSDevReviewSubmitLink" || linkClass == "IAIOPADv2CONOPSDevReviewSubmitImg") {
                                        
                        url = $(this).attr("href") + "?currentFY=" + CurrentFYforAcceptingCONOPS + "&nextFY=" + nextFY + "&fy=" + CurrentFYforAcceptingCONOPS + "&ota=" + OTA + "&otaTitle=" + OTAtitle;

                        wsReviewSubmit = $(this).attr("href") + "?currentFY=" + CurrentFYforAcceptingCONOPS + "&nextFY=" + nextFY + "&fy=" + CurrentFYforAcceptingCONOPS + "&ota=" + OTA + "&otaTitle=" + OTAtitle;
                        if (linkClass == "IAIOPADv2CONOPSDevReviewSubmitImg") {
                            title = previewPageLinkTitle;
                        }
                    }
                    $(this).attr("href", "javascript:void(0);");
                    $(this).attr("onclick", "openPopUpCONOPSDevPage('" + title + "','" + url + "');");
                }
           	});
           	
           //	alert(ws1 + ' | ' + ws1t); return false;
           	
           	//ExecuteOrDelayUntilScriptLoaded(getFirstWorksheetCall, "sp.ui.dialog.js");
			ExecuteOrDelayUntilScriptLoaded(colorIAIOPADv2CONOPSDevPositionTable, "sp.ui.dialog.js");
            //ExecuteOrDelayUntilScriptLoaded(openFirstWorksheetOnLoad, "sp.ui.dialog.js");
            //function openFirstWorksheetOnLoad() {
            //    openPopUpCONOPSDevPage(firstWorksheetTitle, firstWorksheetUrl);
            //}