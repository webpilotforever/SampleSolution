﻿using System;
using System.Text;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace IAIOPADv2.ProgramDashboard
{
    [ToolboxItemAttribute(false)]
    public class ProgramDashboard : WebPart
    {   
        /// <summary>
        /// The root web of a site collection obtained via SPContect object, so no disposal necessary or recommended as per MS documentation.
        /// </summary>
        /// <remarks>This web part will only query documents from a library on the root web.</remarks>
        SPWeb oWebsiteRoot = SPContext.Current.Site.RootWeb;
        /// <summary>
        /// Query docs for current FY.
        /// </summary>
        /// <remarks>CAML</remarks>
        SPQuery oAssessmentsQuery = new SPQuery();
        /// <summary>
        /// StringBuilder to concatenate table elements.
        /// </summary>
        StringBuilder tableColsHeaderRow;
        StringBuilder tableCols;
        StringBuilder tableColsColored;
        StringBuilder tableRows;
        int tableColSpan;
        /// <summary>
        /// Space-delimited list of document acronymns
        /// </summary>
        string deliverables;

        

        /// <summary>
        /// Web Part property decoration
        /// </summary>
        /// <value>RRI​ ACB​ DAP​ FAP​ QLR​ ADP FAR VSM​ VSM-U</value>
        [WebBrowsable(true), WebDisplayName("Column Headers"), WebDescription("Space-delimited list of deliverables as acronyms: RRI​ ACB​ DAP​ FAP​ QLR​ ADP FAR VSM​ VSM-U"), Personalizable(PersonalizationScope.Shared), Category("Configuration")]
        public string documents
        {
            get
            {
                return (deliverables);
            }
            set
            {
                deliverables = value;
            }
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();
            
            // Uncomment to render this property
            // this.Controls.Add(new LiteralControl(this.deliverables));


            tableColsHeaderRow = new StringBuilder();
            tableCols = new StringBuilder();
            tableColsColored = new StringBuilder();
            tableRows = new StringBuilder();
            tableColSpan = new int();

            LiteralControl oItemHtml;

            SPList oAssessmentsList = oWebsiteRoot.Lists["Assessments"];
            oAssessmentsQuery.Query = "<Where>" +
						"<Eq>" +
							"<FieldRef Name=\"Author\"/>" +
							"<Value Type=\"Integer\">" +
								"<UserID Type=\"Integer\"/>" +
							"</Value>" +
						"</Eq>" +
                "</Where>";

            //oItemHtml = new LiteralControl("<ul id='IAIOPADv2SPDatePickerData'>");
            //this.Controls.Add(oItemHtml);



            //oItemHtml = new LiteralControl(lineItems.ToString());
            //this.Controls.Add(oItemHtml);

            //oItemHtml = new LiteralControl("</ul'>");
            //this.Controls.Add(oItemHtml);




            tableColSpan = 1;

            string[] columnHeaders = this.deliverables.Trim().Split();

            foreach (string columnHeader in columnHeaders)
            {
                // <TD class='ms-rteTableOddCol-default'>RRI​</TD><TD class='ms-rteTableEvenCol-default'>ACB​</TD><TD class='ms-rteTableOddCol-default'>DAP​</TD><TD class='ms-rteTableEvenCol-default'>FAP​</TD><TD class='ms-rteTableOddCol-default'>QLR​</TD><TD class='ms-rteTableEvenCol-default'>ADP​</TD><TD class='ms-rteTableOddCol-default'>FAR​</TD><TD class='ms-rteTableEvenCol-default'>VSM​</TD><TD class='ms-rteTableOddCol-default'>VSM-U​</TD>
                tableCols.Append("<TD class='ms-rteTableEvenCol-default'>" + columnHeader + "​</TD>");
                tableColsColored.Append("<TD class='ms-rteTableOddCol-default'>​</TD>"); // a set of cells based on the number of columnHeaders entered by the user into the web part Configuration
                tableColSpan = tableColSpan + 1;
            }





            oItemHtml = new LiteralControl("<DIV class='IAIOPADv2ProgramDashboardContainer'><DIV class='IAIOPADv2ProgramDashboardInnerDiv'><P style='TEXT-ALIGN: center; FONT-SIZE: 10pt' class='ms-rteThemeForeColor-5-0'>");
            this.Controls.Add(oItemHtml);

            var titleOfWP = this.Title;
            this.Controls.Add(new LiteralControl(titleOfWP));

            oItemHtml = new LiteralControl("</P>");
            this.Controls.Add(oItemHtml);
            //oItemHtml = new LiteralControl("<div class='IAIOPADv2ProgramDashboardKey'><div><span><img alt='Expand Key' src='/_layouts/images/TPMax2.gif' border='0' class='IAIOPADv2ProgramDashboardKeyToggleImg'/></span> Legend </div></div><div class='IAIOPADv2ProgramDashboardKeyTable'><table style='width: 100%'><tr><td>Column</td><td>Column</td><td>Column</td><td>Column</td><td>Due</td></tr><tr><td><div class='IAIOPADv2ProgramDashboardGreen'>&nbsp;</div></td><td><div class='IAIOPADv2ProgramDashboardYellow'>&nbsp;</div></td><td><div class='IAIOPADv2ProgramDashboardRed'>&nbsp;</div></td><td><div class='IAIOPADv2ProgramDashboardBlack'>&nbsp;</div></td><td><div class='IAIOPADv2ProgramDashboardWhite'>&nbsp;</div></td></tr></table></div>");

            oItemHtml = new LiteralControl("<div class='IAIOPADv2ProgramDashboardKey'><div><span><img alt='Expand Key' src='/_layouts/images/TPMax2.gif' border='0' class='IAIOPADv2ProgramDashboardKeyToggleImg'/></span> Legend </div></div><div class='IAIOPADv2ProgramDashboardKeyTable'><table style='width: 100%'><tr><td>Submitted</td><td title='Due in 14 days or less'>Due Soon</td><td>Past Due</td><td>Cancelled</td></tr><tr><td><div class='IAIOPADv2ProgramDashboardGreen'>&nbsp;</div></td><td title='Due in 14 days or less'><div class='IAIOPADv2ProgramDashboardYellow'>&nbsp;</div></td><td><div class='IAIOPADv2ProgramDashboardRed'>&nbsp;</div></td><td><div class='IAIOPADv2ProgramDashboardBlack'>&nbsp;</div></td></tr></table></div>");
            this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("<div class='IAIOPADv2ProgramDashboardTable'><TABLE style='TEXT-ALIGN: center; FONT-SIZE: 1em' class='ms-rteTable-default' cellSpacing='0' summary='Submitted deliverables for current FY assessment events' width='100%'><TBODY>");
            this.Controls.Add(oItemHtml);

            SPListItemCollection collListItems = oAssessmentsList.GetItems(oAssessmentsQuery);
            foreach (SPListItem oListItem in collListItems)
            {
                // if any assessments for this user, build rows
                tableRows.Append("<TR class='ms-rteTableOddRow-default'><TD class='ms-rteTableEvenCol-default'><img src='/SiteAssets/assessmentcheckmark.gif'/>​</TD>" + tableColsColored + "</TR>");
            }





            // oItemHtml = new LiteralControl("<TR class='ms-rteTableOddRow-default'><TD class='ms-rteTableEvenCol-default'>Assess1​</TD><TD class='ms-rteTableOddCol-default ms-rteBackColor-6'>​</TD><TD class='ms-rteTableEvenCol-default ms-rteBackColor-6'>​</TD><TD class='ms-rteTableOddCol-default ms-rteBackColor-6'>​</TD><TD class='ms-rteTableEvenCol-default ms-rteBackColor-4'>​</TD><TD class='ms-rteTableOddCol-default ms-rteBackColor-4'>​</TD><TD class='ms-rteTableEvenCol-default ms-rteBackColor-4'>​</TD><TD class='ms-rteTableOddCol-default ms-rteThemeBackColor-1-0'>​</TD><TD class='ms-rteTableEvenCol-default ms-rteThemeBackColor-1-0'>​</TD><TD class='ms-rteTableOddCol-default ms-rteThemeBackColor-1-0'>​</TD></TR>");

            if (tableRows.Length < 1)
            {
                tableColsHeaderRow.Append("<TR class='ms-rteTableEvenRow-default'><TD class='ms-rteTableEvenCol-default'>​</TD>" + tableColsColored + "</TR>");

                // no assessments message
                tableRows.Append("<TR class='ms-rteTableOddRow-default'><TD class='ms-rteTableEvenCol-default' colspan='" + tableColSpan + "'><div class='IAIOPADv2ProgramDashboardNoAssessmentsMsg'>There are no assessments created by you for this fiscal year in IAIOPADv2. </div>​</TD></TR>");

            }
            else
            {
                tableColsHeaderRow.Append("<TR class='ms-rteTableEvenRow-default'><TD class='ms-rteTableEvenCol-default'>​</TD>" + tableCols.ToString() + "</TR>");

            }




            
            
            
            oItemHtml = new LiteralControl("" + tableColsHeaderRow);
            this.Controls.Add(oItemHtml);


            oItemHtml = new LiteralControl("" + tableRows);
            this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("</TBODY></TABLE></div></DIV></DIV>");
            this.Controls.Add(oItemHtml);


        }
    }
}

