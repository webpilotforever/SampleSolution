﻿using System;
using System.Text;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace IAIOPADv2.CalendarDashboard
{
    [ToolboxItemAttribute(false)]
    public class CalendarDashboard : WebPart
    {
        /// <summary>
        /// The root web of a site collection obtained via SPContect object, so no disposal necessary or recommended as per MS documentation.
        /// </summary>
        /// <remarks>This web part will only query events from a calendar on the root web.</remarks>
        SPWeb oWebsiteRoot = SPContext.Current.Site.RootWeb;
        /// <summary>
        /// Small view of month used to pick date to display in Master Calendar.
        /// </summary>
        /// <remarks>Preferred over using third party mini calendars due to its integration with SharePoint. This control is associated with the Master Calendar only through JavaScript. See onclick event handler. In this instance, we highlight dates that contain one or more events. When user clicks on the date, the event opens in a popup window. If there are several events on the date, the day view of the calendar opens in a popup window.</remarks>
        SPDatePickerControl miniCal;
        /// <summary>
        /// Query events for current month.
        /// </summary>
        /// <remarks>CAML using DateRangesOverlap with ExpandRecurrence to get all events including recurring events. You can also get this information  via a web service call using SPServices in JavaScript, but it takes longer to return the items.</remarks>
        SPQuery oQuery = new SPQuery();
        /// <summary>
        /// StringBuilder to concatenate 'li' elements during build of current events as hidden unordered list.
        /// </summary>
        StringBuilder lineItems;
        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            lineItems = new StringBuilder();

            LiteralControl oItemHtml;

            SPList oList = oWebsiteRoot.Lists["Master Calendar"];
            oQuery.Query = "<Where>" +
                    "<DateRangesOverlap>" +
                        "<FieldRef Name='EventDate' />" +
                        "<FieldRef Name='EndDate' />" +
                        "<FieldRef Name='RecurrenceID' />" +
                        "<Value Type='DateTime'>" +
                            "<Month />" +
                        "</Value>" +
                    "</DateRangesOverlap>" +
                "</Where>";
            oQuery.ExpandRecurrence = true;

            oItemHtml = new LiteralControl("<div id='IAIOPADv2CalendarDashboardContainer'>");
            this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("<div id='IAIOPADv2CalendarDashboardTitle'>");
            this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("<p class='ms-rteThemeForeColor-5-0' style='text-align:center; font-size:10pt; color:#0072bc;'>");
            this.Controls.Add(oItemHtml);

            var titleOfWP = this.Title;
            this.Controls.Add(new LiteralControl(titleOfWP));

            //oItemHtml = new LiteralControl("Calendar Dashboard");
            //this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("</p>");
            this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("</div>");
            this.Controls.Add(oItemHtml);

            miniCal = new SPDatePickerControl();
            miniCal.ShowFooter = false;
            miniCal.ShowNextPrevNavigation = false;
            miniCal.ShowNotThisMonthDays = false;
            miniCal.OnClickScriptHandler = "IAIOPADv2CalendarDashboard"; // see function of same name in IAIOPADv2.js

            this.Controls.Add(miniCal);

            oItemHtml = new LiteralControl("<ul id='IAIOPADv2CalendarDashboardData'>");
            this.Controls.Add(oItemHtml);

            SPListItemCollection collListItems = oList.GetItems(oQuery);
            foreach (SPListItem oListItem in collListItems)
            {
                lineItems.Append("<li class='IAIOPADv2CalendarDashboardsData' iid='" + oListItem.ID + "' title='" + oListItem["Title"] + "' startdate='" + oListItem["EventDate"] + "' enddate='" + oListItem["EndDate"] + "'>" + oListItem.RecurrenceID + "</li>");
            }

            oItemHtml = new LiteralControl(lineItems.ToString());
            this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("</ul>");
            this.Controls.Add(oItemHtml);

            oItemHtml = new LiteralControl("</div>");
            this.Controls.Add(oItemHtml);

        }
    }
}
