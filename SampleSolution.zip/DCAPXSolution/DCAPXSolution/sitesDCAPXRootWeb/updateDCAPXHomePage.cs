﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls.WebParts;
using System.Globalization;
using Microsoft.SharePoint.Administration;
using System.IO;
using System.Xml;
using Microsoft.SharePoint.Navigation;



namespace DCAPXSolution.sitesDCAPXRootWeb
{
    class updateDCAPXHomePage
    {
        
        public static void updatePage(String siteUrl, bool activating, string webPartViewCONOPS)
        {
            string traceInfo = "";
            using(SPSite site = new SPSite(siteUrl))
            {
                using(SPWeb web = site.OpenWeb())
                {
                    SPList sitePagesLibrary = web.GetSitePagesLibrary();

                    EnsureSitePagesLibrary(web, sitePagesLibrary);
                    string OTAlong = "Operational Test Agency";
                    string homePageFileName = SPUtility.GetLocalizedString("$Resources:core,WikiPageHomePageName;", "core", web.Language);
                    string homePageUrl = string.Concat(new object[] {sitePagesLibrary.RootFolder.ServerRelativeUrl, '/', homePageFileName, ".aspx"});
                    SPFile homePage = web.GetFile(homePageUrl);

                    
                    if(homePage.Exists)
                    {
                        if (activating)
                        {






                            ChangeWikiContent(homePage, GenerateNewWikiContent(OTAlong));

                            InsertWebPartIntoWikiPage(homePage, webPartViewCONOPS, "{{1}}");


                          

                            //--------- CONOPS links --------------
                            try
                            {
                                SPNavigationNode nodeCONOPSDevelopment = new SPNavigationNode("Development", web.ServerRelativeUrl + "/SitePages/CONOPSDevelopment.aspx");

                                traceInfo = "create CONOPS Development link if not already exists";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSDevFeature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                if (web.Navigation.QuickLaunch[0].Children.Count < 1) 
                                {
                                    web.AllowUnsafeUpdates = true;
                                    web.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSDevelopment);
                                    web.Update();
                                
                                }
                              
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSDevFeature2Activation", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                SPNavigationNode nodeCONOPSApproval = new SPNavigationNode("Approval", web.ServerRelativeUrl + "/_layouts/DCAPXSolution/CONOPSApproval/CONOPSApproval.aspx");

                                traceInfo = "create CONOPS Approval link if none exists";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSApprovalFeature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                if (web.Navigation.QuickLaunch[0].Children.Count == 1)
                                {
                                    web.AllowUnsafeUpdates = true;
                                    web.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSApproval);
                                    web.Update();
                                }
                              
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSApprovalFeature2Activation", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {

                                SPNavigationNode nodeCONOPSApproval = web.Navigation.QuickLaunch[0].Children[1];
                                string nodeT = nodeCONOPSApproval.Title;
                                string TargetGroups = ";;;;CONOPSApproval,DCAPXAO,DCAPXOwners";


                                traceInfo = "Setting Audience for Approval link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                if (nodeT == "Approval")
                                {
                                    if (nodeCONOPSApproval.Properties.Contains("Audience"))
                                    {

                                        traceInfo = "nodeCONOPSApproval.Properties['Audience']: " + nodeCONOPSApproval.Properties["Audience"].ToString();
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                        nodeCONOPSApproval.Properties["Audience"] = TargetGroups;
                                    }
                                    else
                                    {
                                        nodeCONOPSApproval.Properties.Add("Audience", TargetGroups);
                                    }
                                }
                                else
                                {
                                    traceInfo = "this node, nodeT is not set to Approval: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }

                                nodeCONOPSApproval.Update();
                                web.Update();

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                           
                            
                            
                            //LOOP THROUGH GLOBAL NAVIGATION AND SET AUDIENCE

                            SPNavigationNodeCollection topNavBar = web.Navigation.TopNavigationBar;

                            foreach(SPNavigationNode node in topNavBar)
                            {

                                string nodeT = node.Title;
                                string TargetGroups = "";

                                if (nodeT == "AO Administration Dashboards")
                                {
                                    
                                    try
                                    {
                                        TargetGroups = ";;;;CONOPSApproval,DCAPXAO,DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeAOAdministrationDashboards", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                                else
                                {
                                    traceInfo = "nodeT: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }

                                if (nodeT == "Assessment Management")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeAssessmentManagement", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                                else
                                {
                                    traceInfo = "nodeT: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }

                                if (nodeT == "Research and Analysis")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeResearchandAnalysis", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                                else
                                {
                                    traceInfo = "nodeT: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }


                                node.Update();
                                web.Update();
                            }









                            //LOOP THROUGH GLOBAL QUICK LAUNCH MENU NODES AND SET AUDIENCE

                            SPNavigationNodeCollection quickLaunchMenuNodes = web.Navigation.QuickLaunch;

                            foreach (SPNavigationNode node in quickLaunchMenuNodes)
                            {

                                string nodeT = node.Title;
                                string TargetGroups = "";

                                if (nodeT == "MASR")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeMASR", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                                else
                                {
                                    traceInfo = "nodeT: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }
                                if (nodeT == "Master Calendar")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeMasterCalendar", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                                else
                                {
                                    traceInfo = "nodeT: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }

                                if (nodeT == "DECRE")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeDECRE", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                                else
                                {
                                    traceInfo = "nodeT: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("Feature2Activation", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }
                                node.Update();
                                web.Update();
                            }


                        }
                        else
                        {
                            traceInfo = "Delete web parts from home page.";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("deleteWPHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            

                            //This is for removing web parts from right column

                            try
                            {
                                using (SPLimitedWebPartManager limitedWPM = homePage.GetLimitedWebPartManager(PersonalizationScope.Shared))
                                {
                                    for (int i = limitedWPM.WebParts.Count - 1; i >= 0; i--)
                                    {
                                        limitedWPM.DeleteWebPart(limitedWPM.WebParts[i]);
                                    }

                                  
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("deleteWPHomePage", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            web.AllowUnsafeUpdates = true;

                            homePage.Item["WikiField"] = "";
                            homePage.Update();


                            //--------------
                            traceInfo = "Feature2 deactivating removes CONOPSDevelopment page so clear CONOPS links from QL";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("deleteWPHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            
                            SPNavigationNodeCollection nodesSitesDCAPX = web.Navigation.QuickLaunch;
                            foreach (SPNavigationNode nodeInSitesDCAPX in nodesSitesDCAPX)
                            {
                               
                                traceInfo = "node title:" + (string)nodeInSitesDCAPX.Title + ".";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("deleteWPHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if ("CONOPS" == (string)nodeInSitesDCAPX.Title)
                                {
                                    try
                                    {
                                        
                                        if (nodeInSitesDCAPX.Children.Count > 1)
                                        {
                                            traceInfo = "child node to delete title should be Approval:" + (string)nodeInSitesDCAPX.Children[1].Title + ".";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("deleteWPHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            nodeInSitesDCAPX.Children[1].Delete();
                                            web.AllowUnsafeUpdates = true;
                                            web.Update();
                                        }
                                        if (nodeInSitesDCAPX.Children.Count == 0)
                                        {
                                            traceInfo = "child node to delete title:" + (string)nodeInSitesDCAPX.Children[0].Title + ".";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("deleteWPHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            nodeInSitesDCAPX.Children[0].Delete();
                                            web.AllowUnsafeUpdates = true;
                                            web.Update();
                                        }


                                        
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("clearCONOPSchildren", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }



                                }
                            }
                            //-----------
                        }
                    }



                    ////Feature2 activation will recreate these links if ncessary 

                    //SPNavigationNodeCollection nodesSitesDCAPX = web.Navigation.QuickLaunch;

                    //int incr = 0;
                    //int indexOfCONOPSLink = 0;

                    //foreach (SPNavigationNode nodeInSitesDCAPX in nodesSitesDCAPX)
                    //{

                    //    if ("CONOPS" == (string)nodeInSitesDCAPX.Title) 
                    //    {
                    //        indexOfCONOPSLink = incr;
                    //        try
                    //        {
                    //            if ("Development" != (string)nodeInSitesDCAPX.Children[0].Title)
                    //            {
                    //                //clear children
                    //                foreach (SPNavigationNode nodeInCONOPS in nodeInSitesDCAPX.Children)
                    //                {

                    //                    nodeInCONOPS.Delete();
                    //                    web.AllowUnsafeUpdates = true;
                    //                    web.Update();
                    //                }
                                    
                    //            }
                    //        }
                    //        catch (Exception ex)
                    //        {
                    //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("clearCONOPSchildren", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    //        }
                    //    }
                    //    incr = incr + 1;
                    //}
                   
                    //try
                    //{
                    //    SPNavigationNode nodeCONOPSDevelopment = new SPNavigationNode("Development", web.ServerRelativeUrl + "/SitePages/CONOPSDevelopment.aspx");

                    //    traceInfo = "create CONOPS Development link";
                    //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSDev", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    //    web.AllowUnsafeUpdates = true;
                    //    web.Navigation.QuickLaunch[indexOfCONOPSLink].Children.AddAsLast(nodeCONOPSDevelopment);
                    //    web.Update();
                    //}
                    //catch (Exception ex)
                    //{
                    //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSDev", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    //}

                    //try
                    //{
                    //    SPNavigationNode nodeCONOPSApproval = new SPNavigationNode("Approval", web.ServerRelativeUrl + "/_layouts/DCAPXSolution/CONOPSApproval/CONOPSApproval.aspx");

                    //    traceInfo = "create CONOPS Approval link";
                    //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSApproval", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    //    web.AllowUnsafeUpdates = true;
                    //    web.Navigation.QuickLaunch[indexOfCONOPSLink].Children.AddAsLast(nodeCONOPSApproval);
                    //    web.Update();
                    //}
                    //catch (Exception ex)
                    //{
                    //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addCONOPSApproval", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    //}
                    //try
                    //{

                    //    SPNavigationNode nodeCONOPSApproval = web.Navigation.QuickLaunch[0].Children[1];
                    //    string nodeT = nodeCONOPSApproval.Title;
                    //    string TargetGroups = ";;;;CONOPSApproval,DCAPXAO,DCAPXOwners";


                    //    traceInfo = "Setting Audience for Approval link";
                    //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    //    if (nodeT == "Approval")
                    //    {
                    //        if (nodeCONOPSApproval.Properties.Contains("Audience"))
                    //        {

                    //            traceInfo = "nodeCONOPSApproval.Properties['Audience']: " + nodeCONOPSApproval.Properties["Audience"].ToString();
                    //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    //            nodeCONOPSApproval.Properties["Audience"] = TargetGroups;
                    //        }
                    //        else
                    //        {
                    //            nodeCONOPSApproval.Properties.Add("Audience", TargetGroups);
                    //        }
                    //    }
                    //    else
                    //    {
                    //        traceInfo = "this node, nodeT is not set to Approval: " + nodeT;
                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    //    }

                    //    nodeCONOPSApproval.Update();
                    //    web.Update();

                    //}
                    //catch (Exception ex)
                    //{
                    //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    //}
                    ////end navOp


                }

            }
        }

        public static void ChangeWikiContent(SPFile wikiFile, string content)
        {
            if (wikiFile == null)
            {
                throw new ArgumentNullException("wikiFile");
            }

            wikiFile.Item["WikiField"] = content;
            wikiFile.Item.Update();
        }

        public static string GenerateNewWikiContent(string OTAlong)
        {
            StringBuilder sb = new StringBuilder("");
            StringBuilder column1 = new StringBuilder("");
            StringBuilder column2 = new StringBuilder("");
            
            sb.Append("<table id='layoutsTable' style='width: 100%'><tbody><tr style='vertical-align:top'>");

            // prepare the content of column 1
            column1.Append("<td style='width: 66.6%'><div class='ms-rte-layoutszone-outer' style='width:100%'><div class='ms-rte-layoutszone-inner' style='min-height:60px;word-wrap:break-word'>");
            
            if(OTAlong != "")
            {
                column1.Append("<h1 class=\"ms-rteElement-H1B\">" + OTAlong + " Home</h1>");

            }
            else
            {
                column1.Append("<h1 class=\"ms-rteElement-H1B\">Welcome to your site!</h1>");

            }
            
            
            //column1.Append("<p/>");
            column1.Append("<p class=\"homeBlurb1\">The office of the <b>Director, Operational Test & Evaluation (DOT&E)</b> has created this site to facilitate the exchange of information between <B>DOT&E</b> and its partners.</p>");
            column1.Append("<p class=\"homeBlurb2\">This is the home page of the <b>DOT&E Cybersecurity Assessment Program Exchange (DCAPX)</b> site for the <b>" + OTAlong + "</b>.</p>");
            column1.Append("<p class=\"homeBlurb3\"><b>DCAPX</b> is an application built on the SharePoint platform which contains a growing set of modules designed to help the <b>" + OTAlong + "</b> interface with <b>DOT&E</b>. With <b>DCAPX</b>, we aim to improve our ability to serve you with approvals, scheduling, analysis, and reporting.</p>");

            column1.Append("<p class=\"homeBlurb4\"></p>");
            column1.Append("<p class=\"homeBlurb5\">&nbsp;</p>");
            column1.Append("<p class=\"homeBlurb6\">&nbsp;</p>");
            column1.Append("<div class=\"homeBlurbImage\" style='text-align:center'><img alt='DCAPX Seal' src='/_layouts/Images/DCAPXSolution/DCAPXSeal300x300.png' /></div>");
            //column1.Append("<div class=\"homeBlurbImage\" style='text-align:center'></div>");

            //column1.Append("<div class='afotecCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/afoteccollage.png' /></div>");
            //column1.Append("<div class='atecCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/ateccollage.png' /></div>");
            //column1.Append("<div class='cotfCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/cotfcollage.png' /></div>");
            //column1.Append("<div class='jitcCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/jitccollage.png' /></div>");
            //column1.Append("<div class='mcoteaCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/mcoteacollage.png' /></div>");

            
            
            
            
            column1.Append("<p class=\"homeBlurb7\">&nbsp;</p>");
            // the following is a token that will be replaced by InsertWebPartIntoWikiPage()
            //column1.Append(" {{1}}");

            column1.Append("</div></div></td>");


            // prepare the content of column 2
            column2.Append("<td class='DCAPXHomeRightCol' style='width: 33.3%'><div class='ms-rte-layoutszone-outer' style='width: 100%'><div class='ms-rte-layoutszone-inner' style='min-height: 60px; word-wrap: break-word'>");
            column2.Append(" {{1}}");
            column2.Append("</div></div></td>");

            sb.Append(column1.ToString());
            sb.Append(column2.ToString());
            sb.Append("</tr></tbody></table><span id='layoutsData' style='display: none'>false,false,2</span>");

            return sb.ToString();
           
        }

        public static void InsertWebPartIntoWikiPage(SPFile wikiFile, string webPartViewCONOPS, string replaceToken)
        {
            if (wikiFile == null)
            {
                throw new ArgumentNullException("wikiFile");
            }


            FileStream viewCONOPSWebPart = File.OpenRead(webPartViewCONOPS);

            string str = (string)wikiFile.Item["WikiField"];

            SPLimitedWebPartManager limitedWebPartManager = wikiFile.GetLimitedWebPartManager(PersonalizationScope.Shared);
            string error = string.Empty;
            System.Web.UI.WebControls.WebParts.WebPart webpartViewCONOPSWP = limitedWebPartManager.ImportWebPart(XmlReader.Create(viewCONOPSWebPart), out error);


            if (webpartViewCONOPSWP == null)
            {
                throw new ArgumentNullException("webpart");
            }
            
            
            Guid storageKey = Guid.NewGuid();
            string str2 = StorageKeyToID(storageKey);
            webpartViewCONOPSWP.ID = str2;

            limitedWebPartManager.AddWebPart(webpartViewCONOPSWP, "wpz", 0);


            string str3 = string.Format(CultureInfo.InvariantCulture, "<div class='ms-rtestate-read ms-rte-wpbox' contentEditable='false'><div class='ms-rtestate-read {0}' id='div_{0}'></div><div style='display:none' id='vid_{0}'/></div>", new object[] { storageKey.ToString("D") });
            if (str == null)
            {
                str = str3;
            }
            else
            {
                if (!str.Contains(replaceToken))
                {
                    str = str + str3;
                }
                else
                {
                    str = str.Replace(replaceToken, str3);
                }
            }
            wikiFile.Item["WikiField"] = str;
            wikiFile.Item.Update();
            
           

        }

        public static string StorageKeyToID(Guid storageKey)
        {
            if (!(Guid.Empty == storageKey))
            {
                return ("g_" + storageKey.ToString().Replace('-', '_'));
            }
            return string.Empty;
        }

        private static void EnsureSitePagesLibrary(SPWeb web, SPList sitePagesLibrary)
        {
            if (sitePagesLibrary == null)
            {
                sitePagesLibrary = web.Lists.EnsureSitePagesLibrary();
            }
            if (sitePagesLibrary == null)
            {
                throw new SPException(SPResource.GetString("ListGone", new object[0]));

            }
            if (sitePagesLibrary.BaseTemplate != SPListTemplateType.WebPageLibrary)
            {
                throw new SPException(SPResource.GetString("OnlyInWikiLibraries", new object[0]));
            }
            if(sitePagesLibrary.ParentWeb != web)
            {
                throw new SPException(SPResource.GetString("WikiNotInWebException", new object[0]));
            }
        }




    }
    public static class SharePointExtensions
    {
        public static SPList GetSitePagesLibrary(this SPWeb web)
        {
            SPList wikiList;
            try
            {
                string serverRelativeUrl = web.ServerRelativeUrl;
                if (serverRelativeUrl == "/")
                {
                    serverRelativeUrl = "/SitePages";
                }
                else
                {
                    serverRelativeUrl = serverRelativeUrl + "/SitePages";
                }
                wikiList = web.GetList(serverRelativeUrl);
            }
            catch
            {
                wikiList = null;
            }
            if ((wikiList != null) && (wikiList.BaseTemplate != SPListTemplateType.WebPageLibrary))
            {
                wikiList = null;
            }
            return wikiList;
        }
    }
}

