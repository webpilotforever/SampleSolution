﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Publishing.WebControls;
using Microsoft.SharePoint.WebPartPages;
using System.Web.UI.WebControls.WebParts;
using System.Globalization;
using Microsoft.SharePoint.Administration;
using System.IO;
using System.Xml;
using Microsoft.SharePoint.Navigation;

namespace DCAPXSolution.sitesDCAPXRootWeb
{
    class CONOPSAnnualReset
    {
        internal static void resetCONOPSAnnually(SPList oList, string CurrentFYforAcceptingCONOPS, SPWeb oWeb)
        {
            SPListItemCollection collListItems = oList.Items;

            if (oList.Title == "CONOPSDevProgress")
            {
                //If SubmittedFY < CurrentFYforAcceptingCONOPS clear column values
                foreach (SPListItem oListItem in collListItems)
                {
                    if (oListItem["SubmittedFY"] != null)
                    {
                        if (Int32.Parse((string)oListItem["SubmittedFY"]) < Int32.Parse(CurrentFYforAcceptingCONOPS))
                        {
                            //User will have to have Contributor permissions to the list so will not be done by an OTA
                            //Assumption is that a site admin will be visiting the site 
                            try
                            {
                                oListItem["SubmittedFY"] = "";
                                oListItem["SubmittedBy"] = "";
                                oListItem["SubmittedOn"] = "";

                                if (oListItem.Title == "Current FY")
                                {
                                    oListItem["WS1Progress"] = "In Progress";
                                }
                                else
                                {
                                    oListItem["WS1Progress"] = "Not Started";
                                }                                                               

                                oListItem["WS2Progress"] = "Not Started";
                                oListItem["WS3Progress"] = "Not Started";
                                oListItem["WS4Progress"] = "Not Started";
                                oListItem["WSReview"] = "Not Started";

                                oWeb.AllowUnsafeUpdates = true;
                                oListItem.Update();




                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AnnualResetCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                    }

                }
            }
            if (oList.Title == "CONOPSApprovalProgress")
            {
                //If SubmittedFY < CurrentFYforAcceptingCONOPS clear column values
                foreach (SPListItem oListItem in collListItems)
                {
                    if (oListItem["SubmittedFY"] != null)
                    {
                        if (Int32.Parse((string)oListItem["SubmittedFY"]) < Int32.Parse(CurrentFYforAcceptingCONOPS))
                        {
                            //User will have to have Contributor permissions to the list so will not be done by an OTA
                            //Assumption is that a site admin will be visiting the site 
                            try
                            {
                                oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                oListItem["Submitted"] = "";
                                oListItem["SubmittedFY"] = "";
                                oListItem["SubmittedBy"] = "";
                                oListItem["SubmittedOn"] = "";

                                oWeb.AllowUnsafeUpdates = true;
                                oListItem.Update();

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AnnualResetCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                    }

                }

            }
        }
    }
}
