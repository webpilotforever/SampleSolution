﻿namespace DCAPXSolution.Layouts.SPObjectModelExamples
{
    public partial class ApplicationPage1
    {
    }
}
