﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Navigation;
using System.Collections.Generic;
using System.Reflection;
using System.Collections.Specialized;
using System.IO;

namespace DCAPXSolution.Layouts.SPObjectModelExamples
{
    public partial class ApplicationPage1 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            //Includes examples for the following objects from the Microsoft.SharePoint namespace:
            //SPBaseType
            //SPCheckinType
            //SPCheckout
            //SPContentDatabaseCollection 
            //SPContentType
            //SPContentTypeCollection
            //SPContext
            //SPDiagnosticsService
            //SPException 
            //SPField
            //SPFieldCollection
            //SPFieldMultiChoiceValue
            //SPFieldUserValue
            //SPFile
            //SPFileCollection
            //SPFolder
            //SPGroup
            //SPGroupCollection 
            //SPHttpUtility
            //SPList
            //SPListItem
            //SPListItemCollection
            //SPNavigationNode
            //SPListItemCollection
            //SPPrincipal
            //SPQuery
            //SPRoleAssignment
            //SPRoleType
            //SPSite
            //SPSecurity
            //SPUser
            //SPView
            //SPWeb



            //SPBaseType Example
            SPWeb oWeb1 = SPContext.Current.Web;
            SPList oList = oWeb1.Lists["SampleList"];
            if(oList.BaseType == SPBaseType.DocumentLibrary)
            {
                //do something
            }

            //SPContext Example
            SPWeb oWeb = SPContext.Current.Web;

            //SPCheckout Example
            string templateFilename = "spstd1.aspx";
            string hive = SPUtility.GetGenericSetupPath("TEMPLATE\\1033\\STS\\DOCTEMP\\SMARTPGS\\");
            using (FileStream stream = new FileStream(hive + templateFilename, FileMode.Open))
            {
                string samplepage = "";
                string urlToSitePages = "";
                SPFolder SitePages = oWeb.GetFolder(urlToSitePages);

                SPFileCollection SitePagesFiles = SitePages.Files;

                SPFile newSitePagesFile = SitePagesFiles.Add(samplepage, stream, true);

                if (newSitePagesFile.CheckOutType == SPFile.SPCheckOutType.None)
                {
                    newSitePagesFile.CheckOut();
                }

                //SPCheckinType Example
                string featureName = "";
                newSitePagesFile.CheckIn(string.Format("File added by '{0}' feature", featureName), SPCheckinType.MajorCheckIn);

            }

            //SPContentTypeCollection Example
            SPContentTypeCollection sampleContentTypes = oWeb.ContentTypes;

            //SPContentType Example
            SPContentType sampleCT = oWeb.ContentTypes["SampleCT"];

            //SPContentDatabaseCollection Example
            SPContentDatabaseCollection oWebAppContentDBs = oWeb.Site.WebApplication.ContentDatabases;

            //SPDiagnosticsService Example
            var traceInfo = "";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("sample", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //SPException Example
            throw new SPException(SPResource.GetString("ListGone", new object[0]));

            //SPFieldUserValue Example
            SPFieldUserValue currentUser = new SPFieldUserValue(oWeb, oWeb.CurrentUser.ID, oWeb.CurrentUser.Name);

            //SPFolder, SPFile, SPFileCollection Examples
            using (FileStream stream = new FileStream(hive + templateFilename, FileMode.Open))
            {
                string samplepage = "";
                string urlToSitePages = "";
                SPFolder SitePages = oWeb.GetFolder(urlToSitePages);

                SPFileCollection SitePagesFiles = SitePages.Files;

                SPFile newSitePagesFile = SitePagesFiles.Add(samplepage, stream, true);

            }

            //SPFieldCollection Example
            SPFieldCollection webFields = oWeb.Fields;

            //SPFieldMultiChoiceValue Example
            StringCollection choices = new StringCollection();
            choices.Add("choice1");
            choices.Add("choice2");
            SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
            foreach (string choice in choices)
            {
                values.Add(choice);
            }

            //SPGroupCollection Example
            SPGroupCollection currentUsersGroups = oWeb.CurrentUser.Groups;

            //SPGroup Example
            foreach (SPGroup group in currentUsersGroups)
            {
                string groupName = group.Name;
                
            }

            //SPHttpUtility Example
            string owebTitle = SPHttpUtility.HtmlEncode(oWeb.Title);

            //SPList Example
            SPList oList2 = oWeb.Lists["SampleList"];
            SPQuery oQuery = new SPQuery();
            oQuery.Query = "" +
                    "<Where>" +
                            "<Eq>" +
                                "<FieldRef Name=\"FY\"/>" +
                                "<Value Type=\"Text\">20</Value>" +
                            "</Eq>" +
                    "</Where>";
            
            //SPListItemCollection Example
            SPListItemCollection collListItems = oList.GetItems(oQuery);
            if (collListItems.Count > 0)
            {
                //do something
            }
            
            //SPListItem Example
            foreach (SPListItem oListItem in collListItems)
            {
                string title = oListItem.Title;
            }

            try
            {
                //SPNavigationNodeCollection Example
                SPNavigationNodeCollection nodesSite = oWeb.Navigation.QuickLaunch;
                
                string titleOfQLLink = "";
                
                //SPNavigationNode Example
                foreach (SPNavigationNode nodeInSite in nodesSite)
                {
                    if (nodeInSite.Url.Contains("/SitePages"))
                    {
                        titleOfQLLink = nodeInSite.Title;
                    }
                
                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("sample", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            }

            //SPPrincipal Example
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + "/sites/SiteName"))
            {
                using (SPWeb oWeb2 = oSite.OpenWeb())
                {
                    if (oWeb2.HasUniqueRoleAssignments)
                    {
                        SPRoleAssignmentCollection oRoleAssignments = oWeb2.RoleAssignments;

                        foreach (SPRoleAssignment oRoleAssignment in oRoleAssignments)
                        {
                            SPPrincipal oPrincipal = oRoleAssignment.Member;

                            if (oPrincipal is SPGroup)
                            {
                                try
                                {
                                    SPGroup oRoleGroup = (SPGroup)oPrincipal;
                                    string strGroupName = oRoleGroup.Name;
                                    if (strGroupName == "groupName")
                                    {
                                        //returnVal = true;

                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("sample", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                }
                            }


                        }
                    }

                }
            }

            //SPQuery Example
            SPQuery oQuery2 = new SPQuery();
            oQuery2.Query = "" +
                "<GroupBy Collapse=\"TRUE\" GroupLimit=\"30\">" +
                    "<FieldRef Name=\"TSS\"/>" +
                "</GroupBy>" +
                    "<OrderBy>" +
                        "<FieldRef Name=\"FileLeafRef\"/>" +
                    "</OrderBy>" +
                    "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name=\"FY\"/>" +
                                "<Value Type=\"Text\">20</Value>" +
                            "</Eq>" +
                            "<Neq>" +
                                "<FieldRef Name=\"Submitted\"/>" +
                                "<Value Type=\"Text\">Yes</Value>" +
                            "</Neq>" +
                        "</And>" +
                    "</Where>";

            //SPRoleAssignment Example
            SPList oLib = oWeb.Lists["TestDocs"];
            SPGroup TestSiteOwners = oWeb.SiteGroups["TestSiteOwners"];
         
            if (oLib.HasUniqueRoleAssignments)
            {
                try
                {

                    oWeb.AllowUnsafeUpdates = true; 
                    SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                    SPRoleAssignment roleAssignment = new SPRoleAssignment(TestSiteOwners);
                    roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                    oLib.RoleAssignments.Add(roleAssignment);


                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("sample", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }

            //SPRoleType Example
            SPRoleType Administrator = SPRoleType.Administrator;
            SPRoleType Contributor = SPRoleType.Contributor;
            SPRoleType Reader = SPRoleType.Reader;

            
            string otb = Page.Request.QueryString["otb"];
            string summaryfy = Page.Request.QueryString["summaryFY"];

            
            SPUser user;
            Guid siteID;
            
            //SPSite Example
            //SPSite siteCollection = properties.Feature.Parent as SPSite;
            using (SPSite oSite = new SPSite(Page.Request.Url.ToString()))
            {
                using (SPWeb oWeb3 = oSite.RootWeb)
                {
                    user = oWeb3.CurrentUser;
                    siteID = oSite.ID;
                }
            }

            //SPSecurity Example
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb web = site.RootWeb)
                    {
                        try
                        {
                            SPListItem oListItem = oList.Items.Add();
                            
                            string DraftSavedBy = user.ID + ";#" + user.LoginName;
                            oListItem["DraftSavedBy"] = DraftSavedBy;

                            oListItem["Author"] = currentUser;
                            oListItem["Editor"] = currentUser;

                            web.AllowUnsafeUpdates = true;

                            oListItem.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("sample", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }
            });

            string oUser = Page.User.Identity.Name;
            
            //SPUser Example
            SPUser oSPUser = oWeb.AllUsers[oUser];
            traceInfo = "oSPUser.LoginName: " + oSPUser.LoginName + " oSPUser.ID: " + oSPUser.ID;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("sample", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //SPView Example
            SPView viewlib = oLib.DefaultView;

            //SPWeb Example 
            SPWeb oWeb4 = SPContext.Current.Web; 



        }
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            //SPFeatureReceiverProperties Example
            //SPSite psite = properties.Feature.Parent as SPSite;
        }
    }

}


