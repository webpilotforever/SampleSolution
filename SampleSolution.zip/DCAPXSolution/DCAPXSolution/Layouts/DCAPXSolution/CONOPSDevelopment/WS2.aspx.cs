﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls; 
 
namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSDevelopment
{
    public partial class WS2 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var traceInfo = "WS2";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            LabelOTA.Text = Page.Request.QueryString["ota"];
            LabelWSFY.Text = Page.Request.QueryString["fy"];

            //Table rows-----------------------------------------------------------------------------------

            TableRow headerTitleRow = new TableRow();
            TableRow headerRow = new TableRow();
            TableRow headerDescRow = new TableRow();
            TableRow venueRow = new TableRow();
            TableRow venueSubTotalRow = new TableRow();
            TableRow totalRow = new TableRow();
            TableRow attachmentsRow = new TableRow();
            TableRow attachmentsValRow = new TableRow();

            headerTitleRow.Style.Add("text-align", "center");
            headerRow.CssClass = "CONOPSDevWSColHeaders";
            headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
            headerDescRow.Style.Add("text-align", "center");
            headerDescRow.ID = "headerDescRow";
            venueRow.Style.Add("text-align", "center");
            venueSubTotalRow.Style.Add("text-align", "center");
            totalRow.Style.Add("text-align", "center");
            totalRow.ToolTip = "Total";
            totalRow.ID = "totalRow";
            attachmentsRow.Style.Add("text-align", "center");
            attachmentsValRow.Style.Add("text-align", "center");
            attachmentsValRow.ID = "attachmentsValRow";

            //Table cells------------------------------------------------------------------------------------------

            TableCell headerTitleCell = new TableCell();
            headerTitleCell.ColumnSpan = 8;

            headerTitleCell.Controls.Add(headerTitleCellDiv);

            headerTitleRow.Cells.Add(headerTitleCell);

            CONOPSDevWSTable.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTable

            TableCell wsColCell1 = new TableCell();
            TableCell wsColCell2 = new TableCell();
            TableCell wsColCell3 = new TableCell();
            TableCell wsColCell4 = new TableCell();
            TableCell wsColCell5 = new TableCell();
            TableCell wsColCell6 = new TableCell();
            TableCell wsColCell7 = new TableCell();
            TableCell wsColCell8 = new TableCell();

            wsColCell1.CssClass = "CONOPSDevWSColCell";
            wsColCell2.CssClass = "CONOPSDevWSColCell";
            wsColCell3.CssClass = "CONOPSDevWSColCell";
            wsColCell4.CssClass = "CONOPSDevWSColCell";
            wsColCell5.CssClass = "CONOPSDevWSColCell";
            wsColCell6.CssClass = "CONOPSDevWSColCell";
            wsColCell7.CssClass = "CONOPSDevWSColCell";
            wsColCell8.CssClass = "CONOPSDevWSColCell";

            wsColCell1.Style.Add("width", "200px");
            wsColCell2.Style.Add("width", "155px");
            wsColCell3.Style.Add("width", "155px");
            wsColCell4.Style.Add("width", "155px");
            wsColCell5.Style.Add("width", "155px");
            wsColCell6.Style.Add("width", "155px");
            wsColCell7.Style.Add("width", "155px");
            wsColCell8.Style.Add("width", "155px");

            wsColCell1.Style.Add("font-weight", "bold");
            wsColCell2.Style.Add("font-weight", "bold");
            wsColCell3.Style.Add("font-weight", "bold");
            wsColCell4.Style.Add("font-weight", "bold");
            wsColCell5.Style.Add("font-weight", "bold");
            wsColCell6.Style.Add("font-weight", "bold");
            wsColCell7.Style.Add("font-weight", "bold");
            wsColCell8.Style.Add("font-weight", "bold");

            wsColCell1.Text = "Venue​";
            wsColCell2.Text = "Activity/Event​​";
            wsColCell3.Text = "Dates​";
            wsColCell4.Text = "People​";
            wsColCell5.Text = "Location";
            wsColCell6.Text = "Estimated Travel Costs​​";
            wsColCell7.Text = "Estimated Labor Overtime Costs";
            wsColCell8.Text = "Funding​";

            headerRow.Cells.Add(wsColCell1);
            headerRow.Cells.Add(wsColCell2);
            headerRow.Cells.Add(wsColCell3);
            headerRow.Cells.Add(wsColCell4);
            headerRow.Cells.Add(wsColCell5);
            headerRow.Cells.Add(wsColCell6);
            headerRow.Cells.Add(wsColCell7);
            headerRow.Cells.Add(wsColCell8);

            CONOPSDevWSTable.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTable

            TableCell headerDescRowCell1 = new TableCell();
            TableCell headerDescRowCell2 = new TableCell();
            TableCell headerDescRowCell3 = new TableCell();
            TableCell headerDescRowCell4 = new TableCell();
            TableCell headerDescRowCell5 = new TableCell();
            TableCell headerDescRowCell6 = new TableCell();
            TableCell headerDescRowCell7 = new TableCell();
            TableCell headerDescRowCell8 = new TableCell();

            headerDescRowCell1.Style.Add("font-style", "italic");
            headerDescRowCell2.Style.Add("font-style", "italic");
            headerDescRowCell3.Style.Add("font-style", "italic");
            headerDescRowCell4.Style.Add("font-style", "italic");
            headerDescRowCell5.Style.Add("font-style", "italic");
            headerDescRowCell6.Style.Add("font-style", "italic");
            headerDescRowCell7.Style.Add("font-style", "italic");
            headerDescRowCell8.Style.Add("font-style", "italic");

            headerDescRowCell1.Text = "List the proposed assessment value​";
            headerDescRowCell2.Text = "List every activity/event associated with the proposed assessment​";
            headerDescRowCell3.Text = "List the dates for each activity/event​";
            headerDescRowCell4.Text = "List the number of people attending each activity/event​";
            headerDescRowCell5.Text = "Identify the location for each activity/event (List location by military base, not by the city)";
            headerDescRowCell6.Text = "Estimated travel cost for each activity/event​";
            headerDescRowCell7.Text = "Estimated labor overtime cost for each activity/event";
            headerDescRowCell8.Text = "Total proposed funding level for each activity/event";

            headerDescRow.Cells.Add(headerDescRowCell1);
            headerDescRow.Cells.Add(headerDescRowCell2);
            headerDescRow.Cells.Add(headerDescRowCell3);
            headerDescRow.Cells.Add(headerDescRowCell4);
            headerDescRow.Cells.Add(headerDescRowCell5);
            headerDescRow.Cells.Add(headerDescRowCell6);
            headerDescRow.Cells.Add(headerDescRowCell7);
            headerDescRow.Cells.Add(headerDescRowCell8);

            CONOPSDevWSTable.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTable
             
            TableCell venueValCell1 = new TableCell();
            TableCell venueValCell2 = new TableCell();
            TableCell venueValCell3 = new TableCell();
            TableCell venueValCell4 = new TableCell();
            TableCell venueValCell5 = new TableCell();
            TableCell venueValCell6 = new TableCell();
            TableCell venueValCell7 = new TableCell();
            TableCell venueValCell8 = new TableCell();

            venueValCell1.RowSpan = 2;
            venueValCell1.Style.Add("vertical-align", "middle");
            venueValCell1.Style.Add("text-align", "center");
            venueValCell2.Style.Add("text-align", "center");
            venueValCell3.Style.Add("text-align", "center");
            venueValCell4.Style.Add("text-align", "center");
            venueValCell5.Style.Add("text-align", "center");
            venueValCell6.Style.Add("text-align", "center");
            venueValCell7.Style.Add("text-align", "center");
            venueValCell8.Style.Add("text-align", "center");


            venueValCell1.Text = "Text";
            venueValCell2.Text = "Text";
            venueValCell3.Text = "Text";
            venueValCell4.Text = "00";
            venueValCell5.Text = "Text";
            venueValCell6.Text = "0";
            venueValCell7.Text = "0";
            venueValCell8.Text = "0000";


            venueRow.Cells.Add(venueValCell1);
            venueRow.Cells.Add(venueValCell2);
            venueRow.Cells.Add(venueValCell3);
            venueRow.Cells.Add(venueValCell4);
            venueRow.Cells.Add(venueValCell5);
            venueRow.Cells.Add(venueValCell6);
            venueRow.Cells.Add(venueValCell7);
            venueRow.Cells.Add(venueValCell8);

            CONOPSDevWSTable.Rows.Add(venueRow); //-----------------venueRow added to CONOPSDevWSTable

            TableCell venueSubTotalCell1 = new TableCell();
            TableCell venueSubTotalCell2 = new TableCell();
            TableCell venueSubTotalCell3 = new TableCell();

            venueSubTotalCell1.ColumnSpan = 5;
            venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");

            venueSubTotalCell2.Style.Add("text-align", "right");
            venueSubTotalCell2.Style.Add("font-weight", "bold");
            venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
            venueSubTotalCell2.Text = "Sub-Total:​";

            venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
            venueSubTotalCell3.Text = "0000";

            venueSubTotalRow.Cells.Add(venueSubTotalCell1);
            venueSubTotalRow.Cells.Add(venueSubTotalCell2);
            venueSubTotalRow.Cells.Add(venueSubTotalCell3);

            CONOPSDevWSTable.Rows.Add(venueSubTotalRow); //-----------------venueSubTotalRow added to CONOPSDevWSTable

            TableCell totalRowCell1 = new TableCell();
            TableCell totalRowCell2 = new TableCell();

            totalRowCell1.ColumnSpan = 7;
            totalRowCell1.Style.Add("text-align", "right");
            totalRowCell1.Style.Add("font-weight", "bold");
            totalRowCell1.Style.Add("background-color", "#d0ffbc");
            totalRowCell1.Text = "Total:";
            

            totalRowCell2.Text = "0000";
            totalRowCell2.Style.Add("background-color", "#d0ffbc");

            totalRow.Cells.Add(totalRowCell1);
            totalRow.Cells.Add(totalRowCell2);

            CONOPSDevWSTable.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTable

            TableCell attachmentsRowCell = new TableCell();

            attachmentsRowCell.ColumnSpan = 8;
            attachmentsRowCell.Style.Add("font-weight", "bold");
            attachmentsRowCell.Text = "Attachments";

            attachmentsRow.Cells.Add(attachmentsRowCell);

            CONOPSDevWSTable.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTable

            // use javascript like CONOPSDevReviewSubmitAttachments.js for clicking on attachments
            //	var attLink = "<A onclick=\"return DispEx(this,event,'TRUE','FALSE','FALSE','SharePoint.OpenDocuments.3','1','SharePoint.OpenDocuments','','','','" + _spUserId + "','0','0','0x7fffffffffffffff','','')\" id=\"" + attId + "\" href=\"" + attPath + "\" >" + attName + "</a>";
            // also try favorites how to download a file using asp net

            TableCell attachmentsValRowCell = new TableCell();

            attachmentsValRowCell.ColumnSpan = 8;
            attachmentsValRowCell.Text = "attachment1.text";
            attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

            attachmentsValRow.Cells.Add(attachmentsValRowCell);

            CONOPSDevWSTable.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTable

            
            //================= END OF TABLE TEMPLATE ====================



            int venueSubTotalRowIndex = 5;

            string venueIDLast = "";
            string venueIDFirst = "";

            int venueIDFirstMinus1 = 0;
            int attachmentIndex = 7;


            string TimeDraftSaved = "";
            string TimeDraftSavedSnapShot = "";

            string submittedCAML = "<Neq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Neq>";
            if (Page.Request.QueryString["submitted"] == "yes")
            {
                submittedCAML = "<Eq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Eq>";
            }
            SPWeb oWeb = SPContext.Current.Web;
            //------------- lib -----------------
            SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);

            SPQuery oLibQuery = new SPQuery();

            oLibQuery.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                "</Eq>" +
                                 "<Eq>" +
                                    "<FieldRef Name=\"WS\"/>" +
                                    "<Value Type=\"Text\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

            SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

            if (collLibItems.Count > 0)
            {
                bool removeAttachmentRow = true; 

                foreach (SPListItem oLibItem in collLibItems)
                {


                    SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                    foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                    {
                        if ((string)oListItemVersion["CONOPSApproval"] == "Baseline OTA Submission")
                        {
                            traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow attachmentsValRw = new TableRow();

                            TableCell attachmentsValRwCell = new TableCell();

                            attachmentsValRwCell.ColumnSpan = 8;
                            attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                            attachmentsValRwCell.Style.Add("text-align", "center");

                            string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                            traceInfo = versionUrl;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            Literal LiteralattachmentsValRwCell = new Literal();
                            LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                            attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                            attachmentsValRw.Cells.Add(attachmentsValRwCell);

                            CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                            removeAttachmentRow = false;

                            break;

                        }
                    }

                }

                if (removeAttachmentRow)
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                }

                CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

            }
            else
            {
                CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
            }

        














            //------ list -----------------
            traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

            SPQuery oQuery = new SPQuery();

          

            oQuery.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                            "<And>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                "</Eq>" +
                                submittedCAML +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                              "<Eq>" +
                                    "<FieldRef Name=\"CONOPSApproval\"/>" +
                                    "<Value Type=\"Text\">Baseline OTA Submission</Value>" +
                                "</Eq>" +
                                "</And>" +
                        "</Where>";

            SPListItemCollection collListItems = oList.GetItems(oQuery);

            //oQuery to set vars.
            Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");
            foreach (SPListItem oListItem in collListItems)
            {
                //Only one Total

                if (totalRowCell2.Text == "0000")
                {
                    try
                    {
                        traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        totalRowCell2.Text = oListItem[TotalGUID].ToString();

                        traceInfo = "totalRowCell2.Text: " + totalRowCell2.Text;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }

                try { TimeDraftSaved = oListItem["TimeDraftSaved"].ToString(); }
                catch { }

                traceInfo = "TimeDraftSaved: " + TimeDraftSaved;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                if (TimeDraftSavedSnapShot != "")
                {
                    if (TimeDraftSaved != TimeDraftSavedSnapShot)
                    {

                        traceInfo = "venueIDFirst: " + venueIDFirst;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        break;
                    }
                }
                else
                {

                    TimeDraftSavedSnapShot = oListItem["TimeDraftSaved"].ToString();
                    traceInfo = "TimeDraftSavedSnapShot: " + TimeDraftSavedSnapShot;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                }
                if (venueIDLast == "")
                {
                    venueIDLast = oListItem["ID"].ToString();
                    traceInfo = "venueIDLast: " + venueIDLast;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                }

                venueIDFirst = oListItem["ID"].ToString();

            }

            venueIDFirstMinus1 = Int32.Parse(venueIDFirst) - 1;

            //oQuery2 based on vars.

            SPQuery oQuery2 = new SPQuery();

            oQuery2.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Gt>" +
                                    "<FieldRef Name=\"ID\"/>" +
                                    "<Value Type=\"Integer\">" + venueIDFirstMinus1 + "</Value>" +
                                "</Gt>" +
                                "<Lt>" +
                                    "<FieldRef Name=\"ID\"/>" +
                                    "<Value Type=\"Integer\">" + venueIDLast + "</Value>" + // do not include Total
                                "</Lt>" +
                            "</And>" +
                        "</Where>";

            SPListItemCollection collListItems2 = oList.GetItems(oQuery2);


            foreach (SPListItem oListItem2 in collListItems2)
            {
                TableRow rw = new TableRow();
                string VenueSubTotalStr = "VenueSubTotal";
                if (oListItem2.Title.ToString() == VenueSubTotalStr)
                {
                    TableCell VenueCell = new TableCell();
                    TableCell venueSubTotalCell1b = new TableCell();
                    TableCell venueSubTotalCell2b = new TableCell();
                    TableCell venueSubTotalCell3b = new TableCell();
                    VenueCell.Style.Add("vertical-align", "middle");
                    VenueCell.Style.Add("text-align", "center");
                    venueSubTotalCell1b.ColumnSpan = 5;
                    venueSubTotalCell1b.Style.Add("background-color", "#bfbfbf");

                    venueSubTotalCell2b.Style.Add("text-align", "right");
                    venueSubTotalCell2b.Style.Add("font-weight", "bold");
                    venueSubTotalCell2b.Style.Add("background-color", "#d0ffbc");
                    venueSubTotalCell2b.Text = "Sub-Total:​";

                    venueSubTotalCell3b.Style.Add("background-color", "#d0ffbc");
                    venueSubTotalCell3b.Style.Add("text-align", "center");
                    
                    string Venue = "";
                    try { Venue += oListItem2["Venue"].ToString(); }
                    catch { }
                    string VenueSubTotal = "";
                    try { VenueSubTotal += oListItem2["VenueSubTotal"].ToString(); }
                    catch { }
                    VenueCell.Text = Venue;
                    //VenueCell.ToolTip = VenueSubTotalStr;
                    venueSubTotalCell3b.Text = VenueSubTotal;
                    
                    rw.Cells.Add(VenueCell);
                    rw.Cells.Add(venueSubTotalCell1b);
                    rw.Cells.Add(venueSubTotalCell2b);
                    rw.Cells.Add(venueSubTotalCell3b);

                    rw.ToolTip = "Sub-Total";

                    CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                }
                else
                {
                    TableCell VenueCell = new TableCell();
                    TableCell TitleCell = new TableCell();
                    TableCell DatesCell = new TableCell();
                    TableCell PeopleCell = new TableCell();
                    TableCell EventLocationCell = new TableCell();
                    TableCell EstTravelCell = new TableCell();
                    TableCell EstLaborOvertimeCell = new TableCell();
                    TableCell FundingCell = new TableCell();


                    VenueCell.Style.Add("vertical-align", "middle");
                    VenueCell.Style.Add("text-align", "center");
                    TitleCell.Style.Add("text-align", "center");
                    DatesCell.Style.Add("text-align", "center");
                    PeopleCell.Style.Add("text-align", "center");
                    EventLocationCell.Style.Add("text-align", "center");
                    EstTravelCell.Style.Add("text-align", "center");
                    EstLaborOvertimeCell.Style.Add("text-align", "center");
                    FundingCell.Style.Add("text-align", "center");

                    string Venue = "";
                    string Title = "";
                    string Dates = "";
                    string People = "";
                    string EventLocation = "";
                    string EstTravel = "";
                    string EstLaborOvertime = "";
                    string Funding = "";


                    try { Venue += oListItem2["Venue"].ToString(); }
                    catch { }
                    Title += oListItem2.Title.ToString();
                    try { Dates += oListItem2["Dates"].ToString(); }
                            catch { }
                    try { People += oListItem2["People"].ToString(); }
                            catch { }
                    try { EventLocation += oListItem2["EventLocation"].ToString(); }
                            catch { }
                    try { EstTravel += oListItem2["EstTravel"].ToString(); }
                            catch { }
                    try { EstLaborOvertime += oListItem2["EstLaborOvertime"].ToString(); }
                            catch { }
                    try { Funding += oListItem2["Funding"].ToString(); }
                    catch { }


                    VenueCell.Text = Venue;
                    //VenueCell.ToolTip = "Venue";
                    TitleCell.Text = Title;
                    DatesCell.Text = Dates;
                    PeopleCell.Text = People;
                    EventLocationCell.Text = EventLocation;
                    EstTravelCell.Text = EstTravel;
                    EstLaborOvertimeCell.Text = EstLaborOvertime;
                    FundingCell.Text = Funding;


                    rw.Cells.Add(VenueCell);
                    rw.Cells.Add(TitleCell);
                    rw.Cells.Add(DatesCell);
                    rw.Cells.Add(PeopleCell);
                    rw.Cells.Add(EventLocationCell);
                    rw.Cells.Add(EstTravelCell);
                    rw.Cells.Add(EstLaborOvertimeCell);
                    rw.Cells.Add(FundingCell);

                    rw.ToolTip = "Item";

                    CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                }
            }

            try
            {
                CONOPSDevWSTable.Controls.Remove(venueRow);
                CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
            

            TableRowCollection rows = CONOPSDevWSTable.Rows;
            int rowCount = 0;
            int rowSpanCount = 0;
            TableRow rowToUpdate = null;
            
            //RemoveCells
            //Set RowSpan
            try
            {
                foreach (TableRow row in rows)
                {
                    rowCount = rowCount + 1;

                    if (rowCount > 3)
                    {
                        rowSpanCount = rowSpanCount + 1;

                        if (row.ID == "totalRow")
                        {
                            break;
                        }
                        else if (row.ToolTip == "Sub-Total")
                        {
                            rowToUpdate.Cells[0].RowSpan = rowSpanCount;
                            rowToUpdate.Cells[0].ToolTip = "Venue";

                            row.Cells.RemoveAt(0);

                            rowSpanCount = 0;
                        }
                        else if (row.ToolTip == "Item")
                        {
                            if (rowSpanCount > 1)
                            {
                                row.Cells.RemoveAt(0);
                            }
                            else
                            {
                                rowToUpdate = row;
                            }

                        }
                    }

                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }


        
    }
}


