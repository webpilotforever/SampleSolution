﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls; 

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSDevelopment
{
    public partial class WS4 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var traceInfo = "WS4";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            LabelOTA.Text = Page.Request.QueryString["ota"];
            LabelWSFY.Text = Page.Request.QueryString["fy"];

            //Table rows-----------------------------------------------------------------------------------

            TableRow headerTitleRow = new TableRow();
            TableRow headerRow = new TableRow();
            TableRow headerDescRow = new TableRow();
            TableRow itemRow = new TableRow();
            TableRow totalRow = new TableRow();
            TableRow attachmentsRow = new TableRow();
            TableRow attachmentsValRow = new TableRow();

            headerTitleRow.Style.Add("text-align", "center");
            headerRow.CssClass = "CONOPSDevWSColHeaders";
            headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
            headerDescRow.Style.Add("text-align", "center");
            itemRow.Style.Add("text-align", "center");
            totalRow.Style.Add("text-align", "center");
            attachmentsRow.Style.Add("text-align", "center");
            attachmentsValRow.Style.Add("text-align", "center");

            //Table cells------------------------------------------------------------------------------------------

            TableCell headerTitleCell = new TableCell();
            headerTitleCell.ColumnSpan = 4;

            headerTitleCell.Controls.Add(headerTitleCellDiv);

            headerTitleRow.Cells.Add(headerTitleCell);

            CONOPSDevWSTable.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTable

            TableCell wsColCell1 = new TableCell();
            TableCell wsColCell2 = new TableCell();
            TableCell wsColCell3 = new TableCell();
            TableCell wsColCell4 = new TableCell();


            wsColCell1.CssClass = "CONOPSDevWSColCell";
            wsColCell2.CssClass = "CONOPSDevWSColCell";
            wsColCell3.CssClass = "CONOPSDevWSColCell";
            wsColCell4.CssClass = "CONOPSDevWSColCell";


            wsColCell1.Style.Add("width", "200px");
            wsColCell2.Style.Add("width", "155px");
            wsColCell3.Style.Add("width", "155px");
            wsColCell4.Style.Add("width", "155px");


            wsColCell1.Style.Add("font-weight", "bold");
            wsColCell2.Style.Add("font-weight", "bold");
            wsColCell3.Style.Add("font-weight", "bold");
            wsColCell4.Style.Add("font-weight", "bold");


            wsColCell1.Text = "Item Description";
            wsColCell2.Text = "Number";
            wsColCell3.Text = "Remarks​";
            wsColCell4.Text = "Funding​";


            headerRow.Cells.Add(wsColCell1);
            headerRow.Cells.Add(wsColCell2);
            headerRow.Cells.Add(wsColCell3);
            headerRow.Cells.Add(wsColCell4);


            CONOPSDevWSTable.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTable

            TableCell headerDescRowCell1 = new TableCell();
            TableCell headerDescRowCell2 = new TableCell();
            TableCell headerDescRowCell3 = new TableCell();
            TableCell headerDescRowCell4 = new TableCell();


            headerDescRowCell1.Style.Add("font-style", "italic");
            headerDescRowCell2.Style.Add("font-style", "italic");
            headerDescRowCell3.Style.Add("font-style", "italic");
            headerDescRowCell4.Style.Add("font-style", "italic");


            headerDescRowCell1.Text = "Provide a description of each item, service, or training course";
            headerDescRowCell2.Text = "Identify the number of items for purchase or the number of people attending the training​";
            headerDescRowCell3.Text = "Provide any comments to help clarify your cost estimates​";
            headerDescRowCell4.Text = "Estimated cost for each item/service/training course";


            headerDescRow.Cells.Add(headerDescRowCell1);
            headerDescRow.Cells.Add(headerDescRowCell2);
            headerDescRow.Cells.Add(headerDescRowCell3);
            headerDescRow.Cells.Add(headerDescRowCell4);


            CONOPSDevWSTable.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTable

            TableCell itemValCell1 = new TableCell();
            TableCell itemValCell2 = new TableCell();
            TableCell itemValCell3 = new TableCell();
            TableCell itemValCell4 = new TableCell();



            itemValCell1.Style["padding-left"] = "3px";
            itemValCell2.Style["text-align"] = "center";
            itemValCell3.Style["padding-left"] = "3px";
            itemValCell4.Style["text-align"] = "center";


            itemValCell1.Text = "Text";
            itemValCell2.Text = "00";
            itemValCell3.Text = "Text";
            itemValCell4.Text = "0";
          



            itemRow.Cells.Add(itemValCell1);
            itemRow.Cells.Add(itemValCell2);
            itemRow.Cells.Add(itemValCell3);
            itemRow.Cells.Add(itemValCell4);
            


            CONOPSDevWSTable.Rows.Add(itemRow); //-----------------itemRow added to CONOPSDevWSTable

            TableCell totalRowCell1 = new TableCell();
            TableCell totalRowCell2 = new TableCell();

            totalRowCell1.ColumnSpan = 3;
            totalRowCell1.Style.Add("text-align", "right");
            totalRowCell1.Style.Add("font-weight", "bold");
            totalRowCell1.Style.Add("background-color", "#d0ffbc");
            totalRowCell1.Text = "Total:";

            totalRowCell2.Text = "0000";
            totalRowCell2.Style.Add("background-color", "#d0ffbc");

            totalRow.Cells.Add(totalRowCell1);
            totalRow.Cells.Add(totalRowCell2);

            CONOPSDevWSTable.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTable

            TableCell attachmentsRowCell = new TableCell();

            attachmentsRowCell.ColumnSpan = 4;
            attachmentsRowCell.Style.Add("font-weight", "bold");
            attachmentsRowCell.Text = "Attachments";

            attachmentsRow.Cells.Add(attachmentsRowCell);

            CONOPSDevWSTable.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTable

            // use javascript like CONOPSDevReviewSubmitAttachments.js for clicking on attachments
            //	var attLink = "<A onclick=\"return DispEx(this,event,'TRUE','FALSE','FALSE','SharePoint.OpenDocuments.3','1','SharePoint.OpenDocuments','','','','" + _spUserId + "','0','0','0x7fffffffffffffff','','')\" id=\"" + attId + "\" href=\"" + attPath + "\" >" + attName + "</a>";
            // also try favorites how to download a file using asp net

            TableCell attachmentsValRowCell = new TableCell();

            attachmentsValRowCell.ColumnSpan = 4;
            attachmentsValRowCell.Text = "attachment1.text";
            attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

            attachmentsValRow.Cells.Add(attachmentsValRowCell);

            CONOPSDevWSTable.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTable


            //================= END OF TABLE TEMPLATE ====================



            int itemRowIndex = 4;
            
            string itemIDLast = "";
            string itemIDFirst = "";

            int itemIDFirstMinus1 = 0;
            int attachmentIndex = 6;

          
            
            string TimeDraftSaved = "";
            string TimeDraftSavedSnapShot = "";

            string submittedCAML = "<Neq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Neq>";    
            if (Page.Request.QueryString["submitted"] == "yes")
            {
                submittedCAML = "<Eq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Eq>";
            }

            SPWeb oWeb = SPContext.Current.Web;
            //------------- lib -----------------
            SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);
            SPQuery oLibQuery = new SPQuery();
            oLibQuery.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                "</Eq>" +
                                 "<Eq>" +
                                    "<FieldRef Name=\"WS\"/>" +
                                    "<Value Type=\"Text\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";
            SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);
            if (collLibItems.Count > 0)
            {
                bool removeAttachmentRow = true;
                
                foreach (SPListItem oLibItem in collLibItems)
                {
                    SPListItemVersionCollection collListItemVersions = oLibItem.Versions;
                    foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                    {
                        if ((string)oListItemVersion["CONOPSApproval"] == "Baseline OTA Submission")
                        {
                            traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            TableRow attachmentsValRw = new TableRow();
                            TableCell attachmentsValRwCell = new TableCell();
                            attachmentsValRwCell.ColumnSpan = 4;
                            attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                            attachmentsValRwCell.Style.Add("text-align", "center");
                            string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            
                            traceInfo = versionUrl;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            Literal LiteralattachmentsValRwCell = new Literal();
                            LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";
                            attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);
                            attachmentsValRw.Cells.Add(attachmentsValRwCell);
                            CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                            removeAttachmentRow = false;

                            break;
                        }
                    }
                }

                if (removeAttachmentRow)
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                }

                CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

            }
            else
            {
                CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
            }

  


            traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

            SPQuery oQuery = new SPQuery();

       

            oQuery.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                            "<And>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                "</Eq>" + 
                                submittedCAML +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                              "<Eq>" +
                                    "<FieldRef Name=\"CONOPSApproval\"/>" +
                                    "<Value Type=\"Text\">Baseline OTA Submission</Value>" +
                                "</Eq>" +
                                "</And>" +
                        "</Where>";
            
            SPListItemCollection collListItems = oList.GetItems(oQuery);

            //oQuery to set vars.
            Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");
            foreach (SPListItem oListItem in collListItems)
            {
                //Only one Total

                if (totalRowCell2.Text == "0000")
                {
                    try
                    {
                        traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        totalRowCell2.Text = oListItem[TotalGUID].ToString();

                        traceInfo = "totalRowCell2.Text: " + totalRowCell2.Text;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }

                try { TimeDraftSaved = oListItem["TimeDraftSaved"].ToString(); }
                catch { }
                
                traceInfo = "TimeDraftSaved: " + TimeDraftSaved;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                if (TimeDraftSavedSnapShot != "")
                {
                    if (TimeDraftSaved != TimeDraftSavedSnapShot)
                    {

                        traceInfo = "itemIDFirst: " + itemIDFirst;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        break;
                    }
                }
                else
                {
                    
                    TimeDraftSavedSnapShot = oListItem["TimeDraftSaved"].ToString();
                    traceInfo = "TimeDraftSavedSnapShot: " + TimeDraftSavedSnapShot;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                }
                if (itemIDLast == "")
                {
                    itemIDLast = oListItem["ID"].ToString();
                    traceInfo = "itemIDLast: " + itemIDLast;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                }
                
                itemIDFirst = oListItem["ID"].ToString();

                

                
                
            }
            try
            {
                itemIDFirstMinus1 = Int32.Parse(itemIDFirst) - 1;
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
            //oQuery2 based on vars set to get items.

            SPQuery oQuery2 = new SPQuery();

            oQuery2.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Gt>" +
                                    "<FieldRef Name=\"ID\"/>" +
                                    "<Value Type=\"Integer\">" + itemIDFirstMinus1 + "</Value>" +
                                "</Gt>" +
                                "<Lt>" +
                                    "<FieldRef Name=\"ID\"/>" +
                                    "<Value Type=\"Integer\">" + itemIDLast + "</Value>" + // do not include Total
                                "</Lt>" + 
                            "</And>" +
                        "</Where>";
           
            SPListItemCollection collListItems2 = oList.GetItems(oQuery2);

            //AddAt

            foreach (SPListItem oListItem2 in collListItems2)
            {
                TableRow rw = new TableRow();
                
                TableCell ItemDescriptionCell = new TableCell();
                TableCell NumberCell = new TableCell();
                TableCell RemarksCell = new TableCell();
                TableCell FundingCell = new TableCell();

                ItemDescriptionCell.Style["padding-left"] = "3px";
                NumberCell.Style["text-align"] = "center";
                RemarksCell.Style["padding-left"] = "3px";
                FundingCell.Style["text-align"] = "center";

                string ItemDescription = "";
                string Number = "";
                string Remarks = "";
                string Funding = "";

                ItemDescription += oListItem2.Title.ToString();
                try { Number += oListItem2["Number"].ToString(); }
                catch { }
                try { if (oListItem2["Remarks"] != null) { Remarks += oListItem2["Remarks"].ToString(); } }
                            catch { }
                try { Funding += oListItem2["Funding"].ToString(); }
                catch { }

                ItemDescriptionCell.Text = ItemDescription;
                NumberCell.Text = Number;
                RemarksCell.Text = Remarks;
                FundingCell.Text = Funding;



                rw.Cells.Add(ItemDescriptionCell);
                rw.Cells.Add(NumberCell);
                rw.Cells.Add(RemarksCell);
                rw.Cells.Add(FundingCell);


                CONOPSDevWSTable.Rows.AddAt(itemRowIndex, rw);

            }
           try
           {
            
               CONOPSDevWSTable.Controls.Remove(itemRow);
           }
           catch (Exception ex)
           {
               SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
           }

            
        }

    }
}
