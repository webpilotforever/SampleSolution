﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSDevelopment
{
    class ViewCONOPSWPWS3
    {
        internal static void viewCONOPSforWS3(Table CONOPSDevWSTableWS3, HtmlGenericControl headerTitleCellDivWS3, string qs_otashort, string qs_ota, string qs_fy, HiddenField itemIDFirstHidden, HiddenField itemIDLastHidden)
        {
            var traceInfo = "ViewCONOPSWS3";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            bool wsIsSubmitted = false;
            //Query CONOPSApprovalProgress
            //Query if submitted, then build table else update lable

            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where>" +
                "<And><And>" +
                    "<Eq>" +
                        "<FieldRef Name='OperationalTestAgency'/>" +
                            "<Value Type='Choice'>" + qs_otashort + "</Value>" +
                     "</Eq>" +
                     "<Eq>" +
                        "<FieldRef Name='Submitted'/>" +
                            "<Value Type='Text'>Yes</Value>" +
                        "</Eq>" +
                "</And>" +
                 "<Eq>" +
                        "<FieldRef Name='Title'/>" +
                            "<Value Type='Text'>WS3</Value>" +
                        "</Eq>" +
                "</And>" +
            "</Where>";

            SPListItemCollection collItemsSubmitted = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            if (collItemsSubmitted.Count > 0)
            {

                wsIsSubmitted = true;
            }


            if (wsIsSubmitted)
            {
                TableRowCollection rows = CONOPSDevWSTableWS3.Rows;

                int eventRowIndex = 4;
                int attachmentIndex = 6;
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                //Table rows-----------------------------------------------------------------------------------

                TableRow headerTitleRow = new TableRow();
                TableRow headerRow = new TableRow();
                TableRow headerDescRow = new TableRow();
                TableRow eventRow = new TableRow();
                TableRow totalRow = new TableRow();
                TableRow attachmentsRow = new TableRow();
                TableRow attachmentsValRow = new TableRow();

                headerTitleRow.Style.Add("text-align", "center");
                headerRow.CssClass = "CONOPSDevWSColHeaders";
                headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
                headerDescRow.Style.Add("text-align", "center");
                eventRow.Style.Add("text-align", "center");
                totalRow.Style.Add("text-align", "center");
                attachmentsRow.Style.Add("text-align", "center");
                attachmentsValRow.Style.Add("text-align", "center");

                //Table cells------------------------------------------------------------------------------------------

                TableCell headerTitleCell = new TableCell();
                headerTitleCell.ColumnSpan = 5;

                headerTitleCell.Controls.Add(headerTitleCellDivWS3);

                headerTitleRow.Cells.Add(headerTitleCell);

                CONOPSDevWSTableWS3.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTableWS3

                TableCell wsColCell1 = new TableCell();
                TableCell wsColCell2 = new TableCell();
                TableCell wsColCell3 = new TableCell();
                TableCell wsColCell4 = new TableCell();
                TableCell wsColCell5 = new TableCell();

                //TableCell wsColCell6 = new TableCell();
                //TableCell wsColCell7 = new TableCell();

                wsColCell1.CssClass = "CONOPSDevWSColCell";
                wsColCell2.CssClass = "CONOPSDevWSColCell";
                wsColCell3.CssClass = "CONOPSDevWSColCell";
                wsColCell4.CssClass = "CONOPSDevWSColCell";
                wsColCell5.CssClass = "CONOPSDevWSColCell";


                //wsColCell6.CssClass = "CONOPSDevWSColCell";
                //wsColCell7.CssClass = "CONOPSDevWSColCell";
                //wsColCell6.Style.Add("width", "163px");
                //wsColCell7.Style.Add("width", "163px");
                //wsColCell6.Style.Add("font-weight", "bold");
                //wsColCell7.Style.Add("font-weight", "bold");

                wsColCell1.Style.Add("width", "200px");
                wsColCell2.Style.Add("width", "155px");
                wsColCell3.Style.Add("width", "155px");
                wsColCell4.Style.Add("width", "155px");
                wsColCell5.Style.Add("width", "155px");


                wsColCell1.Style.Add("font-weight", "bold");
                wsColCell2.Style.Add("font-weight", "bold");
                wsColCell3.Style.Add("font-weight", "bold");
                wsColCell4.Style.Add("font-weight", "bold");
                wsColCell5.Style.Add("font-weight", "bold");


                wsColCell1.Text = "Event Name​";
                wsColCell2.Text = "People";
                wsColCell3.Text = "Dates​";
                wsColCell4.Text = "Remarks​";
                wsColCell5.Text = "Funding";


                headerRow.Cells.Add(wsColCell1);
                headerRow.Cells.Add(wsColCell2);
                headerRow.Cells.Add(wsColCell3);
                headerRow.Cells.Add(wsColCell4);
                headerRow.Cells.Add(wsColCell5);


                CONOPSDevWSTableWS3.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTableWS3

                TableCell headerDescRowCell1 = new TableCell();
                TableCell headerDescRowCell2 = new TableCell();
                TableCell headerDescRowCell3 = new TableCell();
                TableCell headerDescRowCell4 = new TableCell();
                TableCell headerDescRowCell5 = new TableCell();

                //TableCell headerDescRowCell6 = new TableCell();
                //TableCell headerDescRowCell7 = new TableCell();

                headerDescRowCell1.Style.Add("font-style", "italic");
                headerDescRowCell2.Style.Add("font-style", "italic");
                headerDescRowCell3.Style.Add("font-style", "italic");
                headerDescRowCell4.Style.Add("font-style", "italic");
                headerDescRowCell5.Style.Add("font-style", "italic");

                //headerDescRowCell6.Style.Add("font-style", "italic");
                //headerDescRowCell7.Style.Add("font-style", "italic");

                headerDescRowCell1.Text = "Identify each event";
                headerDescRowCell2.Text = "List the number of people attending each event​";
                headerDescRowCell3.Text = "List the dates for each event​";
                headerDescRowCell4.Text = "Provide any comments to help clarify your cost estimates";
                headerDescRowCell5.Text = "Estimated cost for each event​";

                //headerDescRowCell6.Text = "Reviewer approval";
                //headerDescRowCell7.Text = "Reviewer comments";

                headerDescRow.Cells.Add(headerDescRowCell1);
                headerDescRow.Cells.Add(headerDescRowCell2);
                headerDescRow.Cells.Add(headerDescRowCell3);
                headerDescRow.Cells.Add(headerDescRowCell4);
                headerDescRow.Cells.Add(headerDescRowCell5);


                CONOPSDevWSTableWS3.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTableWS3

                TableCell eventValCell1 = new TableCell();
                TableCell eventValCell2 = new TableCell();
                TableCell eventValCell3 = new TableCell();
                TableCell eventValCell4 = new TableCell();
                TableCell eventValCell5 = new TableCell();

                //TableCell eventValCell6 = new TableCell();
                //TableCell eventValCell7 = new TableCell();

                eventValCell1.Style["padding-left"] = "3px";
                eventValCell2.Style["text-align"] = "center";
                eventValCell3.Style["text-align"] = "center";
                eventValCell4.Style["padding-left"] = "3px";
                eventValCell5.Style["text-align"] = "center";

                eventValCell1.Text = "Text";
                eventValCell2.Text = "00";
                eventValCell3.Text = "Text";
                eventValCell4.Text = "Text";
                eventValCell5.Text = "0000";



                eventRow.Cells.Add(eventValCell1);
                eventRow.Cells.Add(eventValCell2);
                eventRow.Cells.Add(eventValCell3);
                eventRow.Cells.Add(eventValCell4);
                eventRow.Cells.Add(eventValCell5);


                CONOPSDevWSTableWS3.Rows.Add(eventRow); //-----------------eventRow added to CONOPSDevWSTableWS3

                TableCell totalRowCell1 = new TableCell();
                TableCell totalRowCell2 = new TableCell();

                //TableCell totalRowCell3 = new TableCell();
                //TableCell totalRowCell4 = new TableCell();

                totalRowCell1.ColumnSpan = 4;
                totalRowCell1.Style.Add("text-align", "right");
                totalRowCell1.Style.Add("font-weight", "bold");
                totalRowCell1.Style.Add("background-color", "#d0ffbc");
                totalRowCell1.Text = "Total:";

                totalRowCell2.Text = "0000";
                totalRowCell2.Style.Add("background-color", "#d0ffbc");

                totalRow.Cells.Add(totalRowCell1);
                totalRow.Cells.Add(totalRowCell2);

                CONOPSDevWSTableWS3.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTableWS3

                TableCell attachmentsRowCell = new TableCell();

                //TableCell attachmentsRowCell2 = new TableCell();
                //TableCell attachmentsRowCell3 = new TableCell();

                attachmentsRowCell.ColumnSpan = 5;
                attachmentsRowCell.Style.Add("font-weight", "bold");
                attachmentsRowCell.Text = "Attachments";

                attachmentsRow.Cells.Add(attachmentsRowCell);

                CONOPSDevWSTableWS3.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTableWS3

                TableCell attachmentsValRowCell = new TableCell();

                //TableCell attachmentsValRowCell2 = new TableCell();
                //TableCell attachmentsValRowCell3 = new TableCell();

                attachmentsValRowCell.ColumnSpan = 5;
                attachmentsValRowCell.Text = "attachment1.text";
                attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

                attachmentsValRow.Cells.Add(attachmentsValRowCell);

                CONOPSDevWSTableWS3.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTableWS3

                //================= END OF TABLE TEMPLATE ====================      

                SPList oLib = SPContext.Current.Web.GetList(SPContext.Current.Web.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);

                SPQuery oLibQuery = new SPQuery();
                oLibQuery.Query = "" +
                   "<OrderBy>" +
                       "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                   "</OrderBy>" +
                   "<Where>" +
                       "<And>" +
                           "<Eq>" +
                               "<FieldRef Name=\"FY\"/>" +
                               "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                           "</Eq>" +
                            "<Eq>" +
                               "<FieldRef Name=\"WS\"/>" +
                               "<Value Type=\"Text\">WS3</Value>" +
                           "</Eq>" +
                       "</And>" +
                   "</Where>";
                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();

                                attachmentsValRwCell.ColumnSpan = 5;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = SPContext.Current.Web.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                CONOPSDevWSTableWS3.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTableWS3.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTableWS3.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTableWS3.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTableWS3.Controls.Remove(attachmentsValRow);
                }

                SPList oList = SPContext.Current.Web.Lists["CONOPSDevWS" + qs_otashort];

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy><Where>" +
                    "<And><And><And><And>" +
                        "<Eq>" +
                            "<FieldRef Name='CONOPSApproval'/>" +
                                "<Value Type='Choice'>Deputy Director Approval</Value>" +
                         "</Eq>" +
                         "<Eq>" +
                            "<FieldRef Name='ContentType'/>" +
                                "<Value Type='Computed'>WS3</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Eq>" +
                            "<FieldRef Name='FY'/>" +
                                "<Value Type='Text'>" + qs_fy + "</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Not Approved</Value>" +
                            "</Neq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Pending</Value>" +
                            "</Neq>" +
                    "</And>" +
                "</Where>";

                traceInfo = "collListItems next...";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPListItemCollection collListItems = oList.GetItems(oQuery);



                if (collListItems.Count > 0)
                {
                    foreach (SPListItem oListItem in collListItems)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        if (oListItem[TotalGUID] != null)
                        {
                            try
                            {
                                traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                totalRowCell2.Text = oListItem[TotalGUID].ToString();


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents5", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                        }


                    }


                    SPQuery oQuery3 = new SPQuery();
                    oQuery3.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy><Where>" +
                    "<And><And><And><And><And>" +
                        "<Eq>" +
                            "<FieldRef Name='CONOPSApproval'/>" +
                                "<Value Type='Choice'>Deputy Director Approval</Value>" +
                         "</Eq>" +
                         "<Eq>" +
                            "<FieldRef Name='ContentType'/>" +
                                "<Value Type='Computed'>WS3</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Eq>" +
                            "<FieldRef Name='FY'/>" +
                                "<Value Type='Text'>" + qs_fy + "</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Not Approved</Value>" +
                            "</Neq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Pending</Value>" +
                            "</Neq>" +
                    "</And>" +
                     "<Neq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                "</Where>";

                    SPListItemCollection collListItems3 = oList.GetItems(oQuery3);

                    foreach (SPListItem oListItem in collListItems3)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        TableCell EventNameCell = new TableCell();
                        TableCell PeopleCell = new TableCell();
                        TableCell DatesCell = new TableCell();
                        TableCell RemarksCell = new TableCell();
                        TableCell FundingCell = new TableCell();



                        EventNameCell.Style["padding-left"] = "3px";
                        PeopleCell.Style["text-align"] = "center";
                        DatesCell.Style["text-align"] = "center";
                        RemarksCell.Style["padding-left"] = "3px";
                        FundingCell.Style["text-align"] = "center";

                        string EventName = "";
                        string People = "";
                        string Dates = "";
                        string Remarks = "";
                        string Funding = "";

                        EventName += oListItem.Title.ToString();
                        try { People += oListItem["People"].ToString(); }
                        catch { }
                        try { Dates += oListItem["Dates"].ToString(); }
                        catch { }
                        try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                        catch { }
                        try { Funding += oListItem["Funding"].ToString(); }
                        catch { }



                        EventNameCell.Text = EventName;
                        PeopleCell.Text = People;
                        DatesCell.Text = Dates;
                        RemarksCell.Text = Remarks;
                        FundingCell.Text = Funding;


                        rw.Cells.Add(EventNameCell);
                        rw.Cells.Add(PeopleCell);
                        rw.Cells.Add(DatesCell);
                        rw.Cells.Add(RemarksCell);
                        rw.Cells.Add(FundingCell);



                        CONOPSDevWSTableWS3.Rows.AddAt(eventRowIndex, rw);
                    }

                    try
                    {
                        CONOPSDevWSTableWS3.Controls.Remove(attachmentsValRow);
                        CONOPSDevWSTableWS3.Controls.Remove(eventRow);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }




                } // end if

            }
            else
            {
                TableRow headerTitleRow = new TableRow();
                TableRow msgRow = new TableRow();
                TableCell msgCell = new TableCell();
                TableCell headerTitleCell = new TableCell();

                headerTitleRow.Style.Add("text-align", "center");
                msgCell.Text = "Worksheet Pending Approval";
                msgCell.CssClass = "msgCell";
                msgCell.Style.Add("font-size", "14px");

                headerTitleCell.Controls.Add(headerTitleCellDivWS3);
                headerTitleRow.Cells.Add(headerTitleCell);
                msgRow.Cells.Add(msgCell);

                CONOPSDevWSTableWS3.Rows.Add(headerTitleRow);
                CONOPSDevWSTableWS3.Rows.Add(msgRow);
            }
        }

    }
}
