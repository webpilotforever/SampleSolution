﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls; 

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSDevelopment
{
    public partial class WS3 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var traceInfo = "WS3";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            LabelOTA.Text = Page.Request.QueryString["ota"];
            LabelWSFY.Text = Page.Request.QueryString["fy"];

            //Table rows-----------------------------------------------------------------------------------

            TableRow headerTitleRow = new TableRow();
            TableRow headerRow = new TableRow();
            TableRow headerDescRow = new TableRow();
            TableRow eventRow = new TableRow();
            TableRow totalRow = new TableRow();
            TableRow attachmentsRow = new TableRow();
            TableRow attachmentsValRow = new TableRow();

            headerTitleRow.Style.Add("text-align", "center");
            headerRow.CssClass = "CONOPSDevWSColHeaders";
            headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
            headerDescRow.Style.Add("text-align", "center");
            eventRow.Style.Add("text-align", "center");
            totalRow.Style.Add("text-align", "center");
            attachmentsRow.Style.Add("text-align", "center");
            attachmentsValRow.Style.Add("text-align", "center");

            //Table cells------------------------------------------------------------------------------------------

            TableCell headerTitleCell = new TableCell();
            headerTitleCell.ColumnSpan = 5;

            headerTitleCell.Controls.Add(headerTitleCellDiv);

            headerTitleRow.Cells.Add(headerTitleCell);

            CONOPSDevWSTable.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTable

            TableCell wsColCell1 = new TableCell();
            TableCell wsColCell2 = new TableCell();
            TableCell wsColCell3 = new TableCell();
            TableCell wsColCell4 = new TableCell();
            TableCell wsColCell5 = new TableCell();


            wsColCell1.CssClass = "CONOPSDevWSColCell";
            wsColCell2.CssClass = "CONOPSDevWSColCell";
            wsColCell3.CssClass = "CONOPSDevWSColCell";
            wsColCell4.CssClass = "CONOPSDevWSColCell";
            wsColCell5.CssClass = "CONOPSDevWSColCell";


            wsColCell1.Style.Add("width", "200px");
            wsColCell2.Style.Add("width", "155px");
            wsColCell3.Style.Add("width", "155px");
            wsColCell4.Style.Add("width", "155px");
            wsColCell5.Style.Add("width", "155px");


            wsColCell1.Style.Add("font-weight", "bold");
            wsColCell2.Style.Add("font-weight", "bold");
            wsColCell3.Style.Add("font-weight", "bold");
            wsColCell4.Style.Add("font-weight", "bold");
            wsColCell5.Style.Add("font-weight", "bold");


            wsColCell1.Text = "Event Name​";
            wsColCell2.Text = "People";
            wsColCell3.Text = "Dates​";
            wsColCell4.Text = "Remarks​";
            wsColCell5.Text = "Funding";


            headerRow.Cells.Add(wsColCell1);
            headerRow.Cells.Add(wsColCell2);
            headerRow.Cells.Add(wsColCell3);
            headerRow.Cells.Add(wsColCell4);
            headerRow.Cells.Add(wsColCell5);


            CONOPSDevWSTable.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTable

            TableCell headerDescRowCell1 = new TableCell();
            TableCell headerDescRowCell2 = new TableCell();
            TableCell headerDescRowCell3 = new TableCell();
            TableCell headerDescRowCell4 = new TableCell();
            TableCell headerDescRowCell5 = new TableCell();


            headerDescRowCell1.Style.Add("font-style", "italic");
            headerDescRowCell2.Style.Add("font-style", "italic");
            headerDescRowCell3.Style.Add("font-style", "italic");
            headerDescRowCell4.Style.Add("font-style", "italic");
            headerDescRowCell5.Style.Add("font-style", "italic");


            headerDescRowCell1.Text = "Identify each event";
            headerDescRowCell2.Text = "List the number of people attending each event​";
            headerDescRowCell3.Text = "List the dates for each event​";
            headerDescRowCell4.Text = "Provide any comments to help clarify your cost estimates";
            headerDescRowCell5.Text = "Estimated cost for each event​";


            headerDescRow.Cells.Add(headerDescRowCell1);
            headerDescRow.Cells.Add(headerDescRowCell2);
            headerDescRow.Cells.Add(headerDescRowCell3);
            headerDescRow.Cells.Add(headerDescRowCell4);
            headerDescRow.Cells.Add(headerDescRowCell5);


            CONOPSDevWSTable.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTable

            TableCell eventValCell1 = new TableCell();
            TableCell eventValCell2 = new TableCell();
            TableCell eventValCell3 = new TableCell();
            TableCell eventValCell4 = new TableCell();
            TableCell eventValCell5 = new TableCell();

            eventValCell1.Style["padding-left"] = "3px";
            eventValCell2.Style["text-align"] = "center";
            eventValCell3.Style["text-align"] = "center";
            eventValCell4.Style["padding-left"] = "3px";
            eventValCell5.Style["text-align"] = "center";

            eventValCell1.Text = "Text";
            eventValCell2.Text = "00";
            eventValCell3.Text = "Text";
            eventValCell4.Text = "Text";
            eventValCell5.Text = "0000";



            eventRow.Cells.Add(eventValCell1);
            eventRow.Cells.Add(eventValCell2);
            eventRow.Cells.Add(eventValCell3);
            eventRow.Cells.Add(eventValCell4);
            eventRow.Cells.Add(eventValCell5);


            CONOPSDevWSTable.Rows.Add(eventRow); //-----------------eventRow added to CONOPSDevWSTable

            TableCell totalRowCell1 = new TableCell();
            TableCell totalRowCell2 = new TableCell();

            totalRowCell1.ColumnSpan = 4;
            totalRowCell1.Style.Add("text-align", "right");
            totalRowCell1.Style.Add("font-weight", "bold");
            totalRowCell1.Style.Add("background-color", "#d0ffbc");
            totalRowCell1.Text = "Total:";

            totalRowCell2.Text = "0000";
            totalRowCell2.Style.Add("background-color", "#d0ffbc");

            totalRow.Cells.Add(totalRowCell1);
            totalRow.Cells.Add(totalRowCell2);

            CONOPSDevWSTable.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTable

            TableCell attachmentsRowCell = new TableCell();

            attachmentsRowCell.ColumnSpan = 5;
            attachmentsRowCell.Style.Add("font-weight", "bold");
            attachmentsRowCell.Text = "Attachments";

            attachmentsRow.Cells.Add(attachmentsRowCell);

            CONOPSDevWSTable.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTable

            // use javascript like CONOPSDevReviewSubmitAttachments.js for clicking on attachments
            //	var attLink = "<A onclick=\"return DispEx(this,event,'TRUE','FALSE','FALSE','SharePoint.OpenDocuments.3','1','SharePoint.OpenDocuments','','','','" + _spUserId + "','0','0','0x7fffffffffffffff','','')\" id=\"" + attId + "\" href=\"" + attPath + "\" >" + attName + "</a>";
            // also try favorites how to download a file using asp net

            TableCell attachmentsValRowCell = new TableCell();

            attachmentsValRowCell.ColumnSpan = 5;
            attachmentsValRowCell.Text = "attachment1.text";
            attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

            attachmentsValRow.Cells.Add(attachmentsValRowCell);

            CONOPSDevWSTable.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTable

            //================= END OF TABLE TEMPLATE ====================



            int eventRowIndex = 4;

            string eventIDLast = "";
            string eventIDFirst = "";

            int eventIDFirstMinus1 = 0;
            int attachmentIndex = 6;

          

            string TimeDraftSaved = "";
            string TimeDraftSavedSnapShot = "";

            string submittedCAML = "<Neq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Neq>"; 
            if (Page.Request.QueryString["submitted"] == "yes")
            {
                submittedCAML = "<Eq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Eq>";
            }

            SPWeb oWeb = SPContext.Current.Web;
            //------------- lib -----------------
            SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);

            SPQuery oLibQuery = new SPQuery();

            oLibQuery.Query = "" +
                       "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                "</Eq>" +
                                 "<Eq>" +
                                    "<FieldRef Name=\"WS\"/>" +
                                    "<Value Type=\"Text\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

            SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

            if (collLibItems.Count > 0)
            {
                bool removeAttachmentRow = true;

                foreach (SPListItem oLibItem in collLibItems)
                {


                    SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                    foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                    {
                        if ((string)oListItemVersion["CONOPSApproval"] == "Baseline OTA Submission")
                        {
                            traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow attachmentsValRw = new TableRow();

                            TableCell attachmentsValRwCell = new TableCell();

                            attachmentsValRwCell.ColumnSpan = 5;
                            attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                            attachmentsValRwCell.Style.Add("text-align", "center");

                            string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                            traceInfo = versionUrl;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            Literal LiteralattachmentsValRwCell = new Literal();
                            LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                            attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                            attachmentsValRw.Cells.Add(attachmentsValRwCell);

                            CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                            removeAttachmentRow = false;

                            break;

                        }
                    }

                }

                if (removeAttachmentRow)
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                }

                CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

            }
            else
            {
                CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
            }















            //------ list -----------------
            traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

            SPQuery oQuery = new SPQuery();

     

            oQuery.Query = "" +
                  "<OrderBy>" +
                      "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                  "</OrderBy>" +
                  "<Where>" +
                      "<And>" +
                      "<And>" +
                      "<And>" +
                          "<Eq>" +
                              "<FieldRef Name=\"FY\"/>" +
                              "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                          "</Eq>" +
                          submittedCAML +
                      "</And>" +
                          "<Eq>" +
                              "<FieldRef Name=\"ContentType\"/>" +
                              "<Value Type=\"Computed\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                          "</Eq>" +
                      "</And>" +
                        "<Eq>" +
                                    "<FieldRef Name=\"CONOPSApproval\"/>" +
                                    "<Value Type=\"Text\">Baseline OTA Submission</Value>" +
                                "</Eq>" +
                                "</And>" +
                      
                  "</Where>";

            SPListItemCollection collListItems = oList.GetItems(oQuery);

            //oQuery to set vars.

            Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

            foreach (SPListItem oListItem in collListItems)
            {
                //Only one Total
                if (totalRowCell2.Text == "0000")
                {
                    try
                    {
                        traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        totalRowCell2.Text = oListItem[TotalGUID].ToString();

                        traceInfo = "totalRowCell2.Text: " + totalRowCell2.Text;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }

                try { TimeDraftSaved = oListItem["TimeDraftSaved"].ToString(); }
                catch { }

                traceInfo = "TimeDraftSaved: " + TimeDraftSaved;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                if (TimeDraftSavedSnapShot != "")
                {
                    if (TimeDraftSaved != TimeDraftSavedSnapShot)
                    {

                        traceInfo = "eventIDFirst: " + eventIDFirst;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        break;
                    }
                }
                else
                {

                    TimeDraftSavedSnapShot = oListItem["TimeDraftSaved"].ToString();
                    traceInfo = "TimeDraftSavedSnapShot: " + TimeDraftSavedSnapShot;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                }
                if (eventIDLast == "")
                {
                    eventIDLast = oListItem["ID"].ToString();
                    traceInfo = "eventIDLast: " + eventIDLast;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                }

                eventIDFirst = oListItem["ID"].ToString();
            }
            eventIDFirstMinus1 = Int32.Parse(eventIDFirst) - 1;



            //oQuery2 based on vars set to get items.

            SPQuery oQuery2 = new SPQuery();

            oQuery2.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Gt>" +
                                    "<FieldRef Name=\"ID\"/>" +
                                    "<Value Type=\"Integer\">" + eventIDFirstMinus1 + "</Value>" +
                                "</Gt>" +
                                "<Lt>" +
                                    "<FieldRef Name=\"ID\"/>" +
                                    "<Value Type=\"Integer\">" + eventIDLast + "</Value>" + // do not include Total
                                "</Lt>" +
                            "</And>" +
                        "</Where>";

            SPListItemCollection collListItems2 = oList.GetItems(oQuery2);

            //AddAt

            foreach (SPListItem oListItem2 in collListItems2)
            {
                TableRow rw = new TableRow();

                TableCell EventNameCell = new TableCell();
                TableCell PeopleCell = new TableCell();
                TableCell DatesCell = new TableCell();
                TableCell RemarksCell = new TableCell();
                TableCell FundingCell = new TableCell();


                EventNameCell.Style["padding-left"] = "3px";
                PeopleCell.Style["text-align"] = "center";
                DatesCell.Style["text-align"] = "center";
                RemarksCell.Style["padding-left"] = "3px";
                FundingCell.Style["text-align"] = "center";

                string EventName = "";
                string People = "";
                string Dates = "";
                string Remarks = "";
                string Funding = "";

                EventName += oListItem2.Title.ToString();
                try { People += oListItem2["People"].ToString(); }
                catch { }
                try { Dates += oListItem2["Dates"].ToString(); }
                            catch { }
                try { if (oListItem2["Remarks"] != null) { Remarks += oListItem2["Remarks"].ToString(); } }
                            catch { }
                try { Funding += oListItem2["Funding"].ToString(); }
                catch { }

                EventNameCell.Text = EventName;
                PeopleCell.Text = People;
                DatesCell.Text = Dates;
                RemarksCell.Text = Remarks;
                FundingCell.Text = Funding;



                rw.Cells.Add(EventNameCell);
                rw.Cells.Add(PeopleCell);
                rw.Cells.Add(DatesCell);
                rw.Cells.Add(RemarksCell);
                rw.Cells.Add(FundingCell);


                CONOPSDevWSTable.Rows.AddAt(eventRowIndex, rw);

            }
            try
            {
                CONOPSDevWSTable.Controls.Remove(eventRow);
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

    }
}
