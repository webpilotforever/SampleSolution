﻿using System;
using System.IO;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

using iTextSharp.text;
using iTextSharp.text.pdf;


namespace DCAPXSolution.Layouts.DCAPXSolution
{
    public partial class GenPDF : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //var doc1 = new Document();

            //string path = Server.MapPath("Layouts/DCAPXSolution/PDFs");

            //PdfWriter.GetInstance(doc1, new FileStream(path + "/Doc1.pdf", FileMode.Create));

            //doc1.Open();
            //doc1.Add(new Paragraph("My first PDF"));
            //doc1.Close();
            //--------------------------------------------
            var doc = new Document(iTextSharp.text.PageSize.LETTER, 10, 10, 42, 35);

            string path = Server.MapPath("PDFs");

            //PdfWriter.GetInstance(doc, new FileStream("Text.pdf", FileMode.Create));
            PdfWriter.GetInstance(doc, new FileStream(path + "/Text.pdf", FileMode.Create));


            doc.Open();
            Paragraph paragraph = new Paragraph("This is my first line using Paragraph.\n h1 hello");
            doc.Add(paragraph);
            doc.Close();



        }
    }
}
