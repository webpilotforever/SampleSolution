﻿using System;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Collections.Specialized;
using Microsoft.SharePoint.Administration.Claims;

namespace DCAPXSolution.Layouts.DCAPXSolution.ProgramContacts
{
    public partial class ProgramContactsNewForm : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                bool IsListContributor = false; 
                string thisurl = this.Web.Url;
                var traceInfo = "";
                //SPUser usr = Web.AllUsers[User.Identity.Name];

                if (this.Web.UserIsSiteAdmin || this.Web.UserIsWebAdmin || Web.Groups["DCAPXAO"].ContainsCurrentUser || Web.Groups["DCAPXOwners"].ContainsCurrentUser || Web.Groups["CONOPSApproval"].ContainsCurrentUser)
                {
                    traceInfo = "this.Web.UserIsSiteAdmin " + this.Web.UserIsSiteAdmin + " this.Web.UserIsWebAdmin " + this.Web.UserIsWebAdmin + " Web.Groups['DCAPXAO'].ContainsCurrentUser " + Web.Groups["DCAPXAO"].ContainsCurrentUser + " Web.Groups['DCAPXOwners'].ContainsCurrentUser " + Web.Groups["DCAPXOwners"].ContainsCurrentUser + " Web.Groups['CONOPSApproval'].ContainsCurrentUser" + Web.Groups["CONOPSApproval"].ContainsCurrentUser;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsNF", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    DropDownListOperationalTestAgency.Items.Add("AFOTEC");
                    DropDownListOperationalTestAgency.Items.Add("ATEC");
                    DropDownListOperationalTestAgency.Items.Add("COTF");
                    DropDownListOperationalTestAgency.Items.Add("JITC");
                    DropDownListOperationalTestAgency.Items.Add("MCOTEA");


                    //SPClaimProviderManager cpm = SPClaimProviderManager.Local;
                   

                    IsListContributor = true; using (SPSite oSite = new SPSite(thisurl))
                    {
                        using (SPWeb oWeb = oSite.RootWeb)
                        {

                           
                            SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];
                            SPQuery queryThisUser = new SPQuery();
                            queryThisUser.Query = "<Where><Eq><FieldRef Name=\"Account\" /><Value Type=\"Integer\"><UserID/></Value></Eq></Where>";
                            SPListItemCollection queryThisUserColl = ProgramContactsList.GetItems(queryThisUser);
                            foreach (SPListItem oListItem in queryThisUserColl)
                            {

                                DropDownListOperationalTestAgency.SelectedValue = oListItem["OperationalTestAgency"].ToString();

                            }

                        }
                    }
                }
                else
                {
                    

                    using (SPSite oSite = new SPSite(thisurl))
                    {
                        using (SPWeb oWeb = oSite.RootWeb)
                        {

                            string thisUserOTA = "";
                            SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];
                            SPQuery queryThisUser = new SPQuery();
                            queryThisUser.Query = "<Where><Eq><FieldRef Name=\"Account\" /><Value Type=\"Integer\"><UserID/></Value></Eq></Where>";
                            SPListItemCollection queryThisUserColl = ProgramContactsList.GetItems(queryThisUser);
                            foreach (SPListItem oListItem in queryThisUserColl)
                            {
                                thisUserOTA += oListItem["OperationalTestAgency"].ToString();
                                DropDownListOperationalTestAgency.Items.Add(thisUserOTA);

                                IsListContributor = true;
                            }
                        }
                    }
                }


                CheckBoxListModuleAccess.Items.Add("CONOPS Development Module Readers (Gov Only)");
                CheckBoxListModuleAccess.Items.Add("CONOPS Development Module Submitters (Gov Only)");
                CheckBoxListModuleAccess.Items[0].Selected = true;

                if (!IsListContributor)
                {
                    Save.Enabled = false;
                }
            }
            
        }

        protected void Save_Click(object sender, EventArgs e)
        {
            var traceInfo = "";

            if (spPeoplePicker.IsValid)
            {
                traceInfo = "spPeoplePicker.IsValid: " + spPeoplePicker.IsValid;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                bool IsUnique = false;

                string thisurl = this.Web.Url;

                using (SPSite oSite = new SPSite(thisurl))
                {
                    using (SPWeb oWeb = oSite.RootWeb)
                    {
                        
                        SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];

                        PickerEntity picker = (PickerEntity)spPeoplePicker.ResolvedEntities[0];

                        traceInfo = "picker.Key: " + picker.Key; // DOTEDRESOURCE\oberga-p
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPUser programContact = oWeb.EnsureUser(picker.Key);

                        //SPFieldUserValue fieldvalue = new SPFieldUserValue(oWeb, programContact.ID, programContact.LoginName);


                        SPQuery queryprogramContact = new SPQuery();
                        //queryprogramContact.Query = "<Where><Eq><FieldRef Name=\"Account\" /><Value Type=\"User\">" + programContact + "</Value></Eq></Where>";
                        queryprogramContact.Query = "<Where><Eq><FieldRef Name=\"Account\" LookupId=\"TRUE\" /><Value Type=\"Integer\">" + programContact.ID + "</Value></Eq></Where>";
                        
                        SPListItemCollection queryThisUserColl = ProgramContactsList.GetItems(queryprogramContact);
                       
                        traceInfo = "queryThisUserColl.Count: " + queryThisUserColl.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (queryThisUserColl.Count > 0)
                        {
                            IsUnique = false;
                            //Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert('User already exists in ProgramContacts list.'); SP.UI.ModalDialog.commonModalDialogClose('OK', 'ProgramContacts Error');</script>");

                        }
                        else
                        {
                            IsUnique = true;
                        }
                        
                    }
                }

                if (IsUnique)
                {
                    SPUser user = Web.CurrentUser;
                    Guid siteID = Web.Site.ID;
                    //bool saveNow = true;

                    SPSecurity.RunWithElevatedPrivileges(() =>
                    {
                        using (SPSite site = new SPSite(siteID))
                        {
                            using (SPWeb web = site.RootWeb)
                            {

                                try
                                {

                                    traceInfo = "ProgramContacts";
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                    SPList ProgramContactsList = web.Lists["ProgramContacts"];
                                    SPListItemCollection ProgramContactsListItems = ProgramContactsList.Items;
                                    SPListItem ProgramContactsListItem = ProgramContactsListItems.Add();

                                    SPFieldUserValue currentUser = new SPFieldUserValue(web, user.ID, user.Name);

                                    PickerEntity picker = (PickerEntity)spPeoplePicker.ResolvedEntities[0];

                                    if (picker.Key.Length > 0)
                                    {
                                        SPUser programContact = web.EnsureUser(picker.Key);
                                        //SPFieldUserValue fieldvalue = new SPFieldUserValue(web, programContact.ID, programContact.LoginName);



                                        ProgramContactsListItem["Title"] = programContact.Name;

                                        ProgramContactsListItem["Account"] = programContact;


                                        ProgramContactsListItem["OperationalTestAgency"] = DropDownListOperationalTestAgency.SelectedValue;
                                        SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();

                                        for (int i = 0; i < CheckBoxListModuleAccess.Items.Count; i++)
                                        {
                                            if (CheckBoxListModuleAccess.Items[i].Selected)
                                            {
                                                values.Add(CheckBoxListModuleAccess.Items[i].Value);
                                            }
                                        }

                                        if (values.Count > -1)
                                        {
                                            ProgramContactsListItem["ModuleAccess"] = values;
                                            ProgramContactsListItem["Author"] = currentUser;
                                            ProgramContactsListItem["Editor"] = currentUser;

                                            web.AllowUnsafeUpdates = true;
                                            ProgramContactsListItem.Update();

                                            //saveNow = true;
                                        }
                                        //else
                                        //{
                                        //    LabelModuleAccessError.Visible = true;
                                        //    saveNow = false;
                                        //}
                                    }
                                    else
                                    {
                                        spPeoplePicker.IsValid = false;
                                        Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert('Account must not be blank.');</script>");

                                    }




                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }

                            }
                        }
                    });
                    //if (saveNow)
                    //{
                        Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose('OK', 'ProgramContacts Saved');</script>");
                    //}
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert('User already exists in ProgramContacts list.'); SP.UI.ModalDialog.commonModalDialogClose(0, 'ProgramContacts Error');</script>");

                }
             
            }
           

        } 

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");

        }

    }
}
