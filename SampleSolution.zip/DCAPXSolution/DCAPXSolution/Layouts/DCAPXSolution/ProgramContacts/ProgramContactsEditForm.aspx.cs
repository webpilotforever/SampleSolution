﻿using System;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Collections.Specialized;

namespace DCAPXSolution.Layouts.DCAPXSolution.ProgramContacts
{
    public partial class ProgramContactsEditForm : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var traceInfo = "";


                bool IsListContributor = false;
                string thisurl = this.Web.Url;

                SPUser usr = Web.AllUsers[User.Identity.Name];

                if (usr.IsSiteAdmin || Web.Groups["DCAPXAO"].ContainsCurrentUser || Web.Groups["DCAPXOwners"].ContainsCurrentUser || Web.Groups["CONOPSApproval"].ContainsCurrentUser)
                {
                    traceInfo = "usr.IsSiteAdmin " + usr.IsSiteAdmin + " Web.Groups['DCAPXAO'].ContainsCurrentUser " + Web.Groups["DCAPXAO"].ContainsCurrentUser + " Web.Groups['DCAPXOwners'].ContainsCurrentUser " + Web.Groups["DCAPXOwners"].ContainsCurrentUser + " Web.Groups['CONOPSApproval'].ContainsCurrentUser" + Web.Groups["CONOPSApproval"].ContainsCurrentUser;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsEF", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    DropDownListOperationalTestAgency.Items.Add("AFOTEC");
                    DropDownListOperationalTestAgency.Items.Add("ATEC");
                    DropDownListOperationalTestAgency.Items.Add("COTF");
                    DropDownListOperationalTestAgency.Items.Add("JITC");
                    DropDownListOperationalTestAgency.Items.Add("MCOTEA");

                    IsListContributor = true;




                   




                }
                else
                {

                    using (SPSite oSite = new SPSite(thisurl))
                    {
                        using (SPWeb oWeb = oSite.RootWeb)
                        {

                            string thisUserOTA = "";
                            SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];
                            SPQuery queryThisUser = new SPQuery();
                            queryThisUser.Query = "<Where><Eq><FieldRef Name=\"Account\" /><Value Type=\"Integer\"><UserID/></Value></Eq></Where>";
                            SPListItemCollection queryThisUserColl = ProgramContactsList.GetItems(queryThisUser);
                            foreach (SPListItem oListItem in queryThisUserColl)
                            {
                                thisUserOTA += oListItem["OperationalTestAgency"].ToString();
                                DropDownListOperationalTestAgency.Items.Add(thisUserOTA);

                                IsListContributor = true;
                            }

                        }
                    }

                }

                if (!IsListContributor)
                {
                    Save.Enabled = false;
                }

                string id = Page.Request.QueryString["id"];

                CheckBoxListModuleAccess.Items.Add("CONOPS Development Module Readers (Gov Only)");
                CheckBoxListModuleAccess.Items.Add("CONOPS Development Module Submitters (Gov Only)");

                using (SPSite oSite = new SPSite(thisurl))
                {
                    using (SPWeb oWeb = oSite.RootWeb)
                    {

                        SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];
                        SPQuery q = new SPQuery();
                        q.Query = "<Where><Eq><FieldRef Name=\"ID\" /><Value Type=\"Text\">" + id + "</Value></Eq></Where>";
                        SPListItemCollection qColl = ProgramContactsList.GetItems(q);
                        foreach (SPListItem oListItem in qColl)
                        {
                            string accnt = oListItem["Account"].ToString();
                            int accntI = accnt.IndexOf("#") + 1;
                            accnt = accnt.Substring(accntI);
                            Account.Text = accnt;
                            DropDownListOperationalTestAgency.SelectedValue = oListItem["OperationalTestAgency"].ToString();

                            SPFieldMultiChoice choiceField = (SPFieldMultiChoice)ProgramContactsList.Fields.GetField("ModuleAccess");

                            string rawValue = oListItem[choiceField.Id].ToString();

                            SPFieldMultiChoiceValue typedValue = new SPFieldMultiChoiceValue(rawValue);

                            for (int i = 0; i < typedValue.Count; i++)
                            {
                                traceInfo = "typedValue[i] " + typedValue[i];
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsEF", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string typedValueText = typedValue[i];
                                string checkbox1txt = CheckBoxListModuleAccess.Items[0].Text;
                                string checkbox2txt = CheckBoxListModuleAccess.Items[1].Text;

                                if (typedValueText == checkbox1txt)
                                {
                                    CheckBoxListModuleAccess.Items[0].Selected = true;
                                }
                                if (typedValueText == checkbox2txt)
                                {
                                    CheckBoxListModuleAccess.Items[1].Selected = true;
                                }
                            }

                        }

                    }
                }
            }
            
             
        }
        protected void Save_Click(object sender, EventArgs e)
        {
            var traceInfo = "";

            int id = Int32.Parse(Page.Request.QueryString["id"]);

            SPUser user = Web.CurrentUser;
            Guid siteID = Web.Site.ID;
            //bool saveNow = true;

            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb web = site.RootWeb)
                    {

                        try
                        {

                            traceInfo = "ProgramContacts item id: " + id;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsEF", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPList ProgramContactsList = web.Lists["ProgramContacts"];
                            SPListItem ProgramContactsListItem = ProgramContactsList.GetItemById(id);

                            SPFieldUserValue currentUser = new SPFieldUserValue(web, user.ID, user.Name);

                            traceInfo = "DropDownListOperationalTestAgency.SelectedValue: " + DropDownListOperationalTestAgency.SelectedValue;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsEF", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            ProgramContactsListItem["OperationalTestAgency"] = DropDownListOperationalTestAgency.SelectedValue; 
                            
                            SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();

                            for (int i = 0; i < CheckBoxListModuleAccess.Items.Count; i++)
                            {
                                if (CheckBoxListModuleAccess.Items[i].Selected)
                                {
                                    values.Add(CheckBoxListModuleAccess.Items[i].Value);
                                }
                            }

                            if (values.Count > -1)
                            {
                                ProgramContactsListItem["ModuleAccess"] = values;
                                ProgramContactsListItem["Editor"] = currentUser;

                                web.AllowUnsafeUpdates = true;
                                ProgramContactsListItem.Update();
                                
                                traceInfo = "Updated item id: " + id;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsEF", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //saveNow = true;
                            }
                            

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsEF", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }
            });
            //if (saveNow)
            //{
                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose('OK', 'ProgramContacts Saved');</script>");
            //}

        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");

        }

    }
}
