﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Administration;
using System.Web.UI;

namespace DCAPXSolution.Layouts.DCAPXSolution.ProgramContacts
{
    public partial class ProgramContacts : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

         

            int MyItemId = 0;
            
            bool IsListContributor = false;
            
           SPUser usr = Web.AllUsers[User.Identity.Name];

           if (usr.IsSiteAdmin || Web.Groups["DCAPXAO"].ContainsCurrentUser || Web.Groups["DCAPXOwners"].ContainsCurrentUser || Web.Groups["CONOPSApproval"].ContainsCurrentUser)
           {
               IsListContributor = true;
           }
            string thisurl = this.Web.Url;

            using (SPSite oSite = new SPSite(thisurl))
            {
                using (SPWeb oWeb = oSite.RootWeb)
                {
                    SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];

                    SPQuery queryThisUser = new SPQuery();
                    queryThisUser.Query = "<Where><Eq><FieldRef Name=\"Account\" /><Value Type=\"Integer\"><UserID/></Value></Eq></Where>";

                    SPListItemCollection queryThisUserColl = ProgramContactsList.GetItems(queryThisUser);

                    foreach (SPListItem oListItem in queryThisUserColl)
                    {

                        MyItemId = oListItem.ID;
                       

                        string[] ma = oListItem["ModuleAccess"].ToString().Split(new string[] { ";#" }, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string value in ma)
                        {
                            
                            if (value.Contains("Submitters"))
                            {

                                IsListContributor = true;

                            }
                        }
                    }
                }
            }
            if (IsListContributor) 
            {
                AddNewItemLink.Visible = true;
            }
























            var traceInfo = "ProgramContacts";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            
            //headingRow---------------------------
            
            TableCell deletCellheader = new TableCell();
            TableCell titleCellheader = new TableCell();
            TableCell otaCellheader = new TableCell();
            TableCell moduleAccessCellheader = new TableCell();
            
            
            titleCellheader.Text = "Title";
            otaCellheader.Text = "OperationalTestAgency";
            moduleAccessCellheader.Text = "ModuleAccess";

            TableRow headingRow = new TableRow();
            
            headingRow.Cells.Add(deletCellheader);
            headingRow.Cells.Add(titleCellheader);
            headingRow.Cells.Add(otaCellheader);
            headingRow.Cells.Add(moduleAccessCellheader);
            
            Table1.Rows.Add(headingRow);

            //------------------------------------------------
          

            using (SPSite oSite = new SPSite(thisurl))
            {
                using (SPWeb oWeb = oSite.RootWeb)
                {
                    string thisUserOTA = "";
                    SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];
                    SPQuery queryThisUser = new SPQuery();
                    queryThisUser.Query = "<Where><Eq><FieldRef Name=\"Account\" /><Value Type=\"Integer\"><UserID/></Value></Eq></Where>";
                    SPListItemCollection queryThisUserColl = ProgramContactsList.GetItems(queryThisUser);
                    foreach (SPListItem oListItem in queryThisUserColl)
                    {
                        thisUserOTA += oListItem["OperationalTestAgency"].ToString(); 
                       
                    }
                    if (thisUserOTA != "")
                    { 
                        SPQuery oQuery = new SPQuery();
                        oQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"Title\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"OperationalTestAgency\"/>" +
                                    "<Value Type=\"Text\">" + thisUserOTA + "</Value>" +
                                "</Eq>" +
                            "</Where>";
                        SPListItemCollection collListItems = ProgramContactsList.GetItems(oQuery);

                        foreach (SPListItem oListItem in collListItems)
                        {
                            string title = oListItem["Title"].ToString();
                            string ota = oListItem["OperationalTestAgency"].ToString();
                            string id = oListItem["ID"].ToString();
                            string titleLink = "ProgramContactsEditForm.aspx?id=" + id + "&IsDlg=1";
                            string moduleA = "";
                            string[] ma = oListItem["ModuleAccess"].ToString().Split(new string[] { ";#" }, StringSplitOptions.RemoveEmptyEntries);
                            int mai = 1;
                            foreach (string value in ma)
                            {
                                string comma = "";
                                //traceInfo = "mai: " + mai + " ma.Length: " + ma.Length + " value: " + value;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdeleteBtnClick", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (mai < ma.Length)
                                {
                                    comma = ", ";
                                }

                                moduleA += value + comma;

                                mai=mai+1;
                            }

                            TableCell deletCell = new TableCell();
                            TableCell titleCell = new TableCell();
                            TableCell otaCell = new TableCell();
                            TableCell moduleAccessCell = new TableCell();
                            

                            deletCell.VerticalAlign = VerticalAlign.Top;
                            titleCell.VerticalAlign = VerticalAlign.Top;
                            otaCell.VerticalAlign = VerticalAlign.Top;
                            moduleAccessCell.VerticalAlign = VerticalAlign.Top;
                            


                            ImageButton deleteImgBtn = new ImageButton();
                            deleteImgBtn.ID = id;
                            deleteImgBtn.ToolTip = "Delete";
                            deleteImgBtn.ImageUrl = oWeb.ServerRelativeUrl + "/_layouts/Images/DCAPXSolution/deleteattachment.png";
                            deleteImgBtn.Click += deleteImgBtn_Click;
                            deleteImgBtn.OnClientClick = "if(!confirm('Are you sure you want to delete?')) return false;";
                            //deleteImgBtn.OnClientClick = "if(confirm('Are you sure you want to delete?')) { return true; deleting();} else {return false;}";


                        

                            
                            
                            if (IsListContributor && MyItemId != oListItem.ID)
                            {
                                deletCell.Controls.Add(deleteImgBtn);
                            }
                        

                            HyperLink titleTextLink = new HyperLink();
                            titleTextLink.Text = title;
                            titleTextLink.NavigateUrl = titleLink;
                            titleTextLink.Target = "_self";
                            titleCell.Wrap = false;

                            if (IsListContributor)
                            {
                                titleCell.Controls.Add(titleTextLink);
                            }
                            else
                            {
                                titleCell.Text = title;
                            }


                            otaCell.Text = ota;
                            moduleAccessCell.Text = moduleA;

                            TableRow itemRow = new TableRow();
                            itemRow.Cells.Add(deletCell);
                            itemRow.Cells.Add(titleCell);
                            itemRow.Cells.Add(otaCell);
                            itemRow.Cells.Add(moduleAccessCell);
                            

                            Table1.Rows.Add(itemRow);
                        }
                    }
                    else
                    {
                        traceInfo = "Could not find current user's OperationalTestAgency in the ProgramContacts list.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            
                    }

                }
            }

            

        }

        void deleteImgBtn_Click(object sender, ImageClickEventArgs e)
        {
            

            ImageButton deleteImgBtn = (ImageButton)sender;
            
            var traceInfo = "";

            int id = Int32.Parse(deleteImgBtn.ID);

            traceInfo = "deleteBtn_Click deleteBtn.ID: " + id;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdeleteBtnClick", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            bool IsMe = false;
            bool IsListContributor = false;
            if (User.IsInRole("Administrator") || User.IsInRole("Contributor"))
            {
                IsListContributor = true;

            }
            string thisurl = this.Web.Url;

            using (SPSite oSite = new SPSite(thisurl))
            {
                using (SPWeb oWeb = oSite.RootWeb)
                {
                    SPList ProgramContactsList = oWeb.Lists["ProgramContacts"];

                    SPQuery queryThisUser = new SPQuery();
                    queryThisUser.Query = "<Where><Eq><FieldRef Name=\"Account\" /><Value Type=\"Integer\"><UserID/></Value></Eq></Where>";

                    SPListItemCollection queryThisUserColl = ProgramContactsList.GetItems(queryThisUser);

                    foreach (SPListItem oListItem in queryThisUserColl)
                    {

                        int iid = oListItem.ID;
                        if (id == iid)
                        {
                            IsMe = true;
                        }

                        string[] ma = oListItem["ModuleAccess"].ToString().Split(new string[] { ";#" }, StringSplitOptions.RemoveEmptyEntries);

                        foreach (string value in ma)
                        {
                            traceInfo = "value: " + value;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdeleteBtnClick", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            if (value.Contains("Submitters"))
                            {

                                IsListContributor = true;

                            }
                        }
                    }
                }
            }


            if (IsMe)
            {
                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert('You may not delete yourself through this interface.'); SP.UI.ModalDialog.commonModalDialogClose('OK', 'ProgramContact Deleted');</script>");
            }
            else
            {

                Guid siteID = Web.Site.ID;
                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb web = site.RootWeb)
                        {
                            try
                            {
                                SPList ProgramContactsList = web.Lists["ProgramContacts"];

                                SPListItemCollection ProgramContactsListItems = ProgramContactsList.Items;

                                if (IsListContributor)
                                {
                                    traceInfo = "IsListContributor: " + IsListContributor;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdeleteBtnClick2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    web.AllowUnsafeUpdates = true;
                                    ProgramContactsListItems.DeleteItemById(id);
                                }
                                else
                                {
                                    traceInfo = "Could not delete because IsListContributor: " + IsListContributor;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdeleteBtnClick2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert('You must be the CONOPSDevSubmitter to delete fellow OTAs.'); SP.UI.ModalDialog.commonModalDialogClose('OK', 'ProgramContact Deleted');</script>");

                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdeleteBtnClick2", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                    }
                });
               
                Page.ClientScript.RegisterStartupScript(typeof(Page), "refresh", "<script type=\"text/javascript\">location.replace(location.href);</script>");


            }

        }

    }
}
