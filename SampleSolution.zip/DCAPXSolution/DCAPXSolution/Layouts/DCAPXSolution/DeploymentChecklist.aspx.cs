﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Navigation;
using System.Collections.Generic;
using System.Reflection;
using System.Collections.Specialized;

namespace DCAPXSolution.Layouts.DCAPXSolution
{
    public partial class ApplicationPage2 : LayoutsPageBase
    {
        //Cliff requirments as per 1/21 
        //Add static links to DCS chatrooms on sipr for forums available during assessment events in Assessment Management site
        //Allison to set up with ota responsible for assessment and ota leading it as admins/moderators
        //16 links
        //
        //Quicklaunch menu to show CONOPS heading with no link, and indented under it links to Development and Approval

        Guid guidFeatureIDBaseSite = new Guid("b21b090c-c796-4b0f-ac0f-7ef1659c20ae"); // SharePoint Server Standard Site Collection features        
        Guid guidFeatureIDPremiumSite = new Guid("8581a8a7-cf16-4770-ac54-260265ddb0b2"); // SharePoint Server Enterprise Site Collection features
        Guid guidFeatureIDPublishingSite = new Guid("f6924d36-2fa8-4f0b-b16d-06b7250180fa"); // SharePoint Server Publishing Infrastructure
        Guid guidFeatureID = new Guid("a0ddea8f-e3de-41d5-889d-8f9401db024d"); // DCAPXSolution_Feature1 MasterPage
        Guid guidFeatureID2 = new Guid("5bcfb281-b2f6-42da-874d-a267fb0ce0d5"); // DCAPXSolution_Feature2 CONOPSDev Pages
        Guid guidFeatureID3 = new Guid("d2536341-6d90-4c04-b30a-46700ba51ded"); // DCAPXSolution_Feature3

        string traceInfo = "";
        string assemblyVersion = ""; 
        DateTime thisUpdate = DateTime.Now;
        string todaysUpdate = "";
        string DCAPXSolutionVersionInUse = "";
        string DCAPXSolutionLastUpdated = "";

        protected void Page_Load(object sender, EventArgs e)
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);

            SPFarm farm = SPFarm.Local;
             
            //traceInfo = this.Web.CurrentUser.LoginName + " farm.CurrentUserIsAdministrator(true): " + farm.CurrentUserIsAdministrator(true);
            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFarmAdminCheck", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            if (!farm.CurrentUserIsAdministrator(false))
            {
                traceInfo = "Account not recognized as a farm administrator. Please use Central Administration to create a site collection if necessary.";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunchThisWeb", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                //Page.ClientScript.RegisterStartupScript(typeof(Page), "notFarmAdmin", "<script type=\"text/javascript\">alert(\"Please login as a farm admin if you wish to create a site collection.\");</script>");

            }
            
            //if (!farm.CurrentUserIsAdministrator(true))
            //{
            //    userIsNotAuthorizedToUseThisPage();
            //}
            //traceInfo = this.Web.CurrentUser.LoginName + " farm.CurrentUserIsAdministrator(true): " + farm.CurrentUserIsAdministrator(true);
            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFarmAdminCheck", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            traceInfo = this.Web.CurrentUser.LoginName + " this.Web.UserIsSiteAdmin: " + this.Web.UserIsSiteAdmin;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsSiteCollectionAdminCheck", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



            if (!this.Web.UserIsSiteAdmin)
            {
                userIsNotAuthorizedToUseThisPage();
            }
                
                
         

            checkForDCAPXObjects();
            
            
            todaysUpdate = thisUpdate.ToString("d");

            Type t = typeof(ApplicationPage2);
            Assembly assessFromType = t.Assembly;
            AssemblyName assessFromTypeName = assessFromType.GetName();
            Version ver = assessFromTypeName.Version;

            assemblyVersion = ver.ToString();
            //if (Request.Url.Scheme == "https" || Request.Url.Authority.Contains(".smil") || Request.Url.Host == "localhost" || Request.RawUrl.Contains(".smil"))

            if (Request.Url.Scheme == "https" || Request.Url.Authority.Contains(".smil")  || Request.Url.OriginalString.Contains(".smil"))
            {
                
                ThisNetwork.Value = "SIPR Net";

                Label11.Text = "Use the above field to create version-controled environmments for production and deployment verification.";
                Label12.Text = "On SIPR Net, value must be '/sites/DCAPX' or '/sites/DCAPXObjects'.";
                RegularExpressionValidator1.ErrorMessage = "On SIPR Net, value must be '/sites/DCAPX' or '/sites/DCAPXObjects'.";
                RegularExpressionValidator1.ValidationExpression = "(\\/){1}(sites){1}(\\/){1}(DCAPX){1}(Objects)?";
            }

            DCAPXSolution.DeploymentChecklist.AddUsersToWebAppClass.AddUsersToWebApp(Page.Request.Url.ToString(), traceInfo, ThisNetwork.Value);


            Label2.Text = "Hello " + this.Web.CurrentUser.Name;
            Label7.Text = assemblyVersion;
            if (this.Web.AllProperties["DCAPXSolutionLastUpdated"] != null)
            {
                
                DCAPXSolutionLastUpdated = this.Web.AllProperties["DCAPXSolutionLastUpdated"].ToString();
            }
            else
            {
                
                    addPropertyToWeb("DCAPXSolutionLastUpdated", todaysUpdate);

                

            }
            if (DCAPXSolutionLastUpdated != "")
            {
                Label13.Text = DCAPXSolutionLastUpdated;
            }

            if (this.Web.AllProperties["DCAPXSolutionVersionInUse"] != null)
            {
               
                DCAPXSolutionVersionInUse = this.Web.AllProperties["DCAPXSolutionVersionInUse"].ToString();
            }
            else
            {
               
                    addPropertyToWeb("DCAPXSolutionVersionInUse", assemblyVersion);              

                
            }
            if (this.Web.Title != TextBox2.Text && !IsPostBack)
            {
                
                using(SPSite oSite = new SPSite(this.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        try
                        {
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Title = TextBox2.Text;
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventswebTitle", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                }
                
            }

           
            
            checkVersionInUse();

            SPNavigationNodeCollection nodesThisWeb = this.Web.Navigation.QuickLaunch;
            if (nodesThisWeb.Count > 1 && WebAppWebOps.Value != "true" && !IsPostBack)
            {
                
                using (SPSite oSite = new SPSite(this.Web.Url))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPNavigationNodeCollection nodes = oWeb.Navigation.QuickLaunch;
                        try
                        {
                            traceInfo = "Quick Launch Enabled on " + this.Web.Url;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunchEnabled", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";


                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.QuickLaunchEnabled = true;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunchEnabled", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }                        
                        
                        try
                        {
                            traceInfo = "Clearing Quick Launch on " + oWeb.Url;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunchThisWeb", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                            
                            for (int i = nodes.Count - 1; i >= 0; i--)
                            {
                                if (!nodes[i].Title.Contains("DCAPXObjects"))
                                {
                                    nodes[i].Delete();
                                }
                                
                            }
                            oWeb.Description = "";
                            
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunchThisWeb", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                }
            }



            //============================ CHECKBOX1.CHECKED ===================================
            if (CheckBox1.Checked && SiteCollectionCreated.Value != "true")
            {
                traceInfo = TextBox1.Text.Substring(1) + " should be null " + this.Web.Site.WebApplication.Sites[TextBox1.Text.Substring(1)];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreate site collection", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                
                if (this.Web.Site.WebApplication.Sites[TextBox1.Text.Substring(1)] == null)
                {
                    traceInfo = "Creating Site Collection: " + TextBox1.Text;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreate site collection", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                    string sOwner = this.Web.CurrentUser.LoginName;
                    SPUser SiteOwner = null;

                    using (SPSite oSite = new SPSite(Page.Request.Url.ToString()))
                    {
                        using (SPWeb oWeb = oSite.OpenWeb())
                        {
                            SiteOwner = oWeb.EnsureUser(sOwner);
                        }
                    }

                 

                    try
                    {
                        // Log will show SPRequest object reclaimed error, but it is not this code. without the using statement or dispose call, you also get two additional object not disposed errors.
                        // Log will show warning about large sql block, but this is not my code. 
                        
                        //SPSite siteCollection = this.Web.Site.WebApplication.Sites.Add(TextBox1.Text.Substring(1), SiteOwner.LoginName, SiteOwnerEmail);
                        SPSite siteCollection = this.Web.Site.WebApplication.Sites.Add(TextBox1.Text.Substring(1), SiteOwner.LoginName, null); // must be null if using SHAREPOINT\system account which does not have email address

                        siteCollection.Dispose();

                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreate site collection", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsverifySiteCollectionCreated", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); traceInfoDiv.InnerHtml += ex.Message + "<br />";

                    }
                    finally
                    {
                       
                        SiteCollectionCreated.Value = "true";

                    }

                }
                else
                {
                    
                    SiteCollectionCreated.Value = "true";
                }
                 
            }
            if (CheckBox1.Checked && SiteCollectionCreated.Value == "true")
            {

                traceInfo = "Site Collection Creation started: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatesitecoll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                
                verifySiteCollectionCreated();
            
            }
            if (CheckBox1.Checked && VerifySiteCollectionCreated.Value == "true")
            {

                traceInfo = "VerifySiteCollectionCreated: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatesitecoll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                
                DCAPXSolution.DeploymentChecklist.AddUsersToDCAPXClass.AddUsersToDCAPX(leftPartUrl + TextBox1.Text, traceInfo, ThisNetwork.Value);

                if (nodesThisWeb.Count < 1)
                {
                    using (SPSite oSite = new SPSite(this.Web.Url))
                    {
                        using (SPWeb oWeb = oSite.OpenWeb())
                        {
                            SPNavigationNode nodeSitesDCAPX = new SPNavigationNode(TextBox3.Text, TextBox1.Text, true);
                            try
                            {
                                traceInfo = "Adding Node to Quick Launch on " + oWeb.Url;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunchThisWeb", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                oWeb.Update();
                                WebAppWebOps.Value = "true";
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunchUpdateThisWeb", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }
                        }
                    }

                }




                
                using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPFeatureCollection oSiteFeatures = oSite.Features;
                        if (oSiteFeatures[guidFeatureIDBaseSite] != null)
                        {
                            BaseSiteActivated.Value = "true";
                        }
                        if (oSiteFeatures[guidFeatureIDPremiumSite] != null)
                        {
                            PremiumSiteActivated.Value = "true";
                        }
                        if (oSiteFeatures[guidFeatureIDPublishingSite] != null)
                        {
                            PublishingSiteActivated.Value = "true";
                        }
                        if (oSiteFeatures[guidFeatureID] != null)
                        {
                            AddedFeature1.Value = "true";
                        }
                        if (oSiteFeatures[guidFeatureID2] != null)
                        {
                            AddedFeature2.Value = "true";
                        }
                    }
                    
                }
                   
            }
            if (CheckBox1.Checked && SiteCollectionCreated.Value == "true" && BaseSiteActivated.Value != "true")
            {
                
                activateFeature(guidFeatureIDBaseSite, "Standard Site Collection features");
            }
            if (CheckBox1.Checked && SiteCollectionCreated.Value == "true" && PremiumSiteActivated.Value != "true")
            {
                
                activateFeature(guidFeatureIDPremiumSite, "Enterprise Site Collection features");
            }
            if (CheckBox1.Checked && SiteCollectionCreated.Value == "true" && PublishingSiteActivated.Value != "true")
            {
                
                activateFeature(guidFeatureIDPublishingSite, "Publishing Infrastructure");
            }
            if (CheckBox1.Checked && SiteCollectionCreated.Value == "true" && BaseSiteActivated.Value == "true" && PremiumSiteActivated.Value == "true" && PublishingSiteActivated.Value == "true")
            {
                
                AllNativeFeaturesActivated.Value = "true";

            }

            SPRoleType Administrator = SPRoleType.Administrator;
            SPRoleType Contributor = SPRoleType.Contributor;
            SPRoleType Reader = SPRoleType.Reader;

            
            if (CheckBox1.Checked && AllNativeFeaturesActivated.Value == "true")
            {
                
                traceInfo = "All Native Features Activated: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAllNativeFeaturesActivated", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("DCAPXOwners", "DOT&E IT staff", Administrator);


            }

            if (CheckBox1.Checked && AddedDCAPXOwners.Value == "true")
            {   
                traceInfo = "Added DCAPXOwners: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("DCAPXVisitors", "DOT&E personnel", Reader);

            }
            if (CheckBox1.Checked && AddedDCAPXVisitors.Value == "true")
            {
                traceInfo = "Added DCAPXVisitors: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("DCAPXAO", "DOT&E Action Officers", Contributor);

            }
            if (CheckBox1.Checked && AddedDCAPXAO.Value == "true")
            {
                traceInfo = "Added DCAPXAO: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("DCAPXOTA", "Service Operational Test Agencies", Reader);

            }
            if (CheckBox1.Checked && AddedDCAPXOTA.Value == "true")
            {
                traceInfo = "Added DCAPXOTA: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSApproval", "Approvers of CONOPS", Contributor);

            }
            if (CheckBox1.Checked && AddedCONOPSApproval.Value == "true")
            {
                traceInfo = "Added CONOPSApproval: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevReadersAFOTEC", "Members can view CONOPS Development worksheets, but not contribute to them or submit them.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevReadersAFOTEC.Value == "true")
            {
                traceInfo = "Added CONOPSDevReadersAFOTEC: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevReadersATEC", "Members can view CONOPS Development worksheets, but not contribute to them or submit them.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevReadersATEC.Value == "true")
            {
                traceInfo = "Added CONOPSDevReadersATEC: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevReadersCOTF", "Members can view CONOPS Development worksheets, but not contribute to them or submit them.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevReadersCOTF.Value == "true")
            {
                traceInfo = "Added CONOPSDevReadersCOTF: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevReadersJITC", "Members can view CONOPS Development worksheets, but not contribute to them or submit them.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevReadersJITC.Value == "true")
            {
                traceInfo = "Added CONOPSDevReadersJITC: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevReadersMCOTEA", "Members can view CONOPS Development worksheets, but not contribute to them or submit them.", Reader);

            }

            if (CheckBox1.Checked && AddedCONOPSDevReadersMCOTEA.Value == "true")
            {
                traceInfo = "Added CONOPSDevReadersMCOTEA: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevSubmittersAFOTEC", "Members are programmatically allowed to update CONOPS Development lists only through worksheets until worksheets are submitted until the first of January of the next calendar year.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevSubmittersAFOTEC.Value == "true")
            {
                traceInfo = "Added CONOPSDevSubmittersAFOTEC: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevSubmittersATEC", "Members are programmatically allowed to update CONOPS Development lists only through worksheets until worksheets are submitted until the first of January of the next calendar year.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevSubmittersATEC.Value == "true")
            {
                traceInfo = "Added CONOPSDevSubmittersATEC: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevSubmittersCOTF", "Members are programmatically allowed to update CONOPS Development lists only through worksheets until worksheets are submitted until the first of January of the next calendar year.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevSubmittersCOTF.Value == "true")
            {
                traceInfo = "Added CONOPSDevSubmittersCOTF: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevSubmittersJITC", "Members are programmatically allowed to update CONOPS Development lists only through worksheets until worksheets are submitted until the first of January of the next calendar year.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevSubmittersJITC.Value == "true")
            {
                traceInfo = "Added CONOPSDevSubmittersJITC: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("CONOPSDevSubmittersMCOTEA", "Members are programmatically allowed to update CONOPS Development lists only through worksheets until worksheets are submitted until the first of January of the next calendar year.", Reader);

            }
            if (CheckBox1.Checked && AddedCONOPSDevSubmittersMCOTEA.Value == "true")
            {
                traceInfo = "Added CONOPSDevSubmittersMCOTEA: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USAFRICOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSAFRICOM.Value == "true")
            {
                traceInfo = "Added USAFRICOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USCENTCOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSCENTCOM.Value == "true")
            {
                traceInfo = "Added USCENTCOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USEUCOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSEUCOM.Value == "true")
            {
                traceInfo = "Added USEUCOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USNORTHCOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSNORTHCOM.Value == "true")
            {
                traceInfo = "Added USNORTHCOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USPACOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSPACOM.Value == "true")
            {
                traceInfo = "Added USPACOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USSOUTHCOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSSOUTHCOM.Value == "true")
            {
                traceInfo = "Added USSOUTHCOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USSOCOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSSOCOM.Value == "true")
            {
                traceInfo = "Added USSOCOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USSTRATCOM", "Members can access content for this CCMD.", Reader);

            }
            if (CheckBox1.Checked && AddedUSSTRATCOM.Value == "true")
            {
                traceInfo = "Added USSTRATCOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addThisGroup("USTRANSCOM", "Members can access content for this CCMD.", Reader);

            }





            if (CheckBox1.Checked && AddedUSTRANSCOM.Value == "true")
            {

                traceInfo = "Added USTRANSCOM: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                AllGroupsSetWithPerms.Value = "true";
            }
            if (CheckBox1.Checked && AllGroupsSetWithPerms.Value == "true")
            {
                
                traceInfo = "Set Permissions for All Groups: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetGroupPermissions", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                
                webOps();

            }
            if (CheckBox1.Checked && WebOps.Value == "true")
            {
                
                traceInfo = "Web Ops Completed: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventswebOps", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                
                addLists();

            }
            if (CheckBox1.Checked && AllListsAdded.Value == "true")
            {
                
                traceInfo = "All Lists Added: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                    
                removeCustomFeatures();

            }

            if (CheckBox1.Checked && CustomFeaturesRemoved.Value == "true")
            {
                
                traceInfo = "Custom Features Removed: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                 
                addCustomFeatures();
            }
            if (CheckBox1.Checked && CustomFeaturesAdded.Value == "true")
            {
                
                traceInfo = "Custom Features Added: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                breakRoleInheritance();
               

            }
            if (CheckBox1.Checked && BreakRoleInheritance.Value == "true")
            {
                
                traceInfo = "Break Role Inheritance: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsbreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                enableVersioning();
               

            }
            if (CheckBox1.Checked && EnabledVersioning.Value == "true")
            {
                
                traceInfo = "Enabled Versioning: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsenableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                AllowedContentTypes.Value = DCAPXSolution.DeploymentChecklist.AllowContentTypesClass.AllowContentTypes(leftPartUrl + TextBox1.Text, traceInfo);
                

            }
            if (CheckBox1.Checked && AllowedContentTypes.Value == "true")
            {
                
                traceInfo = "Allowed Content Types: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsallowContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";


                SetContentTypes.Value = DCAPXSolution.DeploymentChecklist.SetContentTypesClass.SetContentTypes(leftPartUrl + TextBox1.Text, traceInfo);
              

            }
            if (CheckBox1.Checked && SetContentTypes.Value == "true")
            {
                
                traceInfo = "Set Content Types: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                SetUniqueContentTypeOrder.Value = DCAPXSolution.DeploymentChecklist.SetUniqueContentTypeOrderClass.SetUniqueContentTypeOrder(leftPartUrl + TextBox1.Text, traceInfo);

            }
            if (CheckBox1.Checked && SetUniqueContentTypeOrder.Value == "true")
            {
                
                traceInfo = "Set Unique Content Type Order: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetUniqueContentTypeOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";


                SetDefaultView.Value = DCAPXSolution.DeploymentChecklist.SetDefaultViewClass.SetDefaultView(leftPartUrl + TextBox1.Text, traceInfo);

            }

            if (CheckBox1.Checked && SetDefaultView.Value == "true")
            {
                
                traceInfo = "Set Default View Completed: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";


                SetUniqueRoleAssignments.Value = DCAPXSolution.DeploymentChecklist.SetUniqueRoleAssignmentsClass.SetUniqueRoleAssignments(leftPartUrl + TextBox1.Text, traceInfo);

            }

            if (CheckBox1.Checked && SetUniqueRoleAssignments.Value == "true")
            {
                
                traceInfo = "Set Unique Role Assignments: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetUniqueRoleAssignments", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                AddedItemsToLists.Value = DCAPXSolution.DeploymentChecklist.AddItemsToListsClass.AddItemsToLists(leftPartUrl + TextBox1.Text, traceInfo, ThisNetwork.Value); 

            }
            if (CheckBox1.Checked && AddedItemsToLists.Value == "true")
            {
                
                traceInfo = "Added Items To Lists: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddItemsToLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";




                AddInitialUsersToGroups.Value = DCAPXSolution.DeploymentChecklist.AddInitialUsersToGroupsClass.AddInitialUsersToGroups(leftPartUrl + TextBox1.Text, traceInfo, ThisNetwork.Value);
               

            }
            if (CheckBox1.Checked && AddInitialUsersToGroups.Value == "true")
            {
                
                traceInfo = "Added Initial Users To Groups: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                QuickLaunch.Value = DCAPXSolution.DeploymentChecklist.QuickLaunchOnDCAPXClass.QuickLaunchOnDCAPX(leftPartUrl + TextBox1.Text, traceInfo, TextBox1.Text);

            }
            if (CheckBox1.Checked && QuickLaunch.Value == "true")
            {
                
                traceInfo = "QuickLaunch: " + TextBox1.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                webAppPublishingSiteActivated();

            }

            if (CheckBox1.Checked && WebAppPublishingSiteActivated.Value == "true")
            {
                
                traceInfo = "WebAppPublishingSiteActivated: " + this.Web.Url;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebAppPublishingSiteActivated", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                webAppWebHomePage();

            }
            if (CheckBox1.Checked && WebAppWebHomePage.Value == "true")
            {
                
                traceInfo = "WebAppWebHomePage: " + this.Web.Url;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebAppWebHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addWebAM();

            }




            if (CheckBox1.Checked && AddedWebAM.Value == "true")
            {

                traceInfo = "AddedWebAM";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebAM", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                //addTopNavAAD();

            //}




            //if (CheckBox1.Checked && AddedTopNavAAD.Value == "true")
            //{

            //    traceInfo = "AddedTopNavAAD";
            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddTopNavAAD", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addWebDECRE();

            }
            if (CheckBox1.Checked && AddedWebDECRE.Value == "true")
            {
                
                traceInfo = "AddedWebDECRE";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebDECRE", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addWebMASR();

            }
            if (CheckBox1.Checked && AddedWebMASR.Value == "true")
            {
                
                traceInfo = "AddedWebMASR";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebMASR", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addWebRA();

            }

            if (CheckBox1.Checked && AddedWebRA.Value == "true")
            {
                traceInfo = "AddedWebRA";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebRA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                breakRoleInheritanceSubWebs();

            }
            if (CheckBox1.Checked && BreakRoleInheritanceSubWebs.Value == "true")
            {
                traceInfo = "BreakRoleInheritanceSubWebs";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventBreakRoleInheritanceSubWebs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

            

                RemoveGroupsSubWebs.Value = DCAPXSolution.DeploymentChecklist.RemoveGroupsSubWebsClass.RemoveGroupsSubWebs(leftPartUrl + TextBox1.Text, traceInfo);



            }

            if (CheckBox1.Checked && RemoveGroupsSubWebs.Value == "true")
            {
                traceInfo = "RemoveGroupsSubWebs";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventRemoveGroupsSubWebs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addNavToWebAM();

            }
            if (CheckBox1.Checked && AddedNavToWebAM.Value == "true")
            {
                
                traceInfo = "AddedNavToWebAM";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddNavToWebAM", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                addTopNavAAD();

            }               
            if (CheckBox1.Checked && AddedTopNavAAD.Value == "true")
            {

                traceInfo = "AddedTopNavAAD";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddTopNavAAD", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
   
                addNavToWebRA();

            }
            if (CheckBox1.Checked && AddedNavToWebRA.Value == "true")
            {

                traceInfo = "AddedNavToWebRA";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddNavToWebRA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
    
                addAudiencesForTopNav();

            }

            if (CheckBox1.Checked && AddedAudiencesForTopNav.Value == "true")
            {
                
                traceInfo = "AddedAudiencesForTopNav";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddAudienceForTopNav", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";


                addWebAppRootSiteAdmin();
                setVersionInUse();
            }
            //This will always be the last one
            //if (CheckBox1.Checked && WebAppWebHomePage.Value == "true")
            //{
            //    traceInfo = "WebAppWebHomePage: " + Page.Request.Url.GetLeftPart(UriPartial.Authority);
            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebAppWebHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
             
            //    setVersionInUse();

            //}

        }

        private void addAudiencesForTopNav()
        {
            //LOOP THROUGH GLOBAL NAVIGATION AND SET AUDIENCE
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {

                    SPNavigationNodeCollection topNavBar = oWeb.Navigation.TopNavigationBar;

                    foreach (SPNavigationNode node in topNavBar)
                    {

                        string nodeT = node.Title;
                        string TargetGroups = "";

                        if (nodeT == "AO Administration Dashboards")
                        {

                            try
                            {
                                TargetGroups = ";;;;CONOPSApproval,DCAPXAO,DCAPXOwners";

                                if (node.Properties.Contains("Audience"))
                                {

                                    traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudiencesForTopNav", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                    node.Properties["Audience"] = TargetGroups;
                                }
                                else
                                {
                                    node.Properties.Add("Audience", TargetGroups);
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeAOAdministrationDashboards", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        else
                        {
                            traceInfo = "nodeT: " + nodeT;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudiencesForTopNav", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        }

                        if (nodeT == "Assessment Management")
                        {

                            try
                            {
                                TargetGroups = ";;;;DCAPXOwners";

                                if (node.Properties.Contains("Audience"))
                                {

                                    traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudiencesForTopNav", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                    node.Properties["Audience"] = TargetGroups;
                                }
                                else
                                {
                                    node.Properties.Add("Audience", TargetGroups);
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeAssessmentManagement", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        else
                        {
                            traceInfo = "nodeT: " + nodeT;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudiencesForTopNav", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        }

                        if (nodeT == "Research and Analysis")
                        {

                            try
                            {
                                TargetGroups = ";;;;DCAPXOwners";

                                if (node.Properties.Contains("Audience"))
                                {

                                    traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudiencesForTopNav", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                    node.Properties["Audience"] = TargetGroups;
                                }
                                else
                                {
                                    node.Properties.Add("Audience", TargetGroups);
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeResearchandAnalysis", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        else
                        {
                            traceInfo = "nodeT: " + nodeT;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudiencesForTopNav", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        }

                        oWeb.AllowUnsafeUpdates = true;
                        node.Update();

                        oWeb.Update();
                    }
                }
            }

            

            AddedAudiencesForTopNav.Value = "true";
        }



        private void verifySiteCollectionCreated()
        {

            string url = this.Web.Url.ToString(); // will be "/"


            using (SPSite siteCollectionOuter = new SPSite(url))
            {
                SPWebApplication webApp = siteCollectionOuter.WebApplication;
                SPSiteCollection siteCollections = webApp.Sites;

                foreach (SPSite siteCollectionInner in siteCollections)
                {

                    traceInfo = "siteCollectionInner.ServerRelativeUrl: " + siteCollectionInner.ServerRelativeUrl;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsverifySiteCollectionCreated", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                    traceInfo = "TextBox1.Text: " + TextBox1.Text;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsverifySiteCollectionCreated", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                    try
                    {
                        if (siteCollectionInner.ServerRelativeUrl.Contains(TextBox1.Text) || siteCollectionInner.ServerRelativeUrl == TextBox1.Text)  
                        //if (siteCollectionInner.ServerRelativeUrl == TextBox1.Text)  
                        
                        {
                            traceInfo = "Found " + TextBox1.Text;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsverifySiteCollectionCreated", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";



                            VerifySiteCollectionCreated.Value = "true";
                        }
                    }
                    finally
                    {
                        if (siteCollectionInner != null)
                            siteCollectionInner.Dispose();
                    }
                }


            }



        }

        private void breakRoleInheritanceSubWebs()
        {
            try
            {
                string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
                using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        using (SPWeb amWeb = oWeb.Webs["am"])
                        {
                            if (!amWeb.HasUniqueRoleAssignments)
                            {
                                traceInfo = "amWeb.BreakRoleInheritance";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsamWebBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                amWeb.BreakRoleInheritance(true);
                                amWeb.AllowUnsafeUpdates = true;

                                amWeb.Update();
                            }
                        }
                        //using (SPWeb aadWeb = oWeb.Webs["aad"])
                        //{
                        //    if (!aadWeb.HasUniqueRoleAssignments)
                        //    {
                        //        traceInfo = "aadWeb.BreakRoleInheritance";
                        //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaadWebBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //        aadWeb.BreakRoleInheritance(true);
                        //        aadWeb.AllowUnsafeUpdates = true;

                        //        aadWeb.Update();
                        //    }
                        //}
                        using (SPWeb decreWeb = oWeb.Webs["decre"])
                        {
                            if (!decreWeb.HasUniqueRoleAssignments)
                            {
                                traceInfo = "decreWeb.BreakRoleInheritance";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdecreWebBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                decreWeb.BreakRoleInheritance(true);
                                decreWeb.AllowUnsafeUpdates = true;

                                decreWeb.Update();
                            }
                        }
                        using (SPWeb masrWeb = oWeb.Webs["masr"])
                        {
                            if (!masrWeb.HasUniqueRoleAssignments)
                            {
                                traceInfo = "masrWeb.BreakRoleInheritance";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsmasrWebBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                masrWeb.BreakRoleInheritance(true);
                                masrWeb.AllowUnsafeUpdates = true;

                                masrWeb.Update();
                            }
                        }
                        using (SPWeb raWeb = oWeb.Webs["ra"])
                        {
                            if (!raWeb.HasUniqueRoleAssignments)
                            {
                                traceInfo = "raWeb.BreakRoleInheritance";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsraWebBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                raWeb.BreakRoleInheritance(true);
                                raWeb.AllowUnsafeUpdates = true;

                                raWeb.Update();
                            }
                        }
                    }
                }

                BreakRoleInheritanceSubWebs.Value = "true";

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssubWebsBreakRoleInheritance", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            }
            
        }

        private void checkForDCAPXObjects()
        {
            using (SPSite siteCollectionOuter = new SPSite(this.Web.Url))
            {
                SPWebApplication webApp = siteCollectionOuter.WebApplication;
                SPSiteCollection siteCollections = webApp.Sites;

                //traceInfo = "Checking for /sites/DCAPXObjects";
                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventscheckForDCAPXObjects", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                foreach(SPSite siteCollectionInner in siteCollections)
                {
                    try
                    {
                        if (siteCollectionInner.ServerRelativeUrl.Contains("DCAPXObjects"))
                        {
                            traceInfo = "Found DCAPXObjects. " + siteCollectionInner.ServerRelativeUrl + " Show DeleteDCAPXObjects button.";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventscheckForDCAPXObjects", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                            DeleteDCAPXObjects.Text = "Delete " + TextBox1.Text;
                            DeleteDCAPXObjects.Enabled = true;
                            DeleteDCAPXObjects.Visible = true;

                         
                            //SiteCollectionCreated.Value = "true";
                        }
                    }
                    finally
                    {
                        if (siteCollectionInner != null)
                            siteCollectionInner.Dispose();
                    }
                }
                
               
            }
        }

        private void addWebAppRootSiteAdmin()
        {
            using (SPSite oSite = new SPSite(this.Web.Url))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    if (ThisNetwork.Value == "SIPR Net")
                    {
                        SPUser developer = null;
                        try
                        {
                            if (oWeb.AllUsers["resource\\danielnw"] != null)
                            {
                                developer = oWeb.AllUsers["resource\\danielnw"];
                                if (!developer.IsSiteAdmin)
                                {
                                    developer.IsSiteAdmin = true;

                                    traceInfo = "Adding resource\\danielnw as site admin to " + oWeb.Url;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddingSiteAdmin", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                                    developer.Update();

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddingSiteAdmin", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        SPUser sysadmin = null;
                        try
                        {
                            if (oWeb.AllUsers["resource\\clarkrm"] != null)
                            {
                                sysadmin = oWeb.AllUsers["resource\\clarkrm"];
                                if (!sysadmin.IsSiteAdmin)
                                {
                                    sysadmin.IsSiteAdmin = true;

                                    traceInfo = "Adding resource\\clarkrm as site admin to " + oWeb.Url;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddingSiteAdmin", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                                    sysadmin.Update();

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddingSiteAdmin", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        SPUser sysadmin2 = null;
                        try
                        {
                            if (oWeb.AllUsers["resource\\clarkr-p"] != null)
                            {
                                sysadmin2 = oWeb.AllUsers["resource\\clarkr-p"];
                                if (!sysadmin2.IsSiteAdmin)
                                {
                                    sysadmin2.IsSiteAdmin = true;

                                    traceInfo = "Adding resource\\clarkr-p as site admin to " + oWeb.Url;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddingSiteAdmin", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                                    sysadmin2.Update();

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddingSiteAdmin", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                    }
                    else
                    {

                    }
                }
            }
            
            
        }

        private void addNavToWebRA()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    using (SPWeb raWeb = oWeb.Webs["ra"])
                    {
                        SPNavigationNodeCollection navNodeColl = oWeb.Navigation.TopNavigationBar;
                        bool IsInTopNav = false;

                        foreach (SPNavigationNode nodeTopNav in navNodeColl)
                        {
                            if (nodeTopNav.Title == raWeb.Title)
                            {
                                IsInTopNav = true;
                            }
                        }
                        if (!IsInTopNav)
                        {
                            try
                            {
                                raWeb.Navigation.UseShared = true;
                                SPNavigationNode nodera = new SPNavigationNode(raWeb.Title, raWeb.ServerRelativeUrl);
                                oWeb.Navigation.TopNavigationBar.AddAsLast(nodera);

                                AddedNavToWebRA.Value = "true";
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddNavToWebRA", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        else
                        {
                            AddedNavToWebRA.Value = "true";
                        }

                    }

                }
            }
        }

        private void addNavToWebAM()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    using (SPWeb amWeb = oWeb.Webs["am"])
                    {
                        SPNavigationNodeCollection navNodeColl = oWeb.Navigation.TopNavigationBar;
                        bool IsInTopNav = false;

                        foreach (SPNavigationNode nodeTopNav in navNodeColl)
                        {
                            if (nodeTopNav.Title == amWeb.Title)
                            {
                                IsInTopNav = true;
                            }
                        }
                        if (!IsInTopNav)
                        {
                            try
                            {
                                amWeb.Navigation.UseShared = true;
                                SPNavigationNode nodeamd = new SPNavigationNode(amWeb.Title, amWeb.ServerRelativeUrl);
                                oWeb.Navigation.TopNavigationBar.AddAsLast(nodeamd);

                                AddedNavToWebAM.Value = "true";
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddNavToWebAM", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        else
                        {
                            AddedNavToWebAM.Value = "true";
                        }

                    }

                }
            }
        }

        private void addWebRA()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Creating " + TextBox1.Text + "/ra";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebRA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    try
                    {
                        SPWeb raWeb = oWeb.Webs.Add("ra", "Research and Analysis", "Research and Analysis", oWeb.Language, "STS#0", false, false);
                        AddedWebRA.Value = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebRA", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        if (ex.Message.Contains("already in use"))
                        {
                            AddedWebRA.Value = "true";
                        }
                    }
                }
            }
        }

        private void addWebMASR()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Creating " + TextBox1.Text + "/masr";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebMASR", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    try
                    {
                        SPWeb masrWeb = oWeb.Webs.Add("masr", "MASR", "MASR", oWeb.Language, "STS#0", false, false);
                        AddedWebMASR.Value = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebMASR", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        if (ex.Message.Contains("already in use"))
                        {
                            AddedWebMASR.Value = "true";
                        }
                    }
                }
            }
        }

        private void addWebDECRE()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Creating " + TextBox1.Text + "/decre";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebDECRE", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    try
                    {
                        SPWeb decreWeb = oWeb.Webs.Add("decre", "DECRE", "DECRE", oWeb.Language, "STS#0", false, false);
                        AddedWebDECRE.Value = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebDECRE", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        if (ex.Message.Contains("already in use"))
                        {
                            AddedWebDECRE.Value = "true";
                        }
                    }
                }
            }
        }

        private void addTopNavAAD()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Adding  AAD to TopNav";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddTopNavAAD", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    SPNavigationNodeCollection navNodeColl = oWeb.Navigation.TopNavigationBar;
                    
                    bool IsInTopNav = false;

                    foreach (SPNavigationNode nodeTopNav in navNodeColl)
                    {
                        if (nodeTopNav.Title == "AO Administration Dashboards")
                        {
                            IsInTopNav = true;
                        }
                    }
                    if (!IsInTopNav)
                    {
                        try
                        {
                            SPNavigationNode nodeaad = new SPNavigationNode("AO Administration Dashboards", leftPartUrl + TextBox1.Text + "/_layouts/DCAPXSolution/AOAdministrationDashboards.aspx");
                            oWeb.Navigation.TopNavigationBar.AddAsLast(nodeaad);

                            AddedTopNavAAD.Value = "true";
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddTopNavAAD", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                    else
                    {
                        AddedTopNavAAD.Value = "true";
                    }
                }
            }

        }

        private void addWebAM()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Creating " + TextBox1.Text + "/am";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebAM", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    try
                    {
                        SPWeb amWeb = oWeb.Webs.Add("am", "Assessment Management", "Assessment Management", oWeb.Language, "STS#0", false, false);
                        AddedWebAM.Value = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddWebAM", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        if (ex.Message.Contains("already in use"))
                        {
                            AddedWebAM.Value = "true";
                        }
                    }
                }
            }
        }

        private void setVersionInUse()
        {
            if (this.Web.AllProperties["DCAPXSolutionVersionInUse"] != null)
            {
               
                this.Web.AllowUnsafeUpdates = true;
                this.Web.AllProperties["DCAPXSolutionVersionInUse"] = assemblyVersion;
                this.Web.Update();
                Label8.Text = assemblyVersion;
                Label9.Text = "";
                
                traceInfo = "Property DCAPXSolutionVersionInUse updated: " + this.Web.AllProperties["DCAPXSolutionVersionInUse"].ToString();
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetVersionInUse", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";

                traceInfo = "Versions match. All operations completed";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetVersionInUse", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br /><br /><br />";
                
                CheckBox1.Checked = false;
                CheckBox1.Enabled = false;
                CheckBox1.Text = "Versions match. All operations completed";

                SetVersionInUse.Value = "true";
                Refresh.Visible = true;
            }
        }

        private void checkVersionInUse()
        {
            traceInfo = "checkVersionInUse: " + TextBox1.Text;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventscheckVersionInUse", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            if (DCAPXSolutionVersionInUse != "")
            {
                Label8.Text = DCAPXSolutionVersionInUse;

            }
            if (assemblyVersion != DCAPXSolutionVersionInUse)
            {
                Label9.Text = "Versions do not match.";

            }
           

        }

        private void webAppWebHomePage()
        {
            using (SPSite oSite = new SPSite(this.Web.Url))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {

                    SPFolder oFolder = oWeb.RootFolder;
                    if (oFolder.WelcomePage != "SitePages/DCAPXInfo.aspx")
                    {
                        try
                        {
                            traceInfo = "Setting DCAPXInfo.aspx as Welcome Page on WebAppWeb";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebAppWebHomePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 

                            oWeb.AllowUnsafeUpdates = true;
                            oFolder.WelcomePage = "SitePages/DCAPXInfo.aspx";
                            oFolder.Update();
                          

                            WebAppWebHomePage.Value = "true";

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebAppWebHomePage", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                        WebAppWebHomePage.Value = "true";
                    }

                }
            }
        }

        private void webAppPublishingSiteActivated()
        {
            using (SPSite oSite = new SPSite(this.Web.Url))
            {

                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    if (oSite.Features[guidFeatureIDPublishingSite] == null)
                    {
                        try
                        {
                            oSite.AllowUnsafeUpdates = true;

                            traceInfo = "Activating Publishing Infrastructure on WebApp";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebAppPublishingSiteActivated", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUtility.ValidateFormDigest();
                            oWeb.AllowUnsafeUpdates = true;
                            SPFeature oFeatureWebAppPublishingSite = oSite.Features.Add(guidFeatureIDPublishingSite);
                            oWeb.Update();

                            WebAppPublishingSiteActivated.Value = "true";
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebAppPublishingSiteActivated", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                        WebAppPublishingSiteActivated.Value = "true";
                    }

                }

            }
        }

        private void enableVersioning()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;
                     
                    SPListCollection oWebLists = oWeb.Lists;

                     
                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }
                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                    }


                    if (!libCONOPSDevAFOTEC.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevAFOTEC list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevAFOTEC.EnableVersioning = true;



                    }

                    if (!libCONOPSDevATEC.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevATEC list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevATEC.EnableVersioning = true;



                    }

                    if (!libCONOPSDevCOTF.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevCOTF list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevCOTF.EnableVersioning = true;



                    }

                    if (!libCONOPSDevJITC.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevJITC list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevJITC.EnableVersioning = true;


                    }

                    if (!libCONOPSDevMCOTEA.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevMCOTEA list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEAEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevMCOTEA.EnableVersioning = true;



                    }






                    if (!listCONOPSDevWSAFOTEC.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevWSAFOTEC list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSAFOTEC.EnableVersioning = true;
                           

                     
                    }
                 
                    if (!listCONOPSDevWSATEC.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevWSATEC list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSATEC.EnableVersioning = true;
                           

                       
                    }
                
                    if (!listCONOPSDevWSCOTF.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevWSCOTF list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSCOTF.EnableVersioning = true;
                           

                       
                    }
                  
                    if (!listCONOPSDevWSJITC.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevWSJITC list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSJITC.EnableVersioning = true;
                           

                    }
                 
                    if (!listCONOPSDevWSMCOTEA.EnableVersioning)
                    {

                        traceInfo = "Enable versioning on CONOPSDevWSMCOTEA list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAEnableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSMCOTEA.EnableVersioning = true;
                           

                       
                    }


                    try
                    {
                        traceInfo = "Update() lists";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsenableVersioning", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevMCOTEA.Update();

                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSMCOTEA.Update();

                        EnabledVersioning.Value = "true";

                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsenableVersioning", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

         
                }
            }
        }

        private void breakRoleInheritance()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;

                    SPListCollection oWebLists = oWeb.Lists;


                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }
                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                    }

                    if (!libCONOPSDevAFOTEC.HasUniqueRoleAssignments)
                    {
                        traceInfo = "libCONOPSDevAFOTEC.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevAFOTEC.BreakRoleInheritance(false);

                    }

                    if (!libCONOPSDevATEC.HasUniqueRoleAssignments)
                    {
                        traceInfo = "libCONOPSDevATEC.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevATEC.BreakRoleInheritance(false);

                    }

                    if (!libCONOPSDevCOTF.HasUniqueRoleAssignments)
                    {
                        traceInfo = "libCONOPSDevCOTF.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevCOTF.BreakRoleInheritance(false);

                    }

                    if (!libCONOPSDevJITC.HasUniqueRoleAssignments)
                    {
                        traceInfo = "libCONOPSDevJITC.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevJITC.BreakRoleInheritance(false);

                    }

                    if (!libCONOPSDevMCOTEA.HasUniqueRoleAssignments)
                    {
                        traceInfo = "libCONOPSDevMCOTEA.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEABreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        libCONOPSDevMCOTEA.BreakRoleInheritance(false);

                    }





                    if (!listCONOPSDevWSAFOTEC.HasUniqueRoleAssignments)
                    {
                        traceInfo = "listCONOPSDevWSAFOTEC.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSAFOTEC.BreakRoleInheritance(false);

                    }

                    if (!listCONOPSDevWSATEC.HasUniqueRoleAssignments)
                    {
                        traceInfo = "listCONOPSDevWSATEC.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSATEC.BreakRoleInheritance(false);

                    }

                    if (!listCONOPSDevWSCOTF.HasUniqueRoleAssignments)
                    {
                        traceInfo = "listCONOPSDevWSCOTF.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSCOTF.BreakRoleInheritance(false);

                    }

                    if (!listCONOPSDevWSJITC.HasUniqueRoleAssignments)
                    {
                        traceInfo = "listCONOPSDevWSJITC.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCBreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSJITC.BreakRoleInheritance(false);

                    }

                    if (!listCONOPSDevWSMCOTEA.HasUniqueRoleAssignments)
                    {
                        traceInfo = "listCONOPSDevWSMCOTEA.BreakRoleInheritance";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEABreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSMCOTEA.BreakRoleInheritance(false);

                    }

                    try
                    {
                        traceInfo = "Update() lists";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsbreakRoleInheritance", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevMCOTEA.Update();
                        
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSMCOTEA.Update();

                        BreakRoleInheritance.Value = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsbreakRoleInheritance", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }




                }
            }
        }

        private void webOps()
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    if (oWeb.Description != TextBox2.Text)
                    {
                        try
                        {
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Description = TextBox2.Text;
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebOps", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }

                    }
                    
                }
            }
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    if (oWeb.Title != TextBox3.Text)
                    {
                        try
                        {
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Title = TextBox3.Text;
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsWebOps", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }

                    }

                }
            }
            WebOps.Value = "true";
        }

        private void addLists()
        {

            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    //SPFieldCollection oWebFields = oWeb.Fields;
                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;
                    SPList listCONOPSDevProgress = null; 
                    SPList listCONOPSApprovalProgress = null;
                    SPList listDCAPXPOCs = null;
                    SPList listFeedback = null;
                    SPList listProgramContacts = null;
                    SPList listMasterCalendar = null;
                 
                    SPListCollection oWebLists = oWeb.Lists;

                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }

                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                        if (oList.Title == "CONOPSDevProgress")
                        {
                            listCONOPSDevProgress = oList;
                        }
                        if (oList.Title == "CONOPSApprovalProgress")
                        {
                            listCONOPSApprovalProgress = oList;
                        }
                        if (oList.Title == "DCAPXPOCs")
                        {
                            listDCAPXPOCs = oList;
                        }
                        if (oList.Title == "Feedback")
                        {
                            listFeedback = oList;
                        }
                        if (oList.Title == "ProgramContacts")
                        {
                            listProgramContacts = oList;
                        }
                        if (oList.Title == "MasterCalendar")
                        {
                            listMasterCalendar = oList;
                        }
                            
                            
                        
                        
                    }


                    if (libCONOPSDevAFOTEC == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/CONOPSDevAFOTEC";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 
                            
                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevAFOTEC", "Worksheets Attachments", SPListTemplateType.DocumentLibrary);
                            oWeb.Update();                         
                            
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); 

                        }
                    }
                    if (libCONOPSDevATEC == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/CONOPSDevATEC";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevATEC", "Worksheets Attachments", SPListTemplateType.DocumentLibrary);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (libCONOPSDevCOTF == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/CONOPSDevCOTF";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevCOTF", "Worksheets Attachments", SPListTemplateType.DocumentLibrary);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (libCONOPSDevJITC == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/CONOPSDevJITC";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevJITC", "Worksheets Attachments", SPListTemplateType.DocumentLibrary);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (libCONOPSDevMCOTEA == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/CONOPSDevMCOTEA";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevMCOTEA", "Worksheets Attachments", SPListTemplateType.DocumentLibrary);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listCONOPSDevWSAFOTEC == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/CONOPSDevWSAFOTEC";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevWSAFOTEC", "Worksheets", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listCONOPSDevWSATEC == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/CONOPSDevWSATEC";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevWSATEC", "Worksheets", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listCONOPSDevWSCOTF == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/CONOPSDevWSCOTF";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevWSCOTF", "Worksheets", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listCONOPSDevWSJITC == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/CONOPSDevWSJITC";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevWSJITC", "Worksheets", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listCONOPSDevWSMCOTEA == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/CONOPSDevWSMCOTEA";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevWSMCOTEA", "Worksheets", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listCONOPSDevProgress == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/CONOPSDevProgress";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSDevProgress", "Worksheets Progress", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listCONOPSApprovalProgress == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/CONOPSApprovalProgress";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("CONOPSApprovalProgress", "Worksheets Approval Progress", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listDCAPXPOCs == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/DCAPXPOCs";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("DCAPXPOCs", "DOT&E DCAPX support staff", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listFeedback == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/Feedback";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("Feedback", "Feedback and Comments", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listProgramContacts == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/ProgramContacts";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("ProgramContacts", "OTAs who serve as points of contact for DOT&E", SPListTemplateType.GenericList);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    if (listMasterCalendar == null)
                    {
                        try
                        {
                            traceInfo = "Creating " + TextBox1.Text + "/Lists/MasterCalendar";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.AllowUnsafeUpdates = true;
                            oWebLists.Add("MasterCalendar", "Events from MASR", SPListTemplateType.Events);
                            oWeb.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                        
                    AllListsAdded.Value = "true";
                }
            }
        }

        private void addCustomFeatures()
        {
           
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            
            if(AddedFeature1.Value != "true")
            {
                using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPFeatureCollection oSiteFeatures = oSite.Features;
                        if (oSiteFeatures[guidFeatureID] == null)
                        {
                            oSite.AllowUnsafeUpdates = true;
                            oWeb.AllowUnsafeUpdates = true;
                            try
                            {
                                SPUtility.ValidateFormDigest();
                                SPFeature oFeature1 = oSiteFeatures.Add(guidFeatureID);
                                AddedFeature1.Value = "true";
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }
                        }
                    }

                }
            }


            if (AddedFeature2.Value != "true")
            {
                using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPFeatureCollection oSiteFeatures = oSite.Features;
                        if (oSiteFeatures[guidFeatureID2] == null)
                        {
                            oSite.AllowUnsafeUpdates = true;
                            oWeb.AllowUnsafeUpdates = true;
                            try
                            {
                                SPUtility.ValidateFormDigest();
                                SPFeature oFeature2 = oSiteFeatures.Add(guidFeatureID2);
                                AddedFeature2.Value = "true";
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }
                        }
                    }

                }
            }
            if (AddedFeature3.Value != "true")
            {
                using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPFeatureCollection oSiteFeatures = oSite.Features;
                        if (oSiteFeatures[guidFeatureID3] == null)
                        {
                            oSite.AllowUnsafeUpdates = true;
                            oWeb.AllowUnsafeUpdates = true;
                            try
                            {
                                SPUtility.ValidateFormDigest();
                                SPFeature oFeature3 = oSiteFeatures.Add(guidFeatureID3);
                                AddedFeature3.Value = "true";
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }
                        }
                    }

                }
            }
            using (SPSite oSite = new SPSite(leftPartUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    if (oSite.Features[guidFeatureID] == null )
                    {
                        try
                        {
                            oSite.AllowUnsafeUpdates = true;

                            traceInfo = "Activating Feature1 on WebApp";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUtility.ValidateFormDigest();
                            oWeb.AllowUnsafeUpdates = true;
                            SPFeature oFeatureWebAppFeature1Activated = oSite.Features.Add(guidFeatureID);
                            oWeb.Update();

                            AddedFeature1ToWebApp.Value = "true";
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }

                    if (oSite.Features[guidFeatureID2] == null)
                    {
                        try
                        {
                            oSite.AllowUnsafeUpdates = true;

                            traceInfo = "Activating Feature2 on WebApp";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUtility.ValidateFormDigest();
                            oWeb.AllowUnsafeUpdates = true;
                            SPFeature oFeatureWebAppFeature2Activated = oSite.Features.Add(guidFeatureID2);
                            oWeb.Update();

                            AddedFeature2ToWebApp.Value = "true";
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    } 
                    if (oSite.Features[guidFeatureID3] == null)
                    {
                        try
                        {
                            oSite.AllowUnsafeUpdates = true;

                            traceInfo = "Activating Feature3 on WebApp";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUtility.ValidateFormDigest();
                            oWeb.AllowUnsafeUpdates = true;
                            SPFeature oFeatureWebAppFeature3Activated = oSite.Features.Add(guidFeatureID3);
                            oWeb.Update();

                            AddedFeature3ToWebApp.Value = "true";
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                }

            }
            if (AddedFeature1.Value == "true" && AddedFeature1ToWebApp.Value == "true" && AddedFeature2.Value == "true" && AddedFeature3.Value == "true")
            {
                CustomFeaturesAdded.Value = "true";
            }
            else
            {
                CustomFeaturesAdded.Value = "false";

            }
        }

        private void removeCustomFeatures()
        {
            

            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPFeatureCollection oSiteFeatures = oSite.Features;
                    if (oSiteFeatures[guidFeatureID] != null)
                    {
                        oSite.AllowUnsafeUpdates = true;
                        oWeb.AllowUnsafeUpdates = true;
                        try
                        {
                            SPUtility.ValidateFormDigest();
                            oSiteFeatures.Remove(guidFeatureID, true);

                            AddedFeature1.Value = "false";

                           
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                      
                        AddedFeature1.Value = "false";
                        traceInfo = "Cannot remove Feature1. It is not on " + TextBox1.Text ;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                    
                    }
                }
                
            }

            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using(SPWeb oWeb = oSite.OpenWeb())
                {
                    SPFeatureCollection oSiteFeatures = oSite.Features;
                    if (oSiteFeatures[guidFeatureID2] != null )
                    {
                        oSite.AllowUnsafeUpdates = true;
                        oWeb.AllowUnsafeUpdates = true;
                        try
                        {
                            SPUtility.ValidateFormDigest();
                            oSiteFeatures.Remove(guidFeatureID2, true);

                            AddedFeature2.Value = "false";

                            
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                        traceInfo = "Cannot remove Feature2. It is not on " + TextBox1.Text;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                        AddedFeature2.Value = "false";
                        
                    }
                }
                
            }
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPFeatureCollection oSiteFeatures = oSite.Features;
                    if (oSiteFeatures[guidFeatureID3] != null)
                    {
                        oSite.AllowUnsafeUpdates = true;
                        oWeb.AllowUnsafeUpdates = true;
                        try
                        {
                            SPUtility.ValidateFormDigest();
                            oSiteFeatures.Remove(guidFeatureID3, true);

                            AddedFeature3.Value = "false";

                           
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                        traceInfo = "Cannot remove Feature3. It is not on " + TextBox1.Text;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                        AddedFeature3.Value = "false";
                        
                    }
                }

            }
            // Remove from WebApp
            using (SPSite oSite = new SPSite(leftPartUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPFeatureCollection oSiteFeatures = oSite.Features;
                    if (oSiteFeatures[guidFeatureID3] != null )
                    {
                        oSite.AllowUnsafeUpdates = true;
                        oWeb.AllowUnsafeUpdates = true;
                        try
                        {
                            SPUtility.ValidateFormDigest();
                            oSiteFeatures.Remove(guidFeatureID3, true);

                            AddedFeature3ToWebApp.Value = "false";

                            
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                        traceInfo = "Cannot remove Feature3. It is not on " + leftPartUrl;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                        AddedFeature3ToWebApp.Value = "false";
                        
                    }
                    if (oSiteFeatures[guidFeatureID2] != null)
                    {
                        oSite.AllowUnsafeUpdates = true;
                        oWeb.AllowUnsafeUpdates = true;
                        try
                        {
                            SPUtility.ValidateFormDigest();
                            oSiteFeatures.Remove(guidFeatureID2, true);

                            AddedFeature2ToWebApp.Value = "false";


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                        traceInfo = "Cannot remove Feature2. It is not on " + leftPartUrl;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                        AddedFeature2ToWebApp.Value = "false";

                    }
                    if (oSiteFeatures[guidFeatureID] != null)
                    {
                        oSite.AllowUnsafeUpdates = true;
                        oWeb.AllowUnsafeUpdates = true;
                        try
                        {
                            SPUtility.ValidateFormDigest();
                            oSiteFeatures.Remove(guidFeatureID, true);

                            AddedFeature1ToWebApp.Value = "false";


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {
                        traceInfo = "Cannot remove Feature1. It is not on " + leftPartUrl;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveCustomFeatures", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                        AddedFeature1ToWebApp.Value = "false";

                    }
                }

            }

            if (AddedFeature1.Value == "false" && AddedFeature1ToWebApp.Value == "false" && AddedFeature2.Value == "false" && AddedFeature3.Value == "false")
            {
                CustomFeaturesRemoved.Value = "true";
            }
            else
            {
                CustomFeaturesRemoved.Value = "false";
            }
            
        }

        private void addPropertyToWeb(string p, string todaysUpdate)
        {

            using (SPWeb oWeb = SPContext.Current.Site.OpenWeb())
            {
                try
                {
                    oWeb.AllowUnsafeUpdates = true;
                    oWeb.AddProperty(p, todaysUpdate);
                    oWeb.Update();

                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddProperty", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                }
            }
            
        }

        private void userIsNotAuthorizedToUseThisPage()
        {
            traceInfo = "userIsNotAuthorizedToUseThisPage";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("userIsNotAuthorizedToUseThisPage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 

            
            //throw new AccessViolationException("You must be a server farm administrator to run the Deployment Checklist.");

            SPUtility.Redirect(SPUtility.AccessDeniedPage, SPRedirectFlags.RelativeToLayoutsPage, Context);
        }

        private void addThisGroup(string groupName, string groupDescription, SPRoleType groupRole)
        {
            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    try
                    {
                        oWeb.AllowUnsafeUpdates = true;

                        oWeb.SiteGroups.Add(groupName, oWeb.SiteAdministrators[0], null, groupDescription);

                        oWeb.Update();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventAddaddThisGroup", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                    try
                    {

                        oWeb.AllowUnsafeUpdates = true;

                        oWeb.AssociatedGroups.Add(oWeb.SiteGroups[groupName]);
 
                        oWeb.Update();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventAssocaddThisGroup", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Try to set RoleAssignment for " + groupName;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventRoleAssigaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        
                    try
                    {
                        oWeb.AllowUnsafeUpdates = true;

                        SPGroup oGroup = oWeb.SiteGroups[groupName];

                        SPRoleDefinition oRole = oWeb.RoleDefinitions.GetByType(groupRole);

                        SPRoleAssignment oRoleAssignment = new SPRoleAssignment(oGroup);

                        oRoleAssignment.RoleDefinitionBindings.Add(oRole);

                        oWeb.RoleAssignments.Add(oRoleAssignment);
                     
                        oWeb.Update();

                        traceInfo = "Added " + groupName + " to " + TextBox1.Text;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventRoleAddedaddThisGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                        
                        if(groupName == "DCAPXOwners")
                        {
                            AddedDCAPXOwners.Value = "true";
                        }
                        if (groupName == "DCAPXVisitors")
                        {
                            AddedDCAPXVisitors.Value = "true";
                        }
                        if (groupName == "DCAPXAO")
                        {
                            AddedDCAPXAO.Value = "true";
                        }
                        if (groupName == "DCAPXOTA")
                        {
                            AddedDCAPXOTA.Value = "true";
                        }
                        if (groupName == "CONOPSApproval")
                        {
                            AddedCONOPSApproval.Value = "true";
                        }
                        if (groupName == "CONOPSDevReadersAFOTEC")
                        {
                            AddedCONOPSDevReadersAFOTEC.Value = "true";
                        }
                        if (groupName == "CONOPSDevReadersATEC")
                        {
                            AddedCONOPSDevReadersATEC.Value = "true";
                        }
                        if (groupName == "CONOPSDevReadersCOTF")
                        {
                            AddedCONOPSDevReadersCOTF.Value = "true";
                        }
                        if (groupName == "CONOPSDevReadersJITC")
                        {
                            AddedCONOPSDevReadersJITC.Value = "true";
                        }
                        if (groupName == "CONOPSDevReadersMCOTEA")
                        {
                            AddedCONOPSDevReadersMCOTEA.Value = "true";
                        }
                        if (groupName == "CONOPSDevSubmittersAFOTEC")
                        {
                            AddedCONOPSDevSubmittersAFOTEC.Value = "true";
                        }
                        if (groupName == "CONOPSDevSubmittersATEC")
                        {
                            AddedCONOPSDevSubmittersATEC.Value = "true";
                        }
                        if (groupName == "CONOPSDevSubmittersCOTF")
                        {
                            AddedCONOPSDevSubmittersCOTF.Value = "true";
                        }
                        if (groupName == "CONOPSDevSubmittersJITC")
                        {
                            AddedCONOPSDevSubmittersJITC.Value = "true";
                        }
                        if (groupName == "CONOPSDevSubmittersMCOTEA")
                        {
                            AddedCONOPSDevSubmittersMCOTEA.Value = "true";
                        }
                        if (groupName == "USAFRICOM")
                        {
                            AddedUSAFRICOM.Value = "true";
                        }
                        if (groupName == "USCENTCOM")
                        {
                            AddedUSCENTCOM.Value = "true";
                        }
                        if (groupName == "USEUCOM")
                        {
                            AddedUSEUCOM.Value = "true";
                        }
                        if (groupName == "USNORTHCOM")
                        {
                            AddedUSNORTHCOM.Value = "true";
                        }
                        if (groupName == "USPACOM")
                        {
                            AddedUSPACOM.Value = "true";
                        }
                        if (groupName == "USSOUTHCOM")
                        {
                            AddedUSSOUTHCOM.Value = "true";
                        }
                        if (groupName == "USSOCOM")
                        {
                            AddedUSSOCOM.Value = "true";
                        }
                        if (groupName == "USSTRATCOM")
                        {
                            AddedUSSTRATCOM.Value = "true";
                        }
                        if (groupName == "USTRANSCOM")
                        {
                            AddedUSTRANSCOM.Value = "true";
                        }

                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventRoleAddedaddThisGroup", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }


        }


        private bool groupHasPermissionsOnWeb(string groupName)
        {
            bool returnVal = false;
            var traceInfo = "";

            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    if (oWeb.HasUniqueRoleAssignments)
                    {
                        SPRoleAssignmentCollection oRoleAssignments = oWeb.RoleAssignments;

                        foreach (SPRoleAssignment oRoleAssignment in oRoleAssignments)
                        {
                            SPPrincipal oPrincipal = oRoleAssignment.Member;
                            
                            if (oPrincipal is SPGroup)                            
                            {
                                try
                                {
                                    SPGroup oRoleGroup = (SPGroup)oPrincipal;
                                    string strGroupName = oRoleGroup.Name;
                                    if (strGroupName == groupName)
                                    {
                                        returnVal = true;

                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsgroupHasPermissionsOnWeb", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                }
                            }

                            
                        }
                    }
                    
                }
            }
            
            traceInfo = groupName + returnVal;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsgroupHasPermissionsOnWeb", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

             
            return returnVal;
        }
        




        private void activateFeature(Guid guidFeatureID, string featureName)
        {

            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Activated " + featureName + ": " + TextBox1.Text;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsactivateFeature", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                    try
                    {
                        SPFeatureCollection oSiteFeatures = oSite.Features;
                        SPUtility.ValidateFormDigest();
                        SPFeature oFeature = oSiteFeatures.Add(guidFeatureID);
                        if (featureName == "Standard Site Collection features")
                        {
                            BaseSiteActivated.Value = "true";
                        }
                        if (featureName == "Enterprise Site Collection features")
                        {
                            PremiumSiteActivated.Value = "true";
                        }
                        if (featureName == "Publishing Infrastructure")
                        {
                            PublishingSiteActivated.Value = "true";
                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsactivateFeature", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                    }

                   
                    if (BaseSiteActivated.Value == "true" && PremiumSiteActivated.Value == "true" && PublishingSiteActivated.Value == "true")
                    {
                        AllNativeFeaturesActivated.Value = "true";

                    }
                   
                    
                }
                
        
            }

            
            
        }

        protected void DeleteDCAPXObjects_Click(object sender, EventArgs e)
        {
            using(SPWeb oWeb = SPContext.Current.Site.OpenWeb())
            {
                try
                {
                    oWeb.AllowUnsafeUpdates = true;

                    SPNavigationNodeCollection nodes = oWeb.Navigation.QuickLaunch;
                    for (int i = nodes.Count - 1; i >= 0; i--)
                    {
                        nodes[i].Delete();
                    }

                    oWeb.Update();

                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsClearQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); 

                }
            }
            
            
            
            
            Button clickedButton = (Button)sender;

            Guid contentDBID;
            //SPContentDatabase contentDB = null;

            string leftPartUrl = Page.Request.Url.GetLeftPart(UriPartial.Authority);
            using (SPSite oSite = new SPSite(leftPartUrl + TextBox1.Text))
            {
                using(SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "Deleted site collection " + TextBox1.Text;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeleteDCAPXObjects", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); traceInfoDiv.InnerHtml += traceInfo + "<br />";
                    
                    SPUtility.ValidateFormDigest();
                    contentDBID = oSite.ContentDatabase.Id;
                    //contentDB = oSite.ContentDatabase;
                    oSite.Delete(); 
                }
                

            }

            //try
            //{
            //    if (contentDB.Exists)
            //    {
            //        contentDB.Delete();
            //    }
            //}
            //catch (Exception ex)
            //{
            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("contentDBDelete", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            //}
            try
            {
                SPWebApplication oWebApp = SPContext.Current.Site.WebApplication;
                SPContentDatabaseCollection oWebAppContentDBs = oWebApp.ContentDatabases;

                oWebAppContentDBs[contentDBID].Delete();
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oWebAppContentDBIDDelete", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            }
            clickedButton.Visible = false;
          
            Response.Redirect(Request.RawUrl);
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {


        }

        protected void Refresh_Click(object sender, EventArgs e)
        {
            //button will postback so no need for javascript below
            //Page.ClientScript.RegisterStartupScript(typeof(Page), "refresh", "<script type=\"text/javascript\">location.replace(location.href);</script>");

        }
    }
}
    