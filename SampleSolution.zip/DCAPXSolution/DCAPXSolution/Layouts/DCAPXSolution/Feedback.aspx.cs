﻿using System;
using System.Web.UI;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;

namespace DCAPXSolution.Layouts.DCAPXSolution
{
    public partial class Feedback : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Save_Click(object sender, EventArgs e)
        {

            SPUser user = Web.CurrentUser;
            Guid siteID = Web.Site.ID;


            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb web = site.RootWeb)
                    {

                        try
                        {

                            var traceInfo = "Feedback";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeedback", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            SPList FeedbackList = web.Lists["Feedback"];
                            SPListItemCollection FeedbackListItems = FeedbackList.Items;
                            SPListItem FeedbackListItem = FeedbackListItems.Add();

                            SPFieldUserValue currentUser = new SPFieldUserValue(web, user.ID, user.Name);

                            FeedbackListItem["Title"] = "Feedback and Comments from " + user.Name;
                            FeedbackListItem["Comments"] = SPHttpUtility.HtmlEncode(Comments.Text);

                            FeedbackListItem["Author"] = currentUser;
                            FeedbackListItem["Editor"] = currentUser;

                            web.AllowUnsafeUpdates = true;
                            FeedbackListItem.Update();

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeedback", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                       


                    }
                }
            });
            Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert(\"Thank you " + user.Name + ". Your feedback and comments will help us improve this site.\"); SP.UI.ModalDialog.commonModalDialogClose('OK', 'Feedback Saved');</script>");

        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");

        }
    }
}
