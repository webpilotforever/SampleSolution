﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Collections.Generic;

namespace DCAPXSolution.Layouts.DCAPXSolution
{
    public partial class AOAdministrationDashboards : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            pclink.HRef = Web.ServerRelativeUrl + "/Lists/ProgramContacts/AllItems.aspx";


            if (!Web.CurrentUser.LoginName.Contains("danielnw"))
            {
                //Button1.Enabled = false;
            }
            
            //Are you supposed to be here?

            bool IsListContributor = false;

            try
            {


                string oUser = Page.User.Identity.Name;

                SPUser oSPUser = this.Site.RootWeb.AllUsers[oUser];

                SPGroupCollection currentUsersGroups = oSPUser.Groups;

                foreach (SPGroup group in currentUsersGroups)
                {
                    string groupName = group.Name;
                    if (groupName.Contains("CONOPSApproval") || groupName.Contains("DCAPXAO") || groupName.Contains("DCAPXOwners"))
                    {
                        IsListContributor = true;
                    }
                }

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
            if (!IsListContributor)
            {
                Container.Visible = false;

                DivNotAuthorized.Visible = true;

                LabelNotAuthorized.Visible = true;
                LinkButtonNotAuthorized.PostBackUrl = this.Site.ServerRelativeUrl;
                LinkButtonNotAuthorized.Visible = true;
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            if (Web.CurrentUser.LoginName.Contains("danielnw"))
            {


                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.Lists["CONOPSDevProgress"];

                SPList oListCONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
                SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
                oQueryCONOPSApprovalProgress.Query = "<Where>" +

                        "<Neq>" +
                            "<FieldRef Name='CONOPSApproval'/>" +
                                "<Value Type='Choice'>Baseline OTA Submission</Value>" +
                         "</Neq>" +

                "</Where>";

                SPListItemCollection collItemsSubmitted = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

                try
                {
                    var traceInfo = "Reset CONOPSApprovalProgress";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                    foreach (SPListItem oListItem in collItemsSubmitted)
                    {
                        oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                        oListItem["Submitted"] = "";
                        oListItem["SubmittedBy"] = "";
                        oListItem["SubmittedFY"] = "";
                        oListItem["SubmittedOn"] = "";

                        oListItem.Update();

                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }



                SPListItemCollection oListItems = oList.Items;
                try
                {
                    var traceInfo = "Reset CONOPSDevProgress";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                    foreach (SPListItem oListItem in oListItems)
                    {
                        if (oListItem.ID == 1 || oListItem.ID == 4 || oListItem.ID == 7 || oListItem.ID == 10 || oListItem.ID == 13)
                        {
                            oListItem["WS1Progress"] = "In Progress";
                        }
                        else
                        {
                            oListItem["WS1Progress"] = "Not Started";
                        }

                        oListItem["WS2Progress"] = "Not Started";
                        oListItem["WS3Progress"] = "Not Started";
                        oListItem["WS4Progress"] = "Not Started";
                        oListItem["WSReview"] = "Not Started";
                        oListItem["SubmittedFY"] = "";
                        oListItem["SubmittedOn"] = "";
                        oListItem["SubmittedBy"] = "";

                        oListItem.Update();
                    }
                    //Label1.Visible = true;
                    //Button1.Visible = false;

                    SPList CONOPSDevWSAFOTEC = oWeb.Lists["CONOPSDevWSAFOTEC"]; //SPListItemCollection CONOPSDevWSAFOTECs = CONOPSDevWSAFOTEC.Items;
                    SPList CONOPSDevWSATEC = oWeb.Lists["CONOPSDevWSATEC"]; //SPListItemCollection CONOPSDevWSATECs = CONOPSDevWSATEC.Items;
                    SPList CONOPSDevWSCOTF = oWeb.Lists["CONOPSDevWSCOTF"]; //SPListItemCollection CONOPSDevWSCOTFs = CONOPSDevWSCOTF.Items;
                    SPList CONOPSDevWSJITC = oWeb.Lists["CONOPSDevWSJITC"]; //SPListItemCollection CONOPSDevWSJITCs = CONOPSDevWSJITC.Items;
                    SPList CONOPSDevWSMCOTEA = oWeb.Lists["CONOPSDevWSMCOTEA"]; //SPListItemCollection CONOPSDevWSMCOTEAs = CONOPSDevWSMCOTEA.Items;

                    while (CONOPSDevWSAFOTEC.Items.Count > 0)
                    {
                        CONOPSDevWSAFOTEC.Items[0].Delete();
                    }
                    while (CONOPSDevWSATEC.Items.Count > 0)
                    {
                        CONOPSDevWSATEC.Items[0].Delete();
                    }
                    while (CONOPSDevWSCOTF.Items.Count > 0)
                    {
                        CONOPSDevWSCOTF.Items[0].Delete();
                    }
                    while (CONOPSDevWSJITC.Items.Count > 0)
                    {
                        CONOPSDevWSJITC.Items[0].Delete();
                    }
                    while (CONOPSDevWSMCOTEA.Items.Count > 0)
                    {
                        CONOPSDevWSMCOTEA.Items[0].Delete();
                    }











                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }
        }
    }
}
