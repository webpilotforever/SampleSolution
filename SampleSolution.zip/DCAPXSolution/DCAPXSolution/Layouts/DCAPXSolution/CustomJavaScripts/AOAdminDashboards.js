﻿
if(getParameterByName("admin")=="yes"){
	if(currentUserFromUpperRight == "Neal Daniel"){
		$(".ResetCONOPSDevProgress").show();
	}
}	
// Style web parts on the AO Administration Dashboards page
// ms-WPHeaderTdSelection
$(".s4-wpTopTable").addClass("WebPart");
$("img.ms-WPHeaderMenuImg").css("visibility","visible");
// Add links to Quick Launch 
$(".static.menu-item").each(function(){
	if($(this).text() == "CONOPS"){
		var AODashboardLink = "<UL class=\"static\"><LI class=\"static\"><A class=\"static menu-item\" href=\"javascript:OpenPopUpPage('/SitePages/CONOPSDevelopmentModuleAODashboard.aspx')\"><SPAN class=\"additional-background\"><SPAN class=\"menu-item-text\">CONOPS Dashboard</SPAN></SPAN></A></LI></UL>";
		$(this).closest("li").append(AODashboardLink);
		$(this).closest("li").after($("<LI class=\"static\"><A class=\"static menu-item\" href=\"/SitePages/CONOPSApproval.aspx\"><SPAN class=\"additional-background\"><SPAN class=\"menu-item-text\">CONOPS Approval</SPAN></SPAN></A></LI>"));
	}
});
// Calendar Dashboard -------------------------------------
// Remove js onclick from a tags in Calendar Dashboard (duplicated in td where it is needed when day is single digit and hard to click on.) 
$(".ms-datepickerouter").find("A").attr("href", "javascript:void(0);");
// Highlight days on Calendar Dashboard with events.
highlightDaysWithEvents();
$("#CalendarDashboardContainer").css("border","none").css("width","100%");
$("#CalendarDashboardTitle").html("<input id=\"ButtonMasterCalendarDetail\" type=\"button\" value=\"Master Calendar Detail\" onclick=\"OpenPopUpPage('/Lists/Calendar/calendar.aspx')\" />");
// reset CONOPSDevProgress
var otaToReset = '';
$(".ResetCONOPSDevProgressAFOTEC").click(function(){
	otaToReset = "AFOTEC"; 
	ExecuteOrDelayUntilScriptLoaded(resetCONOPSDevProgress, 'sp.js');

});
$(".ResetCONOPSDevProgressATEC").click(function(){
	otaToReset = "ATEC"; 
	ExecuteOrDelayUntilScriptLoaded(resetCONOPSDevProgress, 'sp.js');

});
$(".ResetCONOPSDevProgressCOTF").click(function(){
	otaToReset = "COTF"; 
	ExecuteOrDelayUntilScriptLoaded(resetCONOPSDevProgress, 'sp.js');

});
$(".ResetCONOPSDevProgressJITC").click(function(){
	otaToReset = "JITC"; 
	ExecuteOrDelayUntilScriptLoaded(resetCONOPSDevProgress, 'sp.js');

});
$(".ResetCONOPSDevProgressMCOTEA").click(function(){
	otaToReset = "MCOTEA"; 
	ExecuteOrDelayUntilScriptLoaded(resetCONOPSDevProgress, 'sp.js');

});
function resetCONOPSDevProgress() {
    //alert("resetCONOPSDevProgress");
	this.clientContext = new SP.ClientContext.get_current();
	var oWeb = clientContext.get_web();
	var oList = oWeb.get_lists().getByTitle("CONOPSDevProgress");
	var camlQuery = new SP.CamlQuery();
	camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="OperationalTestAgency"/><Value Type="Choice">'+otaToReset+'</Value></Eq></Where><OrderBy><FieldRef Name="ID" Ascending="FALSE"/></OrderBy></Query></View>');
	this.collListItem = oList.getItems(camlQuery);
	clientContext.load(collListItem);
	clientContext.executeQueryAsync(Function.createDelegate(this, this.resetCONOPSDevProgressSucceeded), Function.createDelegate(this, this.onQueryFailed));
}
function resetCONOPSDevProgressSucceeded(){
	var listItemEnumerator = collListItem.getEnumerator();	
	while(listItemEnumerator.moveNext()){	
		var oListItem = listItemEnumerator.get_current();	
		if(oListItem.get_item("ForFY") == "Current"){
			oListItem.set_item('WS1Progress','In Progress');
			oListItem.set_item('WS2Progress','Not Started');
			oListItem.set_item('WS3Progress','Not Started');
			oListItem.set_item('WS4Progress','Not Started');
			oListItem.set_item('WSReview','Not Started');
			oListItem.set_item('SubmittedFY', ''); 
			oListItem.set_item('SubmittedBy',''); 
			oListItem.set_item('SubmittedOn', ''); 
		
		}
		else {		
			oListItem.set_item('WS1Progress','Not Started');
			oListItem.set_item('WS2Progress','Not Started');
			oListItem.set_item('WS3Progress','Not Started');
			oListItem.set_item('WS4Progress','Not Started');
			oListItem.set_item('WSReview','Not Started');
			oListItem.set_item('SubmittedFY', ''); 
			oListItem.set_item('SubmittedBy',''); 
			oListItem.set_item('SubmittedOn', ''); 
		}
		oListItem.update();
	}
	
	clientContext.executeQueryAsync(Function.createDelegate(this, this.resetCONOPSDevProgressSucceeded2), Function.createDelegate(this, this.onQueryFailed));
}
function resetCONOPSDevProgressSucceeded2(){
    //alert('CONOPSDevProgress reset for '+otaToReset);
    //alert('resetCONOPSDevProgressSucceeded2');
	resetCONOPSDevAttachmentsLibs("Current");
}
// Change FY in this OTAs attachments libs to 'Reset'
//  the docs will still be there, but will be filtered out on Review Submit page.
//  if user uploads doc of same name, a new version (up to 5) will be created and the FY will be set to the year. 
//  Annually, update FY to FY+1 and delete any others that are still marked Reset. 
function resetCONOPSDevAttachmentsLibs(reviewPageTable){
	
	var CONOPSDevAttachmentsLib = "CONOPSDevAttachments"+reviewPageTable+otaToReset;	
	this.reviewPageTable = reviewPageTable;
	this.clientContext = new SP.ClientContext.get_current();
	var oWeb = clientContext.get_web();
	var oLib = oWeb.get_lists().getByTitle(CONOPSDevAttachmentsLib);
	var camlQuery = new SP.CamlQuery();
	camlQuery.set_viewXml('<View><Query><OrderBy><FieldRef Name="ID" Ascending="FALSE"/></OrderBy></Query></View>');
	this.collListItem = oLib.getItems(camlQuery);
	clientContext.load(collListItem);
	clientContext.executeQueryAsync(Function.createDelegate(this, this.resetCONOPSDevAttachmentsLibsSucceeded), Function.createDelegate(this, this.onQueryFailed));
}
function resetCONOPSDevAttachmentsLibsSucceeded(){
	
	
	var listItemEnumerator = collListItem.getEnumerator();	
	while(listItemEnumerator.moveNext()){	
		var oListItem = listItemEnumerator.get_current();	
		oListItem.set_item("FY","Reset");
		oListItem.update();
	}
	
	clientContext.executeQueryAsync(Function.createDelegate(this, this.resetCONOPSDevAttachmentsLibsPass), Function.createDelegate(this, this.onQueryFailed));
}
function resetCONOPSDevAttachmentsLibsPass(){

	if(reviewPageTable == "Current"){
		resetCONOPSDevAttachmentsLibs("Next"); 
	} else if (reviewPageTable == "Next") {
		resetCONOPSDevAttachmentsLibs("Future");
	} else if (reviewPageTable == "Future") {
		alert('CONOPSDevProgress reset for '+otaToReset+'.\nCONOPSDevAttachmentsLibs reset for '+otaToReset);
	}

}