﻿
// This was initially intended to prepopulate only the next and future worksheets with input from the current worksheets as a starting place
// we need to also prepopulate all worksheets with last years data if it exists


// It has turned into a method to populate worksheets as it would be during the edit process -- if user were interrupted. 
// And it has morphed further to be a way to populate worksheets with any saved items available for the currentFY param -- meaning the user could get interrupted at any point and pick up where user had last saved.

if (getParameterByName("review") == "" && (getParameterByName("showTable") == "next" || getParameterByName("showTable") == "future")) {
    var wsListForOTAb = "CONOPSDevWS" + getParameterByName("ota");
    //alert("wsListForOTAb Should say CONOPSDevWSAFOTEC: " + wsListForOTAb); // CONOPSDevWSAFOTEC
    var CurrentFYforAcceptingCONOPS = getCurrentFYforAcceptingCONOPS();
    var currentFY = getParameterByName("currentFY");
    var cType;

    if (getParameterByName("ws1Prog") == "1") { cType = "WS1"; }
    else if (getParameterByName("ws2Prog") == "1") { cType = "WS2"; }
    else if (getParameterByName("ws3Prog") == "1") { cType = "WS3"; }
    else if (getParameterByName("ws4Prog") == "1") { cType = "WS4"; }

	ExecuteOrDelayUntilScriptLoaded(callgetWSPrePop, "sp.js");
	function callgetWSPrePop() {
	   

	    if ($(".CONOPSDevButton").attr("title") == "Save worksheet") {
	        getWSPrePopByFY(cType, wsListForOTAb, currentFY);
	    }
	    else {
	        getWSPrePopByFY(cType, wsListForOTAb, CurrentFYforAcceptingCONOPS);
	    }
	}


}
function getWSPrePopByFY(cType, wsListForOTAb, fy) {

    var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Prepopulating Worksheet", "Please wait...");

    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle(wsListForOTAb);
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View>" +
				"<Query>" +
					"<OrderBy>" +
						"<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
					"</OrderBy>" +
					"<Where>" +
						"<And>" +
                        "<And>" +
							"<And>" +
								"<Eq>" +
									"<FieldRef Name=\"FY\"/>" +
									"<Value Type=\"Text\">" + fy + "</Value>" +

								"</Eq>" +
								"<Eq>" +
									"<FieldRef Name=\"ContentType\"/>" +
									"<Value Type=\"Computed\">" + cType + "</Value>" +
								"</Eq>" +
							"</And>" +
							"<Neq>" +
								"<FieldRef Name=\"Submitted\"/>" +
								"<Value Type=\"Text\">Yes</Value>" +
							"</Neq>" +
						"</And>" +
                        "<Eq>" +
							"<FieldRef Name=\"CONOPSApproval\"/>" +
							"<Value Type=\"Text\">Baseline OTA Submission</Value>" +
						"</Eq>" +
					"</And>" +
					"</Where>" +
				"</Query></View>");

    this.collListItem = oList.getItems(camlQuery);
    clientContext.load(collListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.getWSPrePopSucceeded), Function.createDelegate(this, this.onQueryFailed));
}
function getWSPrePopSucceeded() {

    //alert("getWSPrePopSucceeded   siteRelURLtopage: " + siteRelURLtopage);

    var DateDraftSaved = "";
    var ven = "";
    if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1) {
        DateDraftSaved = "";
        var commonRowsEverythingElse = new Array();
        var contractRange = new Array();
        var AdditionalLineItemRowsWithDataContractIdContractSubTotalId = new Array();
        var commonRowsContract = new Array();
        var commonRowsAdditionalLineItem = new Array();
        var commonRowsHoursPerYearAmount = new Array();
        var commonRowsContractFee = new Array();
        var commonRowsContractsSubTotal = new Array();
        var commonRowsContractTotal = new Array();
        var firstRows = new Array();
        var firstRowsRow = new Array();
        var GovLaborMonthId;
        var fromId;
        var listItemInfoContracts = "";
        //alert("getting listItemEnumeratorContracts next.");
        var listItemEnumeratorContracts = collListItem.getEnumerator();
        while (listItemEnumeratorContracts.moveNext()) {
            var oListItem = listItemEnumeratorContracts.get_current();
            var oListItemId = oListItem.get_item("ID");

            if (DateDraftSaved !== "" && DateDraftSaved !== oListItem.get_item("DateDraftSaved")) {
                break;
            }
            else {
                DateDraftSaved = oListItem.get_item("DateDraftSaved");
            }


            //var oListItemHoursPerYearAmount = "";
            //alert("getting HoursPerYearAmount next.");


            //if(oListItem.get_item("HoursPerYearAmount")!=="null"){
            //	oListItemHoursPerYearAmount = oListItem.get_item("HoursPerYearAmount");
            //}

            //alert("getting Title next.");
            if (oListItem.get_item("Title") == "Total") {
                //alert("getting Total next.");
                $("#Total").val(oListItem.get_item("Total"));
                $("#Total").closest("tr").find($("input#Title:hidden")).val("Total");
            }

                // contracts
            else if (oListItem.get_item("Title") == "ContractsSubTotal") {
                commonRowsContractsSubTotal.push(oListItem.get_item("ID") + ']]]' + oListItem.get_item("Title") + ']]]' + oListItem.get_item("Contract") + ']]]' + oListItem.get_item("ContractsSubTotal"));
            }
            else if (oListItem.get_item("Title") == "ContractTotal") {
                commonRowsContractTotal.push(oListItem.get_item("Title") + ']]]' + oListItem.get_item("Contract") + ']]]' + oListItem.get_item("ContractTotal"));
            }
            else if (oListItem.get_item("Title") == "ContractFee") {
                var ContractFee = "";
                if (oListItem.get_item("ContractFee")!=null) { ContractFee = oListItem.get_item("ContractFee");}
                commonRowsContractFee.push(oListItem.get_item("Title") + ']]]' + oListItem.get_item("Contract") + ']]]' + ContractFee); // + ']]]' + oListItem.get_item("ContractFeePercentage"));
            }
            else if (oListItem.get_item("Title") == "HoursPerYear") {
                // commonRowsHoursPerYearAmount.push(oListItem.get_item("Title")+ ']]]' + oListItem.get_item("Contract")+ ']]]' + oListItem.get_item("HoursPerYear")+ ']]]' + oListItem.get_item("HoursPerYearAmount"));
                var HoursPerYear = "";
                if (oListItem.get_item("HoursPerYear")!=null) { HoursPerYear = oListItem.get_item("HoursPerYear"); }
                commonRowsHoursPerYearAmount.push(oListItem.get_item("Title") + ']]]' + oListItem.get_item("Contract") + ']]]' + HoursPerYear); //+ ']]]' + oListItemHoursPerYearAmount);

            }
            else if (oListItem.get_item("AdditionalLineItem")) {
                //alert("got AdditionalLineItem");
                var AdditionalLineItem = "";
                if (oListItem.get_item("AdditionalLineItem")!=null) { AdditionalLineItem = oListItem.get_item("AdditionalLineItem"); }
                commonRowsAdditionalLineItem.push(oListItem.get_item("ID") + ']]]' + oListItem.get_item("Title") + ']]]' + oListItem.get_item("Contract") + ']]]' + AdditionalLineItem);
            }
            else if (oListItem.get_item("Title") == "Contract") {
                commonRowsContract.push(oListItem.get_item("ID") + ']]]' + oListItem.get_item("Title") + ']]]' + oListItem.get_item("Contract"));
            }

                // top rows
            else if (oListItem.get_item("Title") == "MilitarySubTotal") {
                $("#MilitarySubTotal").val(oListItem.get_item("MilitarySubTotal"));
                $("#MilitarySubTotal").closest("tr").find($("input#Title:hidden")).val("MilitarySubTotal");
            }
            else if (oListItem.get_item("Title") == "GovLaborYear") {
                $("#GovLaborYear").val(oListItem.get_item("GovLaborYear"));
                $("#GovLaborYear").closest("tr").find($("input#Title:hidden")).val("GovLaborYear");
            }
            else if (oListItem.get_item("Title") == "GovLaborMonth") {
                GovLaborMonthId = oListItem.get_id();
                $("#GovLaborMonth").val(oListItem.get_item("GovLaborMonth"));
                $("#GovLaborMonth").closest("tr").find($("input#Title:hidden")).val("GovLaborMonth");
            }
            else if (GovLaborMonthId > oListItem.get_id()) {
                var DutyTitlePosition = "";
                if (oListItem.get_item("DutyTitlePosition")!=null) { DutyTitlePosition = oListItem.get_item("DutyTitlePosition"); }
                var Status = "";
                if (oListItem.get_item("Status")!=null) { Status = oListItem.get_item("Status"); }
                var Remarks = "";
                if (oListItem.get_item("Remarks")!=null) { Remarks = oListItem.get_item("Remarks"); }
                var GSLevel = "";
                if (oListItem.get_item("GSLevel")!=null) { GSLevel = oListItem.get_item("GSLevel"); }
                var Employer = "";
                if (oListItem.get_item("Employer")!=null) { Employer = oListItem.get_item("Employer"); }
                var Funding = "";
                if (oListItem.get_item("Funding")!=null) { Funding = oListItem.get_item("Funding"); }
                firstRows.push(oListItem.get_item("Title") + ']]]' + DutyTitlePosition + ']]]' + Status + ']]]' + Remarks + ']]]' + GSLevel + ']]]' + Employer + ']]]' + Funding);
            }

                // everything else
            else {
                var ContractorRate = "";
                if (oListItem.get_item("ContractorRate")!=null) { ContractorRate = oListItem.get_item("ContractorRate"); }
                var DutyTitlePosition = "";
                if (oListItem.get_item("DutyTitlePosition")!=null) { DutyTitlePosition = oListItem.get_item("DutyTitlePosition"); }
                var Employer = "";
                if (oListItem.get_item("Employer")!=null) { Employer = oListItem.get_item("Employer"); }
                var Funding = "";
                if (oListItem.get_item("Funding")!=null) { Funding = oListItem.get_item("Funding"); }
                var Remarks = "";
                if (oListItem.get_item("Remarks")!=null) { Remarks = oListItem.get_item("Remarks"); }
                var Status = "";
                if (oListItem.get_item("Status")!=null) { Status = oListItem.get_item("Status"); }
                commonRowsEverythingElse.push(oListItem.get_item("Title") + ']]]' + oListItem.get_item("Contract") + ']]]' + ContractorRate + ']]]' + DutyTitlePosition + ']]]' + Employer + ']]]' + Funding + ']]]' + Remarks + ']]]' + Status);
            }


        } // end while

        // --- replace null values with empty string ----

       



        //-------------------
        firstRows.reverse();
        commonRowsContractsSubTotal.reverse();
        commonRowsContractTotal.reverse();
        commonRowsContractFee.reverse();
        commonRowsHoursPerYearAmount.reverse();
        commonRowsAdditionalLineItem.reverse();
        commonRowsContract.reverse();
        commonRowsEverythingElse.reverse();

        // firstRows
        for (i = 0; i < firstRows.length; i++) {
            if (i > 0) {
                $("input#Employer[value='MilitaryOrGovernmentCivilian']").eq(i - 1).closest("tr").find(".WSBtnAddRow").click();
            }
        }

        for (i = 0; i < firstRows.length; i++) {
            firstRowsRow = firstRows[i].toString().split(']]]');

            setfirstRowsRowWithData(firstRowsRow, i);
        }
        function setfirstRowsRowWithData(firstRowsRow, i) {
            var firstRowsRowToSet = $("input#Employer[value='MilitaryOrGovernmentCivilian']").eq(i).closest("tr");
            $(firstRowsRowToSet).find("#Title").val(firstRowsRow[0]).end().find("#DutyTitlePosition").val(firstRowsRow[1]).end().find("#Status").val(firstRowsRow[2]).end().find("#Remarks").val(firstRowsRow[3]).end().find("#GSLevel").val(firstRowsRow[4]).end().find("#Employer").val(firstRowsRow[5]).end().find("#Funding").val(firstRowsRow[6]);
        }
        // commonRowsContractsSubTotal
        for (i = 0; i < commonRowsContractsSubTotal.length; i++) {
            if (i > 0) {
                $(".WSBtnAddGroup").eq(i - 1).click();
            }
        }
        for (i = 0; i < commonRowsContractsSubTotal.length; i++) {
            var commonRowsContractsSubTotalRow = commonRowsContractsSubTotal[i].toString().split(']]]');
           
            setContractsSubTotalRowWithData(commonRowsContractsSubTotalRow, i);
        }
        function setContractsSubTotalRowWithData(commonRowsContractsSubTotalRow, i) {
            var contractRowToSet = $("input#Contract:visible").eq(i).closest("tr");
            $(contractRowToSet).find("#Title").val("Contract").end().find("#Contract").val(commonRowsContractsSubTotalRow[2]);
            $("tr.ContractItem").eq(i).attr("title", commonRowsContractsSubTotalRow[2]);
            $("input#ContractsSubTotal").eq(i).closest("tr").find("#Title").val(commonRowsContractsSubTotalRow[1]).end().find("#Contract").val(commonRowsContractsSubTotalRow[2]).end().find("#ContractsSubTotal").val(commonRowsContractsSubTotalRow[3]);
        }



        // commonRowsContractTotal
        for (i = 0; i < commonRowsContractTotal.length; i++) {
            var commonRowsContractTotalRow = commonRowsContractTotal[i].toString().split(']]]');
           
            setContractTotalRowWithData(commonRowsContractTotalRow, i);
        }
        function setContractTotalRowWithData(commonRowsContractTotalRow, i) {
            $("input#ContractTotal").eq(i).closest("tr").find("#Title").val(commonRowsContractTotalRow[0]).end().find("#Contract").val(commonRowsContractTotalRow[1]).end().find("#ContractTotal").val(commonRowsContractTotalRow[2]);
        }

        // commonRowsContractFee
        for (i = 0; i < commonRowsContractFee.length; i++) {
            var commonRowsContractFeeRow = commonRowsContractFee[i].toString().split(']]]');
           
            setContractFeeRowWithData(commonRowsContractFeeRow, i);
        }
        function setContractFeeRowWithData(commonRowsContractFeeRow, i) {
            $("input#ContractFee").eq(i).closest("tr").find("#Title").val(commonRowsContractFeeRow[0]).end().find("#Contract").val(commonRowsContractFeeRow[1]).end().find("#ContractFee").val(commonRowsContractFeeRow[2]); // .end().find("#ContractFeePercentage").val(commonRowsContractFeeRow[3]);			
        }

        // commonRowsHoursPerYearAmount
        for (i = 0; i < commonRowsHoursPerYearAmount.length; i++) {
            var commonRowsHoursPerYearAmountRow = commonRowsHoursPerYearAmount[i].toString().split(']]]');
           
            setHoursPerYearAmountRowWithData(commonRowsHoursPerYearAmountRow, i);
        }
        function setHoursPerYearAmountRowWithData(commonRowsHoursPerYearAmountRow, i) {
            $("input#HoursPerYear").eq(i).closest("tr").find("#Title").val(commonRowsHoursPerYearAmountRow[0]).end().find("#Contract").val(commonRowsHoursPerYearAmountRow[1]).end().find("#HoursPerYear").val(commonRowsHoursPerYearAmountRow[2]); // .end().find("#HoursPerYearAmount").val(commonRowsHoursPerYearAmountRow[3]);			
        }

        // commonRowsAdditionalLineItem 
        $("input#AdditionalLineItem").closest('tr').addClass("FirstAdditionalLineItem");

        var contractRangeInc = 0;

        for (i = 0; i < commonRowsContract.length; i++) { // set contractRage		
            var commonRowsContractRow = commonRowsContract[i].toString().split(']]]');
           
            var commonRowsContractsSubTotalRow = commonRowsContractsSubTotal[i].toString().split(']]]');
            
            var ContractId = commonRowsContractRow[0];
            var ContractSubTotalId = commonRowsContractsSubTotalRow[0];
            contractRange.push(parseInt(ContractId) + '|' + parseInt(ContractSubTotalId));
        }
        var ss = 0;
        for (i = 0; i < commonRowsAdditionalLineItem.length; i++) {

            var thiscontractRange = contractRange[contractRangeInc].toString().split('|');
           
            var ContractId = thiscontractRange[0];
            var ContractSubTotalId = thiscontractRange[1];

            var commonRowsAdditionalLineItemRow = commonRowsAdditionalLineItem[i].toString().split(']]]');
          
            var AdditionalLineItemId = commonRowsAdditionalLineItemRow[0];

            if (parseInt(AdditionalLineItemId) > parseInt(ContractId) && parseInt(AdditionalLineItemId) < parseInt(ContractSubTotalId)) {
                if (ss > 0) {
                    $(".FirstAdditionalLineItem").eq(contractRangeInc).find(".WSBtnAddRow").click();
                }
                ss++;

            } else {
                contractRangeInc++;
                ss = 0;
                i = i - 1;
            }
        }

        for (i = 0; i < commonRowsAdditionalLineItem.length; i++) {
            var commonRowsAdditionalLineItemRow = commonRowsAdditionalLineItem[i].toString().split(']]]');
          
            setAdditionalLineItemRowWithData(commonRowsAdditionalLineItemRow, i);
        }
        function setAdditionalLineItemRowWithData(commonRowsAdditionalLineItemRow, i) {
            $("input#AdditionalLineItem").eq(i).closest("tr").find("#Title").val(commonRowsAdditionalLineItemRow[1]).end().find("#Contract").val(commonRowsAdditionalLineItemRow[2]).end().find("#AdditionalLineItem").val(commonRowsAdditionalLineItemRow[3]);
        }


        // commonRowsEverythingElse

        var contractEverythingElseRowIndexA;
        var contractEverythingElseRowIndexB;
        for (i = 0; i < commonRowsEverythingElse.length; i++) {
            var commonRowsEverythingElseRow = commonRowsEverythingElse[i].toString().split(']]]');
           
            createEverythingElseRows(commonRowsEverythingElseRow, i);
        }
        function createEverythingElseRows(commonRowsEverythingElseRow, i) {
            var contract = commonRowsEverythingElseRow[1];
            var contractEverythingElseRowToSet;


            $(".WSGroupStartRow").find("input#Contract").each(function () {
                if ($(this).val() == contract) {
                    contractEverythingElseRowToSet = $(this).closest('tr').next();
                    contractEverythingElseRowIndexA = contractEverythingElseRowToSet.index(); // alert(contractEverythingElseRowIndexA );
                }
            });

            if (contractEverythingElseRowIndexA == contractEverythingElseRowIndexB) {

                $(contractEverythingElseRowToSet).find(".WSBtnAddRow").click();

            } else {
                contractEverythingElseRowIndexB = contractEverythingElseRowIndexA;
            }


        }

        for (i = 0; i < commonRowsEverythingElse.length; i++) {
            var commonRowsEverythingElseRow = commonRowsEverythingElse[i].toString().split(']]]');
          
            setsEverythingElseRowWithData(commonRowsEverythingElseRow, i);
        }
        function setsEverythingElseRowWithData(commonRowsEverythingElseRow, i) {
            var commonRowsEverythingElseRowToSet = $(".ContractItem").eq(i).closest("tr");
            $(commonRowsEverythingElseRowToSet).find("#Title").val(commonRowsEverythingElseRow[0]).end().find("#Contract").val(commonRowsEverythingElseRow[1]).end().find("#ContractorRate").val(commonRowsEverythingElseRow[2]).end().find("#DutyTitlePosition").val(commonRowsEverythingElseRow[3]).end().find("#Employer").val(commonRowsEverythingElseRow[4]).end().find("#Funding").val(commonRowsEverythingElseRow[5]).end().find("#Remarks").val(commonRowsEverythingElseRow[6]).end().find("#Status").val(commonRowsEverythingElseRow[7]);
        }
    }
    if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS2.aspx") > -1) {
        //	builds blank venue groups of rows first and gets set of items
        DateDraftSaved = "";
        var commonRowsRaw = new Array();
        var commonRows = new Array();
        var commonRowsVenueSubTotal = new Array();
        var commonRowsWithData = new Array();
        var commonRowWithData = new Array();
        var commonRowsWithDataCount = 0;
        var fromId;
        var listItemInfoVenue = "";
        var listItemEnumeratorVenue = collListItem.getEnumerator();
        while (listItemEnumeratorVenue.moveNext()) {
            var oListItem = listItemEnumeratorVenue.get_current();
            var oListItemId = oListItem.get_item("ID");

            if (DateDraftSaved !== "" && DateDraftSaved !== oListItem.get_item("DateDraftSaved")) {
                break;
            }
            else {
                DateDraftSaved = oListItem.get_item("DateDraftSaved");
            }

            //alert("get VenueSubTotal"); 		
            if (oListItem.get_item("Title") == "Total") {
                $("#Total").val(oListItem.get_item("Total"));
                $("#Total").closest("tr").find($("input#Title:hidden")).val("Total");

            }

            else if (oListItem.get_item("VenueSubTotal") !== null) {
                commonRowsVenueSubTotal.push(oListItem.get_item("VenueSubTotal"));
                //alert("got VenueSubTotal");
            }

            else {

                commonRowsWithData.push(oListItem.get_item("Title") + ']]]' + oListItem.get_item("Dates") + ']]]' + oListItem.get_item("People") + ']]]' + oListItem.get_item("EventLocation") + ']]]' + oListItem.get_item("EstTravel") + ']]]' + oListItem.get_item("EstLaborOvertime") + ']]]' + oListItem.get_item("Funding") + ']]]' + oListItem.get_item("Venue"));

            }


            //alert("get Venue");
            if (oListItem.get_item("Venue") !== null) {
                if (ven == oListItem.get_item("Venue")) {
                    // alert("Venue: "+oListItem.get_item("Venue")+"\nTitle: "+oListItem.get_item("Title"));
                    commonRows.push(oListItem.get_item("Venue"));
                    commonRowsRaw.push(oListItem.get_item("Venue"));

                } else if (ven !== "") {
                    $(".WSBtnAddGroup:last").click();
                    //alert('clicked');
                }
                ven = oListItem.get_item("Venue");
            }

        } // end while
        //alert('oListItemId' ); return false;
        commonRowsRaw.reverse();
        commonRows.reverse();
        commonRowsVenueSubTotal.reverse();
        commonRowsWithData.reverse();

        var commonRowsUnique = jQuery.unique(commonRows);
        for (i = 0; i < commonRowsUnique.length; i++) {
            $("tr.WSGroupStartRow").eq(i).find("input#Venue").val(commonRowsUnique[i]);
            $("tr.WSGroupEndRow").eq(i).find("input#VenueSubTotal").val(commonRowsVenueSubTotal[i]).end().find("input#Venue").val(commonRowsUnique[i]).end().find($("input#Title:hidden")).val("VenueSubTotal");
        }

        var commonRowsVal = "";
        for (i = 0; i < commonRowsRaw.length; i++) {
            a = jQuery.inArray(commonRowsRaw[i], commonRowsUnique); // 0 or 1 etc

            if (commonRowsVal == commonRowsRaw[i]) {
                $("tr.WSGroupStartRow").eq(a).find(".WSBtnAddRow").click();
            }
            else {

                commonRowsVal = commonRowsRaw[i];
            }
        }
        for (i = 0; i < commonRowsWithData.length; i++) {

            commonRowWithData = commonRowsWithData[i].toString().split(']]]');
          
            setRowWithData(commonRowWithData, i);
        }
        function setRowWithData(commonRowWithData, i) {
            // $("input#Title:visible").eq(i).val(i+'kkk');
            var rowToSet = $("input#Title:visible").eq(i).closest("tr");
            $(rowToSet).find("#Title").val(commonRowWithData[0]).end().find("#Dates").val(commonRowWithData[1]).end().find("#People").val(commonRowWithData[2]).end().find("#EventLocation").val(commonRowWithData[3]).end().find("#EstTravel").val(commonRowWithData[4]).end().find("#EstLaborOvertime").val(commonRowWithData[5]).end().find("#Funding").val(commonRowWithData[6]).end().find("#Venue").val(commonRowWithData[7]);


        }
    }
    if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS3.aspx") > -1) { // worksheet #3
        DateDraftSaved = "";
        var listItemInfo = "";
        var listItemEnumerator = collListItem.getEnumerator();
        while (listItemEnumerator.moveNext()) {
            var oListItem = listItemEnumerator.get_current();
            var oListItemId = oListItem.get_item("ID");

            if (DateDraftSaved !== "" && DateDraftSaved !== oListItem.get_item("DateDraftSaved")) {
                break;
            }
            else {
                DateDraftSaved = oListItem.get_item("DateDraftSaved");
            }

            if (oListItem.get_item("Title") == "Total") { $("#Total").val(oListItem.get_item("Total")); }
            else {
                var tvals = "";
                $(".WSBtnAddRow:first").closest('tr').find('input:text').each(function () {
                    var tval = $(this).val();
                    tvals += tval;
                });
                if (tvals.length) {
                    $(".WSBtnAddRow:first").click();
                    tvals = "";
                }
                $("#Title:first").val(oListItem.get_item("Title")); $("#People:first").val(oListItem.get_item("People")); $("#Dates:first").val(oListItem.get_item("Dates")); $("#Remarks:first").val(oListItem.get_item("Remarks")); $("#Funding:first").val(oListItem.get_item("Funding"));
            }
            listItemInfo += oListItemId + " ";

        }
        // alert(listItemInfo );

    }
    if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS4.aspx") > -1) { // worksheet #4

        //alert("Got to worksheet #4");
        DateDraftSaved = "";
        var listItemInfo = "";
        var listItemEnumerator = collListItem.getEnumerator();
        while (listItemEnumerator.moveNext()) {
            var oListItem = listItemEnumerator.get_current();
            var oListItemId = oListItem.get_item("ID");

            if (DateDraftSaved !== "" && DateDraftSaved !== oListItem.get_item("DateDraftSaved")) {
                break;
            }
            else {
                DateDraftSaved = oListItem.get_item("DateDraftSaved");
            }

            if (oListItem.get_item("Title") == "Total") { $("#Total").val(oListItem.get_item("Total")); }
            else {
                var tvals = "";
                $(".WSBtnAddRow:first").closest('tr').find('input:text').each(function () {
                    var tval = $(this).val();
                    tvals += tval;
                });
                if (tvals.length) {
                    $(".WSBtnAddRow:first").click();
                    tvals = "";
                }
                $("#Title:first").val(oListItem.get_item("Title")); $("#Number:first").val(oListItem.get_item("Number")); $("#Remarks:first").val(oListItem.get_item("Remarks")); $("#Funding:first").val(oListItem.get_item("Funding"));
            }


            listItemInfo += oListItemId + " ";

        }
        //alert(listItemInfo );

    }

    SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog	
}
