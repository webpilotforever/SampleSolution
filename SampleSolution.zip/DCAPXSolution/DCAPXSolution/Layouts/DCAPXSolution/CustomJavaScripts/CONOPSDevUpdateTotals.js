﻿
function updateTotals() {
    // set totals in worksheet
    if (worksheetPageName.indexOf("WS1") > -1) {
        // ws1 top
        var MilitarySubTotal = 0;
        $("input[id*='Funding']").each(function (i) {
            var fundingVal;
            if ($(this).val().length) {
                fundingVal = $(this).val();
            }
            else {
                fundingVal = "0.00";
                $(this).val(fundingVal);
            }

           
            if (fundingVal.indexOf("$") > -1) {
                fundingVal = fundingVal.substr(fundingVal.indexOf("$") + 1);
                $(this).val(fundingVal);
            }
            if (fundingVal.indexOf(",") > -1) {
                fundingVal = fundingVal.replace(/,/g, "");
                $(this).val(fundingVal);
            }
            if ($.isNumeric(fundingVal)) {
                //var nn = Math.round(fundingVal);
                fundingVal = parseFloat(fundingVal);
                var nn = fundingVal.toFixed(2);
                $(this).val(nn);
                if ($(this).closest('tr').index() < $("input[id*='MilitarySubTotal']").closest('tr').index()) {
                    //MilitarySubTotal += parseInt($(this).val());
                    MilitarySubTotal = (MilitarySubTotal * 10 + parseFloat(nn) * 10) / 10;
                }
            }
        });

        var GovLaborMonthRound = Math.round(MilitarySubTotal / 12);
        $("input[id*='GovLaborMonth']").val(GovLaborMonthRound.toFixed(2));
        $("input[id*='MilitarySubTotal']").val(MilitarySubTotal.toFixed(2));
        // ws1 contractors

        var ContractsSubTotal = 0;

        var contractSliceStart;
        var contractSliceEnd;
        var contractSliced;

        $("tr.WSGroupStartRow").each(function (i) {
            contractSliceStart = $(this).index();
            contractSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
            contractSliced = $(this).parent().children().slice(contractSliceStart, contractSliceEnd);
            var ContractTotal = 0;
            contractSliced.find("input[id*='Funding']").each(function () {
                var fundingVal;
                if ($(this).val().length) {
                    fundingVal = $(this).val();
                }
                else {
                    fundingVal = "0.00";
                    $(this).val(fundingVal);
                }
                if ($.isNumeric(fundingVal)) {
                    fundingVal = parseFloat(fundingVal);
                    var nn = fundingVal.toFixed(2);
                    $(this).val(nn);
                    //ContractTotal += parseInt($(this).val());
                    ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
                }
            });

            contractSliced.find("input[id*='AdditionalLineItem']").each(function () {

                var additionalLineItemVal;

                if ($(this).val().length) {
                    additionalLineItemVal = $(this).val();
                }
                else {
                    additionalLineItemVal = "0.00";
                    $(this).val(additionalLineItemVal);
                }

                if ($.isNumeric(additionalLineItemVal)) {
                    additionalLineItemVal = parseFloat(additionalLineItemVal);
                    var nn = additionalLineItemVal.toFixed(2);
                    $(this).val(nn);
                    //ContractTotal += parseInt($(this).val());
                    ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
                }
             
            });

            var contractFeeVal = contractSliced.find("input[id*='ContractFee']").val();
            if ($.isNumeric(contractFeeVal)) {
                contractFeeVal = parseFloat(contractFeeVal);
                var nn = contractFeeVal.toFixed(2);
                contractSliced.find("input[id*='ContractFee']").val(nn);
                ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
            }

            var contractTotalStr = ContractTotal.toFixed(2);
            var contractsSubTotalStr = ContractsSubTotal.toFixed(2);

            contractSliced.find("input[id*='ContractTotal']").val(contractTotalStr);
            //ContractsSubTotal += ContractTotal;
            ContractsSubTotal = (parseFloat(contractsSubTotalStr) * 10 + parseFloat(contractTotalStr) * 10) / 10;
            contractSliced.find("input[id*='ContractsSubTotal']").val(ContractsSubTotal.toFixed(2));
        });
        var militarySubTotalStr = MilitarySubTotal.toFixed(2);
        var contractsSubTotalStr = ContractsSubTotal.toFixed(2);
        var totalCal = (parseFloat(militarySubTotalStr) * 10 + parseFloat(contractsSubTotalStr) * 10) / 10;
        //$("input[id*='Total']").last().val(MilitarySubTotal + ContractsSubTotal);
        $("input[id*='Total']").last().val(totalCal.toFixed(2));
    }
    if (worksheetPageName.indexOf("WS2") > -1) {

        var venueSliceStart;
        var venueSliceEnd;
        var venueSliced;

        var Total = 0;

        $("tr.WSGroupStartRow").each(function (i) {
            var VenueSubTotal = 0;
            venueSliceStart = $(this).index();
            venueSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
            venueSliced = $(this).parent().children().slice(venueSliceStart, venueSliceEnd);

            venueSliced.find("input[id*='Funding']").each(function () {

                var venueVal = $(this).val();
                if (venueVal.indexOf("$") > -1) {
                    venueVal = venueVal.substr(venueVal.indexOf("$") + 1);
                    $(this).val(venueVal);
                }
                if ($.isNumeric(venueVal)) {
                    //var nn = Math.round(venueVal);
                    venueVal = parseFloat(venueVal);
                    var nn = venueVal.toFixed(2);
                    $(this).val(nn);
                    //VenueSubTotal += parseInt($(this).val());
                    VenueSubTotal = (VenueSubTotal * 10 + parseFloat(nn) * 10) / 10;

                }

            });

            venueSliced.find("input[id*='VenueSubTotal']").val(VenueSubTotal.toFixed(2));

            Total += VenueSubTotal;

        });
        $("input[id*='Total']").last().val(Total.toFixed(2));

    }
    if (worksheetPageName.indexOf("WS3") > -1 || worksheetPageName.indexOf("WS4") > -1) {
        var Total = 0;










        $("input[id*='Funding']").each(function () {

            var fundingVal;
            if ($(this).val().length) {
                fundingVal = $(this).val();
            }
            else {
                fundingVal = "0.00";
                $(this).val(fundingVal);
            }


           if (fundingVal.indexOf("$") > -1) {
                fundingVal = fundingVal.substr(fundingVal.indexOf("$") + 1);
                $(this).val(fundingVal);
            }
            if (fundingVal.indexOf(",") > -1) {
                fundingVal = fundingVal.replace(/,/g, "");
                $(this).val(fundingVal);
            }
           
            if ($.isNumeric(fundingVal)) {
                //var nn = Math.round(fundingVal);
                fundingVal = parseFloat(fundingVal);
                var nn = fundingVal.toFixed(2);
                $(this).val(nn);
                Total = (Total * 10 + parseFloat(nn) * 10) / 10;
            }
        });
        $("input[id*='Total']").val(Total.toFixed(2));
    }


}

$("#s4-workspace").on('focusout', 'input[id*="Funding"]', function () { // using event delegation for this dynamic content

    updateTotals();
});

$("#s4-workspace").on('focusout', 'input[id*="EstTravel"]', function () { // using event delegation for this dynamic content
    var EstTravelVal = $(this).val();
    if ($.isNumeric(EstTravelVal) && $(this).val()) {
        //var nn = Math.round(EstTravelVal);
        EstTravelVal = parseFloat(EstTravelVal);
        var nn = EstTravelVal.toFixed(2);
        $(this).val(nn);

        if ($(this).closest("tr").find("input[id*='EstLaborOvertime']").val()) {

            var fundingCal;

            var estLaborOvertimeVal = $(this).closest("tr").find("input[id*='EstLaborOvertime']").val();
            estLaborOvertimeVal = parseFloat(estLaborOvertimeVal);
            var nn2 = estLaborOvertimeVal.toFixed(2);
            $(this).closest("tr").find("input[id*='EstLaborOvertime']").val(nn2);

            fundingCal = (parseFloat(nn) * 10 + parseFloat(nn2) * 10) / 10;

            $(this).closest("tr").find("input[id*='Funding']").val(fundingCal.toFixed(2));
            

        }
        else {
            $(this).closest("tr").find("input[id*='Funding']").val(nn);
        }
    }
    else {
        if ($(this).closest("tr").find("input[id*='Venue']").val()) {
            alert("Please enter a number for [" + $(this).attr("title") + "]."); $(this).val('');

        }
        else {
            $(this).val('');
        }


    }
    updateTotals();

});

$("#s4-workspace").on('focusout', 'input[id*="EstLaborOvertime"]', function () { // using event delegation for this dynamic content
    var EstLaborOvertimeVal = $(this).val();
    if ($.isNumeric(EstLaborOvertimeVal) && $(this).val()) {
        //var nn = Math.round(EstLaborOvertimeVal);
        EstLaborOvertimeVal = parseFloat(EstLaborOvertimeVal);
        var nn = EstLaborOvertimeVal.toFixed(2);
        $(this).val(nn);

        if ($(this).closest("tr").find("input[id*='EstTravel']").val()) {


            var fundingCal;

            var estTravelVal = $(this).closest("tr").find("input[id*='EstTravel']").val();
            estTravelVal = parseFloat(estTravelVal);
            var nn2 = estTravelVal.toFixed(2);
            $(this).closest("tr").find("input[id*='EstTravel']").val(nn2);

            fundingCal = (parseFloat(nn) * 10 + parseFloat(nn2) * 10) / 10;

            $(this).closest("tr").find("input[id*='Funding']").val(fundingCal.toFixed(2));


        }
        else {
            $(this).closest("tr").find("input[id*='Funding']").val(nn);
        }
    }
    else {
        if ($(this).closest("tr").find("input[id*='Venue']").val()) {
            alert("Please enter a number for [" + $(this).attr("title") + "]."); $(this).val('');
        }
        else {
            $(this).val('');
        }


    }
    updateTotals();
});

$("#s4-workspace").on('focusout', 'input[id*="AdditionalLineItem"]', function () { // using event delegation for this dynamic content

    var additionalLineItemVal = $(this).val();
    if (additionalLineItemVal.indexOf("$") > -1) {
        additionalLineItemVal = additionalLineItemVal.substr(additionalLineItemVal.indexOf("$") + 1);
        $(this).val(additionalLineItemVal);
    }
    if ($.isNumeric(additionalLineItemVal)) {
        //var nn = Math.round(additionalLineItemVal);
        additionalLineItemVal = parseFloat(additionalLineItemVal);
        var nn = additionalLineItemVal.toFixed(2);
        $(this).val(nn);
    }
    updateTotals();
});

$("#s4-workspace").on('focusout', 'input[id*="ContractFee"]', function () { // using event delegation for this dynamic content

    var contractFeeVal = $(this).val();
    if (contractFeeVal.indexOf("$") > -1) {
        contractFeeVal = contractFeeVal.substr(contractFeeVal.indexOf("$") + 1);
        $(this).val(contractFeeVal);
    }
    if ($.isNumeric(contractFeeVal)) {
        //var nn = Math.round(contractFeeVal);
        contractFeeVal = parseFloat(contractFeeVal);
        var nn = contractFeeVal.toFixed(2);
        $(this).val(nn);
    }
    updateTotals();
});


