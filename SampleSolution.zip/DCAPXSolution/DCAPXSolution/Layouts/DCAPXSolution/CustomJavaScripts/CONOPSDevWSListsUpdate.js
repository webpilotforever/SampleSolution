﻿// ----- CONOPS WORKSHEETS -----

function saveWorksheet(wsListForOTA, worksheetRows, itemIdFromCONOPSDevProgressToUpdate, i, wsNumFromPageName) {

    $("input[name*='CONOPSDev']").not(".CONOPSDevButton").each(function () {
        var rowNum = $(this).closest("tr").index();
        var elemName = $(this).attr("name");
        $(this).attr("name", rowNum + elemName);
    });
    //alert("clicking .CONOPSDevButton");
    //queryCONOPSDevProgress(itemIdFromCONOPSDevProgressToUpdate)
    $(".CONOPSDevButton").click();
}

function saveWorksheet_9_9_15bak(wsListForOTA, worksheetRows, itemIdFromCONOPSDevProgressToUpdate, i, wsNumFromPageName) {
	var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle(wsListForOTA);
    var itemCreateInfo = new SP.ListItemCreationInformation();
    this.oListItem = oList.addItem(itemCreateInfo);
    this.wsListForOTA= wsListForOTA;
    this.wsNumFromPageName = wsNumFromPageName;
    this.itemIdFromCONOPSDevProgressToUpdate=itemIdFromCONOPSDevProgressToUpdate;
    this.worksheetRows=worksheetRows;
    this.i=i;
	this.worksheetRow = worksheetRows[i].split("|,|");
	//alert('worksheetRow: '+worksheetRow);

    var ii = 0;
    while (worksheetRow[ii]) {
        var column = worksheetRow[ii];
        //alert("column: "+column); 
        ii++;
        var columnValue = worksheetRow[ii]; 
        if (columnValue.length) {
            // has value so...
            if(columnValue !=="" && columnValue !== null){
            	//alert('columnValue: |'+columnValue+"|");
            	oListItem.set_item(column, columnValue);
            }
            
        } //else { alert('columnValue is nothing: '+columnValue+"\nii: "+ii+"\nworksheetRow array of columns: "+worksheetRow);}
        ii++;
    }
    oListItem.update();
    clientContext.load(oListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.saveWorksheetSucceeded), Function.createDelegate(this, this.saveWorksheetFailed));
}
function saveWorksheetSucceeded() {
	i=i+1;
    if (oListItem.get_id() > -1) { 
    	//alert('saveWorksheetSucceeded. id of new list item: '+oListItem.get_id()+'\ni: '+i+'\nworksheetRows.length: '+worksheetRows.length);
    	if (i >= worksheetRows.length){
			//alert('i is gt or eq worksheetRows.length');
			if(getParameterByName("review") == "true"){
				//alert('review is true.');
				CONOPSDevProgressUpdateSucceeded();
			}else{
				queryCONOPSDevProgress(itemIdFromCONOPSDevProgressToUpdate); 
			}
		} else {
			//alert('i is Not gt or eq worksheetRows.length');
			
    		saveWorksheet(wsListForOTA, worksheetRows, itemIdFromCONOPSDevProgressToUpdate, i, wsNumFromPageName);
		
		}
    } 
    	
    
}
function saveWorksheetFailed(sender, args){
	alert('saveWorksheetFailed called. Saving failed. ' + args.get_message());	
}


// ----- query CONOPSDevProgress list -----

function queryCONOPSDevProgress(itemIdFromCONOPSDevProgressToUpdate) {
    //alert('getCONOPSDevProgAODash');
	this.clientContext = new SP.ClientContext.get_current();
	var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevProgress");
	var camlQuery = new SP.CamlQuery();
	camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="OperationalTestAgency"/><Value Type="Choice">'+OTA+'</Value></Eq></Where><OrderBy><FieldRef Name="ID" Ascending="FALSE"/></OrderBy></Query></View>');
	this.collListItem = oList.getItems(camlQuery);
	this.itemIdFromCONOPSDevProgressToUpdate=itemIdFromCONOPSDevProgressToUpdate; //alert('itemIdFromCONOPSDevProgressToUpdate: '+itemIdFromCONOPSDevProgressToUpdate);
	
	clientContext.load(collListItem);
	clientContext.executeQueryAsync(Function.createDelegate(this, this.queryCONOPSDevProgressSucceeded), Function.createDelegate(this, this.onQueryFailed));
}
function queryCONOPSDevProgressSucceeded(){
	var wsNum = ""+siteRelURLtopage.replace(/\D/g,""); // sometimes returns 2020! CONOPSDevReviewSubmitWorksheets.aspx
	if(wsNum==''|| wsNum=='2020'){wsNum="5";}
	//var progressListCols = { 1:"WS1Progress", 2:"WS2Progress", 3:"WS3Progress", 4:"WS4Progress", 5:"WSReview" };
	var worksheetCompleted = progressListCols[wsNum];	//alert('worksheetCompleted: '+worksheetCompleted);
//if(worksheetCompleted !== "WS1Progress"&&worksheetCompleted !== "WS2Progress"&&worksheetCompleted !== "WS3Progress"&&worksheetCompleted !== "WS4Progress"&&worksheetCompleted !== "WSReview"){
//alert("worksheetCompleted does not have a correct value: "+worksheetCompleted+"\nwsNum: "+wsNum );
//return false;
//}
	var isLastRow=true;
	var listItemInfo = '';	
	var listItemEnumerator = collListItem.getEnumerator();	
	while(listItemEnumerator.moveNext()){	
		var oListItem = listItemEnumerator.get_current();		
		var oListItemId = oListItem.get_item("ID");				
		if(parseInt(oListItemId) > itemIdFromCONOPSDevProgressToUpdate ){ isLastRow = false; } 
		if (parseInt(oListItemId) == itemIdFromCONOPSDevProgressToUpdate ) { // alert('88');
			oListItem.set_item(worksheetCompleted,'Draft Completed'); 
			oListItem.update();
		}		
		if(isLastRow == false){	// alert('92');
			// looping through items in descending order, so do this now...if we have an extra row and worksheetCompleted is WSReview set next row, first worksheet column to In Progress
			if(worksheetCompleted == "WSReview" && parseInt(oListItemId) == parseInt(itemIdFromCONOPSDevProgressToUpdate) + 1){
				oListItem.set_item('WS1Progress','In Progress');
				oListItem.update();
			}			
			if (parseInt(oListItemId) == parseInt(itemIdFromCONOPSDevProgressToUpdate) ) { 								
				// set next column to In Progress
				if(worksheetCompleted !== "WSReview"){
					oListItem.set_item(progressListCols[parseInt(wsNum)+1],'In Progress'); 
					oListItem.update();
				}						
			}			
		}		
		if(isLastRow == true){ 
			if (parseInt(oListItemId) == parseInt(itemIdFromCONOPSDevProgressToUpdate) ) { 	
				if(worksheetCompleted !== "WSReview"){
					// set next column to In Progress	
					oListItem.set_item(progressListCols[parseInt(wsNum)+1],'In Progress'); 
					oListItem.update();				
				}						
										
			}			

		}

	}
		clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSDevProgressUpdateSucceeded), Function.createDelegate(this, this.CONOPSDevProgressUpdateSucceededFailed));

}
// ----- UPDATE CONOPSDEVPROGRESS TO SUBMITTED FOR ALL ------



// ----- CONOPSDevProgressUpdateSucceeded -----
function CONOPSDevProgressUpdateSucceeded(){
	SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes Saving dialog
	closeAgain();
}
function closeAgain(){
	if(getParameterByName("review")=="true"){
		SP.UI.ModalDialog.commonModalDialogClose("OK", "Worksheet edited during review");
	}
	else{
		// alert('Saving dialog closed. now close this worksheet.');
	    SP.UI.ModalDialog.commonModalDialogClose(null, 1); // closes worksheet -- calls CONOPSDevDialogs.js.nextCONOPSDevPage() 
	}
}
function CONOPSDevProgressUpdateSucceededFailed(sender, args){
	alert('CONOPSDevProgressUpdateSucceededFailed called. Update failed. ' + args.get_message());	
	SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes Saving dialog
	closeAgain();

}
