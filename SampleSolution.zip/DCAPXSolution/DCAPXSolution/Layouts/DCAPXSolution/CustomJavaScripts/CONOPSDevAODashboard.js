﻿var CurrentFYforAcceptingCONOPS = getCurrentFYforAcceptingCONOPS(); // for example: as of Jan 1, 2014 this would be 15

$(".CONOPSDevAODashboardCurrentFY").text(CurrentFYforAcceptingCONOPS);
$(".CONOPSDevAODashboardNextFY").text(parseInt(CurrentFYforAcceptingCONOPS)+1);
$(".CONOPSDevAODashboardFutureFY").text(parseInt(CurrentFYforAcceptingCONOPS)+2);

ExecuteOrDelayUntilScriptLoaded(getCONOPSDevProgAODash, "sp.js");

function getCONOPSDevProgAODash() {
    //alert('getCONOPSDevProgAODash');
	var clientContext = new SP.ClientContext.get_current();
	var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevProgress");	
	var camlQuery = new SP.CamlQuery();
	camlQuery.set_viewXml('<View><RowLimit>100</RowLimit></View>');
	this.collListItem = oList.getItems(camlQuery);	
	clientContext.load(collListItem);	
	clientContext.executeQueryAsync(Function.createDelegate(this, this.getCONOPSDevProgAODashSucceeded), Function.createDelegate(this, this.getCONOPSDevProgAODashFailed));
}
function getCONOPSDevProgAODashSucceeded(){	
	var listItemInfo = '';	
	var oListItemForFY, oListItemOTA, oListItemWS1Progress, oListItemWS2Progress, oListItemWS3Progress, oListItemWS4Progress, oListItemWSReview;	
	var CONOPSDevAODashboardRowClass = "";	
	var ccolorKey = {DraftCompleted:"Green", NotStarted:"Red", InProgress:"Yellow", Submitted:"Black"};	
	var listItemEnumerator = collListItem.getEnumerator();
	while(listItemEnumerator.moveNext()){		
		var oListItem = listItemEnumerator.get_current();		
		oListItemForFY=oListItem.get_item('ForFY');
		oListItemOTA=oListItem.get_item('OperationalTestAgency');
		oListItemWS1Progress=oListItem.get_item('WS1Progress');
		oListItemWS2Progress=oListItem.get_item('WS2Progress');
		oListItemWS3Progress=oListItem.get_item('WS3Progress');
		oListItemWS4Progress=oListItem.get_item('WS4Progress');
		oListItemWSReview=oListItem.get_item('WSReview');
		
		CONOPSDevAODashboardRowClass = "CONOPSDevAODashboard" + oListItemForFY + oListItemOTA + "WS1Status";
		$("."+CONOPSDevAODashboardRowClass+"").attr("title","" + oListItemWS1Progress + "").attr("alt","" + oListItemWS1Progress + "").attr("src","/_layouts/Images/DCAPXSolution/CONOPSDevAODashboard"+ccolorKey[""+oListItemWS1Progress.replace(/\s/g,'')+""]+".png");

		CONOPSDevAODashboardRowClass = "CONOPSDevAODashboard" + oListItemForFY + oListItemOTA + "WS2Status";
		$("."+CONOPSDevAODashboardRowClass+"").attr("title","" + oListItemWS2Progress + "").attr("alt","" + oListItemWS1Progress + "").attr("src","/_layouts/Images/DCAPXSolution/CONOPSDevAODashboard"+ccolorKey[""+oListItemWS2Progress.replace(/\s/g,'')+""]+".png");

		CONOPSDevAODashboardRowClass = "CONOPSDevAODashboard" + oListItemForFY + oListItemOTA + "WS3Status";
		$("."+CONOPSDevAODashboardRowClass+"").attr("title","" + oListItemWS3Progress + "").attr("alt","" + oListItemWS1Progress + "").attr("src","/_layouts/Images/DCAPXSolution/CONOPSDevAODashboard"+ccolorKey[""+oListItemWS3Progress.replace(/\s/g,'')+""]+".png");

		CONOPSDevAODashboardRowClass = "CONOPSDevAODashboard" + oListItemForFY + oListItemOTA + "WS4Status";
		$("."+CONOPSDevAODashboardRowClass+"").attr("title","" + oListItemWS4Progress + "").attr("alt","" + oListItemWS1Progress + "").attr("src","/_layouts/Images/DCAPXSolution/CONOPSDevAODashboard"+ccolorKey[""+oListItemWS4Progress.replace(/\s/g,'')+""]+".png");

		CONOPSDevAODashboardRowClass = "CONOPSDevAODashboard" + oListItemForFY + oListItemOTA + "WSReview";
		$("."+CONOPSDevAODashboardRowClass+"").attr("title","" + oListItemWSReview + "").attr("alt","" + oListItemWS1Progress + "").attr("src","/_layouts/Images/DCAPXSolution/CONOPSDevAODashboard"+ccolorKey[""+oListItemWSReview.replace(/\s/g,'')+""]+".png");

	}	
}
function getCONOPSDevProgAODashFailed(sender, args){
	alert('Request failed. ' + args.get_message());	
}




