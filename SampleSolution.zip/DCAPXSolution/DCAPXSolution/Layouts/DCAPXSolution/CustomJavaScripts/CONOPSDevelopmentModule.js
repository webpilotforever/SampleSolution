﻿
if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevelopment.aspx") > -1) {

    $("h3:contains(CONOPS Dashboard)").hide();

    ////$("#s4-leftpanel-content").html("<DIV class=\"ms-quicklaunchouter\"><DIV class=\"ms-quickLaunch\"><DIV id=\"ctl00_PlaceHolderLeftNavBar_QuickLaunchNavigationManager\" class=\"ms-quicklaunch-navmgr\"><DIV><DIV id=\"zz17_V4QuickLaunchMenu\" class=\"s4-ql\"><DIV class=\"menu vertical menu-vertical\"><UL class=\"root static\"><LI class=\"static\"><A class=\"static menu-item\" href=\"/sites/DCAPXObjects\"><SPAN class=\"additional-background\"><SPAN class=\"menu-item-text\">DCAPXObjects</SPAN></SPAN></A></LI></UL></DIV></DIV></DIV></DIV><UL class=\"s4-specialNavLinkList\"><LI><A id=\"ctl00_PlaceHolderLeftNavBar_PlaceHolderQuickLaunchBottom_PlaceHolderQuickLaunchBottomV4_idNavLinkRecycleBin\" class=\"s4-rcycl\" href=\"/_layouts/recyclebin.aspx\"><SPAN style=\"POSITION: relative; WIDTH: 16px; DISPLAY: inline-block; HEIGHT: 16px; OVERFLOW: hidden\" class=\"s4-clust s4-specialNavIcon\"><IMG style=\"POSITION: absolute; BORDER-RIGHT-WIDTH: 0px; BORDER-TOP-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; TOP: -428px !important; LEFT: 0px !important\" src=\"/_layouts/images/fgimg.png\"></SPAN>&nbsp;<SPAN class=ms-splinkbutton-text>Recycle Bin</SPAN></A> </LI><LI><A accessKey=\"3\" id=\"ctl00_PlaceHolderLeftNavBar_PlaceHolderQuickLaunchBottom_PlaceHolderQuickLaunchBottomV4_idNavLinkViewAllV4\" href=\"/_layouts/viewlsts.aspx\"><SPAN style=\"POSITION: relative; WIDTH: 16px; DISPLAY: inline-block; HEIGHT: 16px; OVERFLOW: hidden\" class=\"s4-clust s4-specialNavIcon\"><IMG style=\"POSITION: absolute; BORDER-RIGHT-WIDTH: 0px; BORDER-TOP-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; TOP: 0px !important; LEFT: 0px !important\" src=\"/_layouts/images/fgimg.png\"></SPAN>&nbsp;<SPAN class=ms-splinkbutton-text>All Site Content</SPAN></A> </LI></UL></DIV></DIV>");
    //$("#s4-leftpanel-content").html("<DIV class=\"ms-quicklaunchouter\"><DIV class=\"ms-quickLaunch\"><DIV id=\"ctl00_PlaceHolderLeftNavBar_QuickLaunchNavigationManager\" class=\"ms-quicklaunch-navmgr\"><DIV><DIV id=\"zz17_V4QuickLaunchMenu\" class=\"s4-ql\"><DIV class=\"menu vertical menu-vertical\"><UL class=\"root static\"></UL></DIV></DIV></DIV></DIV><UL class=\"s4-specialNavLinkList\"><LI><A id=\"ctl00_PlaceHolderLeftNavBar_PlaceHolderQuickLaunchBottom_PlaceHolderQuickLaunchBottomV4_idNavLinkRecycleBin\" class=\"s4-rcycl\" href=\"/_layouts/recyclebin.aspx\"><SPAN style=\"POSITION: relative; WIDTH: 16px; DISPLAY: inline-block; HEIGHT: 16px; OVERFLOW: hidden\" class=\"s4-clust s4-specialNavIcon\"><IMG style=\"POSITION: absolute; BORDER-RIGHT-WIDTH: 0px; BORDER-TOP-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; TOP: -428px !important; LEFT: 0px !important\" src=\"/_layouts/images/fgimg.png\"></SPAN>&nbsp;<SPAN class=ms-splinkbutton-text>Recycle Bin</SPAN></A> </LI><LI><A accessKey=\"3\" id=\"ctl00_PlaceHolderLeftNavBar_PlaceHolderQuickLaunchBottom_PlaceHolderQuickLaunchBottomV4_idNavLinkViewAllV4\" href=\"/_layouts/viewlsts.aspx\"><SPAN style=\"POSITION: relative; WIDTH: 16px; DISPLAY: inline-block; HEIGHT: 16px; OVERFLOW: hidden\" class=\"s4-clust s4-specialNavIcon\"><IMG style=\"POSITION: absolute; BORDER-RIGHT-WIDTH: 0px; BORDER-TOP-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; TOP: 0px !important; LEFT: 0px !important\" src=\"/_layouts/images/fgimg.png\"></SPAN>&nbsp;<SPAN class=ms-splinkbutton-text>All Site Content</SPAN></A> </LI></UL></DIV></DIV>");
    //ExecuteOrDelayUntilScriptLoaded(buildQuicklaunch, "sp.js");
}
//$(".CONOPSDevButton").closest("div").addClass("CONOPSDevReload");
$("#s4-leftpanel").hide();
$("#MSO_ContentTable").css("margin-left", "15px");
//Commenting out because links to ProgramContacts and Feedback in Quick Launch menu become truncated 
//$("body").append("<div class='quicklaunchtoggle'>&nbsp;</div>");

//var heightTopNavigationMenuV4 = $("div[id*='TopNavigationMenuV4']").css("height"); heightTopNavigationMenuV4 = parseInt(heightTopNavigationMenuV4.replace("px", ""));

//if (heightTopNavigationMenuV4 > 30) {
//    $(".quicklaunchtoggle").css("top", 188 + heightTopNavigationMenuV4 / 2);
//}

$(".viewWorksheetsButton").click(function () {
    $("#worksheetsList").slideToggle("slow", function () {
        //$(".viewWorksheetsButton").closest("div").css("background-color", "whitesmoke");
    });

});




// ----- SET FISCAL YEAR (for accepting CONOPS) -----
CurrentFYforAcceptingCONOPS = getCurrentFYforAcceptingCONOPS(); // for example: as of Jan 1, 2014 this would be 15
var PreviousFYforAcceptingCONOPS = parseInt(CurrentFYforAcceptingCONOPS)-1 ;
PreviousFYforAcceptingCONOPS = PreviousFYforAcceptingCONOPS.toString();
// ----- SET FYs IN POSITION CHART RELATIVE TO CURRENT FY -----
var newFYKey = { 15:CurrentFYforAcceptingCONOPS, 16:parseInt(CurrentFYforAcceptingCONOPS)+1, 17:parseInt(CurrentFYforAcceptingCONOPS)+2 };
$('span[id="wsTitleA"]').each(function(){
	var text = $(this).text();
	var textFY = text.replace(new RegExp(/\D/g),''); // get fys in default text of cells
	var newText = text.replace(new RegExp(/\d{2}/g), newFYKey[textFY] );
	$(this).text(newText);
});
//var locationSearch = location.search;
//var locationUpToSearch = location.href.substr(0, location.href.indexOf(locationSearch)); // alert(locationUpToSearch);
//// ----- RELOAD BUTTON ----- displayed in background along with progress chart until user submits conops
//$("#ButtonContinue").click(function(){
//	location.href=locationUpToSearch;
//});
// ----- HIDE DoNotDeleteMessage -----
$(".DoNotDeleteMessage").css("display","none");            
// ----- CURRENT USER OTA -----
var currentUserOTA = ""; 	
currentUserOTA += $(".OTATitleCONOPSDev").attr("title"); // ATEC
//var currentUserOTATitle = OTAtitleKey[currentUserOTA];
var currentUserOTATitle = $(".OTATitleCONOPSDev").text();
//$(".OTATitleCONOPSDev").text(currentUserOTATitle);
ExecuteOrDelayUntilScriptLoaded(openFirstWorksheetOnLoad, "sp.js");
//ExecuteOrDelayUntilScriptLoaded(loadSPUIDialogJS, "sp.js");
//function loadSPUIDialogJS() {
//    ExecuteOrDelayUntilScriptLoaded(openFirstWorksheetOnLoad, "SP.UI.Dialog.js");
//}


function openFirstWorksheetOnLoad() {
    if (currentUserOTA.length > 1) {
        //alert("openFirstWorksheetOnLoad called from CONOPSDevelopmentModule.js");
		getCONOPSDevProgress(); 
	}	
    else {
        var siteUrlArray = location.href.split("/");
        var isites = -1;
        var i;
        for (i = 0; i < siteUrlArray.length; i++) {
            
            if (siteUrlArray[i] == "sites") {
                isites = i+1;
            }
            
        }
        var siteName = siteUrlArray[isites];
      
        alert("Failed to get OTA of current user. Select a DCAPX POC from the left menu. Request to be added to the Program Contacts list with an OTA indicated."); location.replace("/sites/" + siteName + "/Lists/DCAPXPOCs/AllItems.aspx");
	}
}
// -------------------
function getCONOPSDevProgress(){
    //alert("getCONOPSDevProgress called from CONOPSDevelopmentModule.js");
    this.clientContext = new SP.ClientContext.get_current();
	var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevProgress");
	
	var camlQueryAnyInProgress = new SP.CamlQuery();
	camlQueryAnyInProgress.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><Or><Or><Or><Or><And><Eq><FieldRef Name=\"OperationalTestAgency\"/><Value Type=\"Text\">"+currentUserOTA+"</Value></Eq><Eq><FieldRef Name=\"WS1Progress\"/><Value Type=\"Text\">In Progress</Value></Eq></And><Eq><FieldRef Name=\"WS2Progress\"/><Value Type=\"Text\">In Progress</Value></Eq></Or><Eq><FieldRef Name=\"WS3Progress\"/><Value Type=\"Text\">In Progress</Value></Eq></Or><Eq><FieldRef Name=\"WS4Progress\"/><Value Type=\"Text\">In Progress</Value></Eq></Or><Eq><FieldRef Name=\"WSReview\"/><Value Type=\"Text\">In Progress</Value></Eq></Or></Where></Query><ViewFields><FieldRef Name=\"OperationalTestAgency\"/><FieldRef Name=\"WS1Progress\"/><FieldRef Name=\"WS2Progress\"/><FieldRef Name=\"WS3Progress\"/><FieldRef Name=\"WS4Progress\"/><FieldRef Name=\"WSReview\"/><FieldRef Name=\"ForFY\"/><FieldRef Name=\"ID\"/></ViewFields></View>");
	this.collListItemAnyInProgress = oList.getItems(camlQueryAnyInProgress);
	
	var camlQueryDraftCompleted = new SP.CamlQuery(); // updated
	camlQueryDraftCompleted.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><And><And><And><Eq><FieldRef Name=\"OperationalTestAgency\"/><Value Type=\"Text\">"+currentUserOTA+"</Value></Eq><Eq><FieldRef Name=\"WS1Progress\"/><Value Type=\"Text\">Draft Completed</Value></Eq></And><Eq><FieldRef Name=\"WS2Progress\"/><Value Type=\"Text\">Draft Completed</Value></Eq></And><Eq><FieldRef Name=\"WS3Progress\"/><Value Type=\"Text\">Draft Completed</Value></Eq></And><Eq><FieldRef Name=\"WS4Progress\"/><Value Type=\"Text\">Draft Completed</Value></Eq></And><Eq><FieldRef Name=\"WSReview\"/><Value Type=\"Text\">Draft Completed</Value></Eq></And></Where></Query><ViewFields><FieldRef Name=\"OperationalTestAgency\"/><FieldRef Name=\"WS1Progress\"/><FieldRef Name=\"WS2Progress\"/><FieldRef Name=\"WS3Progress\"/><FieldRef Name=\"WS4Progress\"/><FieldRef Name=\"WSReview\"/><FieldRef Name=\"ForFY\"/><FieldRef Name=\"ID\"/></ViewFields></View>");
	this.collListItemDraftCompleted = oList.getItems(camlQueryDraftCompleted);

	var camlQueryNotStarted = new SP.CamlQuery();
	camlQueryNotStarted.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><And><And><And><And><Eq><FieldRef Name=\"OperationalTestAgency\"/><Value Type=\"Text\">"+currentUserOTA+"</Value></Eq><Eq><FieldRef Name=\"WS1Progress\"/><Value Type=\"Text\">Not Started</Value></Eq></And><Eq><FieldRef Name=\"WS2Progress\"/><Value Type=\"Text\">Not Started</Value></Eq></And><Eq><FieldRef Name=\"WS3Progress\"/><Value Type=\"Text\">Not Started</Value></Eq></And><Eq><FieldRef Name=\"WS4Progress\"/><Value Type=\"Text\">Not Started</Value></Eq></And><Eq><FieldRef Name=\"WSReview\"/><Value Type=\"Text\">Not Started</Value></Eq></And></Where></Query><ViewFields><FieldRef Name=\"OperationalTestAgency\"/><FieldRef Name=\"WS1Progress\"/><FieldRef Name=\"WS2Progress\"/><FieldRef Name=\"WS3Progress\"/><FieldRef Name=\"WS4Progress\"/><FieldRef Name=\"WSReview\"/><FieldRef Name=\"ForFY\"/><FieldRef Name=\"ID\"/></ViewFields></View>");
	this.collListItemNotStarted = oList.getItems(camlQueryNotStarted);
	
	var camlQuerySubmitted = new SP.CamlQuery();
	camlQuerySubmitted.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><Eq><FieldRef Name=\"OperationalTestAgency\"/><Value Type=\"Text\">"+currentUserOTA+"</Value></Eq><Eq><FieldRef Name=\"SubmittedFY\"/><Value Type=\"Text\">"+CurrentFYforAcceptingCONOPS+"</Value></Eq></And></Where></Query><ViewFields><FieldRef Name=\"OperationalTestAgency\"/><FieldRef Name=\"WS1Progress\"/><FieldRef Name=\"WS2Progress\"/><FieldRef Name=\"WS3Progress\"/><FieldRef Name=\"WS4Progress\"/><FieldRef Name=\"WSReview\"/><FieldRef Name=\"ForFY\"/><FieldRef Name=\"ID\"/><FieldRef Name=\"SubmittedFY\"/><FieldRef Name=\"SubmittedBy\"/><FieldRef Name=\"SubmittedOn\"/></ViewFields></View>");
	this.collListItemSubmitted = oList.getItems(camlQuerySubmitted);
	
	var camlQuerySubmittedPreviousFY = new SP.CamlQuery();
	camlQuerySubmittedPreviousFY.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Eq><FieldRef Name=\"OperationalTestAgency\"/><Value Type=\"Text\">"+currentUserOTA+"</Value></Eq><Eq><FieldRef Name=\"SubmittedFY\"/><Value Type=\"Text\">"+ PreviousFYforAcceptingCONOPS +"</Value></Eq></And></Where></Query><ViewFields><FieldRef Name=\"OperationalTestAgency\"/><FieldRef Name=\"WS1Progress\"/><FieldRef Name=\"WS2Progress\"/><FieldRef Name=\"WS3Progress\"/><FieldRef Name=\"WS4Progress\"/><FieldRef Name=\"WSReview\"/><FieldRef Name=\"ForFY\"/><FieldRef Name=\"ID\"/><FieldRef Name=\"SubmittedFY\"/><FieldRef Name=\"SubmittedBy\"/><FieldRef Name=\"SubmittedOn\"/></ViewFields></View>");
	this.collListItemSubmittedPreviousFY = oList.getItems(camlQuerySubmittedPreviousFY);
	
	clientContext.load(collListItemAnyInProgress);
	clientContext.load(collListItemDraftCompleted);
	clientContext.load(collListItemNotStarted);
	clientContext.load(collListItemSubmitted);
	clientContext.load(collListItemSubmittedPreviousFY);	
	
	clientContext.executeQueryAsync(Function.createDelegate(this, this.getCONOPSDevProgressSucceeded), Function.createDelegate(this, this.getCONOPSDevProgressFailed));
}
function getCONOPSDevProgressSucceeded(){	
	var itemId = "0";
    var summaryFY = "";
	var showTable = "";
	var heightoverride = "";
	var countAnyInProgress = collListItemAnyInProgress.get_count(); // can return more than 3 because this query uses Or condition
	var countDraftCompleted = collListItemDraftCompleted.get_count();
	var countNotStarted = collListItemNotStarted.get_count();
	var countSubmitted = collListItemSubmitted.get_count();
	var countSubmittedPreviousFY = collListItemSubmittedPreviousFY.get_count();
	var worksheetFY, wsInProg, wsInProgTitle, wsInProgPage, oListItemForFY, oListItemOTA, oListItemWS1Progress, oListItemWS2Progress, oListItemWS3Progress, oListItemWS4Progress, oListItemWSReview;
	var listItemInfo = '';
	var CONOPSDevProgressKey = {NotStarted:0, InProgress:1, DraftCompleted:2, Submitted:3};
	var ForFYKey = {Current:"1", Next:"2", Future:"3"};	// for styling
	
	// ----- AT LEAST ONE WORKSHEET/REVIEW PAGE IS REQUIRED TO BE 'In Progress' -----
	if(countAnyInProgress < 1){ // nothing In Progress 
		if(countDraftCompleted > 2){ // all are Draft Completed
			wsInProg="FYRS"; wsInProgTitle="Review"; wsInProgPage="CONOPSDevReviewSubmitWorksheets";
			oListItemForFY = "Future";
			showTable = "&showTable=submit";
			heightoverride = "280";
			worksheetFY = parseInt(CurrentFYforAcceptingCONOPS) + 2;

			summaryFY = "&summaryFY=" + CurrentFYforAcceptingCONOPS; //added for attachments

			listItemInfo = "ws1Prog=2&ws2Prog=2&ws3Prog=2&ws4Prog=2&wsRevProg=2&ota=" + currentUserOTA + "&otaTitle=" + encodeURIComponent(currentUserOTATitle) + "&currentFY=" + worksheetFY + "&itemId=" + itemId + summaryFY + showTable;
		}
		else if (countNotStarted > 2){ // all are Not Started
			// set first worksheet (WS1Progress) in first row to 'In Progress'
			// alert('setting WS1Progress to In Progress.');
			var listItemEnumeratorNotStarted = collListItemNotStarted.getEnumerator();
			while(listItemEnumeratorNotStarted.moveNext()){
				var oListItem = listItemEnumeratorNotStarted.get_current();				
				oListItem.set_item('WS1Progress','In Progress');
				oListItem.update();
				break;			
			}
			clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSDevProgressUpdateInProgressSucceeded), Function.createDelegate(this, this.onQueryFailed));
		}
		else if (countSubmitted > 2){ // all are Submitted for this fy		
			// possible next steps...
			// present launch page to ota with message 'If you believe this is an error, request this module be reset for the current fiscal year by clicking the Request Reset button. ' Add Request Reset button. 
			// and below this add 'SubmittedFY: 16, SubmittedBy: username, SubmittedOn: date'
			// task admins with 'Reset CONOPS Development Module for current fiscal year for OTA: X'  task (no Reset Requests list necessary?) and revealed button on AO Administration Dashboard which sets all to Not Started except for the first WS1Progress which is set to In Progress then reload the launch page.
			var listItemEnumeratorSubmitted = collListItemSubmitted.getEnumerator();
			var SubmittedFY, SubmittedBy, SubmittedOn;	
			while(listItemEnumeratorSubmitted.moveNext()){
				var oListItem = listItemEnumeratorSubmitted.get_current();		
				SubmittedFY = oListItem.get_item('SubmittedFY');
				SubmittedBy = oListItem.get_item('SubmittedBy').get_lookupValue();
				var SubmittedOnDate = new Date( oListItem.get_item('SubmittedOn').toString()  );
				SubmittedOn = SubmittedOnDate.toLocaleDateString() +" "+ SubmittedOnDate.toLocaleTimeString();
				break;
			} 
			//// alert("All CONOPS have been submitted for the current fiscal year. \n\nCONOPS submitted for fiscal year: FY20"+SubmittedFY+" \nSubmitted by: "+SubmittedBy+"  \nSubmitted on: "+SubmittedOn+" \n\nClick OK to go to the home page."); 
			//alert("All CONOPS have been submitted for the FY "+SubmittedFY+" build year. \n\nCONOPS submitted for FY "+SubmittedFY+" - "+(parseInt(SubmittedFY)+2)+" \nSubmitted by: "+SubmittedBy+"  \nSubmitted on: "+SubmittedOn+" \n\nClick OK to go to the home page."); 			
			
                
                
			$(".CONOPSDevSubmittedMsg").html("<div class=\"CONOPSDevSubmittedMsgBox\"><div style=\"text-align: left\">All CONOPS have been submitted for the FY " + SubmittedFY + " build year.<br/><br/>CONOPS submitted for FY " + SubmittedFY + " - " + (parseInt(SubmittedFY) + 2) + " <br/>Submitted by: " + SubmittedBy + "  <br/>Submitted on: " + SubmittedOn + " </div> </div>");

		    //location.href = locationUpToSite;

			$(".drafts").addClass("submitted");


		    //hide chart and continue button
		    //$(".CONOPSDevButton").hide();
			//var ls = location.search.toString();
			//var lh = location.href.toString();
			//lh = lh.replace(ls, "");
			
			if (getParameterByName("submitted") !== "yes") {
			    location.search = "wsClosed=false&submitted=yes";
			}
            
		}
		else if (countSubmittedPreviousFY > 2){ // all are Submitted for previous fy
			// alert('All are Submitted for previous year, so resetting. ');
			var listItemEnumeratorSubmittedPreviousFY = collListItemSubmittedPreviousFY.getEnumerator();
			var i=0;	
			while(listItemEnumeratorSubmittedPreviousFY.moveNext()){
				var oListItem = listItemEnumeratorSubmittedPreviousFY.get_current();				
				if(i<1){
					oListItem.set_item('WS1Progress','In Progress');
					oListItem.set_item('WS2Progress','Not Started');
					oListItem.set_item('WS3Progress','Not Started');
					oListItem.set_item('WS4Progress','Not Started');
					oListItem.set_item('WSReview','Not Started');
					oListItem.set_item('SubmittedFY','');
					oListItem.set_item('SubmittedBy','');
					oListItem.set_item('SubmittedOn',null);
				} else{
					oListItem.set_item('WS1Progress','Not Started');
					oListItem.set_item('WS2Progress','Not Started');
					oListItem.set_item('WS3Progress','Not Started');
					oListItem.set_item('WS4Progress','Not Started');
					oListItem.set_item('WSReview','Not Started');
					oListItem.set_item('SubmittedFY','');
					oListItem.set_item('SubmittedBy','');
					oListItem.set_item('SubmittedOn',null);
				}
				oListItem.update();
				i=i+1;		
			}
			clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSDevProgressUpdateInProgressSucceeded), Function.createDelegate(this, this.onQueryFailed));
		}
		else {
			alert("Error: Expected at least one Worksheet/Review Page to be 'In Progress'. "); return false;
		}
	} 
	
	// ----- AT LEAST ONE WORKSHEET/REVIEW PAGE IS 'In Progress', so proceed normally -----	
	else { 
		var listItemEnumeratorAnyInProgress = collListItemAnyInProgress.getEnumerator();
		while(listItemEnumeratorAnyInProgress.moveNext()){
			var oListItem = listItemEnumeratorAnyInProgress.get_current();
			itemId = oListItem.get_id();
			oListItemForFY=oListItem.get_item('ForFY'); // alert('oListItemForFY: '+oListItemForFY); // Current and Next 
			worksheetFY=parseInt(CurrentFYforAcceptingCONOPS)+parseInt(ForFYKey[oListItemForFY])-1; // alert('worksheetFY: '+worksheetFY); // 16 and 17
			oListItemOTA=oListItem.get_item('OperationalTestAgency');
			oListItemWS1Progress=oListItem.get_item('WS1Progress');
			oListItemWS2Progress=oListItem.get_item('WS2Progress');
			oListItemWS3Progress=oListItem.get_item('WS3Progress');
			oListItemWS4Progress=oListItem.get_item('WS4Progress');
			oListItemWSReview=oListItem.get_item('WSReview');
			oListItemWS1Progress=oListItemWS1Progress.replace(/\s/g,'');
			oListItemWS2Progress=oListItemWS2Progress.replace(/\s/g,'');
			oListItemWS3Progress=oListItemWS3Progress.replace(/\s/g,'');
			oListItemWS4Progress=oListItemWS4Progress.replace(/\s/g,'');
			oListItemWSReview=oListItemWSReview.replace(/\s/g,'');
			// ------------------
			if (oListItemWSReview=="DraftCompleted"){
				if(oListItemWS1Progress!=="InProgress"||oListItemWS2Progress!=="InProgress"||oListItemWS3Progress!=="InProgress"||oListItemWS4Progress!=="InProgress"||oListItemWSReview!=="InProgress"){
					wsInProg="FYRS"; wsInProgTitle="Review"; wsInProgPage="CONOPSDevReviewSubmitWorksheets";
					
					showTable = "&showTable=submit"; //alert('showTable: '+ showTable);
					heightoverride = "280";
				    //alert('yep: itemId: '+itemId+' | '+wsInProg+' | '+wsInProgTitle+' | '+wsInProgPage);

					summaryFY = "&summaryFY=" + CurrentFYforAcceptingCONOPS; //added for attachments

				}
			} 
			else if(oListItemWS1Progress=="InProgress"||oListItemWS2Progress=="InProgress"||oListItemWS3Progress=="InProgress"||oListItemWS4Progress=="InProgress"||oListItemWSReview=="InProgress"){
	
			    if (oListItemWS1Progress == "InProgress") { wsInProg = "FYWS1"; wsInProgTitle = "Worksheet #1"; wsInProgPage = "CONOPSDevWS1"; }
			    if (oListItemWS2Progress == "InProgress") { wsInProg = "FYWS2"; wsInProgTitle = "Worksheet #2"; wsInProgPage = "CONOPSDevWS2"; }
			    if (oListItemWS3Progress == "InProgress") { wsInProg = "FYWS3"; wsInProgTitle = "Worksheet #3"; wsInProgPage = "CONOPSDevWS3"; }
			    if (oListItemWS4Progress == "InProgress") { wsInProg = "FYWS4"; wsInProgTitle = "Worksheet #4"; wsInProgPage = "CONOPSDevWS4"; }
			    if (oListItemWSReview == "InProgress") { wsInProg = "FYRS"; wsInProgTitle = "Review"; wsInProgPage = "CONOPSDevReviewSubmitWorksheets"; }
				
				if(parseInt(worksheetFY)==parseInt(CurrentFYforAcceptingCONOPS)){
					showTable = "&showTable=current";
					summaryFY = "&summaryFY="+CurrentFYforAcceptingCONOPS;
				} else if(parseInt(worksheetFY)==parseInt(CurrentFYforAcceptingCONOPS)+1){      
					showTable = "&showTable=next";     
					summaryFY = "&summaryFY="+(parseInt(CurrentFYforAcceptingCONOPS)+1);
				} else if(parseInt(worksheetFY)==parseInt(CurrentFYforAcceptingCONOPS)+2){      
					showTable = "&showTable=future";   
					summaryFY = "&summaryFY="+(parseInt(CurrentFYforAcceptingCONOPS)+2);
				}	
			} 
		}
		listItemInfo  = "ws1Prog=" + CONOPSDevProgressKey[oListItemWS1Progress] + "&ws2Prog=" + CONOPSDevProgressKey[oListItemWS2Progress] + "&ws3Prog=" + CONOPSDevProgressKey[oListItemWS3Progress] + "&ws4Prog=" + CONOPSDevProgressKey[oListItemWS4Progress] + "&wsRevProg=" + CONOPSDevProgressKey[oListItemWSReview] + "&ota=" + currentUserOTA + "&otaTitle=" + encodeURIComponent(currentUserOTATitle) + "&currentFY=" + worksheetFY + "&itemId=" + itemId + summaryFY + showTable;
	}	// end of else	
	// ----- show row in CONOPS Dev Progress table -----
	var rowToShowA = "CONOPSDevProgressRow" + ForFYKey[oListItemForFY] + "a"; 
	var rowToShowB = "CONOPSDevProgressRow" + ForFYKey[oListItemForFY] + "b";	
	// alert('rowToShowA: '+rowToShowA+" rowToShowB: "+rowToShowB); // CONOPSDevProgressRow3a
	$("."+rowToShowA+"").show(); $("."+rowToShowB).show();
	// ----- set CONOPS Dev Progress table colors -----
	// WS3Progress In Progress
	var inProgressA = "CONOPSDev" + oListItemForFY + wsInProg + "a";
	var inProgressB = "CONOPSDev" + oListItemForFY + wsInProg + "b";
	// alert('inProgressA: '+inProgressA +' inProgressB: '+inProgressB ); // CONOPSDevFutureFYWS1a, CONOPSDevFutureFYWS1b
	$("."+inProgressA+"").addClass("CONOPSDevPositionInProgressa");
	$("."+inProgressB+"").addClass("CONOPSDevPositionInProgressb");
	// get text from In Progress td
	var usersPositionInCONOPSDevProcess = "";
	usersPositionInCONOPSDevProcess += $(".CONOPSDevPositionInProgressb").text(); // FY 16 Budget Worksheet #3: Non-Assessment Travel
	//alert(usersPositionInCONOPSDevProcess );
	// previous cells should be marked Draft Completed (green)
	// following cells should be marked Not Started (red)
	// Find matching cell.
	var cellB = $(".CONOPSDevPositionTable").find("td:contains("+usersPositionInCONOPSDevProcess+")");
	var cellBindex = cellB.index();
	// Show the row.
	var rowB = cellB.closest("tr").show();
	var rowAindex = rowB.index()-1; 
	var rowA = $(".CONOPSDevPositionTable").find("tr:eq("+rowAindex+")").show();
	rowA.children(":even").each(function(){
		if($(this).index() < cellBindex){
			$(this).addClass("CONOPSDevPositionDraftCompletea");
			$(this).text("Draft Completed");
		} else if($(this).index() == cellBindex){
			$(this).addClass("CONOPSDevPositionInProgressa");
			$(this).text("In Progress");
		} else {
			$(this).addClass("CONOPSDevPositionNotStarteda");
			$(this).text("Not Started");
		}
	});
	rowB.children(":even").each(function(){
		if($(this).index() < cellBindex){
			$(this).addClass("CONOPSDevPositionDraftCompleteb");
		} else if($(this).index() == cellBindex){
			$(this).addClass("CONOPSDevPositionInProgressb");
		} else {
			$(this).addClass("CONOPSDevPositionNotStartedb");
		}
	});
	// open first worksheet
	if (getParameterByName('wsClosed') == "") {


	    if ($("input[id*='isSubmitter']").val() == 'No') {
	        $(".CONOPSDevPositionTable").show("slow", function () {
	            $(".viewWorksheetsButton").show("slow", function () {
                    
	            });

	            // $(".CONOPSDevButtonDiv").show("slow", function () { });


	        });
	    }
	    else {
	        $(".CONOPSDevPositionTableMsg").show("slow", function () {
	            $(".CONOPSDevPositionTablePrime").show("slow", function () {
	                openPopUpCONOPSDevPage(wsInProgTitle, locationUpToSite + "/SitePages/" + encodeURIComponent(wsInProgPage) + ".aspx?" + listItemInfo, heightoverride);
	            });
	        });
	    }


	}	
	else if (getParameterByName('wsClosed') == "true") {
	    $(".CONOPSDevPositionTable").show("slow", function () {
	        $(".viewWorksheetsButton").show("slow", function () {
	            
	        });

	        $(".CONOPSDevButtonDiv").show("slow", function () { });

			
		 });
	}
	else if (getParameterByName('submitted') == "yes") {
	    //$(".CONOPSDevPositionTableMsg").text("submitted worksheets");
	    $(".CONOPSDevPositionTableMsg").text("");
	    $(".viewWorksheetsButton").val("View Submitted Worksheets");

	    $(".CONOPSDevPositionTableMsg").show("slow", function () {
	        $(".viewWorksheetsButton").show("slow", function () {

	        });

	    });
	}
}
function getCONOPSDevProgressFailed(sender, args){
	alert('Request failed. ' + args.get_message());	
}
function CONOPSDevProgressUpdateInProgressSucceeded(){
	location.replace(location.href);
}
var toggleDisplayState=0;
$(".quicklaunchtoggle").click(function(){
	if(toggleDisplayState==0){
		$("#MSO_ContentTable").animate({
			marginLeft: "155px"
		}, 600, function(){	
		});
		$(".quicklaunchtoggle").animate({
			left: "150px"
		}, 600, function(){	
		});
		$(".belowQuickLaunch").removeAttr("style");
		$("#s4-leftpanel").show("slow", function(){
		});
		toggleDisplayState=1;
	} else {
		$("#s4-leftpanel").hide("slow", function(){				
			$("#MSO_ContentTable").animate({
				marginLeft: "15px"
			}, 500, function(){
				toggleDisplayState=0;
			});
		});	
		$(".quicklaunchtoggle").animate({
			left: "0px"
		}, 600, function(){	
		});
	}
});
