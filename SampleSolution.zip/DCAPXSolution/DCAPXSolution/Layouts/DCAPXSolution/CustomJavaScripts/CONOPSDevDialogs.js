﻿function openPopUpCONOPSDevPage(title, url, heightoverride) {
    //alert("openPopUpCONOPSDevPage title: "+title+"\nurl: "+ url); 
    var heightVal = 625;
    if(heightoverride!==""){
    	if(heightoverride=="autoSize"){
    		heightVal = null;
    	} else {
    		heightVal = heightoverride; 
    	}
    }
    // alert(heightoverride);
    var args = {
        prevWS: title,
        prevWSUrl: url
    };
    var options = {
        width: 1000,
        height: heightVal,
        title: title,
        url: url
    };
    
    SP.UI.ModalDialog.commonModalDialogOpen(url, options, nextCONOPSDevPage, args);
    
}
function pleaseWaitClosed(dialogResult, returnValue) { // not called. call when using wait dialog with cancel button as way to close worksheet after wait dialog is closed.
		
	SP.UI.ModalDialog.commonModalDialogClose(null, 1);

}

function nextCONOPSDevPage(dialogResult, returnValue) {
        

    var args = this.get_args();
    var prevWS = args.prevWS;
    var prevWSUrl = args.prevWSUrl;
    
    var incomingParams = prevWSUrl.substr(prevWSUrl.indexOf("?"));
    
    var newParams = incomingParams.replace('Prog=1','Prog=2'); 
    newParams = newParams.replace('Prog=0','Prog=1'); 
    
    var cntFY = incomingParams.substr(newParams.indexOf("currentFY=")+10, 2);

	var newParamsShowSubmit = incomingParams.replace(/Prog=1|Prog=0/,'Prog=2'); 
	newParamsShowSubmit = newParamsShowSubmit.replace(/&showTable=current|&showTable=next|&showTable=future/,'&showTable=submit');
	
	// do not appear to be using the following
	var newParamsForNextFY = incomingParams.replace(/Prog=1|Prog=2/,'Prog=0');
	newParamsForNextFY = newParamsForNextFY.replace(/ws1Prog=0/,'ws1Prog=1');
	newParamsForNextFY = newParamsForNextFY.replace('currentFY='+cntFY,'currentFY='+parseInt(cntFY)+1);
	
	
    if (dialogResult == 0) { 
    
    	// ----- WORKSHEET CLOSED BY USER SO SHOW CONTINUE BUTTON -----
    	var prevWSb = '';
    	if(prevWS.indexOf("Review")>-1){
    		// alert(prevWS); // Review
    		prevWSb = '5';
    	} else if (prevWS.indexOf("#")>-1){
    		prevWSb = prevWS.replace(/\D/g,'');// a worksheet number
    	
    	}
    	if(prevWSb.length > 0){ // if user closed a worksheet show the continue button
        	location.href=location.href+"?wsClosed=true"; // update position table and show continue button
        }
        	

    }     
    else if (returnValue) { // Saving dialog has closed so open next worksheet.
    	var summaryFY = "";
        var showTable = ""; 
        // compare to CurrentFYforAcceptingCONOPS
        if(newParams.indexOf("showTable")>-1){
        	// remove showTable from params // don't know if this is a necessary approach since final review is different in that it closes review page first
        	newParams.replace(/(&showTable=current|&showTable=next|&showTable=future)/,'');
        	// also remove summaryFY from params? -- just because did similarly above. trying to avoid build-up of repeated params in query string 
        	
        	if(incomingParams.indexOf("showTable=future")>-1 && incomingParams.indexOf("wsRevProg=1")>-1){
        	    showTable = "&showTable=submit";
        	    summaryFY = "&summaryFY=" + CurrentFYforAcceptingCONOPS; //added for attachments

        	}   
        } else if(parseInt(cntFY)==parseInt(CurrentFYforAcceptingCONOPS)){
        	showTable = "&showTable=current";
        	summaryFY = "&summaryFY="+CurrentFYforAcceptingCONOPS;
        } else if(parseInt(cntFY)==parseInt(CurrentFYforAcceptingCONOPS)+1){      
        	showTable = "&showTable=next";  
        	summaryFY = "&summaryFY="+(parseInt(CurrentFYforAcceptingCONOPS)+1);    
        } else if(parseInt(cntFY)==parseInt(CurrentFYforAcceptingCONOPS)+2){      
        	showTable = "&showTable=future";   
        	summaryFY = "&summaryFY="+(parseInt(CurrentFYforAcceptingCONOPS)+2);   
        } 
		
        if (returnValue == "Worksheet edited during review") { 
			var paramsPostEditDuringReview = incomingParams.replace("&review=true","");            
			openPopUpCONOPSDevPage(worksheetTitlesAndUrls["wsRt"], worksheetTitlesAndUrls["wsR"]+paramsPostEditDuringReview, "");             
        } 
        else {             
	        if (prevWS == worksheetTitlesAndUrls["ws1t"]  || prevWS.indexOf("#1") > -1) {           
	           openPopUpCONOPSDevPage(worksheetTitlesAndUrls["ws2t"], worksheetTitlesAndUrls["ws2"]+newParams, "");            
	        }
	        if (prevWS == worksheetTitlesAndUrls["ws2t"]  || prevWS.indexOf("#2") > -1) {
	            openPopUpCONOPSDevPage(worksheetTitlesAndUrls["ws3t"], worksheetTitlesAndUrls["ws3"]+newParams, "");            
	        }
	        if (prevWS == worksheetTitlesAndUrls["ws3t"] || prevWS.indexOf("#3") > -1) {      	
	        	openPopUpCONOPSDevPage(worksheetTitlesAndUrls["ws4t"], worksheetTitlesAndUrls["ws4"]+newParams, "");            
	        }
	        if (prevWS == worksheetTitlesAndUrls["ws4t"]  || prevWS.indexOf("#4") > -1) { 
	           	openPopUpCONOPSDevPage(worksheetTitlesAndUrls["wsRt"], worksheetTitlesAndUrls["wsR"]+newParams+summaryFY+showTable, "");            
	        }
	        if (prevWS == "Review/Submit Worksheets" || prevWS.indexOf("Review") > -1) {
				// alert('returnValue: '+returnValue); return false;
				var returnValueTxt = returnValue.toString();
				
				if(returnValueTxt.indexOf("WORKSHEET #")>-1){ // Print or EDIT button clicked from review page which closed review page and now opening a worksheet
					
				  
				    var reviewWSNum = returnValueTxt.substr(returnValueTxt.indexOf("#") + 1, 1); // 1
				    var reviewCurrentFY = returnValueTxt.substr(returnValueTxt.indexOf("FY ") + 3, 2); // 16
				    var reviewWSTitle = "Worksheet #" + reviewWSNum;
				    var showTableEdit;

				    if (parseInt(reviewCurrentFY) == parseInt(CurrentFYforAcceptingCONOPS)) {
				        showTableEdit = "current";
				    }
				    else if (parseInt(reviewCurrentFY) == parseInt(CurrentFYforAcceptingCONOPS) + 1) {
				        showTableEdit = "next";
				    }

				    else if (parseInt(reviewCurrentFY) == parseInt(CurrentFYforAcceptingCONOPS) + 2) {
				        showTableEdit = "future";
				    }

				    var newReviewParams = incomingParams.replace(/summaryFY=+\d+\d/, 'summaryFY=' + reviewCurrentFY);
				    newReviewParams = newReviewParams.replace(/(&showTable=current|&showTable=next|&showTable=future)/, '&showTable=' + showTableEdit);


				    openPopUpCONOPSDevPage(reviewWSTitle, worksheetTitlesAndUrls["ws" + reviewWSNum] + newReviewParams + "&review=true", "");
				    
				} 
				else { 
					
					// final fy review button clicked which closed dialog and now is reloading launch page to trigger dialog for review page with submit to open
				    ////location.replace(location);
				    //location.replace(location.href + "?wsClosed=submitted");
				    location.replace(location.href);
				}
				
	        }
       	}


   
 }
}
