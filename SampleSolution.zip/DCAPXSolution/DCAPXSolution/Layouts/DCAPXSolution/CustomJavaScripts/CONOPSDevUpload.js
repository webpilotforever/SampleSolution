﻿function uploadValidation(dest, fileName){ 
	this.fileName = fileName;
    var clientContext = new SP.ClientContext.get_current();  
    var oList = clientContext.get_web().get_lists().getByTitle(dest);
    var camlQuery = new SP.CamlQuery();
    camlQuery.set_viewXml("<View><Query><Where><Eq><FieldRef Name=\"FileLeafRef\"/><Value Type=\"Text\">"+fileName+"</Value></Eq></Where></Query></View>");

    this.collListItem = oList.getItems(camlQuery);
    
    clientContext.load(collListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.uploadValidationSucceeded), Function.createDelegate(this, this.onQueryFailed));

}

function uploadValidationSucceeded(){
	
	if(collListItem.get_count() > 0){
		SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
		var txt;
		
		var r = confirm(fileName+" already exists. Rename your file and try again. Or click OK to replace the file. ");
		if(r==true){
			txt = "OK";
			$("input[id*='btnOK']").click();	
		}
		else {
			txt = "Cancel";
			$("input[id*='BtnCancel']").click();
		}
	
	
		
		
	}
	else {
		
		SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
		$("input[id*='btnOK']").click();
	}
	
	
}	
