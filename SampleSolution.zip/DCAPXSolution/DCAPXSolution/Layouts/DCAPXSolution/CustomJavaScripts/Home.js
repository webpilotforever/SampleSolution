﻿// OTA long for H1

var pathName = location.pathname; // /sites/DCAPXObjects/SitePages/Home.aspx
var pathNameArray = pathName.split("/");
//  pathNameArray[1] sites
//  pathNameArray[2] DCAPXObjects
//  pathNameArray[3] SitePages
//  pathNameArray[4] Home.aspx

if (pathNameArray[3] == "SitePages") { // only execute on sites/DCAPX not on sub webs
    ExecuteOrDelayUntilScriptLoaded(getOTALong, "sp.js");
}
function getOTALong() {
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle("ProgramContacts"); 
    var camlQuery = new SP.CamlQuery(); 
    camlQuery.set_viewXml("<View><Query><Where><Eq><FieldRef Name=\"Account\"/><Value Type=\"Integer\"><UserID/></Value></Eq></Where></Query></View>");
    this.collListItem = oList.getItems(camlQuery);

    clientContext.load(collListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.getOTALongSucceeded), Function.createDelegate(this, this.getOTALongFailed));


}
function getOTALongSucceeded(sender, args) {
   

    var listItemEnumerator = collListItem.getEnumerator();
    while (listItemEnumerator.moveNext()) {
        
        var oListItem = listItemEnumerator.get_current();

        var OTAshort = oListItem.get_item("OperationalTestAgency");
        var OTAlong = "" + OTAtitleKey[OTAshort];
        if (OTAlong.length > 1) {
            $("h1.ms-rteElement-H1B").text(OTAlong + " Home");

            var homeBlurb2 = "" + $('.homeBlurb2').html();
            homeBlurb2 = homeBlurb2.replace(/Operational Test Agency/g, OTAlong);
            $('.homeBlurb2').html(homeBlurb2);

            var homeBlurb3 = "" + $('.homeBlurb3').html();
            homeBlurb3 = homeBlurb3.replace(/Operational Test Agency/g, OTAlong);
            $('.homeBlurb3').html(homeBlurb3);

            $('.homeBlurb4').hide(); //minimizes chance that extra space will remain below Quick Launch

            if (OTAshort == "AFOTEC") {
                //$('.homeBlurbImage').html("<img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/afoteccollage.png' />");
                //<div class='afotecCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/afoteccollage.png' /></div>
                $('.homeBlurbImage').html("<img class='afotecCollage' style='display:none' width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/afoteccollage.png' />");
                $('.afotecCollage').fadeIn("slow");
                

            }
            if (OTAshort == "ATEC") {
                //$('.homeBlurbImage').html("<img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/ateccollage.png' />");
                //<div class='atecCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/ateccollage.png' /></div>
                $('.homeBlurbImage').html("<img class='atecCollage' style='display:none' width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/ateccollage.png' />");
                $('.atecCollage').fadeIn("slow");
                
            }
            if (OTAshort == "COTF") {
                //$('.homeBlurbImage').html("<img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/cotfcollage.png' />");
                //<div class='cotfCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/cotfcollage.png' /></div>
                $('.homeBlurbImage').html("<img class='cotfCollage' style='display:none' width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/cotfcollage.png' />");
                $('.cotfCollage').fadeIn("slow");
                
            }
            if (OTAshort == "JITC") {
                //$('.homeBlurbImage').html("<img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/jitccollage.png' />");
                //<div class='jitcCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/jitccollage.png' /></div>
                $('.homeBlurbImage').html("<img class='jitcCollage' style='display:none' width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/jitccollage.png' />");
                $('.jitcCollage').fadeIn("slow");
                
            }
            if (OTAshort == "MCOTEA") {
                //$('.homeBlurbImage').html("<img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/mcoteacollage.png' />");
                //<div class='mcoteaCollage' style='text-align:center; display:none'><img width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/mcoteacollage.png' /></div>
                $('.homeBlurbImage').html("<img class='mcoteaCollage' style='display:none' width='300px' height='300px' alt='Collage' src='/_layouts/Images/DCAPXSolution/mcoteacollage.png' />");
                $('.mcoteaCollage').fadeIn("slow");
                
            }


        }
        
        
    }
    if ($("h1.ms-rteElement-H1B").text() == 'Operational Test Agency Home') {

        $("h1.ms-rteElement-H1B").text("DCAPX Home");
        //$("h1.ms-rteElement-H1B").css('font-family', 'sans-serif');
        $('.homeBlurb1').css('color', 'gray');
        $('.homeBlurb1').css('font-size', 'inherit');
        $('.homeBlurb2').css('color', 'gray');
        $('.homeBlurb3').css('color', 'gray');

        $('.homeBlurb2').html("This is the home page of the <b>DOT&E Cybersecurity Assessment Program Exchange (DCAPX)</b> site.");
        $('.homeBlurb3').html("<b>DCAPX</b> is an application built on the SharePoint platform which contains a growing set of modules designed to help Operational Test Agencies interface with <b>DOT&E</b>. With <b>DCAPX</b>, we aim to improve approvals, scheduling, analysis, and reporting.");

    }


}
function getOTALongFailed() {
    //alert('failed');
    
}





//// Style web parts on Home page
//$(".s4-wpTopTable").addClass("WebPart"); //not getting added to webparts because Home.js gets added to page too late via Global.js
//CONOP Development Dashboard (ViewCONOPS web part see DCAPXSolution/CONOPSDevModule/)
//$("table.WebPart").css("background-color", "black");
//alert($("table.WebPart > h3.ms-standardheader").text());
$("h3.ms-standardheader").css("text-align", "center");
$("#ViewCONOPSWebPartBtnDiv").closest("td").css("border-style", "solid");
$("#ViewCONOPSWebPartBtnDiv").closest("td").css("border-color", "#9CC7FF");
$("#ViewCONOPSWebPartBtnDiv").closest("td").css("border-width", "1px");


//$(".s4-wpTopTable").css("background-color", "#f5f6f7");
//$(".s4-wpTopTable").css("background-image", "url(/_layouts/Images/DCAPXSolution/selbg.png)");
//$(".s4-wpTopTable").css("background-repeat", "repeat-x");

//$("tr.ms-WPHeader").css("background-color", "transparent");
//$("tr.ms-WPHeader").css("outline-color", "#9CC7FF");
//$("tr.ms-WPHeader").css("outline-style", "solid");
//$("tr.ms-WPHeader").css("outline-width", "1px");

//$("td.ms-WPHeaderTd").css("padding-left", "20px");



// Background color for right col
var firstRowLayoutsTable = $("#layoutsTable").find("tr:first");
firstRowLayoutsTable.children("td:last").addClass("DCAPXHomeRightCol");
// Calendar Dashboard -------------------------------------
$("#CalendarDashboardContainer").css("position","absolute").css("bottom","30px");
// Remove js onclick from a tags in Calendar Dashboard (duplicated in td where it is needed when day is single digit and hard to click on.) 
$(".ms-datepickerouter").find("A").attr("href", "javascript:void(0);");
// Highlight days on Calendar Dashboard with events.          
highlightDaysWithEvents();


//-----Hide ViewCONOPS Web Part title -----
//$("h3.ms-WPTitle:contains(ViewCONOPS)").closest("table").hide();

