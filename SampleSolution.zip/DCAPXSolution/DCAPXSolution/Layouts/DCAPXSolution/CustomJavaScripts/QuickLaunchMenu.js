﻿if (siteRelURLtopage.indexOf("/SitePages/DCAPXInfo.aspx") > -1 ) {
    $(".s4-ql UL.root").closest('div.ms-quickLaunch').prepend("<div style='background:url(/_layouts/images/selbg.png) #f6f6f6 repeat-x left top; color:#003759; margin:1px; padding:5px; font-weight:bold; text-align:center;'>DCAPX Site</div>");


}
else if(location.href.indexOf('/sites/') > -1) {
    $(".s4-ql UL.root").closest('div.ms-quickLaunch').prepend("<div style='background:url(/_layouts/images/selbg.png) #f6f6f6 repeat-x left top; color:#003759; margin:1px; padding:5px; font-weight:bold; text-align:center;'>Modules</div>");
    //alert("loaded QuickLaunchMenu.js");

}

//alert("loaded QuickLaunchMenu.js");

var s4mainareaHeight = $("#s4-mainarea").css("height"); s4mainareaHeight = parseInt(s4mainareaHeight.replace("px", "")); // alert(s4mainareaHeight ); return false;
var QuickLaunchHeight = $("#s4-leftpanel-content").css("height"); QuickLaunchHeight = parseInt(QuickLaunchHeight.replace("px", "")); // alert("s4mainareaHeight: "+s4mainareaHeight +" QuickLaunchHeight: "+QuickLaunchHeight ); // return false;

var belowQuickLaunchHeight = $(".belowQuickLaunch").css("height");
$(".belowQuickLaunch").css("min-height", belowQuickLaunchHeight);

$(".s4-ba").css("padding-bottom", 1); $("#s4-leftpanel-content").css("padding-bottom", 1);

var DCAPXHomeRightColHeight;

if ($(".DCAPXHomeRightCol").length) { // for Home //
	
    DCAPXHomeRightColHeight = $(".DCAPXHomeRightCol").css("height"); DCAPXHomeRightColHeight = parseInt(DCAPXHomeRightColHeight.replace("px", ""));
    $(".belowQuickLaunch").css("height", DCAPXHomeRightColHeight - QuickLaunchHeight);
    
} else {
	
    $("#MSO_ContentTable").css("min-height", s4mainareaHeight);
    $(".belowQuickLaunch").css("height", s4mainareaHeight - QuickLaunchHeight);
    
}

//Feedback And Comments
//onclick='javascript:AddFeedbackAndComments();return false;'

//$(".menu-item-text:contains(Feedback)").closest("A").attr("onclick", "javascript:AddFeedbackAndComments();return false;");
//var feedbackLink = $(".menu-item-text:contains(Feedback)").closest("A").attr("href");

//if (feedbackLink.length > -1) {
//    var feedbackweb = feedbackLink.substr(0, feedbackLink.indexOf("/Lists"));
//    var feedbacknewLink = feedbackweb + "/_layouts/DCAPXSolution/Feedback.aspx";

//    $(".menu-item-text:contains(Feedback)").closest("A").attr("href", "javascript:OpenPopUpPage('" + feedbacknewLink + "')");


//}

//var feedbackUrl = $(".menu-item-text[contains:Feedback]").closest("A").attr("href");
//alert("feedbackUrl: " + feedbackUrl);
//<A id=idHomePageNewItem class=ms-addnew onclick='javascript:NewItem2(event, "http://dotersrcndapp5:12909/sites/DCAPXObjects/_layouts/listform.aspx?PageType=8&amp;ListId={B10D452B-8DA2-4398-BF8E-A22DAC829800}&amp;RootFolder=");javascript:return false;' href="http://dotersrcndapp5:12909/sites/DCAPXObjects/_layouts/listform.aspx?PageType=8&amp;ListId={B10D452B-8DA2-4398-BF8E-A22DAC829800}&amp;RootFolder=" target=_self>Add new item</A>



