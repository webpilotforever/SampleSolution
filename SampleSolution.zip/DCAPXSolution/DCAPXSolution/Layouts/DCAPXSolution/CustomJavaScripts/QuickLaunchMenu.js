﻿if (siteRelURLtopage.indexOf("/SitePages/DCAPXInfo.aspx") > -1 ) {
    $(".s4-ql UL.root").closest('div.ms-quickLaunch').prepend("<div style='background:url(/_layouts/images/selbg.png) #f6f6f6 repeat-x left top; color:#003759; margin:1px; padding:5px; font-weight:bold; text-align:center;'>DCAPX Site</div>");


}
else if(location.href.indexOf('/sites/') > -1) {
    $(".s4-ql UL.root").closest('div.ms-quickLaunch').prepend("<div style='background:url(/_layouts/images/selbg.png) #f6f6f6 repeat-x left top; color:#003759; margin:1px; padding:5px; font-weight:bold; text-align:center;'>Modules</div>");
    //alert("loaded QuickLaunchMenu.js");

    //ProgramContacts link for AOs points to list not to special form for OTAs
    ExecuteOrDelayUntilScriptLoaded(ProgramContactsLinkForAOs, 'sp.js');
    ///Lists/ProgramContacts/AllItems.aspx
}

//alert("loaded QuickLaunchMenu.js");

var s4mainareaHeight = $("#s4-mainarea").css("height"); s4mainareaHeight = parseInt(s4mainareaHeight.replace("px", "")); // alert(s4mainareaHeight ); return false;
var QuickLaunchHeight = $("#s4-leftpanel-content").css("height"); QuickLaunchHeight = parseInt(QuickLaunchHeight.replace("px", "")); // alert("s4mainareaHeight: "+s4mainareaHeight +" QuickLaunchHeight: "+QuickLaunchHeight ); // return false;

var belowQuickLaunchHeight = $(".belowQuickLaunch").css("height");
$(".belowQuickLaunch").css("min-height", belowQuickLaunchHeight);

$(".s4-ba").css("padding-bottom", 1); $("#s4-leftpanel-content").css("padding-bottom", 1);

var DCAPXHomeRightColHeight;

if ($(".DCAPXHomeRightCol").length) { // for Home //
	
    DCAPXHomeRightColHeight = $(".DCAPXHomeRightCol").css("height"); DCAPXHomeRightColHeight = parseInt(DCAPXHomeRightColHeight.replace("px", ""));
    $(".belowQuickLaunch").css("height", DCAPXHomeRightColHeight - QuickLaunchHeight);
    
} else {
	
    $("#MSO_ContentTable").css("min-height", s4mainareaHeight);
    $(".belowQuickLaunch").css("height", s4mainareaHeight - QuickLaunchHeight);
    
}

//Feedback And Comments
//onclick='javascript:AddFeedbackAndComments();return false;'

//$(".menu-item-text:contains(Feedback)").closest("A").attr("onclick", "javascript:AddFeedbackAndComments();return false;");
//var feedbackLink = $(".menu-item-text:contains(Feedback)").closest("A").attr("href");

//if (feedbackLink.length > -1) {
//    var feedbackweb = feedbackLink.substr(0, feedbackLink.indexOf("/Lists"));
//    var feedbacknewLink = feedbackweb + "/_layouts/DCAPXSolution/Feedback.aspx";

//    $(".menu-item-text:contains(Feedback)").closest("A").attr("href", "javascript:OpenPopUpPage('" + feedbacknewLink + "')");


//}

//var feedbackUrl = $(".menu-item-text[contains:Feedback]").closest("A").attr("href");
//alert("feedbackUrl: " + feedbackUrl);
//<A id=idHomePageNewItem class=ms-addnew onclick='javascript:NewItem2(event, "http://dotersrcndapp5:12909/sites/DCAPXObjects/_layouts/listform.aspx?PageType=8&amp;ListId={B10D452B-8DA2-4398-BF8E-A22DAC829800}&amp;RootFolder=");javascript:return false;' href="http://dotersrcndapp5:12909/sites/DCAPXObjects/_layouts/listform.aspx?PageType=8&amp;ListId={B10D452B-8DA2-4398-BF8E-A22DAC829800}&amp;RootFolder=" target=_self>Add new item</A>





function ProgramContactsLinkForAOs() {
    var clientContext = new SP.ClientContext.get_current();
    var collGroup = clientContext.get_web().get_siteGroups();
    var oGroup = collGroup.getById(21); // CONOPSApproval
    var oGroup2 = collGroup.getById(19); // DCAPXAO
    var oGroup3 = collGroup.getById(17); // DCAPXOwners

    this.collUser = oGroup.get_users();
    this.collUser2 = oGroup2.get_users();
    this.collUser3 = oGroup3.get_users();


    clientContext.load(collUser);
    clientContext.load(collUser2);
    clientContext.load(collUser3);


    clientContext.executeQueryAsync(Function.createDelegate(this, ProgramContactsLinkForAOsSucceeded), Function.createDelegate(this, ProgramContactsLinkForAOsFailed));

}
function ProgramContactsLinkForAOsSucceeded() {

    var isAO = false;

    //var userInfo = '';

    var userEnumerator = collUser.getEnumerator();

    while (userEnumerator.moveNext()) {

        var oUser = userEnumerator.get_current();
        if (oUser.get_id.length > -1) {
            isAO = true;
        }
        //this.userInfo += '\nUser: ' + oUser.get_title() +
        //    '\nID: ' + oUser.get_id() +
        //    '\nEmail: ' + oUser.get_email() +
        //    '\nLogin Name: ' + oUser.get_loginName();
    }

    //alert(userInfo);

    var userEnumerator2 = collUser2.getEnumerator();

    while (userEnumerator2.moveNext()) {

        var oUser2 = userEnumerator2.get_current();
        if (oUser2.get_id.length > -1) {
            isAO = true;
        }
    }
    var userEnumerator3 = collUser3.getEnumerator();

    while (userEnumerator3.moveNext()) {

        var oUser3 = userEnumerator3.get_current();
        if (oUser3.get_id.length > -1) {
            isAO = true;
        }
    }

    if (isAO) {

        var ProgramContactsLinkInQL = $(".menu-item-text:contains(Program Contacts)");
        ProgramContactsLinkInQL.closest("a").attr("href", locationUpToSite + "/Lists/ProgramContacts/AllItems.aspx");
    }

}

function ProgramContactsLinkForAOsFailed(sender, args) {
    //will fail if user does not have permission to read groups
}