﻿$(".WSNav").show().end().css("text-align","left");
//$(".CONOPSDevButtonDiv").show().end().css("text-align","left");
// ----- GET COMMON ROW DATA -----
// currentFY param represents currentWorksheet fy not real fy from getCurrentFYforAcceptingCONOPS()
var FY = getParameterByName("summaryFY"); // get from query string

var Submitted = "No";
var mousedown = false;


// ----- DELETE ROW BUTTON -----
$(".WSBtnDeleteRow").attr("title", "Delete row: disabled for first item").css("background-color", "#b0b0b0").css("cursor", "arrow"); // mark initial set of delete row buttons as disabled			
$("#s4-workspace").on('click', '.WSBtnDeleteRow', function () { // using event delegation for this dynamic content
    if ($(this).attr("title") !== "Delete row: disabled for first item") {
    	
        // Get local Venue cell ------------
        var VenueCell;
        var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
        $(".VenueRow").each(function () {
            if ($(this).index() > thisRowIndex) {
                return false;
            }
            else {
                VenueCell = $(this).children().first();
            }
        });
        // Remove this row ---------------
        $(this).closest('tr').remove();
        if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS2.aspx")>-1) {
            // Decrement rowSpan of Venue cell -----------
            var rowSpanDecrement = parseInt(VenueCell.attr("rowSpan")) - 1; //alert(rowSpanDecrement );
            VenueCell.attr("rowSpan", rowSpanDecrement);
        }
    }
});
// ----- ADD ROW BUTTON -----
$("#s4-workspace").on('mousedown', '.WSBtnAddRow', function (event) {
	mousedown = true;
});
$("#s4-workspace").on('click', '.WSBtnAddRow', function (event) {
	
	var thisRow = $(this).closest('tr')[0];
	var thisRowIndex = $(this).closest("tr").index(); // alert(thisRowIndex);
	function reviewScriptClick(){
		//alert("reviewScriptClick");
		// alert(Title+''+Dates+''+ People+''+ EventLocation+''+ EstTravel+''+ EstLaborOvertime+''+ Funding+''+ Venue);
		//alert('clicked: '+event.type);
		// clone rows without requiring validation so we can populate form from latest entries
	    // var thisRow = $(this).closest('tr')[0];
	    if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS2.aspx")>-1) {
	        // Get local Venue cell ------------
	        var VenueCell;
	        $(".VenueRow").each(function () {
	            if ($(this).index() > thisRowIndex) {
	                return false;
	            }
	            else {
	                VenueCell = $(this).children().first();
	            }
	            //alert("venueRow index: "+$(this).index());
	        });
	        // Clone Venue row -----------------------		
	        var venueVal = VenueCell.find("#Venue").val();
	        $(VenueRow).clone().insertAfter(thisRow).find("td:last").append("<input name='CONOPSDevVenue' type='hidden' id='Venue' value='" + venueVal + "' />").end().removeClass("VenueRow WSGroupStartRow").end().children().first().remove().end().find('.WSBtnDeleteRow').attr('title', 'Delete row').end().find('.WSBtnDeleteRow').removeAttr('style'); // clone row and do not clear inputs
	        // Increment rowSpan of Venue cell -----------
	        var rowSpanIncrement = parseInt(VenueCell.attr("rowSpan")) + 1; //alert(rowSpanIncrement );
	        VenueCell.attr("rowSpan", rowSpanIncrement);	        

	    }
	    else {
	        $(thisRow).clone().insertAfter(thisRow).removeClass("FirstAdditionalLineItem").end().find('.WSBtnDeleteRow').attr('title', 'Delete row').end().find('.WSBtnDeleteRow').removeAttr('style'); // clone row and do not clear inputs
	    }
	
	};
		
	function reviewMouseDown(){
	    var readyToClone = "Yes";
	    var invalidFields = "Please enter information for ";
	    
	    $("input", thisRow).each(function () {
	        var inputTitle = $(this).attr("title");
	        var inputId = $(this).attr("id");
	        var inputVal = $(this).val();
	        if (inputVal.length) {
	            // do nothing
	        }
	        else {

	            var SkipAdditionalLineItem = false;

	            if (inputTitle == "Additional Line Item Title") {
	                if (thisRow.find("input[title='Additional Line Item']").val().length) {
	                    // do nothing
	                }
	                else {
	                    SkipAdditionalLineItem = true;
	                }
	                
	            }


	            if (inputTitle == "Remarks") {
	                // do nothing
	            }
	            else {
	                invalidFields += "[" + inputTitle + "], ";
	                readyToClone = "No";
	            }
	        }
	    });
	    if (readyToClone == "No") {
	        var lastComma = invalidFields.lastIndexOf(",");
	        if (lastComma > -1) {
	            invalidFields = invalidFields.substr(0, lastComma);
	            lastComma = invalidFields.lastIndexOf(",");
	            if (lastComma > -1) {
	                invalidFields = invalidFields.substring(0, lastComma) + " and" + invalidFields.substring(lastComma + 1);
	            }
	            alert(invalidFields); // Please enter information for ...
	        }
	    }
	    else {
	        if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS2.aspx")>-1) {
	            // Get local Venue cell ------------
	            var VenueCell;
	            
	            $(".VenueRow").each(function () {
	                if ($(this).index() > thisRowIndex) {
	                    return false;
	                }
	                else {
	                    VenueCell = $(this).children().first();
	                }
	                // alert("venueRow index: "+$(this).index());
	            });
	            // Clone Venue row -----------------------		
	            var venueVal = VenueCell.find("#Venue").val();
	            $(VenueRow).clone().insertAfter(thisRow).find("td:last").append("<input name='CONOPSDevVenue' type='hidden' id='Venue' value='" + venueVal + "' />").end().find('input:text').val('').end().removeClass("VenueRow WSGroupStartRow").end().children().first().remove().end().find('.WSBtnDeleteRow').attr('title', 'Delete row').end().find('.WSBtnDeleteRow').removeAttr('style'); // clone row and clear inputs
	            // Increment rowSpan of Venue cell -----------
	            var rowSpanIncrement = parseInt(VenueCell.attr("rowSpan")) + 1; //alert(rowSpanIncrement );
	            VenueCell.attr("rowSpan", rowSpanIncrement);
	        }
	        else {
	            $(thisRow).clone().insertAfter(thisRow).removeClass("FirstAdditionalLineItem").end().find('input:text').val('').end().find('.WSBtnDeleteRow').attr('title', 'Delete row').end().find('.WSBtnDeleteRow').removeAttr('style'); // clone row and clear inputs
	        }
	    }
	
	};

	// if(getParameterByName("review")=="true" && mousedown == false){ // if click is triggered by script during review process
	if(mousedown == false){ // if click is triggered by script during review process
		
		reviewScriptClick();
		mousedown = false;
	
	} else {
	
		reviewMouseDown();
	}
});




// ----- DELETE VENUE BUTTON -----
$(".WSBtnDeleteGroup").attr("title", "Delete group: disabled for first group").css("background-color", "#b0b0b0").css("cursor", "arrow"); // mark initial set of delete row buttons as disabled			
$("#s4-workspace").on('click', '.WSBtnDeleteGroup', function () { // using event delegation for this dynamic content
    if ($(this).attr("title") !== "Delete group: disabled for first group") {
    	
        var ix = $(this).closest('tr').index();
        var ii = -1;
        var sliceEndGroupelete = ix + 1;
        $(".WSGroupStartRow").each(function () {
            if ($(this).index() < ix) {
                ii = $(this).index();
            }
        });
        var sliceStartDelete = ii;
        var thisGroupTitleRowSet = tbody.children().slice(sliceStartDelete, sliceEndGroupelete);
        thisGroupTitleRowSet.remove();
    }
});

// ----- ADD GROUP BUTTON ----- ('GROUP' refers to a set of table rows in worksheets #1 and 2)
$("#s4-workspace").on('mousedown', '.WSBtnAddGroup', function (event) {
	mousedown = true;
});

$("#s4-workspace").on('click', '.WSBtnAddGroup', function () { // using event delegation for this dynamic content
    
	//var firstGroupFirstRow = $("#Venue:first").closest('tr')[0]; 
	var thisRow = $(this).closest('tr')[0];  
    var thisRowIndex = $(this).closest("tr").index(); // alert('thisRowIndex: '+thisRowIndex);
     
    if(getParameterByName("review")=="true" && mousedown == false){ // if click is triggered by script during review process
		
		reviewScriptClickAddGroup();
		mousedown = false;
	
	} else {
	
		reviewMouseDownAddGroup();
	}

    
    function reviewScriptClickAddGroup(){
    
        if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1) {
	        $(groupTemplate).clone().insertAfter(thisRow).find('.WSBtnDeleteGroup').attr('title', 'Delete group').end().find('.WSBtnDeleteGroup').removeAttr('style'); // clone row and do not clear inputs
	
	    } else {
			// worksheet #2
			// first group is available to jQuery, but not dynamically created cloned groups inserted after.
			// var fff = $(this).closest("tr").index(); alert(fff); return false;
	        $(groupTemplate).clone().insertAfter(thisRow).find('.WSBtnDeleteGroup').attr('title', 'Delete group').end().find('.WSBtnDeleteGroup').removeAttr('style').end().find(".WSGroupTitle").parent().attr("rowSpan", "2");

	
	    }
	}
    function reviewMouseDownAddGroup(){

        if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1) {
	        $(groupTemplate).clone().insertAfter(thisRow).find('#Contract').val('').end().find('input:text').val('').end().find('.WSBtnDeleteGroup').attr('title', 'Delete group').end().find('.WSBtnDeleteGroup').removeAttr('style'); // clone row and clear inputs
	
	    } else {
	
	        $(groupTemplate).clone().insertAfter(thisRow).find("input:text").val("").end().find('.WSBtnDeleteGroup').attr('title', 'Delete group').end().find('.WSBtnDeleteGroup').removeAttr('style').end().find(".WSGroupTitle").parent().attr("rowSpan", "2");
	
	    }
    }

});
// ----- SET FY AND OTA IN FORM TEXT ELEMENTS -----
$(".WSFY").text(FY);  
$(".WSOTA").text(OTAtitle.toUpperCase()); 



wsNumFromPageName= worksheetPageName.substr(11); //alert('wsNumFromPageName: '+wsNumFromPageName);
wsListForOTA= "CONOPSDevWS" + OTA; // alert(wsListForOTA); // CONOPSDevWSAFOTEC

// ----- EDIT WORKSHEET FROM REVIEW PAGE ----- if Editing worksheet from Review page populate form from latest entries
if(getParameterByName("review") == "true"){
	//alert("review is true so populate form from latest entries"); 
	// see CONOPSDevGetWorksheetData.js
	ExecuteOrDelayUntilScriptLoaded(callgetWorksheetData, "sp.js");
	function callgetWorksheetData(){
		getWorksheetData(wsListForOTA, FY, wsNumFromPageName);
		
	}
}

// ----- SAVE NEXT BUTTON -----
$("input[id*='SaveWSButton']").attr("onclick","javascript:return false;"); // prevent the SaveWSButton web part from clicking
$("#s4-workspace").on('mousedown', 'input:submit', function () { // SaveWSButton web part mousedown
	if($(this).attr("title")=="Save worksheet"){
		var numOfFieldsToUpdate = $("input[name*='CONOPSDev']").length-1;
		$("input[name*='CONOPSDev']").each(function(i){
			// Tag fields with row index
			var rowIndex = $(this).closest("tr").index();
			var nameVal = $(this).attr("name");
			nameVal = nameVal.replace(/\d/g, '');
			
			$(this).attr("name", rowIndex+nameVal);
			
			if(i==numOfFieldsToUpdate){
				//alert('i: '+i+'\nnumOfFieldsToUpdate: '+ numOfFieldsToUpdate);
				$("input[id*='SaveWSButton']").removeAttr("onclick").end().click(); // enable click on button and call click now that updates to dom are done
				// click event handled in web part cs file
				
			}
			
		});	

	
	}
	
});
$("#s4-workspace").on('click', '.WSBtnSaveAndNext', function () { // using event delegation for this dynamic content

	var q=0;
	
	$("input#Title").each(function(){
		
	    var titleVal = $(this).val();
		
		if(titleVal.length < 1){
			
		    var titleTitle = $(this).attr("title");
			
		    //if (titleTitle !== "Additional Line Item Title") {
		    //    //alert('titleTitle: ' + titleTitle);
			//    q = 1;
			//    alert("Please enter a value for [" + titleTitle + "]");
            //}
		    //else { // Require Additional Line Item Title if Additional Line Item has value
		    //    //alert('AdditionalLineItem value: ' + $(this).closest("tr").find($("#AdditionalLineItem")).val());

		    //    var addLIRW = $(this).closest("tr");
		       
		    //    if (addLIRW.find("input[title='Additional Line Item']").val().length) {
		    //        q = 1;
		    //        alert("Please enter a value for [" + titleTitle + "]");
		    //    }
		    //}

		    if (titleTitle !== "Additional Line Item Title") {

		        q = 1;
		        alert("Please enter a value for [" + titleTitle + "]");
		    }
		    else {



		        var addLIRW = $(this).closest("tr");
		        var addLI = addLIRW.find("input[title='Additional Line Item']");

		        var addLIVal;

		        //alert('addLI.val(): ' + addLI.val()); // TEST

		        if (addLI.val().length) {

		            //alert('addLI.val().length: ' + addLI.val().length); // TEST

		            if ($.isNumeric(addLI.val())) {

		                //alert('$.isNumeric(addLI.val()): ' + $.isNumeric(addLI.val())); // TEST

		                addLIVal = addLI.val();
		                addLIVal = parseFloat(addLIVal);

		                //alert('addLIVal: ' + addLIVal); // TEST


		                if (addLIVal > 0) {
		                    q = 1;
		                    alert("Please enter a value for [" + titleTitle + "]");
		                }
		                else {
		                    //if Additional Line Item Title is blank and Additional Line Item is 0 remove the row. Do not require user to have an Additional Line Item!


		                    //alert('removing'); // TEST

		                    //addLIRW.remove();

		                    addLIRW.find("input").each(function () {
		                        $(this).remove();
		                    });
		                }
		            }
		        }


		    }

		}
		
	});
	

	if (q == 1) {
		return false;
	}

	updateTotals();
	//var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Saving", "Please wait..."); // opens second dialog WITHOUT CANCEL BUTTON BECAUSE it is too fast and may interfere with save, and it is difficult to reverse multiple colums and potentially 2 rows in CONOPSDevProgress list.
    var inputVals = ""; // collect input values
    var DateDraftSavedDate = new Date(); 
    var TimeDraftSaved = DateDraftSavedDate.getTime();
    DateDraftSavedDate = DateDraftSavedDate.toLocaleString(); 
    $(".WSTable > tbody > tr:has('input')").each(function () {
        var row = this;
        var values = "";
        var hasValue = 0;
        $("input", row).each(function () {
            var inputId = $(this).attr("id");
            var inputVal = $(this).val();
            if (inputVal.length) {
            	// alert('inputVal: '+inputVal);
                hasValue = hasValue + 1;
                values += inputId + "|,|" + inputVal + "|,|";
            }
        });
        if (hasValue > 0) {
            // inputVals += values + "OTA|,|" + OTA + "|,|" + "FY|,|" + FY + "|,|" + "Submitted|,|" + Submitted + "|,|" + "DateDraftSaved|,|" + DateDraftSavedDate + "|||"; 
            inputVals += values + "OTA|,|" + OTA + "|,|" + "FY|,|" + FY + "|,|" + "Submitted|,|" + Submitted + "|,|" + "TimeDraftSaved|,|" + TimeDraftSaved + "|,|" + "DateDraftSaved|,|" + DateDraftSavedDate + "|||"; 

        }
    });
	var itemIdFromCONOPSDevProgressToUpdate = getParameterByName("itemId");
	var ws1Prog=getParameterByName("ws1Prog");
	var ws2Prog=getParameterByName("ws2Prog");
	var ws3Prog=getParameterByName("ws3Prog");
	var ws4Prog=getParameterByName("ws4Prog");
	var wsRevProg=getParameterByName("wsRevProg");	
	
	// alert(ws1Prog + '|' + ws2Prog + '|' + ws3Prog + '|' + ws4Prog + '|' + wsRevProg); return false;
	var progressColumnToUpdate;
	if(ws1Prog=="1"){progressColumnToUpdate="WS1Progress"}
	if(ws2Prog=="1"){progressColumnToUpdate="WS2Progress"}
	if(ws3Prog=="1"){progressColumnToUpdate="WS3Progress"}
	if(ws4Prog=="1"){progressColumnToUpdate="WS4Progress"}
	if(wsRevProg=="1"){progressColumnToUpdate="WSReview"}
	var newProgressColumnValue="Draft Completed";
	//alert(inputVals); return false;
	inputVals = inputVals.substr(0,inputVals.lastIndexOf("|||"));
	//alert("inputVals \n"+inputVals); return false;
	var worksheetRows = inputVals.split("|||"); // input values into array for updating worksheet list
	
	saveWorksheet(wsListForOTA, worksheetRows, itemIdFromCONOPSDevProgressToUpdate, 0, wsNumFromPageName); 
   	
});
