﻿function highlightDaysWithEvents() {
    $(".ms-picker-today").find("A").css("font-weight", "bold");
    var currDate = new Date();
    var currDateMo = numberAsTwoDigits(currDate.getMonth() + 1);
    var linkIds = "";
    var smallCalLinkDate = "";
    $(".ms-picker-table").find("A").each(function () { // get link ids for current month from the Calendar Dashboard on the home page.
        var smallCalLinkId = $(this).attr("id");
        var smallCalLinkIdMo = smallCalLinkId.substring(4, 6);
        var highlightThis = "";
        if (smallCalLinkIdMo == currDateMo) {
            var smallCalLinkIdYr = smallCalLinkId.substring(0, 4);
            var smallCalLinkIdDay = smallCalLinkId.substr(6);
            smallCalLinkDate = smallCalLinkIdMo + "/" + smallCalLinkIdDay + "/" + smallCalLinkIdYr;
            // alert(smallCalLinkDate);
            highlightThis += CalendarDashboard(smallCalLinkDate, true);
            if (highlightThis == "Yes") {
                $(this).parent().attr("onmouseover", "this.className='ms-picker-dayselected';").attr("onmouseout", "this.className='ms-picker-dayselected';").addClass("ms-picker-dayselected");
            }
        }
    });
}
function CalendarDashboard(eventDate, highlight) {
    highlight = typeof highlight !== 'undefined' ? highlight : false;
    // If only one event on day clicked, then go to event DispForm, 
    // otherwise go to day in calendar. http://dotersrcndapp5:15429/Lists/Calendar/calendar.aspx?CalendarDate=2014-08-11&CalendarPeriod=day for Aug 11, 2014
    var eventDateForLargePopUp = "";
    var eventDateArray = eventDate.split("/"); // 8/7/2014   
    var eventDateMo = numberAsTwoDigits(eventDateArray[0]);
    var eventDateDay = numberAsTwoDigits(eventDateArray[1]);
    var eventDateYr = eventDateArray[2];
    eventDateForLargePopUp = eventDateYr + "-" + eventDateMo + "-" + eventDateDay;
    var eventID = "";
    var eventDateAsDate = new Date(eventDate);
    eventDateAsDate.setHours(0, 0, 0, 0);
    var eventsOnThisDayCount = 0;
    var yesNo = "No";
    $(".CalendarDashboardsData").each(function () {
        var startdate = $(this).attr("startdate");
        startdate = startdate.substr(0, startdate.indexOf(" "));
        var startdateStrAsDate = new Date(startdate);
        startdateStrAsDate.setHours(0, 0, 0, 0);
        var enddate = $(this).attr("enddate"); // alert('enddate |'+ enddate + '|');
        enddate = enddate.substr(0, enddate.indexOf(" "));
        var enddateStrAsDate = new Date(enddate);
        enddateStrAsDate.setHours(0, 0, 0, 0);
        if (eventDateAsDate.valueOf() === startdateStrAsDate.valueOf()) // events with same start date
        {
            yesNo = "Yes";
            //alert('events with same start date: true ' + '\neventDateAsDate.toDateString(): ' + eventDateAsDate.toDateString()+ '\nstartdateStrAsDate.toDateString(): ' + startdateStrAsDate.toDateString());
            eventsOnThisDayCount = eventsOnThisDayCount + 1; eventID = $(this).text();
        }
        else if (eventDateAsDate.valueOf() === enddateStrAsDate.valueOf()) // events with same end date 
        {
            yesNo = "Yes";
            //alert('events with same end date: true');
            eventsOnThisDayCount = eventsOnThisDayCount + 1; eventID = $(this).text();
        }
        else if (eventDateAsDate > startdateStrAsDate && eventDateAsDate < enddateStrAsDate) // events spanning mult days		
        {
            yesNo = "Yes";
            //alert('events spanning multi days: true');
            eventsOnThisDayCount = eventsOnThisDayCount + 1; eventID = $(this).text();
        }
    });
    // alert(eventsOnThisDayCount);
    if (eventsOnThisDayCount > 0 && highlight == false) {
        // alert('greater than zero');
        if (eventsOnThisDayCount > 1) {
            // Events on Calendar Dashboard day view open in their own dialog, so open calendar day view in large window.
            OpenPopUpPage('../Lists/MasterCalendar/calendar.aspx?CalendarDate=' + eventDateForLargePopUp + '&CalendarPeriod=day', null, 800, 800);
        }
        else {
            // alert('eventsOnThisDayCount: ' + eventsOnThisDayCount + '\neventID: ' + eventID);
            OpenPopUpPage('../Lists/MasterCalendar/DispForm.aspx?ID=' + eventID);
        }
    }
    if (highlight == false) {
        // function is being called as part of onclick event
        return void (0);
    }
    else {
        // alert(yesNo);
        return yesNo;
    }
}