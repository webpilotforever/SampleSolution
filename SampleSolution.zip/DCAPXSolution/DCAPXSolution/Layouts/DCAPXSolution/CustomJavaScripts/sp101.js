﻿//alert("JavaScript linked successfully, click OK to see your custom branding ");
//ExecuteOrDelayUntilScriptLoaded(function () { alert("Delayed Alert") }, 'init.js');