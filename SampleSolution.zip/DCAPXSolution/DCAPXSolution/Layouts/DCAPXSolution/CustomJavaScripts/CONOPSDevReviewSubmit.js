﻿// ----- GET COMMON ROW DATA AND VARS -----
var CurrentFYforAcceptingCONOPS = getCurrentFYforAcceptingCONOPS();
var nextFY = parseInt(CurrentFYforAcceptingCONOPS) + 1;
var futureFY = parseInt(CurrentFYforAcceptingCONOPS) + 2;
//var ota = OTA;
var ota = getParameterByName("ota");
var worksheetList = "CONOPSDevWS" + ota;
var currentFY = parseInt(getParameterByName("currentFY")); // not current fy for accepting conops, but fy relevant to this worksheet
var showTableKey = { "current": CurrentFYforAcceptingCONOPS, "next": nextFY, "future": futureFY };
var summaryFYforQueryString = showTableKey[getParameterByName("showTable")];
var summaryFY = showTableKey[getParameterByName("showTable")]; // init fy to queryWSListsForSummary
//-------

$(".WSOTADiv").show(); $(".WSTitle").show();
// ----- HIDE VENUESUBTOTAL ROW ----- (amount is same as Total)
$(".ReviewWS2VenueSubTotal").closest('tr').hide();
// ----- RETITLE DIALOG -----
if (parent.document.getElementById("dialogTitleSpan") !== null) {
    parent.document.getElementById("dialogTitleSpan").innerHTML = "CONOPS Development Module";
}
// ----- SHOW SUBMIT WHEN READY -----
var WSReviewCurrentFYCell, WSReviewNextFYCell, WSReviewFutureFYCell, showSubmit;
WSReviewCurrentFYCell = $(".WSReviewCurrentFYCell");
WSReviewNextFYCell = $(".WSReviewNextFYCell");
WSReviewFutureFYCell = $(".WSReviewFutureFYCell");
var windowlocationhref = window.location.href.toString(); // alert("windowlocationhref "+windowlocationhref );
if (getParameterByName("showTable") !== "") { // if showTable, strip it and summaryFY out in windowlocationhref variable so we can update it when user clicks button
    windowlocationhref = windowlocationhref.substr(0, windowlocationhref.indexOf("&summaryFY"));
    if (getParameterByName("showTable") == "submit") {
        
        $(".WSBtnSubmitCONOPS").show(2000);
       
        $(".CONOPSDevButtonDiv").show("slow", function () { });
        

    }
}
var worksheetsDoneStateCurrentFY = "Not Started";
var worksheetsDoneStateNextFY = "Not Started";
var worksheetsDoneStateFutureFY = "Not Started";




if (getParameterByName("showTable") == "submit") {
    worksheetsDoneStateCurrentFY = "Review Completed";
    worksheetsDoneStateNextFY = "Review Completed";
    worksheetsDoneStateFutureFY = "Review Completed";
}
else if (getParameterByName("wsRevProg") == "1") { // if wsRevProg is In Progress
    if (currentFY == futureFY) { // if this is the last set
        worksheetsDoneStateCurrentFY = "Review Completed"; worksheetsDoneStateNextFY = "Review Completed"; worksheetsDoneStateFutureFY = "In Progress";
        // isTheLastSet = true;
    } else if (currentFY == nextFY) {
        worksheetsDoneStateCurrentFY = "Review Completed"; worksheetsDoneStateNextFY = "In Progress";
    } else if (currentFY == parseInt(CurrentFYforAcceptingCONOPS)) {
        worksheetsDoneStateCurrentFY = "In Progress";

    }
}

if (worksheetsDoneStateCurrentFY == "Not Started") { applyReviewColor(worksheetsDoneStateCurrentFY, ".WSReviewCurrentFYColor", "WSReviewNotStarted", ".WSReviewCurrentFYCell", "WSReviewNotStartedCell"); } // not possible
if (worksheetsDoneStateCurrentFY == "In Progress") { applyReviewColor(worksheetsDoneStateCurrentFY, ".WSReviewCurrentFYColor", "WSReviewInProgress", ".WSReviewCurrentFYCell", "WSReviewInProgressCell"); }
if (worksheetsDoneStateCurrentFY == "Review Completed") { applyReviewColor(worksheetsDoneStateCurrentFY, ".WSReviewCurrentFYColor", "WSReviewReviewed", ".WSReviewCurrentFYCell", "WSReviewReviewedCell"); }

if (worksheetsDoneStateNextFY == "Not Started") { applyReviewColor(worksheetsDoneStateNextFY, ".WSReviewNextFYColor", "WSReviewNotStarted", ".WSReviewNextFYCell", "WSReviewNotStartedCell"); }
if (worksheetsDoneStateNextFY == "In Progress") { applyReviewColor(worksheetsDoneStateNextFY, ".WSReviewNextFYColor", "WSReviewInProgress", ".WSReviewNextFYCell", "WSReviewInProgressCell"); }
if (worksheetsDoneStateNextFY == "Review Completed") { applyReviewColor(worksheetsDoneStateNextFY, ".WSReviewNextFYColor", "WSReviewReviewed", ".WSReviewNextFYCell", "WSReviewReviewedCell"); }

if (worksheetsDoneStateFutureFY == "Not Started") { applyReviewColor(worksheetsDoneStateFutureFY, ".WSReviewFutureFYColor", "WSReviewNotStarted", ".WSReviewFutureFYCell", "WSReviewNotStartedCell"); }
if (worksheetsDoneStateFutureFY == "In Progress") { applyReviewColor(worksheetsDoneStateFutureFY, ".WSReviewFutureFYColor", "WSReviewInProgress", ".WSReviewFutureFYCell", "WSReviewInProgressCell"); }
if (worksheetsDoneStateFutureFY == "Review Completed") { applyReviewColor(worksheetsDoneStateFutureFY, ".WSReviewFutureFYColor", "WSReviewReviewed", ".WSReviewFutureFYCell", "WSReviewReviewedCell"); }

function applyReviewColor(cellText, cellByClass, classToAdd, cellByClass2, classToAdd2) {
    $("" + cellByClass + "").text(cellText).addClass(classToAdd);
    $("" + cellByClass2 + "").addClass(classToAdd2);
}
// ----- THREE BLOCK BUTTONS -----

//.WSReviewCurrentFYBlock, .WSReviewNextFYBlock, .WSReviewFutureFYBlock
if (getParameterByName("showTable") == "current") {
    $(".WSReviewCurrentFYBlock").css("background-color", "white");
    // now remove bg color from other FYBlock buttons that may have been set
    $(".WSReviewNextFYBlock").removeAttr("style");
    $(".WSReviewFutureFYBlock").removeAttr("style");
}
if (getParameterByName("showTable") == "next") {
    $(".WSReviewNextFYBlock").css("background-color", "white");
    // now remove bg color from other FYBlock buttons that may have been set
    $(".WSReviewCurrentFYBlock").removeAttr("style");
    $(".WSReviewFutureFYBlock").removeAttr("style");

}
if (getParameterByName("showTable") == "future") {
    $(".WSReviewFutureFYBlock").css("background-color", "white");
    // now remove bg color from other FYBlock buttons that may have been set
    $(".WSReviewCurrentFYBlock").removeAttr("style");
    $(".WSReviewNextFYBlock").removeAttr("style");

}
if (getParameterByName("showTable") == "submit") {
    $(".WSReviewCurrentFYBlock").removeClass("WSReviewCurrentFYBlock").css("color", "#fff").css("margin-bottom", "10px");

    $(".WSReviewNextFYBlock").removeClass("WSReviewNextFYBlock").css("color", "#fff").css("margin-bottom", "10px");

    $(".WSReviewFutureFYBlock").removeClass("WSReviewFutureFYBlock").css("color", "#fff").css("margin-bottom", "10px");

    //$(".WSBtnSubmitCONOPS").parent().addClass("WSReviewInProgressCell");

    $(".CONOPSDevButton").click(function () {
        $(this).closest('div').append("<div style='font-weight:bold; padding:10px'>Submitting. Please wait...</div>");
    });
}

//---

$(".WSReviewCurrentFYBlock").click(function () {

    if (getParameterByName("showTable") !== "current") {
        //location.replace( windowlocationhref +"&showTable=current&IsDlg=1");
        summaryFYforQueryString = showTableKey["current"];
        location.replace(windowlocationhref + "&summaryFY=" + summaryFYforQueryString + "&showTable=current&IsDlg=1");

    }
});
$(".WSReviewNextFYBlock").click(function () {
    if (getParameterByName("showTable") !== "next" && worksheetsDoneStateNextFY !== "Not Started") {
        //location.replace( windowlocationhref + "&showTable=next&IsDlg=1");
        summaryFYforQueryString = showTableKey["next"];
        location.replace(windowlocationhref + "&summaryFY=" + summaryFYforQueryString + "&showTable=next&IsDlg=1");

    }
});
$(".WSReviewFutureFYBlock").click(function () {
    if (getParameterByName("showTable") !== "future" && worksheetsDoneStateFutureFY !== "Not Started") {
        //location.replace( windowlocationhref +"&showTable=future&IsDlg=1");
        summaryFYforQueryString = showTableKey["future"];
        location.replace(windowlocationhref + "&summaryFY=" + summaryFYforQueryString + "&showTable=future&IsDlg=1");

    }
});

if (worksheetsDoneStateNextFY == "Not Started") {
    $(".WSReviewNextFYBlock").css("color", "DarkGray").css("background-color", "Silver").css("cursor", "arrow").css("border", "none");
}
if (worksheetsDoneStateFutureFY == "Not Started") {
    $(".WSReviewFutureFYBlock").css("color", "DarkGray").css("background-color", "Silver").css("cursor", "arrow").css("border", "none");
}
// -----  PRINT BUTTONS -----
$(".WS1ReviewPrint").click(function () {
    OpenPopUpPage(L_Menu_BaseUrl + '/_layouts/DCAPXSolution/CONOPSDevelopment/WS1.aspx?ota=' + OTAtitleKey[ota] + '&otashort=' + ota + '&fy=' + summaryFY + '&ws=1&submitted=no');

});
$(".WS2ReviewPrint").click(function () {
    OpenPopUpPage(L_Menu_BaseUrl + '/_layouts/DCAPXSolution/CONOPSDevelopment/WS2.aspx?ota=' + OTAtitleKey[ota] + '&otashort=' + ota + '&fy=' + summaryFY + '&ws=2&submitted=no');

});
$(".WS3ReviewPrint").click(function () {
    OpenPopUpPage(L_Menu_BaseUrl + '/_layouts/DCAPXSolution/CONOPSDevelopment/WS3.aspx?ota=' + OTAtitleKey[ota] + '&otashort=' + ota + '&fy=' + summaryFY + '&ws=3&submitted=no');

});
$(".WS4ReviewPrint").click(function () {
    OpenPopUpPage(L_Menu_BaseUrl + '/_layouts/DCAPXSolution/CONOPSDevelopment/WS4.aspx?ota=' + OTAtitleKey[ota] + '&otashort=' + ota + '&fy=' + summaryFY + '&ws=4&submitted=no');

});
// ----- EDIT BUTTONS -----
$(".WSReviewEdit").click(function () {
    var reviewWSTitle = $(this).closest('tr').children().eq(2).text();
    SP.UI.ModalDialog.commonModalDialogClose("OK", reviewWSTitle); // close review dialog
});
// ----- REVIEW OK BUTTON -----
$(".WSBtnReviewFYOK").click(function () {
    var revOkBtnTx = $(this).text(); //alert("itemId: "+getParameterByName("itemId"));
    var revOkBtnTxFY = revOkBtnTx.substr(revOkBtnTx.indexOf("FY ") + 3, 2); //alert("revOkBtnTxFY: "+revOkBtnTxFY +"\ncurrentFY: "+getParameterByName("currentFY"));
    if (revOkBtnTxFY !== getParameterByName("currentFY")) {
        $(".WSReviewInProgressCell").find("div:eq(1)").click(); // reload
    }
    else {
        //var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Saving", "Please wait..."); // opens second dialog WITHOUT CANCEL BUTTON BECAUSE it is too fast and may interfere with save, and it is difficult to reverse multiple colums and potentially 2 rows in CONOPSDevProgress list.		
        //queryCONOPSDevProgress(getParameterByName("itemId")); // let query determine if this is the last row
        $(".CONOPSDevButton").click();
    }
});

// ----- SUBMIT BUTTON -----
//WSBtnSubmitCONOPS replaced with CONOPSDevButton
//<INPUT id=ctl00_m_g_e3542c17_a5d4_4bb7_9bee_14e6f77a29c3_CONOPSDevButton class=CONOPSDevButton title="Submit CONOPS to DOT&amp;E" value="Submit CONOPS to DOT&amp;E" type=submit name=ctl00$m$g_e3542c17_a5d4_4bb7_9bee_14e6f77a29c3$CONOPSDevButton>
//$(".WSBtnSubmitCONOPS").click(function () {
//    var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Saving", "Please wait...");
//    updateCONOPSDevProgressToSubmittedAll();
//});






//$(".WSReviewFYTable").show(2000, function () { $(".WSBtnReviewFYOK").show("fast") });


if (getParameterByName("showTable") !== "submit") {
    $(".WSReviewFYTable").show(2000, function () { $(".WSBtnReviewFYOK").show("fast") });

}
