﻿var siteRelURLtopage = window.location.pathname;
var worksheetPageName = siteRelURLtopage.substr(siteRelURLtopage.lastIndexOf("/") + 1);
$(document).ready(function () {

    var urlToPage = location.href;
    var urlSearch = location.search;
    urlToPage = urlToPage.replace(urlSearch, "");
    var urlToSite = location.href.substr(0, location.href.lastIndexOf("/") + 1);
    $(".CONOPSDevWSColHeaders").css("cursor","none");
    //$(".CONOPSDevWSColHeaders").mouseover(function () {

    //    $(".CONOPSDevWSColHeaderDesc").show();

    //});
    //$(".CONOPSDevWSColHeaders").mouseout(function () {

    //    $(".CONOPSDevWSColHeaderDesc").hide();

    //});

    if (getParameterByName('print') == "yes") {
        window.print();
    }
    getmsdlgTitleBtns(urlToSite);

    if (worksheetPageName.indexOf('ViewCONOPSWP.aspx') > -1) {
        $(".CONOPSDevWSOTADiv:gt(0)").html("&nbsp;");
    }

        var rowToJet = new Array();
        $("tr[title*='NewItem']").each(function () {

            var newItemContract = $(this).attr("title");
            newItemContract = newItemContract.replace("NewItem_", "");
            var newItemContractID = $(this).attr("id");

            $(this).clone(true).insertBefore($("tr[id*='contractorsBlankRow']").filter("[title='" + newItemContract + "']"));



            rowToJet.push(newItemContractID);
        });


        var rowToJet1 = new Array();
        $("tr[title*='NewLineItem']").each(function () {

            var newLineItemContract = $(this).attr("title");
            newLineItemContract = newLineItemContract.replace("NewLineItem_", "");
            var newLineItemContractID = $(this).attr("id");
            //alert("newLineItemContract: " + newLineItemContract);
            var rowForAdditionalLineItem;



            $("input[id*='HoursPerYear']").each(function () {
                if ($(this).attr("title") == newLineItemContract) {
                    rowForAdditionalLineItem = $(this).closest("tr");
                }

            });
            $("span[id*='HoursPerYear']").each(function () {
                if ($(this).attr("title") == newLineItemContract) {
                    rowForAdditionalLineItem = $(this).closest("tr");
                }

            });


            $(this).clone(true).insertBefore(rowForAdditionalLineItem);

            rowToJet1.push(newLineItemContractID);
        });

        //-------

        for (i = 0; i < rowToJet.length; i++) {
            $("tr[id='" + rowToJet[i] + "']").last().remove();
        }
        for (i = 0; i < rowToJet1.length; i++) {
            $("tr[id='" + rowToJet1[i] + "']").last().remove();
        }


});
function getParameterByName(name) { name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"); var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search); return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
function getmsdlgTitleBtns(urlToSite) {

    //var wsPrintUrl = "WS1.aspx?ota=Army Test and Evaluation Command&otashort=ATEC&fy=16&ws=4&submitted=no&IsDlg=1&print=yes";

    var formElem = document.getElementById("aspnetForm");
    var wsPrintUrl = formElem.getAttribute("action");
    wsPrintUrl = urlToSite + wsPrintUrl + "&print=yes";

    var printBtn = parent.document.createElement("A");
    printBtn.setAttribute("class", "ms-dlgCloseBtn");
    printBtn.setAttribute("title", "Print");
    printBtn.setAttribute("target", "_blank");
    printBtn.setAttribute("href", wsPrintUrl);
    printBtn.innerHTML = "<SPAN style=\"POSITION: relative; WIDTH: 18px; DISPLAY: inline-block; HEIGHT: 18px; OVERFLOW: hidden\" class=\"s4-clust\"><IMG class=\"ms-dlgCloseBtnImg\" src=\"/_layouts/Images/DCAPXSolution/print.png\"></SPAN>";


    var spans = parent.document.getElementsByTagName("SPAN");

    for (i = 0; i < spans.length; i++) {

        if (spans[i].getAttribute("class") == "ms-dlgTitleBtns") {

            if (spans[i].hasChildNodes()) {

                var spansChildren = spans[i].childNodes;

                for (ii = 0; ii < spansChildren.length; ii++) {
                    if (spansChildren[ii].nodeName == "A") {

                        spansChildren[ii].setAttribute("style", "display: none;");

                        spans[i].insertBefore(printBtn, spansChildren[ii]);

                        break;
                    }
                }

            }

        }
    }




}
