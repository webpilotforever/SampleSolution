﻿function ModuleAccessIsValid() {


    var result = false;
   
    //var checkboxtable = document.getElementsByClassName("CheckBoxListModuleAccess"); // returns a node set so have to use for loop
    //var contextId = checkboxtable.id;

    //result = document.getElementById(contextId + "_0").checked;



    result = document.getElementById("ctl00_PlaceHolderMain_CheckBoxListModuleAccess_0").checked;

    if (!result) {
        result = document.getElementById("ctl00_PlaceHolderMain_CheckBoxListModuleAccess_1").checked;
        //result = document.getElementById(contextId + "_1").checked;
    }
    if (!result) { $(".LabelModuleAccessError").show(); }
    return result;
}

function callpleaseWaitDeleting() {
    ExecuteOrDelayUntilScriptLoaded(pleaseWaitDeleting, "sp.ui.dialog.js");

}

function pleaseWaitDeleting() {
    var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Please wait...", "Deleting user from Program Contacts. Removing user from CONOPS Development groups.");
}

//function closeDlg() {
//    ExecuteOrDelayUntilScriptLoaded(closeDlg2, "sp.js");

//}

//function closeDlg2() {

//    SP.UI.ModalDialog.commonModalDialogClose(null, 1);
//    window.location.replace(window.location.href);

//}
//function deleting() {

//    $(document).ready(function () {
//        $("input[title='Delete']").closest("tr").html("<td colspan='4' valign='top' style='text-align:center; color:red;'>Please wait. Deleting user from Program Contacts. Removing user from CONOPS Development groups...</td>");       
//    });

    
//}
//$(document).ready(function () {
//    $("input[title='Delete']").click(function () {
//        //if ($("input[id*='SiteCollectionCreated']").val() !== "true") {
//        ExecuteOrDelayUntilScriptLoaded(callpleaseWaitCreatingSiteCollection, "sp.js");
//        //}
//    });
//});
