﻿//$("td[title*='CONOPSDevAttachmentsWebPart']").closest("table.s4-wpTopTable").closest("tr").hide();
var summaryFYforQueryString = getParameterByName("summaryFY");
//var reviewPageThird = getParameterByName("showTable");
//reviewPageThird = reviewPageThird.replace(/^[a-z]/,function(m){return m.toUpperCase()});
var documentLibrary = "CONOPSDev"+getParameterByName("ota"); 
var addDocumentHref;



var docId = "";
var docLib = "";

var CONOPSDevAttachmentsInHiddenLabel = "" + $("span[id*='CONOPSDevAttachments']").text();
// testOfUploadAttachedDocs2D.txt,17,/CONOPSDevATEC/testOfUploadAttachedDocs2D.txt
// WS1,2,/sites/DCAPXObjects/CONOPSDevATEC/testOfUploadAttachedDocs.txt,testOfUploadAttachedDocs.txt



var attachmentsArray = CONOPSDevAttachmentsInHiddenLabel.split("|||");

attachmentsArray.reverse();


var attListId = $("span[id*='CONOPSDevLibID']").text();
if (getParameterByName("showTable") !== "submit") {
    //addDocumentHref = locationUpToSite + "/_layouts/Upload.aspx?List={" + attListId + "}&ota=" + getParameterByName("ota") + "&summaryFY=" + summaryFYforQueryString + "&summaryWS=summaryWSVal&showTable=showTableVal&RootFolder=";
    //addDocumentHref = locationUpToSite + "/SitePages/CONOPSDevUpload.aspx" + location.search;
    addDocumentHref = locationUpToSite + "/SitePages/CONOPSDevUpload.aspx?ota=" + getParameterByName("ota") + "&summaryFY=" + summaryFYforQueryString + "&summaryWS=summaryWSVal&showTable=showTableVal";
    //alert("addDocumentHref: " + addDocumentHref);
}
else {
    addDocumentHref = locationUpToSite + "/SitePages/CONOPSDevUpload.aspx?ota=" + getParameterByName("ota") + "&summaryFY=" + summaryFYforQueryString + "&summaryWS=summaryWSVal&showTable=showTableVal";

}

// get attachment sections
var attachmentSectionWS1 = $("div.ReviewWS1AttachmentsAdd").parent();
var attachmentSectionWS2 = $("div.ReviewWS2AttachmentsAdd").parent();
var attachmentSectionWS3 = $("div.ReviewWS3AttachmentsAdd").parent();
var attachmentSectionWS4 = $("div.ReviewWS4AttachmentsAdd").parent();

var submitAttachmentsAdd = $("div.SubmitAttachmentsAdd").parent();
if (CONOPSDevAttachmentsInHiddenLabel !== "") {


    for (i = 0; len = attachmentsArray.length, i < len; i++) {
        // to test ... 
        // http://dotersrcndapp5:2619/sites/DCAPXObjects/SitePages/CONOPSDevReviewSubmitWorksheets.aspx?summaryFY=18&showTable=current&ota=ATEC&IsDlg=1
        var attachmentArray = attachmentsArray[i].split(",");

        var attWS = "" + attachmentArray[0]; // WS1
        var attId = attachmentArray[1]; // 17
        var attPath = attachmentArray[2]; // /CONOPSDevATEC/testOfUploadAttachedDocs2D.txt
        var attName = attachmentArray[3]; // testOfUploadAttachedDocs2D.txt

        //alert("attWS: " + attWS + " attId: " + attId + " attPath: " + attPath + " attName: " + attName);


        var attLink = "<A onclick=\"return DispEx(this,event,'TRUE','FALSE','FALSE','SharePoint.OpenDocuments.3','1','SharePoint.OpenDocuments','','','','" + _spUserId + "','0','0','0x7fffffffffffffff','','')\" id=\"" + attId + "\" href=\"" + attPath + "\" >" + attName + "</a>";


        //var attLink = "<a id=\"" + attId + "\" href=\"" + attPath + "\">" + attName + "</a>";

        if (attWS == "WS1") { $(attachmentSectionWS1).prepend(attLink); }
        else if (attWS == "WS2") { $(attachmentSectionWS2).prepend(attLink); }
        else if (attWS == "WS3") { $(attachmentSectionWS3).prepend(attLink); }
        else if (attWS == "WS4") { $(attachmentSectionWS4).prepend(attLink); }
        else if (attWS == "") { $(submitAttachmentsAdd).prepend(attLink); }
    }

    // wrap attachment links in div with deletion 'button'
    $(attachmentSectionWS1).find("a").wrap("<div class=\"ReviewWS1Attachments\"></div>").end().find("div.ReviewWS1Attachments").prepend("<div class=\"WSBtnRemoveAttachment\" title=\"Delete\"><img src=\"/_layouts/Images/DCAPXSolution/deleteattachment.png\"/></div>");
    $(attachmentSectionWS2).find("a").wrap("<div class=\"ReviewWS2Attachments\"></div>").end().find("div.ReviewWS2Attachments").prepend("<div class=\"WSBtnRemoveAttachment\" title=\"Delete\"><img src=\"/_layouts/Images/DCAPXSolution/deleteattachment.png\"/></div>");
    $(attachmentSectionWS3).find("a").wrap("<div class=\"ReviewWS3Attachments\"></div>").end().find("div.ReviewWS3Attachments").prepend("<div class=\"WSBtnRemoveAttachment\" title=\"Delete\"><img src=\"/_layouts/Images/DCAPXSolution/deleteattachment.png\"/></div>");
    $(attachmentSectionWS4).find("a").wrap("<div class=\"ReviewWS4Attachments\"></div>").end().find("div.ReviewWS4Attachments").prepend("<div class=\"WSBtnRemoveAttachment\" title=\"Delete\"><img src=\"/_layouts/Images/DCAPXSolution/deleteattachment.png\"/></div>");
    $(submitAttachmentsAdd).find("a").wrap("<div class=\"SubmitAttachments\"></div>").end().find("div.SubmitAttachments").prepend("<div class=\"WSBtnRemoveAttachment\" title=\"Delete\"><img src=\"/_layouts/Images/DCAPXSolution/deleteattachment.png\"/></div>");

}
// ----- ATTACHMENTS BUTTONS ----- 

$(".ReviewWS1AttachmentsAdd").click(function (event) {

    var cl = $(this).attr("class");
    var summaryWS = cl.substr(cl.indexOf("WS"), 3); // WS1
    var addDocumentHrefThis = addDocumentHref.replace("summaryWSVal", "" + summaryWS);
    addDocumentHrefThis = addDocumentHrefThis.replace("showTableVal", getParameterByName("showTable"));
    OpenPopUpPageWithTitle(addDocumentHrefThis, function () { location.replace(location.href) }, 400, 400, "Add Attachment");

    return false;
});
$(".ReviewWS2AttachmentsAdd").click(function (event) {
    var cl = $(this).attr("class");
    var summaryWS = cl.substr(cl.indexOf("WS"), 3); // WS2
    var addDocumentHrefThis = addDocumentHref.replace("summaryWSVal", "" + summaryWS);
    addDocumentHrefThis = addDocumentHrefThis.replace("showTableVal", getParameterByName("showTable"));
    OpenPopUpPageWithTitle(addDocumentHrefThis, function () { location.replace(location.href) }, 400, 400, "Add Attachment");

    return false;
});
$(".ReviewWS3AttachmentsAdd").click(function (event) {
    var cl = $(this).attr("class");
    var summaryWS = cl.substr(cl.indexOf("WS"), 3); // WS3
    var addDocumentHrefThis = addDocumentHref.replace("summaryWSVal", "" + summaryWS);
    addDocumentHrefThis = addDocumentHrefThis.replace("showTableVal", getParameterByName("showTable"));
    OpenPopUpPageWithTitle(addDocumentHrefThis, function () { location.replace(location.href) }, 400, 400, "Add Attachment");

    return false;
});
$(".ReviewWS4AttachmentsAdd").click(function (event) {
    var cl = $(this).attr("class");
    var summaryWS = cl.substr(cl.indexOf("WS"), 3); // WS4
    var addDocumentHrefThis = addDocumentHref.replace("summaryWSVal", "" + summaryWS);
    addDocumentHrefThis = addDocumentHrefThis.replace("showTableVal", getParameterByName("showTable"));
    OpenPopUpPageWithTitle(addDocumentHrefThis, function () { location.replace(location.href) }, 400, 400, "Add Attachment");

    return false;
});
$(".SubmitAttachmentsAdd").click(function (event) {

    var addDocumentHrefThis = addDocumentHref.replace("summaryWSVal", "None");
    addDocumentHrefThis = addDocumentHrefThis.replace("showTableVal", getParameterByName("showTable"));
    OpenPopUpPageWithTitle(addDocumentHrefThis, function () { location.replace(location.href) }, 400, 400, "Add Attachment");

    return false;
});


$(".WSBtnRemoveAttachment").click(function () {

    var lnk = $(this).parent().find("a");

    var fileName = lnk.text();
    //alert("fileName: " + fileName);
    var fileExt = fileName.substr(fileName.lastIndexOf(".") + 1);
    //alert("fileExt: " + fileExt);
    fileName = fileName.replace("." + fileExt, "");
    //alert("fileName: " + fileName);

    docId = $(lnk).attr("id");
    var removeDocHref = locationUpToSite + "/SitePages/CONOPSDevUpload.aspx?ota=" + getParameterByName("ota") + "&docId=" + docId + "&docOps=delete&docName=" + encodeURIComponent(fileName) + "&docExt=" + fileExt;
    //alert("removeDocHref: " + removeDocHref);
    OpenPopUpPageWithTitle(removeDocHref, function () { location.replace(location.href) }, 400, 400, "Remove Attachment");

});

function removeAttachmentSucceeded(){
	location.replace(location);
}
// ----- EDIT BUTTONS -----
//$(".WSReviewEdit").click(function(){
//	var reviewWSTitle = $(this).closest('tr').children().eq(1).text();	
//	SP.UI.ModalDialog.commonModalDialogClose("OK", reviewWSTitle ); // close review dialog
//});
//// ----- REVIEW OK BUTTON -----
//$(".WSBtnReviewFYOK").click(function(){
//	var revOkBtnTx = $(this).text(); //alert("itemId: "+getParameterByName("itemId"));
//	var revOkBtnTxFY = revOkBtnTx.substr(revOkBtnTx.indexOf("FY ")+3,2); //alert("revOkBtnTxFY: "+revOkBtnTxFY +"\ncurrentFY: "+getParameterByName("currentFY"));
//	if(revOkBtnTxFY !== getParameterByName("currentFY")){
//		$(".WSReviewInProgressCell").find("div:eq(1)").click(); // reload
//	} 
//	else {  
//		var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Saving", "Please wait..."); // opens second dialog WITHOUT CANCEL BUTTON BECAUSE it is too fast and may interfere with save, and it is difficult to reverse multiple colums and potentially 2 rows in CONOPSDevProgress list.		
//		queryCONOPSDevProgress(getParameterByName("itemId")); // let query determine if this is the last row
//	}
//});				

// ----- SUBMIT BUTTON -----
//$(".WSBtnSubmitCONOPS").click(function(){
//	var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Saving", "Please wait..."); 
//	updateCONOPSDevProgressToSubmittedAll();
//});	
function summarize(i){
	var WSTitleVal = $(".WSTitle").eq(i).text();	
	var wsNumm = WSTitleVal.substr(WSTitleVal.indexOf("#")+1, 1);
	summarywsList = "CONOPSDevWS" + getParameterByName("ota"); // CONOPSDevWSAFOTEC
	queryWSListsForSummary(summarywsList, summaryFY, i, wsNumm);
}
function queryWSListsForSummary(summarywsList, summaryFY, i, wsNumm){ 
    var clientContext = new SP.ClientContext.get_current();
    var oList = clientContext.get_web().get_lists().getByTitle(summarywsList);
	this.summarywsList = summarywsList;
	this.worksheetNum = wsNumm;
	this.fytofilteron = summaryFY;
	this.i = i;
	var ct = "WS"+wsNumm;
    var camlQuery = new SP.CamlQuery(); 
    camlQuery.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + fytofilteron + "</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">" + ct + "</Value></Eq></And><Eq><FieldRef Name=\"CONOPSApproval\"/><Value Type=\"Text\">Baseline OTA Submission</Value></Eq></And></Where></Query></View>");
	this.collListItem = oList.getItems(camlQuery);	
    clientContext.load(collListItem);    
    clientContext.executeQueryAsync(Function.createDelegate(this, this.queryWSListsForSummarySucceeded), Function.createDelegate(this, this.onQueryFailed));
}
function queryWSListsForSummarySucceeded(){
	var DateDraftSaved = "";
	var listItemInfo = "";
	// WS1 vars
	var MilitaryOrGovernmentCivilianCountWS1 = 0;
	var MilitarySubTotalWS1 = "";
	var ContractorCountWS1 = 0;
	var ContractsWS1 = new Array();
	var ContractsSubTotalWS1 = "";	
	var TotalWS1 = "";	
	// WS2 vars
	var VenuesWS2 = new Array();
	var VenueSubTotalWS2 = 0;
	var TotalWS2 = "";
	// WS3 vars 
	var TotalWS3 = "";
	// WS4 vars
	var TotalWS4 = "";
	var listItemEnumerator = collListItem.getEnumerator();
	while(listItemEnumerator.moveNext()){	
		var oListItem = listItemEnumerator.get_current();		
		var oListItemId = oListItem.get_item("ID");	
		if(DateDraftSaved !== oListItem.get_item("DateDraftSaved") && DateDraftSaved !== ""){
			fromId = oListItem.get_id()+1;
			break;
		} else {
			DateDraftSaved = oListItem.get_item("DateDraftSaved");			
		}
		//listItemInfo += oListItemId + '\n';
		if(worksheetNum == "1"){
			if(oListItem.get_item("Employer") == "MilitaryOrGovernmentCivilian"){
				MilitaryOrGovernmentCivilianCountWS1++;
			} 
			if(oListItem.get_item("Title") == "MilitarySubTotal"){
				MilitarySubTotalWS1 = oListItem.get_item("MilitarySubTotal").toString();
			} 
			
			if(oListItem.get_item("Employer") == "Contractor"){
				ContractorCountWS1++;
			} 
			if(oListItem.get_item("Title") == "Contract"){
				ContractsWS1.push(" "+oListItem.get_item("Contract"));
			} 
			if(oListItem.get_item("Title") == "ContractsSubTotal"){				
				if(ContractsSubTotalWS1 ==""){
					ContractsSubTotalWS1 = oListItem.get_item("ContractsSubTotal").toString();
				}
			} 
			if(oListItem.get_item("Title") == "Total"){
				TotalWS1 = oListItem.get_item("Total").toString();
			}				
		}
		else if(worksheetNum == "2"){
			if(oListItem.get_item("Title") == "VenueSubTotal"){
				VenuesWS2.push(" "+oListItem.get_item("Venue"));
				//VenueSubTotalWS2 = VenueSubTotalWS2+parseInt(oListItem.get_item("VenueSubTotal"));
			} 
			if(oListItem.get_item("Title") == "Total"){
				TotalWS2 = oListItem.get_item("Total").toString();
			}			
		}
		else if(worksheetNum == "3"){			
			if(oListItem.get_item("Title") == "Total"){
				TotalWS3 = oListItem.get_item("Total").toString();
			}						
		}
		else if(worksheetNum == "4"){			
			if(oListItem.get_item("Title") == "Total"){
				TotalWS4 = oListItem.get_item("Total").toString();
			}						
		}
	}
	//alert('listItemInfo: '+listItemInfo );
	if(worksheetNum == "1"){
		$(".ReviewWS1NumOfMilPersonnel").text(MilitaryOrGovernmentCivilianCountWS1);
		$(".ReviewWS1MilSubTotal").text(MilitarySubTotalWS1);
		$(".ReviewWS1NumOfContractors").text(ContractorCountWS1);
		$(".ReviewWS1Contract").text(ContractsWS1);
		$(".ReviewWS1ContractsSubTotal").text(ContractsSubTotalWS1);
		$(".ReviewWS1Total").text(TotalWS1);
	}
	else if(worksheetNum == "2"){
		$(".WS2Venue").text(VenuesWS2);
		$(".ReviewWS2Total").text(TotalWS2);
	}
	else if(worksheetNum == "3"){
		$(".ReviewWS3Total").text(TotalWS3);
	}
	else if(worksheetNum == "4"){
		$(".ReviewWS4Total").text(TotalWS4);
	}
	if(i<3){
		i++;
		summarize(i);
	} 
	else  {
		SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
		$(".WSReviewFYTable").show(2000, function(){ $(".WSBtnReviewFYOK").show("fast") });
	}
}
