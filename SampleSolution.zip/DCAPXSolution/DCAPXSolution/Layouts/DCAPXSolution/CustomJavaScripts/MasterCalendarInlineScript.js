﻿<script>
// Color events by OTA. Referenced in xmlviewer webpart on /Lists/Calendar/calendar.aspx
// needs the script tags. Remove script tags when editing page or adding web parts or get type mismatch error.
// this script referenced on the page because the events are rendered asynchronously by sharepoint

// This solution dependent on workflow appending title with [ota].

// ----- Load calendar -----

_spBodyOnLoadFunctionNames.push('colorCalendarEventLinkIntercept');
var array = [];		

Array.prototype.unique = function(){

	var arr = this;
	return $.grep(arr, function(v, i){
	
		return $.inArray(v, arr) === i;
		
	});

}
		
function colorCalendarEventLinkIntercept(){
	
	if(window.location.href.indexOf("/Lists/MasterCalendar/calendar.aspx")>-1){	

		if(SP.UI.ApplicationPages.CalendarNotify.$4a){	
			var OldCalendarNotify = SP.UI.ApplicationPages.CalendarNotify.$4a;
			SP.UI.ApplicationPages.CalendarNotify.$4a = function(){		
				OldCalendarNotify();
				colorCalendarEventLinks();		
			}	
		}
		if(SP.UI.ApplicationPages.CalendarNotify.$4b){	
			var OldCalendarNotify = SP.UI.ApplicationPages.CalendarNotify.$4b;
			SP.UI.ApplicationPages.CalendarNotify.$4b = function(){		
				OldCalendarNotify();
				colorCalendarEventLinks();		
			}	
		}
	}
}

// ---------------------------------------------------------------------------------		

	
function colorCalendarEventLinks(){

	var otaColorDict = {  ATEC:"LightGreen", AFOTEC:"LightSkyBlue", COTF:"LightCyan", JITC:"Plum", MCOTEA:"LightCoral" };
		
	$(".ms-acal-item").find("a").each(function(){
						
		var linkT = $(this).text(); //alert(linkT);
		
		linkT = linkT.substr(linkT.indexOf("[")+1); 
		linkT = linkT.substr(0, linkT.indexOf("]")); 
		
		var otaAcronym = "";
		otaAcronym += linkT;	// alert(otaAcronym);
		if(otaAcronym.length > 0){
		
			$(this).closest(".ms-acal-item").css("background-color", otaColorDict[otaAcronym]);
		
		}		
				
	});	

	
}
</script>