﻿
var AssessmentDashboardWebPart = $("span:contains(Assessment Dashboard)").closest(".s4-wpTopTable");
AssessmentDashboardWebPart.addClass("AssmntDashWPContainer");

var groupText = AssessmentDashboardWebPart.find("td.ms-gb").text();
var IsGrouped = "No";
if(groupText.length){ // if this is a grouped view for admins/aos
 IsGrouped = "Yes";
}

var AssessmentDbWPColorkey = {NoShellCreated:"#c0c0c0", Submitted:"#009933", DueSoon:"#ffff66", PastDue:"#cc3300", Canceled:"#333333"};
$("span:contains(Assessment Dashboard)").closest(".ms-WPTitle").addClass("AssmntDashWPTitle").closest(".ms-WPHeader").css("background-color","transparent");
AssessmentDashboardWebPart.find(".ms-alternating").removeClass(); 

// No assessments message
var noAssessmentsMsg = "";
noAssessmentsMsg += $(".AssmntDashWPNoItemsLbl").text();
var systemnoAssessmentMsg = "";
systemnoAssessmentMsg = $(".ms-vb:contains(There are no items to show in this view of the \"AssessmentProgress\" list.)");
if(systemnoAssessmentMsg.length){
	systemnoAssessmentMsg.addClass("AssmntDashWPNoItems").text(noAssessmentsMsg);
	AssessmentDashboardWebPart.find(".ms-viewheadertr").css("display","none"); 
}

// legend button click event handler
$("#ButtonLegend").click(function(){ $("#legendcolors").toggle("slow", function(){}); });

$("#legendColorsTable").attr("cellspacing","1");

AssessmentDashboardWebPart.find(".ms-vb2").css("border","#f7f7f7 1px solid");

AssessmentDashboardWebPart.find(".ms-vh2:first").text("");

var minusInt = 0;

if(IsGrouped == "No"){ // formatting for OTA view which should be on home page in right column

	minusInt = 0;
	AssessmentDashboardWebPart.find(".ms-vb2").each(function(){
				
		var t = $(this).text();
		
		if($(this).index() > 9){ // SourceID
		
			var assessmentLinkThisRow = $(this).closest("tr").children(":first");
			var assessmentLinkThisRowTxt = assessmentLinkThisRow.text();
			assessmentLinkThisRow.css("font-size","9px").attr("title",assessmentLinkThisRowTxt);
			if(assessmentLinkThisRowTxt.length > 10){
				assessmentLinkThisRowTxt = assessmentLinkThisRowTxt.substr(0,7)+". . .";
			} 
			
			assessmentLinkThisRow.html("<a href=\"javascript:OpenPopUpPage('/Lists/Assessment/DispForm.aspx?ID="+ t +"')\">"+assessmentLinkThisRowTxt+"</a>");
		
		}
	
	});
	
	AssessmentDashboardWebPart.find(".ms-vb2").each(function(){	
		
		var t = $(this).text();
		var tx = $(this).text();
		tx = tx.replace(/\s/g,'');
		var colorHex;
		
		if($(this).find("a").length){
			$(this).css("background","url(/_layouts/images/selbg.png) #f5f6f7 repeat-x");
		}
		if(AssessmentDbWPColorkey[""+tx+""]!=null){
			colorHex = AssessmentDbWPColorkey[""+tx+""]; 
			$(this).css("background","url(/_layouts/images/selbg.png) #f5f6f7 repeat-x");
			$(this).css("background-color", colorHex).text("");
			$(this).attr("title",t);
		}

	});	
	AssessmentDashboardWebPart.find(".ms-vh2:last-child").remove();
	AssessmentDashboardWebPart.find(".ms-vb2:last-child").remove();
	
	AssessmentDashboardWebPart.find(".ms-vh2").css("font-size","9px").css("color","gray").css("font-weight","normal").css("line-height","inherit").css("letter-spacing","1.8px").css("border","transparent 0px solid");
	AssessmentDashboardWebPart.find(".ms-vh2:last").css("letter-spacing","-1px");

}
if(IsGrouped == "Yes"){
	minusInt = 1;
	AssessmentDashboardWebPart.find("a:contains(OperationalTestAgency)").each(function(){
		var grpTitle = $(this).parent().text();
		var grpTitle2 = grpTitle.substr(grpTitle.indexOf(":")+2);
		var grpTitle2L = grpTitle2.length;
		
		$(this).text(grpTitle2);
		
	});
	AssessmentDashboardWebPart.find(".ms-gb").each(function(){
		var h = $(this).html();
		var hh = h.lastIndexOf(":&nbsp;");
		h = h.substr(0, hh);
		//alert(h);
		$(this).html(h);
		
	});


	$("#legendColorsTable").removeClass("auto-style2").find("td").removeClass("auto-style3").removeClass("auto-style1");
	$(".auto-style7").css("width","150px").parent().css("height","20px");
	$(".auto-style11").css("width","150px");


	AssessmentDashboardWebPart.find("td.ms-gb").css("background","url(/_layouts/images/selbg.png) #f5f6f7 repeat-x").css("padding-top","0");
	AssessmentDashboardWebPart.find(".ms-vh2").css("color","gray").css("font-weight","normal").css("line-height","inherit").css("text-align","center").css("min-width","40px").css("border","transparent 0px solid"); // .css("letter-spacing","2px")
	AssessmentDashboardWebPart.find(".ms-vh2:last").remove();
	
	
	AssessmentDashboardWebPart.find(".ms-vh-group").parent().children("td:nth-child(2)").css("white-space","nowrap").each(function(){
	
		var t = $(this).text();
		var tid = $(this).closest("tr").children("td:last").text();
		
		
		$(this).html("<a href=\"javascript:OpenPopUpPage('/Lists/Assessment/DispForm.aspx?ID="+ tid +"')\">"+t+"</a>");
				
	});
	AssessmentDashboardWebPart.find(".ms-vb2:last-child").remove();
	

	AssessmentDashboardWebPart.find(".ms-vh-group").parent().children("td").each(function(){
		var t = $(this).text();
		var tx = $(this).text();
		tx = tx.replace(/\s/g,'');
		var colorHex;
		
		if($(this).find("a").length){
			$(this).css("background","url(/_layouts/images/selbg.png) #f5f6f7 repeat-x");
		}
		if(AssessmentDbWPColorkey[""+tx+""]!=null){
			colorHex = AssessmentDbWPColorkey[""+tx+""]; 
			$(this).css("background","url(/_layouts/images/selbg.png) #f5f6f7 repeat-x");
			$(this).css("background-color", colorHex).text("");
			$(this).attr("title",t);
		}
		
	});
}

var thTxt = AssessmentDashboardWebPart.find(".ms-vh2");
AssessmentDashboardWebPart.find(".ms-vh2").each(function(){
	var thisInd = $(this).index()-minusInt;
	var tx = thTxt.eq(  thisInd  ).text();
	tx = tx.replace(/\s/g,'');
	if(tx.indexOf("RRI")>-1){$(this).attr("title", "Readiness Review I");}
	else if(tx.indexOf("ACB")>-1){$(this).attr("title", "Assessment Concept Brief");}
	else if(tx.indexOf("DAP")>-1){$(this).attr("title", "Draft Assessment Plan");}
	else if(tx.indexOf("FAP")>-1){$(this).attr("title", "Final Assessment Plan");}
	else if(tx.indexOf("QLR")>-1){$(this).attr("title", "Quick Look Review");}
	else if(tx.indexOf("ADP")>-1){$(this).attr("title", "Authenticated Data Package");}
	else if(tx.indexOf("FAR")>-1){$(this).attr("title", "Final Assessment Report");}
	else if(tx.indexOf("VSMU")>-1){$(this).attr("title", "Vulnerability Shortfall Matrix Update");}
	else if(tx.indexOf("VSM")>-1){$(this).attr("title", "Vulnerability Shortfall Matrix");}


});
	


