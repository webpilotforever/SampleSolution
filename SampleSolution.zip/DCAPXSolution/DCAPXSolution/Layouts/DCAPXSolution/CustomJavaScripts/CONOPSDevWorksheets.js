﻿// progress key 
// 0 = Not Started
// 1 = In Progress
// 2 = Draft Completed
// 3 = Submitted
$(".WSOTADiv").show(); $(".WSTitle").show();
SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes loading worksheet dialog
$(".ms-PartSpacingVertical").css("margin","0"); // remove spacing below web parts


// ----- DIALOG TOP -----
if(parent.document.getElementById("dialogTitleSpan") !== null){

	var dialogTitle = parent.document.getElementById("dialogTitleSpan").innerHTML;
	dialogTitleText = dialogTitle;
	//alert(dialogTitleText ); // Worksheet #1
	var CONOPSDevProgThmDivWS1 = "";
	var CONOPSDevProgThmDivWS2 = "";
	var CONOPSDevProgThmDivWS3 = "";
	var CONOPSDevProgThmDivWS4 = "";
	var CONOPSDevProgThmDivRev = "";
	
	
	
	var ws1Prog=getParameterByName("ws1Prog");
	var ws2Prog=getParameterByName("ws2Prog");
	var ws3Prog=getParameterByName("ws3Prog");
	var ws4Prog=getParameterByName("ws4Prog");
	var wsRevProg=getParameterByName("wsRevProg");
	var worksheetFY="FY "+getParameterByName("currentFY")+" ";
	
	//alert(ws1Prog + "|" + ws2Prog + "|" + ws3Prog + "|" + ws4Prog + "|" + wsRevProg);
	
	if(ws1Prog=="2"){ CONOPSDevProgThmDivWS1 = "CONOPSDevProgThmDivGreen" }
	if(ws2Prog=="2"){ CONOPSDevProgThmDivWS2 = "CONOPSDevProgThmDivGreen" }
	if(ws3Prog=="2"){ CONOPSDevProgThmDivWS3 = "CONOPSDevProgThmDivGreen" }
	if(ws4Prog=="2"){ CONOPSDevProgThmDivWS4 = "CONOPSDevProgThmDivGreen" }
	if(wsRevProg=="2"){ CONOPSDevProgThmDivRev = "CONOPSDevProgThmDivGreen" }
	
	if(ws1Prog=="1"){ CONOPSDevProgThmDivWS1 = "CONOPSDevProgThmDivYellow" }
	if(ws2Prog=="1"){ CONOPSDevProgThmDivWS2 = "CONOPSDevProgThmDivYellow" }
	if(ws3Prog=="1"){ CONOPSDevProgThmDivWS3 = "CONOPSDevProgThmDivYellow" }
	if(ws4Prog=="1"){ CONOPSDevProgThmDivWS4 = "CONOPSDevProgThmDivYellow" }
	if(wsRevProg=="1"){ CONOPSDevProgThmDivRev = "CONOPSDevProgThmDivYellow" }
	
	
	// write in the Progress Thumbnail div with class .ms-dlgBorder
	
	if(dialogTitle == "Worksheet #1"){ CONOPSDevProgThmDivWS1 += " CONOPSDevProgThmDivActive" }
	
	if(dialogTitle == "Worksheet #2"){ CONOPSDevProgThmDivWS2 += " CONOPSDevProgThmDivActive" }
	
	if(dialogTitle == "Worksheet #3"){ CONOPSDevProgThmDivWS3 += " CONOPSDevProgThmDivActive" }
	
	if(dialogTitle == "Worksheet #4"){ CONOPSDevProgThmDivWS4 += " CONOPSDevProgThmDivActive" }
	
	if(dialogTitle == "Review"){ CONOPSDevProgThmDivRev += " CONOPSDevProgThmDivActive" }
	
	
	if (dialogTitle !== "Review" && getParameterByName("review") !== "true") {
	    // ----- PROGRESS THUMBNAIL -----
	    parent.document.getElementById("dialogTitleSpan").innerHTML = "CONOPS Development Module<div class=\"CONOPSDevProgThmTitle\">" + worksheetFY + "Progress</DIV><div id='CONOPSDevProgThmDiv'><div id='CONOPSDevProgThmDivWS1' title='Worksheet #1' class='" + CONOPSDevProgThmDivWS1 + "'>&nbsp;</div><div id='CONOPSDevProgThmDivWS2' title='Worksheet #2' class='" + CONOPSDevProgThmDivWS2 + "'>&nbsp;</div><div id='CONOPSDevProgThmDivWS3' title='Worksheet #3' class='" + CONOPSDevProgThmDivWS3 + "'>&nbsp;</div><div id='CONOPSDevProgThmDivWS4' title='Worksheet #4' class='" + CONOPSDevProgThmDivWS4 + "'>&nbsp;</div><div id='CONOPSDevProgThmDivRev' title='Review' class='" + CONOPSDevProgThmDivRev + "'>&nbsp;</div></div>";
	}

	else if (getParameterByName("review") == "true") {
	    // alert(getParameterByName("review"));
	    parent.document.getElementById("dialogTitleSpan").innerHTML = "CONOPS Development Module<div class=\"CONOPSDevProgThmTitle\">REVIEW EDITS</DIV>";
	    //editWS();
	}
	
	parent.document.getElementById("dialogTitleSpan").style.visibility = "visible";

}


         	
			

$("#Total").parent().append("<input name='CONOPSDevTitle' type='hidden' value='Total' id='Title' />");
// Clone Venue row when ready ------------------
$("#Venue").closest("tr").addClass("VenueRow");
var VenueRow = $(".VenueRow")[0];
var venueRow = $(".VenueRow");
// ----- HIDE DIALOG PAGE TAB IN RIBBON -----
// $(".ms-cui-tt-a").css("display","inline");



// ----- TAG WS TABLE WITH CLASS ----------
$(".WSBtnDeleteRow").closest('table').addClass("WSTable");
$("#Venue").addClass("WSGroupTitle");
$("#Contract").addClass("WSGroupTitle");
$(".WSGroupTitle").closest('tr').addClass("WSGroupStartRow");
$(".WSBtnAddGroup").closest('tr').addClass("WSGroupEndRow");


// ----- WS TABLE TBODY and TEMPLATES FOR CLONING ROWS AND GROUPS -----
var tbody = $(".WSBtnDeleteRow").closest('tr').parent();

//tbody.children().find("td:last").find("input:text").parent().append("<input name=\"CONOPSDevContentTypeId\" id=\"ContentTypeId\" type=\"hidden\"/>");
//alert('\nws1ContentTypeId: '+ws1ContentTypeId + '\nws2ContentTypeId: '+ws2ContentTypeId + '\nws3ContentTypeId: '+ws3ContentTypeId + '\nws4ContentTypeId: '+ws4ContentTypeId);


if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1) { $("input#ContentTypeId").val(ws1ContentTypeId); }
if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS2.aspx") > -1) { $("input#ContentTypeId").val(ws2ContentTypeId); }
if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS3.aspx") > -1) { $("input#ContentTypeId").val(ws3ContentTypeId); }
if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS4.aspx") > -1) { $("input#ContentTypeId").val(ws4ContentTypeId); }


var sliceStartTemplate = $(".WSGroupTitle").closest('tr').index(); // alert(sliceStartTemplate);
var sliceEndTemplate = $(".WSBtnAddGroup").closest('tr').index() + 1; //alert(sliceEndTemplate );
var groupTemplate = tbody.children().slice(sliceStartTemplate, sliceEndTemplate); // set of row elements

//$("#s4-workspace").on('focusout', 'input:text', function () { // using event delegation for this dynamic content
//	var titleVal = $(this).val();
//	if(titleVal.indexOf(",") > -1){
//		titleVal = titleVal.replace(/,/g,"");
//		$(this).val(titleVal);
//	}
//});


if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1 || siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS2.aspx") > -1) {
    
    $("#s4-workspace").on('focusin', 'input:text', function () { // using event delegation for this dynamic content

        if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1) {
            var inxForThisFieldRow = $(this).closest('tr').index();
            var inxForTheClosestContractFieldRow = 0;
            tbody.find("input[title='Contract']").each(function () {
                if ($(this).closest('tr').index() < inxForThisFieldRow) {
                    //$(this).css("background-color","red");
                    inxForTheClosestContractFieldRow = $(this).closest('tr').index();
                }
            });
            var inxForNextAddGroupBtn = 0;
            tbody.find(".WSBtnAddGroup").each(function () {
                if ($(this).closest('tr').index() > inxForThisFieldRow) {
                    //$(this).css("background-color","red");
                    inxForNextAddGroupBtn = $(this).closest('tr').index() + 1;
                    return false;
                }
            });
            if ($(this).attr("id") !== "Contract" && inxForTheClosestContractFieldRow > 0) {
                var thisContract = tbody.children().slice(inxForTheClosestContractFieldRow, inxForNextAddGroupBtn);
                if (thisContract.find("input:text[id='Contract']").val() == "") {
                    alert("Please enter information for [Contract]");
                }
            }
        } else {
            var sliceStartVenue;
            var sliceEndVenue;
            var thisRowIndex = $(this).closest("tr").index(); //alert(thisRowIndex);
            $(".VenueRow").each(function () {
                if ($(this).index() > thisRowIndex) {
                    return false;
                } else {
                    sliceStartVenue = $(this).index();
                }
            });
            // alert(sliceStartVenue );
            tbody.children(".WSGroupEndRow").each(function () {
                if ($(this).index() > sliceStartVenue) {
                    sliceEndVenue = $(this).index();
                    return false;
                }
            });
            // alert(sliceEndVenue );
            var thisVenue = tbody.children().slice(sliceStartVenue, sliceEndVenue);
            if ($(this).attr("id") !== "Venue") {
                if (thisVenue.find("input:text[id='Venue']").val() == "") {
                    alert("Please enter information for [Venue]");
                }
            }
        }
    });

    $("#s4-workspace").on('focusout', '#AdditionalLineItem', function () { // using event delegation for this dynamic content
        if ($(this).val().length) {
            // do nothing
        }
        else {
            $(this).val("0");
        }
    });

    // ----- APPEND GROUP ROWS WITH HIDDEN GROUP TITLE FIELD -----
    $("#s4-workspace").on('focusout', '.WSGroupTitle', function () { // using event delegation for this dynamic content
        
        
        // return false;
        var groupTitleFieldVal = $(this).val();
        var groupTitleFieldValIsUnique = true;
        
        $(".WSGroupTitle").not($(this)).each(function(){
        
        	var WSGroupTitleVal = $(this).val();
        	if(WSGroupTitleVal !=="" && groupTitleFieldVal !== ""){
        		if(WSGroupTitleVal == groupTitleFieldVal){
        		
        			groupTitleFieldValIsUnique = false;
        		}
        	}
        
        });
        if(groupTitleFieldValIsUnique == false){ $(this).val(''); alert("Duplicate "+$(this).attr("id")+". \nPlease enter a unique value."); return false;}
        
        var sliceStartGroup = $(this).closest('tr').index();
        if ($(this).attr("id") == "Venue" || $(this).attr("id") == "Contract") {
            sliceStartGroup = sliceStartGroup + 1;
        }
        var sliceEndGroup = tbody.children().slice(sliceStartGroup).find(".WSBtnDeleteGroup").first().closest('tr').index() + 1;

        var thisGroupTitleRowSett = tbody.children().slice(sliceStartGroup, sliceEndGroup);
        thisGroupTitleRowSett.each(function () { // iterate through rows
            //alert(groupTitleFieldVal ); 
            if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1) {
                if ($(this).find(".WSGroupTitle").index() > -1) {
                    $(this).find(".WSGroupTitle").val(groupTitleFieldVal);
                }
                else {
                    if ($(this).find("input:hidden[id='Contract']").length) {
                        // update hidden Contract fields
                        $(this).find("input:hidden[id='Contract']").val(groupTitleFieldVal);
                    }
                    else {
                        $(this).find("input:not(#Contract)").last().parent().append("<input name='CONOPSDevContract' type='hidden' value='" + groupTitleFieldVal + "' id='Contract' />");
                    }
                }
            } else {
                var lastFieldVal = $(this).find("input:text").last().attr("id");
                $(this).find("input:hidden[id='Title']").val(lastFieldVal);

                if ($(this).find("input:hidden[id='Venue']").length) {
                    // update hidden Venue fields
                    $(this).find("input:hidden[id='Venue']").val(groupTitleFieldVal);
                }
                else {
                    $(this).find("input:not(#Venue)").last().parent().append("<input name='CONOPSDevVenue' type='hidden' value='" + groupTitleFieldVal + "' id='Venue' />");
                }
            }
        });
    });
    // ----- HIDDEN FIELDS -----		
    tbody.children().each(function () { // Append rows with no Title field with a hidden Title field with the value of the last field's id attribute in the last cell
        var foundInput = "No";
        var foundTitle = "No";
        // $(this).find("input:text").each(function () {
        $(this).find("input").each(function () {
			
            //alert( $(this).attr("id") ); 
            foundInput = "Yes";
            if ($(this).attr("id") == "Title") {
                foundTitle = "Yes";
            }
        });
        if (foundInput == "Yes" && foundTitle == "No") {
            // $(this).css("display","none");
            var inputId = $(this).find("input:text").last().attr("id");
            $(this).find("input:text").last().parent().append("<input name='CONOPSDevTitle' type='hidden' value='" + inputId + "' id='Title' />");
        }
    });
    tbody.find("input:text").each(function () { // GSLevel and ContractorRate field cells should be appended with a hidden field for Employer
        if ($(this).attr("id") == "GSLevel") {
            $(this).parent().append("<input name='CONOPSDevEmployer' type='hidden' value='MilitaryOrGovernmentCivilian' id='Employer' />");
        }
        if ($(this).attr("id") == "ContractorRate") {
            $(this).parent().append("<input name='CONOPSDevEmployer' type='hidden' value='Contractor' id='Employer' />");
        }
    });
}

// ----- REMARKS FIELD -----
var remarksWidth = $("#Remarks").css("width");
$("#s4-workspace").on('focusin', '#Remarks', function () {
    $(this).css("width", "300px");
});
$("#s4-workspace").on('focusout', '#Remarks', function () {
    $(this).css("width", remarksWidth);
});

// ----- COLUMN DESCRIPTIONS -----
$(".WSColHeaders").click(function () {
    $(".WSColDesc").slideToggle("fast");
});
//$(".WSColHeaders").hover(function () {
//    $(".WSColDesc").slideToggle("fast");
//});


