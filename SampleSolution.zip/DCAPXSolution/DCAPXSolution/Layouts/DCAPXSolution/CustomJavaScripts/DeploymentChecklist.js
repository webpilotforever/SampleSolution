﻿var textBox1txt = "";

$(document).ready(function () {
    $("div[id*='traceInfoDiv']").animate({ scrollTop: $("div[id*='traceInfoDiv']").prop("scrollHeight") }, 50);
    textBox1txt = $("input[id*='TextBox1']").val();

    $("input[id*='CheckBox1']").click(function () {
        //if ($("input[id*='SiteCollectionCreated']").val() !== "true") {
            ExecuteOrDelayUntilScriptLoaded(callpleaseWaitCreatingSiteCollection, "sp.js");
        //}
    });
});
function callpleaseWaitCreatingSiteCollection() {
    ExecuteOrDelayUntilScriptLoaded(pleaseWaitCreatingSiteCollection, "sp.ui.dialog.js");

}

function pleaseWaitCreatingSiteCollection() {
    var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Performing DCAPXSolution Operations", "Please wait...");
}



function clickRefreshBtn() {
    var clickRB = $("input[id*='RefreshBtn']").click()
}