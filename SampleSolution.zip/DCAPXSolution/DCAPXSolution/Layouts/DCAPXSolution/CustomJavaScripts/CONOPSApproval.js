﻿var siteRelURLtopage = window.location.pathname; 
var worksheetPageName = siteRelURLtopage.substr(siteRelURLtopage.lastIndexOf("/") + 1);
var contractName;
var venueName;
var gCurrentUser2 = "";// domain\\username
var ctrlid;
var otatoupdate;
var wsNum;
var wsNumInt;
var originalValue;
var newValue;
var updateContractFY;
var updateContractOTAShort;
var updateContractCount;
var updateVenueFY;
var updateVenueOTAShort;






$(document).ready(function () {

    var tab = getParameterByName("tab");

    if (tab == "OTASubmission") {

        $("#OTASubmission").addClass("tabselected");
    }
    if (tab == "AOReview") {

        $("#AOReview").addClass("tabselected");
        $(".SaveDiv").show();
    }
    if (tab == "PMReview") {

        $("#PMReview").addClass("tabselected");
        $(".SaveDiv").show();
    }
    if (tab == "DeputyDirectorReviewandApproval") {

        $("#DeputyDirectorReviewandApproval").addClass("tabselected");
        $(".SaveDiv").show();
    }




    $("td[title='Venue']").closest('tr').addClass("WSGroupStartRow"); // remove first cell for new items above?
    $("span:contains('dentifier')").closest('tr').addClass("WSGroupStartRow");

    $("input[id*='ContractsSubTotal']").closest('tr').addClass("WSGroupEndRow");

  


    //$("textarea[id*='Comments']").focusin(function () {
    //    if ($(this).val() == "Please enter comments.") { $(this).val(''); }
    //});

    
    var ota = getParameterByName("ota");
    var otashort = getParameterByName("otashort");
    var fy = getParameterByName("fy");
    var ws = getParameterByName("ws");
    var submitted = getParameterByName("submitted");
    var w = getParameterByName("w");

    var urlToPage = location.href;
    var urlSearch = location.search;
    urlToPage = urlToPage.replace(urlSearch, "");
    var urlToSite = location.href.substr(0, location.href.lastIndexOf("/") + 1);
    

    if (w == "new") {

        //Open OTA Submission in new window 
        $("#AOReview").hide();
        $("#PMReview").hide();
        $("#DeputyDirectorReviewandApproval").hide();
    }

    var fromPanelQueryParam = "";
    if (getParameterByName("fromPanel") == "1") {
        fromPanelQueryParam = "&fromPanel=1";
    }

    $("#OTASubmission").click(function () {
        if ($('input[disabled="disabled"]').length) {
            if (confirm("Unsaved values will be lost. Continue?") == true) {
                location.replace(urlToPage + "?" + "tab=OTASubmission&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

            }
        }
        else {
            location.replace(urlToPage + "?" + "tab=OTASubmission&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

        }
    });
    $("#AOReview").click(function () {
        if ($('input[disabled="disabled"]').length) {
            if (confirm("Unsaved values will be lost. Continue?") == true) {
                location.replace(urlToPage + "?" + "tab=AOReview&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

            }
        }
        else {
            location.replace(urlToPage + "?" + "tab=AOReview&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

        }
    });
 
 

    if ($("input[id*='DisablePMReview']").val() == "Yes") {
        $("#PMReview").addClass("tabdisabled").attr("title", "Disabled");
    }
    else {
        $("#PMReview").click(function () {
            if ($('input[disabled="disabled"]').length) {
                if (confirm("Unsaved values will be lost. Continue?") == true) {
                    location.replace(urlToPage + "?" + "tab=PMReview&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

                }
            }
            else {
                location.replace(urlToPage + "?" + "tab=PMReview&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

            }
        });
    }
    if ($("input[id*='DisableDeputyDirectorReviewandApproval']").val() == "Yes") {
        $("#DeputyDirectorReviewandApproval").addClass("tabdisabled").attr("title", "Disabled");
    }
    else {
        $("#DeputyDirectorReviewandApproval").click(function () {
            if ($('input[disabled="disabled"]').length) {
                if (confirm("Unsaved values will be lost. Continue?") == true) {
                    location.replace(urlToPage + "?" + "tab=DeputyDirectorReviewandApproval&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

                }
            }
            else {
                location.replace(urlToPage + "?" + "tab=DeputyDirectorReviewandApproval&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + fromPanelQueryParam + "&IsDlg=1");

            }
        });
    }


    $("#OTASubmission").prepend("<img src='/_layouts/Images/DCAPXSolution/tabcheck.png' class='tabarrowandcheck' title='Status OTA Submission' alt='Status OTA Submission' />");

    if ($("input[id*='AllTabsChecked']").val() == "Yes") {
        $("#AOReview").prepend("<img src='/_layouts/Images/DCAPXSolution/tabcheck.png' class='tabarrowandcheck' title='Status AO Review' alt='Status AO Review' />");
        $("#PMReview").prepend("<img src='/_layouts/Images/DCAPXSolution/tabcheck.png' class='tabarrowandcheck' title='Status PM Review' alt='Status PM Review' />");
        $("#DeputyDirectorReviewandApproval").prepend("<img src='/_layouts/Images/DCAPXSolution/tabcheck.png' class='tabarrowandcheck' title='Status Deputy Director Review and Approval' alt='Status Deputy Director Review and Approval' />");
    }
    else {

        //--arrow lasttabenabled to indicate status and encourage user to click on tab
        if ($("input[id*='DisablePMReview']").val() == "Yes" && $("input[id*='DisableDeputyDirectorReviewandApproval']").val() == "Yes") {
            $("#AOReview").prepend("<img src='/_layouts/Images/DCAPXSolution/tabarrow.png' class='tabarrowandcheck' title='Status AO Review' alt='Status AO Review' />");
        }
        if ($("input[id*='DisablePMReview']").val() !== "Yes" && $("input[id*='DisableDeputyDirectorReviewandApproval']").val() == "Yes") {
            $("#AOReview").prepend("<img src='/_layouts/Images/DCAPXSolution/tabcheck.png' class='tabarrowandcheck' title='Status AO Review' alt='Status AO Review' />");
            $("#PMReview").prepend("<img src='/_layouts/Images/DCAPXSolution/tabarrow.png' class='tabarrowandcheck' title='Status PM Review' alt='Status PM Review' />");
        }
        if ($("input[id*='DisablePMReview']").val() !== "Yes" && $("input[id*='DisableDeputyDirectorReviewandApproval']").val() !== "Yes") {
            $("#AOReview").prepend("<img src='/_layouts/Images/DCAPXSolution/tabcheck.png' class='tabarrowandcheck' title='Status AO Review' alt='Status AO Review' />");
            $("#PMReview").prepend("<img src='/_layouts/Images/DCAPXSolution/tabcheck.png' class='tabarrowandcheck' title='Status PM Review' alt='Status PM Review' />");
            $("#DeputyDirectorReviewandApproval").prepend("<img src='/_layouts/Images/DCAPXSolution/tabarrow.png' class='tabarrowandcheck' title='Status Deputy Director Review and Approval' alt='Status Deputy Director Review and Approval' />");
        }

    }


    $(".OTASubmissionNewWindow").click(function () {

        window.open(urlToPage + "?" + "tab=OTASubmission&ota=" + encodeURI(ota) + "&otashort=" + otashort + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted + "&IsDlg=1&w=new", "_blank");
    });



    $(".ViewWorksheetsButton").click(function () {
        $(this).parent().parent().find($(".worksheetsListDiv")).slideToggle("slow", function () {
        });

    });




    if (location.href.indexOf("CONOPSApproval/WS") > -1) {
        //$(".CONOPSDevWSColCell").mouseover(function () {

          
        //    $(".CONOPSDevWSColHeaderDesc").show("slow", function () {

        //    });

        //});
        //$(".CONOPSDevWSColCell").mouseout(function () {

        //    $(".CONOPSDevWSColHeaderDesc").hide("slow", function () {

        //    });
        //});

        //$(".CONOPSDevWSColCell").hover(function () {
        //    $(".CONOPSDevWSColHeaderDesc").show("slow", function () {

        //    });
        //}, function () {
        //    $(".CONOPSDevWSColHeaderDesc").hide("slow", function () {

        //    });
        //});
        $(".CONOPSDevWSColHeaderDesc").children().hide();
        //$(".CONOPSDevWSColCell").hover(function () {
        //    $(".CONOPSDevWSColHeaderDesc").children().fadeIn(1000);
        //}, function () {
        //    $(".CONOPSDevWSColHeaderDesc").children().fadeOut(1000);

        //});
        $(".CONOPSDevWSColCell").click(function () {
            $(".CONOPSDevWSColHeaderDesc").children().fadeToggle("slow", "linear");
        });
    }

    if (getParameterByName('print') == "yes") {
        window.print();
    }
    getmsdlgTitleBtns(urlToSite);



    //-----------------------------


    if (urlToPage.indexOf("CONOPSApproval.aspx") > -1) {

        

        //$("input:button").each(function () {

        //    if ($(this).val() == "OTA Submission Pending")
        //    {
        //        $(this).hide();

        //        $(this).closest('td').text("OTA Submission Pending").end().css("color", "coral").end().css("white-space","nowrap");

        //    }
        //    if ($(this).val() == "Completed") {
        //        $(this).hide();

        //        $(this).closest('td').text("Completed").end().css("white-space", "nowrap");

        //    }
        //});

        $(".showPanelButton").click(function () {

            location.replace(location.href);
        });

        $(".CONOPSApprovalStatusTable").find('td:contains(OTA Submission Pending)').each(function () {
            $(this).css("color","coral");
        });

        $(".CONOPSApprovalStatusTable").find('td:contains(Completed)').each(function () {
            $(this).css("color","green");
        });

        var divAFOTEC = $("div[id*='divAFOTEC']");
        var divATEC = $("div[id*='divATEC']");
        var divCOTF = $("div[id*='divCOTF']");
        var divJITC = $("div[id*='divJITC']");
        var divMCOTEA = $("div[id*='divMCOTEA']");

        var CONOPSApprovalSelectStatusDropDownListVal = $(".CONOPSApprovalSelectStatusDropDownList").val();
        var CONOPSApprovalSelectOTADropDownListVal = $(".CONOPSApprovalSelectOTADropDownList").val();

        var RadioButton1Checked = $("input[id*='RadioButton1']:checked");
        var RadioButton2Checked = $("input[id*='RadioButton2']:checked");
        var RadioButton3Checked = $("input[id*='RadioButton3']:checked");

        var showNoItemsIfNecessary = false;

        if (RadioButton1Checked.length || RadioButton2Checked.length || RadioButton3Checked.length) {

            var headerStatusOverviewtxt = $(".headerStatusOverview").text();
            $(".headerStatusOverview").hide();

            $(".showPanelButton").val(headerStatusOverviewtxt);
            $(".showPanelButton").show();
            
            $(".CONOPSApprovalStatusTable").find("tr").each(function () {

                if($(this).index() > 0){
                    $(this).hide();
                }
            });



            



            if (RadioButton1Checked.length) {
                
                if (CONOPSApprovalSelectOTADropDownListVal !== "(None)") {
                
                    showNoItemsIfNecessary = true;
                }
            }
            if (RadioButton2Checked.length) {

                if (CONOPSApprovalSelectStatusDropDownListVal !== "(None)") {

                    showNoItemsIfNecessary = true;



                   
                    $(".worksheetsListDiv").each(function () {
                        var n = $(this).find("li").length;
                        if (n < 1) {
                            //$(this).parent().css("background-color", "red");
                            $(this).parent().hide();

                        }
                    });

                    



                }
            }
       


        }
        else {
            $(".headerStatusOverview").css("margin-left", "0");
            $(".worksheetSection").append("<span class='NoItemsCONOPSApproval'>Please make a selection from above.</span>");
        }



        if (showNoItemsIfNecessary) {

            if ($(".submittedUL").find("li").length) {
                // nothing
            }
            else { //if no li on page, show no items message

                $(".worksheetSection").append("<span class='NoItemsCONOPSApproval'>No submitted worksheets found.</span><span class='NoItemsCONOPSApproval'>Please make a different selection from above.</span>");
                divAFOTEC.hide();
                divATEC.hide();
                divCOTF.hide();
                divJITC.hide();
                divMCOTEA.hide();
            }
        }
        
    }






    //======= View CONOPS Buttons ================

    var qs_fy = "";
    var qs_ota = "";
    var qs_otashort = "";

  // add js link
    $(".ViewCONOPSButton").each(function () {

        qs_fy = $("input[id*='CurrentFY']").val();
        qs_otashort = $(this).attr("id"); qs_otashort = qs_otashort.replace('ViewCONOPSButton', '');
        qs_ota = $(this).attr("title");
        // link here
        var wssite = window.location.href; 
        var wssitelastslash = wssite.lastIndexOf('/');
        wssite = wssite.substring(0, wssitelastslash);
        var wslinkhref = wssite + "/ViewCONOPS.aspx?ota=" + encodeURI(qs_ota) + "&otashort=" + qs_otashort + "&fy=" + qs_fy;

        var wslink = "javascript:OpenPopUpPage('" + wslinkhref + "')";

        $(this).attr("onclick", wslink);

    });


    //========
    if (worksheetPageName.indexOf('ViewCONOPS.aspx') > -1) {
        $(".CONOPSDevWSOTADiv:gt(0)").html("&nbsp;");
    }
    
    //===============

    $(".CONOPSApprovalAddMilGovButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }

    });
    $(".CONOPSApprovalAddContractorButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }


        contractName = $(this).attr("title");
        ctrlid = $(this).attr("id");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser2, "sp.js");
    });
    //===============

    $(".CONOPSApprovalAddLineItemButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }
        contractName = $(this).attr("title");
        ctrlid = $(this).attr("id");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser3, "sp.js");
    });
    //======================

    $(".CONOPSApprovalAddContractButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }
        ctrlid = $(this).attr("id");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser4, "sp.js");
    });


    //=====================
    $(".CONOPSApprovalAddVenueButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }
        ctrlid = $(this).attr("id");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser5, "sp.js");

    });

    //=====================
    $(".CONOPSApprovalAddActivityEventButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }
        venueName = $(this).attr("title");
        ctrlid = $(this).attr("id");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser6, "sp.js");

    });

    //=====================
    $(".CONOPSApprovalAddEventButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }
        ctrlid = $(this).attr("id");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser7, "sp.js");

    });
    //=====================
    $(".CONOPSApprovalAddItemButton").click(function () {
        if ($(this).attr("alt") == "disabled") {
            alert("Please save your recent changes first."); return false;
        }
        ctrlid = $(this).attr("id");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser8, "sp.js");

    });
    if (location.href.indexOf("CONOPSApproval/ViewCONOPS") > -1) {
        $(".CONOPSDevWSColHeaders").css("cursor", "none");
    }
    //==================
    if (location.href.indexOf("CONOPSApproval/WS") > -1 || location.href.indexOf("CONOPSApproval/ViewCONOPS") > -1) {








        //======Approved With Revisions alert===





        ////original funding values
        //var originalFunding = '';
        //var originalContractFee = '';
        //var originalAdditionalLineItem = '';

        //var changedFunding = '';
        //var changedContractFee = '';
        //var changedAdditionalLineItem = '';


        //$('input[id*="Funding"]').focusin(function () {
        //    originalFunding = $(this).val();
        //});
        //$('input[id*="ContractFee"]').focusin(function () {
        //    originalContractFee = $(this).val();
        //});
        //$('input[id*="AdditionalLineItem"]').focusin(function () {
        //    originalAdditionalLineItem = $(this).val();
        //});
        //$(".CONOPSApprovalSelect").focusin(function () {
        //    originalFunding = $(this).closest('tr').find($('input[id*="Funding"]')).val();
        //    originalContractFee = $(this).closest('tr').find($('input[id*="ContractFee"]')).val();
        //    originalAdditionalLineItem = $(this).closest('tr').find($('input[id*="AdditionalLineItem"]')).val();
        //});
        //$(".CONOPSApprovalSelect").focusout(function () {

        //    if ($(this).val() == "Approved With Revisions") {
        //        if ($(this).closest('tr').find($('input[id*="Funding"]')).length) {
        //            changedFunding = $(this).closest('tr').find($('input[id*="Funding"]')).val();
        //            if (changedFunding == originalFunding) {
        //                alert('Please revise Funding.');
        //            }
        //        }
        //        if ($(this).closest('tr').find($('input[id*="ContractFee"]')).length) {
        //            changedContractFee = $(this).closest('tr').find($('input[id*="ContractFee"]')).val();
        //            if (changedContractFee == originalContractFee) {
        //                alert('Please revise ContractFee.');
        //            }
        //        }
        //        if ($(this).closest('tr').find($('input[id*="AdditionalLineItem"]')).length) {
        //            changedAdditionalLineItem = $(this).closest('tr').find($('input[id*="AdditionalLineItem"]')).val();
        //            if (changedAdditionalLineItem == originalAdditionalLineItem) {
        //                alert('Please revise AdditionalLineItem.');
        //            }
        //        }
        //    }

        //});
        //======end Approved With Revisions alert===


        if ($(".CONOPSApprovalSelect").length) {

            $(".CONOPSApprovalSelect").each(function () {

                //==Approved With Revisions====
                if ($(this).closest('tr').find($('input[id*="Funding"]')).length) {
                    $(this).closest('td').append('<input class="originalMonetaryValue" type="hidden" value="' + $(this).closest('tr').find($('input[id*="Funding"]')).val() + '" />');
                }
                if ($(this).closest('tr').find($('input[id*="ContractFee"]')).length) {
                    $(this).closest('td').append('<input class="originalMonetaryValue" type="hidden" value="' + $(this).closest('tr').find($('input[id*="ContractFee"]')).val() + '" />');
                }
                if ($(this).closest('tr').find($('input[id*="AdditionalLineItem"]')).length) {
                    $(this).closest('td').append('<input class="originalMonetaryValue" type="hidden" value="' + $(this).closest('tr').find($('input[id*="AdditionalLineItem"]')).val() + '" />');
                }
                //end Approved With Revisions====

            });

            //$(".CONOPSApprovalColCell:contains(Approval)").append("<div class=\"ApproveAll\">approve all</div>");

            $(".CONOPSApprovalColCell:contains(Approval)").append("<div><input class=\"CONOPSApprovalApproveAllButton\" value=\"Approve All\" type=\"button\" /></div>");
            $(".CONOPSApprovalApproveAllButton").click(function () {

                if (confirm("Are you sure you want to approve all items?") == true) {
                        

                    $(".CONOPSApprovalSelect").val("Approved");
                    $(".CONOPSApprovalSelect").change();

                    $(".CONOPSApprovalSubmitCheckBox").attr("disabled", "disabled");
                    $(".CONOPSApprovalSaveButton").removeAttr("disabled");
                    $(".CONOPSApprovalSaveButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalSaveButton").css("cursor", "pointer");

                    //$(".CONOPSApprovalAddMilGovButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddMilGovButton").css("background", "none"); $(".CONOPSApprovalAddMilGovButton").css("cursor", "none");

                    //$(".CONOPSApprovalAddContractorButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddContractorButton").css("background", "none"); $(".CONOPSApprovalAddContractorButton").css("cursor", "none");

                    //$(".CONOPSApprovalAddLineItemButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddLineItemButton").css("background", "none"); $(".CONOPSApprovalAddLineItemButton").css("cursor", "none");

                    //$(".CONOPSApprovalAddContractButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddContractButton").css("background", "none"); $(".CONOPSApprovalAddContractButton").css("cursor", "none");

                    //$(".CONOPSApprovalAddVenueButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddVenueButton").css("background", "none"); $(".CONOPSApprovalAddVenueButton").css("cursor", "none");


                    //$(".CONOPSApprovalAddActivityEventButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddActivityEventButton").css("background", "none"); $(".CONOPSApprovalAddActivityEventButton").css("cursor", "none");
                    //$(".CONOPSApprovalAddEventButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddEventButton").css("background", "none"); $(".CONOPSApprovalAddEventButton").css("cursor", "none");
                    //$(".CONOPSApprovalAddItemButton").attr("disabled", "disabled");
                    //$(".CONOPSApprovalAddItemButton").css("background", "none"); $(".CONOPSApprovalAddItemButton").css("cursor", "none");

                    $(".CONOPSApprovalAddMilGovButton").attr("alt", "disabled");
                    $(".CONOPSApprovalAddContractorButton").attr("alt", "disabled");
                    $(".CONOPSApprovalAddLineItemButton").attr("alt", "disabled");
                    $(".CONOPSApprovalAddContractButton").attr("alt", "disabled");
                    $(".CONOPSApprovalAddVenueButton").attr("alt", "disabled");
                    $(".CONOPSApprovalAddActivityEventButton").attr("alt", "disabled");
                    $(".CONOPSApprovalAddEventButton").attr("alt", "disabled");
                    $(".CONOPSApprovalAddItemButton").attr("alt", "disabled");
                }
            });
        }
       

        $("input:text").change(function () {
            $(".CONOPSApprovalSubmitCheckBox").attr("disabled", "disabled");

            //
            //$(".CONOPSApprovalAddMilGovButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddMilGovButton").css("background", "none"); $(".CONOPSApprovalAddMilGovButton").css("cursor", "none");

            //$(".CONOPSApprovalAddContractorButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddContractorButton").css("background", "none"); $(".CONOPSApprovalAddContractorButton").css("cursor", "none");

            //$(".CONOPSApprovalAddLineItemButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddLineItemButton").css("background", "none"); $(".CONOPSApprovalAddLineItemButton").css("cursor", "none");

            //$(".CONOPSApprovalAddActivityEventButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddActivityEventButton").css("background", "none"); $(".CONOPSApprovalAddActivityEventButton").css("cursor", "none");
            //$(".CONOPSApprovalAddItemButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddItemButton").css("background", "none"); $(".CONOPSApprovalAddItemButton").css("cursor", "none");

            //$(".CONOPSApprovalAddEventButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddEventButton").css("background", "none"); $(".CONOPSApprovalAddEventButton").css("cursor", "none");

            //$(".CONOPSApprovalAddContractButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddContractButton").css("background", "none"); $(".CONOPSApprovalAddContractButton").css("cursor", "none"); 

            //$(".CONOPSApprovalAddVenueButton").attr("disabled", "disabled");
            //$(".CONOPSApprovalAddVenueButton").css("background", "none"); $(".CONOPSApprovalAddVenueButton").css("cursor", "none");

            //

            $(".CONOPSApprovalSaveButton").removeAttr("disabled");
            $(".CONOPSApprovalSaveButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalSaveButton").css("cursor", "pointer");


            $(".CONOPSApprovalAddMilGovButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddContractorButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddLineItemButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddContractButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddVenueButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddActivityEventButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddEventButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddItemButton").attr("alt", "disabled");
        });
        $("textarea").change(function () {
            $(".CONOPSApprovalSubmitCheckBox").attr("disabled", "disabled");

           

            $(".CONOPSApprovalSaveButton").removeAttr("disabled");
            $(".CONOPSApprovalSaveButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalSaveButton").css("cursor", "pointer");

            $(".CONOPSApprovalAddMilGovButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddContractorButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddLineItemButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddContractButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddVenueButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddActivityEventButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddEventButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddItemButton").attr("alt", "disabled");
        });
        $("input:text").each(function () {

       
            if ($(this).val() == "Enter Contract" || $(this).val() == "Enter Venue") {
                $(this).css("background-color", "LightCoral");
                
                $(".CONOPSApprovalSubmitCheckBox").attr("disabled", "disabled");
                $(".CONOPSApprovalSubmitCheckBox").attr("title", "Disabled: " + $(this).val());
                $(".CONOPSApprovalSaveButton").attr("disabled", "disabled");
                $(".CONOPSApprovalSaveButton").css("background", "none"); $(".CONOPSApprovalSaveButton").css("cursor", "none"); $(".CONOPSApprovalSaveButton").attr("title", "" + $(this).val() + "");
                //$(".CONOPSApprovalAddContractButton").attr("disabled", "disabled");
                //$(".CONOPSApprovalAddContractButton").css("background", "none"); $(".CONOPSApprovalAddContractButton").css("cursor", "none"); $(".CONOPSApprovalAddContractButton").attr("title", "" + $(this).val() + "");
                //$(".CONOPSApprovalAddVenueButton").attr("disabled", "disabled");
                //$(".CONOPSApprovalAddVenueButton").css("background", "none"); $(".CONOPSApprovalAddVenueButton").css("cursor", "none"); $(".CONOPSApprovalAddVenueButton").attr("title", "" + $(this).val() + "");

                $(".CONOPSApprovalAddContractButton").attr("alt", "disabled");
                $(".CONOPSApprovalAddVenueButton").attr("alt", "disabled");
            }
            if (ws == "1") {

                $("input[id*='Total']").attr("readonly", "readonly");
                $("input[id*='GovLaborMonth']").attr("readonly", "readonly");

            }
            if (ws == "2") {

                $("input[id*='Total']").attr("readonly", "readonly");
                $("input[id*='Funding']").attr("readonly", "readonly");

            }
            if (ws == "3") {

                $("input[id*='Total']").attr("readonly", "readonly");

            }
            if (ws == "4") {

                $("input[id*='Total']").attr("readonly", "readonly");

            }
        });

        
        $('.CONOPSApprovalCell').each(function () {
            if($(this).text() == 'Not Approved'){
                $(this).closest('tr').find('td').not($('.CONOPSApprovalCell')).each(function () {

                    $(this).css('text-decoration', 'line-through');
                });
            
            }

        });
       

        $(".CONOPSApprovalSelect").each(function () {
            if ($(this).val() == "Pending") {
                $(this).css("background-color", "LightCoral");

            }
            if ($(this).val() == "Not Approved") {
                $(this).closest('tr').find('input').each(function () {

                    $(this).css('text-decoration','line-through');
                });

                if ($(this).closest('tr').find('textarea').val().length) { 
                    // do nothing 
                }
                else {

                    $(this).closest('tr').find('textarea').css("background-color", "LightCoral");
                    $(".CONOPSApprovalSubmitCheckBox").attr("disabled", "disabled");
                    alert("Please enter a comment for items that are Not Approved.");
                }

            }
        });
        $(".CONOPSApprovalSelect").change(function () {
            $(".CONOPSApprovalSubmitCheckBox").attr("disabled", "disabled");
            $(".CONOPSApprovalSaveButton").removeAttr("disabled");
            $(".CONOPSApprovalSaveButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalSaveButton").css("cursor", "pointer");
          

            $(".CONOPSApprovalAddMilGovButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddContractorButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddLineItemButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddContractButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddVenueButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddActivityEventButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddEventButton").attr("alt", "disabled");
            $(".CONOPSApprovalAddItemButton").attr("alt", "disabled");


            //------------------------------------------
         
            if ($(this).val() == "Pending") {
                //$(".CONOPSApprovalSubmitCheckBox").attr("disabled", "disabled");
                //$(".CONOPSApprovalSubmitCheckBox").attr("title", "Disabled: Please review all Pending items.");
                $(this).css("background-color", "LightCoral");
            }
            else {
                //$(".CONOPSApprovalSaveButton").removeAttr("disabled");
                //$(".CONOPSApprovalSaveButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalSaveButton").css("cursor", "pointer");
                $(this).css("background-color", "#ffffff");

            }

            if ($(this).val() == "Not Approved") {
                $(this).closest('tr').find('input').each(function () {

                    $(this).css('text-decoration', 'line-through');
                });

            }
            //-------------Approved With Comments: require comments -------
            //if ($(this).val() == "Approved With Comments") {
            //    $(this).closest("tr").find($("textarea")).val("Please enter comments.");


            //}
            ////----Approved With Revisions ----

            if ($(this).val() == "Approved With Revisions") {

                var originalMonetaryValue = $(this).closest('td').find('.originalMonetaryValue').val();
                if ($(this).closest("tr").find($("input[id*='Funding']")).length) {

                    if ($(this).closest("tr").find($("input[id*='Funding']")).val() == originalMonetaryValue) {
                        alert("Please revise Funding.");
                    }
                   
                }
                if ($(this).closest("tr").find($("input[id*='ContractFee']")).length) {

                    if ($(this).closest("tr").find($("input[id*='ContractFee']")).val() == originalMonetaryValue) {
                        alert("Please revise ContractFee.");
                    }

                }
                if ($(this).closest("tr").find($("input[id*='AdditionalLineItem']")).length) {

                    if ($(this).closest("tr").find($("input[id*='AdditionalLineItem']")).val() == originalMonetaryValue) {
                        alert("Please revise AdditionalLineItem.");
                    }

                }
            }





        });

       
        $(".ContractIdentifyer").focusin(function () {
            originalValue = $(this).val();
        });
        $(".ContractIdentifyer").focusout(function () {
            newValue = $(this).val();
            if(originalValue == newValue){
            
                return false;
            }
            //confirm val is unique

            if ($(".ContractIdentifyer[value='" + $(this).val() + "']").not($(this)).length) {

                alert("Contract already exists on this form.");
                $(this).val(originalValue); return false;
            }

            if ($(this).val() !== "Enter Contract") {
                $(".CONOPSApprovalSaveButton").attr("disabled", "disabled");
                $(".CONOPSApprovalSaveButton").css("background", "none"); $(".CONOPSApprovalSaveButton").css("cursor", "none"); 

                //$(".CONOPSApprovalSaveButton").removeAttr("disabled");
                //$(".CONOPSApprovalSaveButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalSaveButton").css("cursor", "pointer");
                ////also enable add contract button
                //$(".CONOPSApprovalAddContractButton").removeAttr("disabled");

            }

           
            if (confirm("Contract for associated items below will be updated from '" + originalValue + "' to '" + newValue+"'") == true) {
                updateContractFY=getParameterByName("fy");
                updateContractOTAShort=getParameterByName("otashort");

                updateContract();
            } else {
                $(this).val(originalValue);
            }

        });





        var rowToJet = new Array();
        $("tr[title*='NewItem']").each(function () {
            
            var newItemContract = $(this).attr("title");
            newItemContract = newItemContract.replace("NewItem_", ""); 
            var newItemContractID = $(this).attr("id");

            $(this).clone(true).insertBefore($("tr[id*='contractorsBlankRow']").filter("[title='" + newItemContract + "']"));
            
         

            rowToJet.push(newItemContractID);
        });

      
        //-----

       

        var rowToJet1 = new Array();
        $("tr[title*='NewLineItem']").each(function () {

            var newLineItemContract = $(this).attr("title");
            newLineItemContract = newLineItemContract.replace("NewLineItem_", "");
            var newLineItemContractID = $(this).attr("id");
            //alert("newLineItemContract: " + newLineItemContract);
            var rowForAdditionalLineItem;



            $("input[id*='HoursPerYear']").each(function () {
                if ($(this).attr("title") == newLineItemContract) {
                    rowForAdditionalLineItem = $(this).closest("tr");
                }

            });
            $("span[id*='HoursPerYear']").each(function () {
                if ($(this).attr("title") == newLineItemContract) {
                    rowForAdditionalLineItem = $(this).closest("tr");
                }

            });

          
            $(this).clone(true).insertBefore(rowForAdditionalLineItem);

            rowToJet1.push(newLineItemContractID);
        });

        //-------

        for (i = 0; i < rowToJet.length; i++) {
            $("tr[id='" + rowToJet[i] + "']").last().remove();
        }
        for (i = 0; i < rowToJet1.length; i++) {
            $("tr[id='" + rowToJet1[i] + "']").last().remove();
        }



        $("td[title='Venue'] > input").addClass("VenueIdentifyer");

   



        $(".VenueIdentifyer").focusin(function () {
            originalValue = $(this).val();
        });
        $(".VenueIdentifyer").focusout(function () {
            newValue = $(this).val();
            if (originalValue == newValue) {

                return false;
            }
            //confirm val is unique

            if ($(".VenueIdentifyer[value='" + $(this).val() + "']").not($(this)).length) {

                alert("Venue already exists on this form.");
                $(this).val(originalValue); return false;
            }

            if ($(this).val() !== "Enter Venue") {
                $(".CONOPSApprovalSaveButton").attr("disabled", "disabled");
                $(".CONOPSApprovalSaveButton").css("background", "none"); $(".CONOPSApprovalSaveButton").css("cursor", "none");

                //$(".CONOPSApprovalSaveButton").removeAttr("disabled");
                //$(".CONOPSApprovalSaveButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalSaveButton").css("cursor", "pointer");
                ////also enable add contract button
                //$(".CONOPSApprovalAddContractButton").removeAttr("disabled");
                //$(".CONOPSApprovalAddContractButton").css("background", "#ffffff url(/_layouts/Images/DCAPXSolution/bgximg.png) repeat-x 0px -489px"); $(".CONOPSApprovalAddContractButton").css("cursor", "pointer");

            }


            if (confirm("Venue for associated items below will be updated from '" + originalValue + "' to '" + newValue + "'") == true) {
                updateVenueFY = getParameterByName("fy");
                updateVenueOTAShort = getParameterByName("otashort");

                updateVenue();
            } else {
                $(this).val(originalValue);
            }

        });

   
    }

});









function getParameterByName(name) { name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"); var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search); return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
function getmsdlgTitleBtns(urlToSite) {

    //var wsPrintUrl = "WS1.aspx?ota=Army Test and Evaluation Command&otashort=ATEC&fy=16&ws=4&submitted=no&IsDlg=1&print=yes";

    var formElem = document.getElementById("aspnetForm");
    var wsPrintUrl = formElem.getAttribute("action");
    wsPrintUrl = urlToSite + wsPrintUrl + "&print=yes";

    var printBtn = parent.document.createElement("A");
    printBtn.setAttribute("class", "ms-dlgCloseBtn");
    printBtn.setAttribute("title", "Print");
    printBtn.setAttribute("target", "_blank");
    printBtn.setAttribute("href", wsPrintUrl);
    printBtn.innerHTML = "<SPAN style=\"POSITION: relative; WIDTH: 18px; DISPLAY: inline-block; HEIGHT: 18px; OVERFLOW: hidden\" class=\"s4-clust\"><IMG class=\"ms-dlgCloseBtnImg\" src=\"/_layouts/Images/DCAPXSolution/print.png\"></SPAN>";


    var spans = parent.document.getElementsByTagName("SPAN");

    for (i = 0; i < spans.length; i++) {

        if (spans[i].getAttribute("class") == "ms-dlgTitleBtns") {

            if (spans[i].hasChildNodes()) {

                var spansChildren = spans[i].childNodes;

                for (ii = 0; ii < spansChildren.length; ii++) {
                    if (spansChildren[ii].nodeName == "A") {

                        spansChildren[ii].setAttribute("style", "display: none;");

                        spans[i].insertBefore(printBtn, spansChildren[ii]);

                        break;
                    }
                }

            }

        }
    }




}



//CONOPS Approval Dialogs====================
//dont open next dlg -- just reopen current one if closed during save or submit
function openWorksheet(url) {
    var fromPanelVar = 0;

    if(url.indexOf("fromPanel") > -1){
        fromPanelVar = 1;
    }

    //alert('openWorksheet called: ' + url);
    //this same worksheet will open if the dialogResult is OK (not closed by close button, but rather by Save button or Submit checkbox)
    var args = {
        prevWSUrl: url,
        fromPanel: fromPanelVar
    };



    var options = {
        title: "CONOPS Approval Module",
        url: url
    };

    SP.UI.ModalDialog.commonModalDialogOpen(url, options, reopenWorksheet, args);

}

function reopenWorksheet(dialogResult, returnValue) {


    var args = this.get_args();
    var prevWSUrl = args.prevWSUrl;
    var fromPanel = args.fromPanel;

    //========================



    if (dialogResult == "OK") {

        // ----- Dialog was not closed by close button, but rather by postback action when saved or submitted -----






        if (returnValue) {
            if (returnValue == "1") {
                openWorksheet(prevWSUrl);
            }
            else {
                openWorksheet(returnValue);
            }

        }

    }
    else {

        if (dialogResult == 0) {

            otatoupdate = prevWSUrl.substr(prevWSUrl.indexOf("otashort=")+9);
            otatoupdate = otatoupdate.substr(0, otatoupdate.indexOf("&"));
            //alert("otatoupdate: " + otatoupdate);

            wsNum = prevWSUrl.substr(prevWSUrl.indexOf("ws=")+3);
            wsNum = wsNum.substr(0, wsNum.indexOf("&"));
            
            wsNumInt = parseInt(wsNum) - 1;
            //alert("wsNum: " + wsNum + " wsNumInt: " + wsNumInt);

            if (fromPanel == "1") {
                location.replace(location.href);
            }
            else {
                ExecuteOrDelayUntilScriptLoaded(updateBullet, "sp.js");
            }

        }
    }
  
}

function ss(ctrl) { //confirm submit

    var checkBox = document.getElementById(ctrl.id);
    if (confirm('Submit and lock this view?')) {
        __doPostBack(ctrl.id, '');

    }
    else {

        return false;
    }
}

//===== UPDATE TOTALS ===========

function updateTotals() {

    


    // set totals in worksheet
    if (worksheetPageName.indexOf("WS1") > -1) {
        // ws1 top
        var MilitarySubTotal = 0;
        $("input[id*='Funding']").each(function (i) {

            var fundingVal = $(this).val();
            if (fundingVal.indexOf("$") > -1) {
                fundingVal = fundingVal.substr(fundingVal.indexOf("$") + 1);
                $(this).val(fundingVal);
            }
            if (fundingVal.indexOf(",") > -1) {
                fundingVal = fundingVal.replace(/,/g, "");
                $(this).val(fundingVal);
            }
            if ($.isNumeric(fundingVal)) {
                //var nn = Math.round(fundingVal);
                fundingVal = parseFloat(fundingVal);
                var nn = fundingVal.toFixed(2);
                $(this).val(nn);
                if ($(this).closest('tr').index() < $("input[id*='MilitarySubTotal']").closest('tr').index()) {
                    //MilitarySubTotal += parseInt($(this).val());
                    MilitarySubTotal = (MilitarySubTotal * 10 + parseFloat(nn) * 10) / 10;
                }
            }
        });

        var GovLaborMonthRound = Math.round(MilitarySubTotal / 12);
        $("input[id*='GovLaborMonth']").val(GovLaborMonthRound.toFixed(2));
        $("input[id*='MilitarySubTotal']").val(MilitarySubTotal.toFixed(2));
        // ws1 contractors

        var ContractsSubTotal = 0;

        var contractSliceStart;
        var contractSliceEnd;
        var contractSliced;

        $("tr.WSGroupStartRow").each(function (i) {
            contractSliceStart = $(this).index();
            contractSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
            contractSliced = $(this).parent().children().slice(contractSliceStart, contractSliceEnd);
            var ContractTotal = 0;
            contractSliced.find("input[id*='Funding']").each(function () {
                var fundingVal = $(this).val();
                if ($.isNumeric(fundingVal)) {
                    fundingVal = parseFloat(fundingVal);
                    var nn = fundingVal.toFixed(2);
                    $(this).val(nn);
                    //ContractTotal += parseInt($(this).val());
                    ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
                }
            });

            contractSliced.find("input[id*='AdditionalLineItem']").each(function () {
                var additionalLineItemVal = $(this).val();
                if ($.isNumeric(additionalLineItemVal)) {
                    additionalLineItemVal = parseFloat(additionalLineItemVal);
                    var nn = additionalLineItemVal.toFixed(2);
                    $(this).val(nn);
                    //ContractTotal += parseInt($(this).val());
                    ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
                }
                //if ($.isNumeric($(this).val())) {
                //    //ContractTotal += parseInt($(this).val());
                //    ContractTotal = (ContractTotal * 10 + parseFloat($(this).val()) * 10) / 10;

                //}
            });

            var contractFeeVal = contractSliced.find("input[id*='ContractFee']").val();
            if ($.isNumeric(contractFeeVal)) {
                contractFeeVal = parseFloat(contractFeeVal);
                var nn = contractFeeVal.toFixed(2);
                contractSliced.find("input[id*='ContractFee']").val(nn);
                ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
            }

            var contractTotalStr = ContractTotal.toFixed(2);
            var contractsSubTotalStr = ContractsSubTotal.toFixed(2);

            contractSliced.find("input[id*='ContractTotal']").val(contractTotalStr);
            //ContractsSubTotal += ContractTotal;
            ContractsSubTotal = (parseFloat(contractsSubTotalStr) * 10 + parseFloat(contractTotalStr) * 10) / 10;
            contractSliced.find("input[id*='ContractsSubTotal']").val(ContractsSubTotal.toFixed(2));
        });
        var militarySubTotalStr = MilitarySubTotal.toFixed(2);
        var contractsSubTotalStr = ContractsSubTotal.toFixed(2);
        var totalCal = (parseFloat(militarySubTotalStr) * 10 + parseFloat(contractsSubTotalStr) * 10) / 10;
        //$("input[id*='Total']").last().val(MilitarySubTotal + ContractsSubTotal);
        $("input[id*='Total']").last().val(totalCal.toFixed(2));
    }
    if (worksheetPageName.indexOf("WS2") > -1) {

        var venueSliceStart;
        var venueSliceEnd;
        var venueSliced;

        var Total = 0;

        $("tr.WSGroupStartRow").each(function (i) {
            var VenueSubTotal = 0;
            venueSliceStart = $(this).index();
            venueSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
            venueSliced = $(this).parent().children().slice(venueSliceStart, venueSliceEnd);

            venueSliced.find("input[id*='Funding']").each(function () {

                var venueVal = $(this).val();
                if (venueVal.indexOf("$") > -1) {
                    venueVal = venueVal.substr(venueVal.indexOf("$") + 1);
                    $(this).val(venueVal);
                }
                if (venueVal.indexOf(",") > -1) {
                    venueVal = venueVal.replace(/,/g, "");
                    $(this).val(venueVal);
                }
                if ($.isNumeric(venueVal)) {
                    //var nn = Math.round(venueVal);
                    venueVal = parseFloat(venueVal);
                    var nn = venueVal.toFixed(2);
                    $(this).val(nn);
                    //VenueSubTotal += parseInt($(this).val());
                    VenueSubTotal = (VenueSubTotal * 10 + parseFloat(nn) * 10) / 10;

                }

            });

            venueSliced.find("input[id*='VenueSubTotal']").val(VenueSubTotal.toFixed(2));

            Total += VenueSubTotal;

        });
        $("input[id*='Total']").last().val(Total.toFixed(2));

    }
    if (worksheetPageName.indexOf("WS3") > -1 || worksheetPageName.indexOf("WS4") > -1) {
        var Total = 0;










        $("input[id*='Funding']").each(function () {

            var fundingVal = $(this).val();
            if (fundingVal.indexOf("$") > -1) {
                fundingVal = fundingVal.substr(fundingVal.indexOf("$") + 1);
                $(this).val(fundingVal);
            }
            if (fundingVal.indexOf(",") > -1) {
                fundingVal = fundingVal.replace(/,/g, "");
                $(this).val(fundingVal);
            }
            if ($.isNumeric(fundingVal)) {
                //var nn = Math.round(fundingVal);
                fundingVal = parseFloat(fundingVal);
                var nn = fundingVal.toFixed(2);
                $(this).val(nn);
                Total = (Total * 10 + parseFloat(nn) * 10) / 10;
            }
        });
        $("input[id*='Total']").val(Total.toFixed(2));
    }


}


$("#s4-workspace").on('focusout', 'input[id*="Funding"]', function () { // using event delegation for this dynamic content
 
    updateTotals();
});

$("#s4-workspace").on('focusout', 'input[id*="EstTravel"]', function () { // using event delegation for this dynamic content
    var EstTravelVal = $(this).val();
    if ($.isNumeric(EstTravelVal) && $(this).val()) {
        //var nn = Math.round(EstTravelVal);
        EstTravelVal = parseFloat(EstTravelVal);
        var nn = EstTravelVal.toFixed(2);
        $(this).val(nn);

        if ($(this).closest("tr").find("input[id*='EstLaborOvertime']").val()) {

            var fundingCal;
            
            var estLaborOvertimeVal = $(this).closest("tr").find("input[id*='EstLaborOvertime']").val();
            estLaborOvertimeVal = parseFloat(estLaborOvertimeVal);
            var nn2 = estLaborOvertimeVal.toFixed(2);
            $(this).closest("tr").find("input[id*='EstLaborOvertime']").val(nn2);

            fundingCal = (parseFloat(nn) * 10 + parseFloat(nn2) * 10) / 10;

            $(this).closest("tr").find("input[id*='Funding']").val(fundingCal.toFixed(2));


        }
        else {
            $(this).closest("tr").find("input[id*='Funding']").val(nn);
        }
    }
    else {
        if ($(this).closest("tr").find("input[id*='Venue']").val()) {
            alert("Please enter a number for [" + $(this).attr("title") + "]."); $(this).val('');
        }
        else {
            $(this).val('');
        }


    }
    updateTotals();

});

$("#s4-workspace").on('focusout', 'input[id*="EstLaborOvertime"]', function () { // using event delegation for this dynamic content
    var EstLaborOvertimeVal = $(this).val();
    if ($.isNumeric(EstLaborOvertimeVal) && $(this).val()) {
        //var nn = Math.round(EstLaborOvertimeVal);
        EstLaborOvertimeVal = parseFloat(EstLaborOvertimeVal);
        var nn = EstLaborOvertimeVal.toFixed(2);
        $(this).val(nn);

        if ($(this).closest("tr").find("input[id*='EstTravel']").val()) {


            var fundingCal;

            var estTravelVal = $(this).closest("tr").find("input[id*='EstTravel']").val();
            estTravelVal = parseFloat(estTravelVal);
            var nn2 = estTravelVal.toFixed(2);
            $(this).closest("tr").find("input[id*='EstTravel']").val(nn2);

            fundingCal = (parseFloat(nn) * 10 + parseFloat(nn2) * 10) / 10;

            $(this).closest("tr").find("input[id*='Funding']").val(fundingCal.toFixed(2));


        }
        else {
            $(this).closest("tr").find("input[id*='Funding']").val(nn);
        }
    }
    else {
        if ($(this).closest("tr").find("input[id*='Venue']").val()) {
            alert("Please enter a number for [" + $(this).attr("title") + "]."); $(this).val('');
        }
        else {
            $(this).val('');
        }


    }
    updateTotals();
});

    $("#s4-workspace").on('focusout', 'input[id*="AdditionalLineItem"]', function () { // using event delegation for this dynamic content

    var additionalLineItemVal = $(this).val();
    if (additionalLineItemVal.indexOf("$") > -1) {
        additionalLineItemVal = additionalLineItemVal.substr(additionalLineItemVal.indexOf("$") + 1);
        $(this).val(additionalLineItemVal);
    }
    if (additionalLineItemVal.indexOf(",") > -1) {
        additionalLineItemVal = additionalLineItemVal.replace(/,/g, "");
        $(this).val(additionalLineItemVal);
    }
    if ($.isNumeric(additionalLineItemVal)) {
        //var nn = Math.round(additionalLineItemVal);
        additionalLineItemVal = parseFloat(additionalLineItemVal);
        var nn = additionalLineItemVal.toFixed(2);
        $(this).val(nn);
    }
    updateTotals();
});

    $("#s4-workspace").on('focusout', 'input[id*="ContractFee"]', function () { // using event delegation for this dynamic content

    var contractFeeVal = $(this).val();
    if (contractFeeVal.indexOf("$") > -1) {
        contractFeeVal = contractFeeVal.substr(contractFeeVal.indexOf("$") + 1);
        $(this).val(contractFeeVal);
    }
    if (contractFeeVal.indexOf(",") > -1) {
        contractFeeVal = contractFeeVal.replace(/,/g, "");
        $(this).val(contractFeeVal);
    }
    if ($.isNumeric(contractFeeVal)) {
        //var nn = Math.round(contractFeeVal);
        contractFeeVal = parseFloat(contractFeeVal);
        var nn = contractFeeVal.toFixed(2);
        $(this).val(nn);
    }
    updateTotals();
});

    // ----- CONOPSAPPROVALSELECT -----
    $("#s4-workspace").on('change', '.CONOPSApprovalSelect', function () { // using event delegation for this dynamic content

        var CONOPSApprovalSelectVal = $(this).val();
        if (CONOPSApprovalSelectVal == 'Not Approved') {
            $(this).closest('tr').find('input[id*="Funding"]').val('0');
            $(this).closest('tr').find('input[id*="ContractFee"]').val('0');
            $(this).closest('tr').find('input[id*="AdditionalLineItem"]').val('0');
            $(this).closest('tr').find('input[id*="EstLaborOvertime"]').val('0');
            $(this).closest('tr').find('input[id*="EstTravel"]').val('0');

        }
        else {
            $(this).closest('tr').find('input').each(function () {

                $(this).css('text-decoration', 'none');
            });
        }
        
            

        
        updateTotals();
    });


    function CancelSaveFileButton_Click() {

        SP.UI.ModalDialog.commonModalDialogClose(null, 1);
    }

//----------CONOPSApprovalAddContractor--------------
    
    function ggetCurrentUser2() {

        this.clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        this.user2 = oWeb.get_currentUser();

        clientContext.load(user2);
        clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded2), Function.createDelegate(this, onQueryFailed));
    }
    function ggetCurrentUserSucceeded2() {
       
        gCurrentUser2 = user2.get_id() + ";#" + user2.get_loginName(); 
        CONOPSApprovalAddContractor();
    }
    function CONOPSApprovalAddContractor() {

        //var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Adding Contractor", "Please wait...");

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        //this.user = oWeb.get_currentUser();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'Enter Name');
        oListItem.set_item('Contract', contractName);

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        //datedraftsaveddate = datedraftsaveddate.toLocaleString();
        datedraftsaveddate = datedraftsaveddate.toDateString();


        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }
     
        oListItem.set_item('Funding', '0');
        oListItem.set_item('ContractorRate', '0');
        oListItem.set_item('Remarks', 'None');
        oListItem.set_item('Status', 'None');
        oListItem.set_item('DutyTitlePosition', 'None');
        oListItem.set_item('Employer', 'Contractor');
        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();
        
        clientContext.load(oListItem); //clientContext.load(user);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContractorSucceeded), Function.createDelegate(this, this.CONOPSApprovalAddContractorFailed));
    }

    function CONOPSApprovalAddContractorSucceeded() {
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog	
        __doPostBack(ctrlid, '');
    }
    function CONOPSApprovalAddContractorFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
    }


    //----------CONOPSApprovalAddLineItem--------------

    function ggetCurrentUser3() {

        this.clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        this.user2 = oWeb.get_currentUser();

        clientContext.load(user2);
        clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded3), Function.createDelegate(this, onQueryFailed));
    }
    function ggetCurrentUserSucceeded3() {

        gCurrentUser2 = user2.get_id() + ";#" + user2.get_loginName();
        CONOPSApprovalAddLineItem();
    }
    function CONOPSApprovalAddLineItem() {

        //var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Adding Contractor", "Please wait...");

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        //this.user = oWeb.get_currentUser();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'Enter Title');
        oListItem.set_item('Contract', contractName);

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        //datedraftsaveddate = datedraftsaveddate.toLocaleString();
        datedraftsaveddate = datedraftsaveddate.toDateString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }

        oListItem.set_item('AdditionalLineItem', '0');
        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem); //clientContext.load(user);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddLineItemSucceeded), Function.createDelegate(this, this.CONOPSApprovalAddLineItemFailed));
    }

    function CONOPSApprovalAddLineItemSucceeded() {
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog	
        __doPostBack(ctrlid, '');
    }
    function CONOPSApprovalAddLineItemFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
    }


    //----------CONOPSApprovalAddContract--------------

    function ggetCurrentUser4() {

        this.clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        this.user2 = oWeb.get_currentUser();

        clientContext.load(user2);
        clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded4), Function.createDelegate(this, onQueryFailed));
    }
    function ggetCurrentUserSucceeded4() {

        gCurrentUser2 = user2.get_id() + ";#" + user2.get_loginName();
        CONOPSApprovalAddContract();
    }
    function CONOPSApprovalAddContract() {
        
        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'Contract');
        oListItem.set_item('Contract', 'Enter Contract');

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem); 
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContract2), Function.createDelegate(this, this.CONOPSApprovalAddContractFailed));
    
        //}
    }

    function CONOPSApprovalAddContract2() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'Enter Name');
        oListItem.set_item('Contract', 'Enter Contract');
        oListItem.set_item('Employer', "Contractor");
        oListItem.set_item('Funding', "0");
        oListItem.set_item('ContractorRate', "0");
        oListItem.set_item('Remarks', "None");
        oListItem.set_item('Status', "None");
        oListItem.set_item('DutyTitlePosition', "None");

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContract3), Function.createDelegate(this, this.CONOPSApprovalAddContractFailed));
        

    }

    function CONOPSApprovalAddContract3() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'None');

        oListItem.set_item('Contract', 'Enter Contract');
        oListItem.set_item('AdditionalLineItem', "0");


        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContract4), Function.createDelegate(this, this.CONOPSApprovalAddContractFailed));


    }

    function CONOPSApprovalAddContract4() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'HoursPerYear');
    oListItem.set_item('Contract', 'Enter Contract');
        oListItem.set_item('HoursPerYear', "0");


        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContract5), Function.createDelegate(this, this.CONOPSApprovalAddContractFailed));


    }

    function CONOPSApprovalAddContract5() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'ContractFee');
    oListItem.set_item('Contract', 'Enter Contract');
        oListItem.set_item('ContractFee', "0");


        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContract6), Function.createDelegate(this, this.CONOPSApprovalAddContractFailed));


    }

    function CONOPSApprovalAddContract6() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'ContractTotal');
    oListItem.set_item('Contract', 'Enter Contract');
        oListItem.set_item('ContractTotal', "0");


        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString(); 

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContract7), Function.createDelegate(this, this.CONOPSApprovalAddContractFailed));


    }

    function CONOPSApprovalAddContract7() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'ContractsSubTotal');

        oListItem.set_item('Contract', 'Enter Contract');
        oListItem.set_item('ContractsSubTotal', "0");


        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddContractDoPostBack), Function.createDelegate(this, this.CONOPSApprovalAddContractFailed));


    }


    function CONOPSApprovalAddContractDoPostBack() {
        alert('Contract added. Enter Contract id or name next.');
        __doPostBack(ctrlid, '');
    }
    function CONOPSApprovalAddContractFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
    }

//======


    function updateBullet() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSApprovalProgress");

        var camlQuery = new SP.CamlQuery();
        camlQuery.set_viewXml('<View><Query><Where><And><And><Eq><FieldRef Name="OperationalTestAgency"/><Value Type="Choice">' + otatoupdate + '</Value></Eq><Eq><FieldRef Name="Title" /><Value Type="Text">WS' + wsNum + '</Value></Eq></And><Eq><FieldRef Name="Submitted" /><Value Type="Text">Yes</Value></Eq></And></Where></Query></View>');
        this.collListItem = oList.getItems(camlQuery);
        clientContext.load(collListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.updateBulletSucceeded), Function.createDelegate(this, this.updateBulletFailed));


    }
    function updateBulletSucceeded() {
        if (collListItem.get_count() > 0) {
            //alert("collListItem.get_count()" + collListItem.get_count());
            $(".submittedUL[id*='" + otatoupdate + "']").children().eq(wsNumInt).css("list-style-image", "url(/_layouts/Images/DCAPXSolution/tinytick.gif)");

        }

    }
    function updateBulletFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
    }




//=========================
    
    function updateContract(){
        ExecuteOrDelayUntilScriptLoaded(updateContract2, "sp.js");
    }

    function updateContract2() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + updateContractOTAShort);

        var camlQuery = new SP.CamlQuery();

        camlQuery.set_viewXml('<View><Query><Where><And><And><Eq><FieldRef Name="ContentType" /><Value Type="Computed">WS' + getParameterByName("ws") + '</Value></Eq><Eq><FieldRef Name="FY" /><Value Type="Text">'+updateContractFY+'</Value></Eq></And>><Eq><FieldRef Name="Contract"/><Value Type="Text">'+originalValue+'</Value></Eq></And></Where></Query></View>');
        this.collListItem = oList.getItems(camlQuery);
        clientContext.load(collListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.updateContract2Succeeded), Function.createDelegate(this, this.updateContract2Failed));


    }
    var updateContractTotalCount = 0;
    function updateContract2Succeeded() {
        var listItemEnumerator = collListItem.getEnumerator();
        updateContractCount = collListItem.get_count();

        while(listItemEnumerator.moveNext()){
            var oListItem = listItemEnumerator.get_current();
            var oListItemId = oListItem.get_id();
            updateContract3(oListItemId);
        }
    }

    function updateContract3(oListItemId) {
        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + updateContractOTAShort);

        this.oListItem = oList.getItemById(oListItemId);

        oListItem.set_item('Contract', newValue);

        oListItem.update();
        clientContext.executeQueryAsync(Function.createDelegate(this, this.updateContract3Succeeded), Function.createDelegate(this, this.updateContract2Failed));

    }
    function updateContract3Succeeded() {
        updateContractTotalCount = updateContractTotalCount + 1;
        if(updateContractTotalCount == updateContractCount){
        
            alert('Contract updated for all associated items.');
            $(".CONOPSApprovalSaveButton").removeAttr("disabled");
            $(".CONOPSApprovalSaveButton").click();
        }
        

    }
    function updateContract2Failed(sender, args) {
        alert('Request failed. ' + args.get_message());
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
    }


    //=========================

    function updateVenue() {
        ExecuteOrDelayUntilScriptLoaded(updateVenue2, "sp.js");
    }

    function updateVenue2() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + updateVenueOTAShort);

        var camlQuery = new SP.CamlQuery();

        camlQuery.set_viewXml('<View><Query><Where><And><And><Eq><FieldRef Name="ContentType" /><Value Type="Computed">WS' + getParameterByName("ws") + '</Value></Eq><Eq><FieldRef Name="FY" /><Value Type="Text">' + updateVenueFY + '</Value></Eq></And>><Eq><FieldRef Name="Venue"/><Value Type="Text">' + originalValue + '</Value></Eq></And></Where></Query></View>');
        this.collListItem = oList.getItems(camlQuery);
        clientContext.load(collListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.updateVenue2Succeeded), Function.createDelegate(this, this.updateVenue2Failed));


    }
    var updateVenueTotalCount = 0;
    function updateVenue2Succeeded() {
        var listItemEnumerator = collListItem.getEnumerator();
        updateVenueCount = collListItem.get_count();

        while (listItemEnumerator.moveNext()) {
            var oListItem = listItemEnumerator.get_current();
            var oListItemId = oListItem.get_id();
            updateVenue3(oListItemId);
        }
    }

    function updateVenue3(oListItemId) {
        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + updateVenueOTAShort);

        this.oListItem = oList.getItemById(oListItemId);

        oListItem.set_item('Venue', newValue);

        oListItem.update();
        clientContext.executeQueryAsync(Function.createDelegate(this, this.updateVenue3Succeeded), Function.createDelegate(this, this.updateVenue2Failed));

    }
    function updateVenue3Succeeded() {
        updateVenueTotalCount = updateVenueTotalCount + 1;
        if (updateVenueTotalCount == updateVenueCount) {

            alert('Venue updated for all associated items.');
            $(".CONOPSApprovalSaveButton").removeAttr("disabled");
            $(".CONOPSApprovalSaveButton").click();
        }


    }
    function updateVenue2Failed(sender, args) {
        alert('Request failed. ' + args.get_message());
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
    }

//====================CONOPSApprovalAddVenueButton===========================

    function ggetCurrentUser5() {

        this.clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        this.user2 = oWeb.get_currentUser();

        clientContext.load(user2);
        clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded5), Function.createDelegate(this, onQueryFailed));
    }
    function ggetCurrentUserSucceeded5() {

        gCurrentUser2 = user2.get_id() + ";#" + user2.get_loginName();
        CONOPSApprovalAddVenue();
    }
    function CONOPSApprovalAddVenue() {
        //var rFalse = "";
        //$(".WSGroupStartRow").each(function () {

        //    var aVenueOnThisPage = $(this).find("input").val();
        //    if (venueName == aVenueOnThisPage) {
        //        rFalse = "yes";
        //        alert("Please enter a unique Venue."); return false;
        //    }
        //});

        //if (venueName == "Enter Venue" || venueName == "" || rFalse == "yes") {
        //    alert("The following Venue is invalid: " + venueName); return false;
        //}
        //else {

            var clientContext = new SP.ClientContext.get_current();
            var oWeb = clientContext.get_web();
            var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

            var itemCreateInfo = new SP.ListItemCreationInformation();
            this.oListItem = oList.addItem(itemCreateInfo);

            oListItem.set_item('Title', 'Enter Event');
            oListItem.set_item('Venue', 'Enter Venue');
            oListItem.set_item('Dates', "None");
            oListItem.set_item('People', "0");
            oListItem.set_item('Funding', "0");
            oListItem.set_item('EventLocation', "None");
            oListItem.set_item('EstTravel', "0");
            oListItem.set_item('EstLaborOvertime', "0");


            var datedraftsaveddate = new Date();
            var TimeDraftSaved = datedraftsaveddate.getTime();
            datedraftsaveddate = datedraftsaveddate.toLocaleString();

            var tab;
            if (getParameterByName("tab") == "AOReview") {
                tab = "AO Recommendation";
            }
            if (getParameterByName("tab") == "PMReview") {
                tab = "PM Preapproval";
            }
            if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
                tab = "Deputy Director Approval";
            }


            oListItem.set_item('OTA', getParameterByName('otashort'));
            oListItem.set_item('FY', getParameterByName('fy'));
            oListItem.set_item('CONOPSApproval', tab);
            oListItem.set_item('ContentTypeId', '0x0100723D11F834A847FE81D94D02BD3DF83F');
            oListItem.set_item('DateDraftSaved', datedraftsaveddate);
            oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
            oListItem.set_item('DraftSavedBy', gCurrentUser2);

            oListItem.update();

            clientContext.load(oListItem);
            clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddVenue2), Function.createDelegate(this, this.CONOPSApprovalAddVenueFailed));

        //}
    }

    function CONOPSApprovalAddVenue2() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'VenueSubTotal');
        oListItem.set_item('Venue', 'Enter Venue');
        oListItem.set_item('VenueSubTotal', "0");
       

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }


        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100723D11F834A847FE81D94D02BD3DF83F');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddVenueDoPostBack), Function.createDelegate(this, this.CONOPSApprovalAddVenueFailed));


    }

    function CONOPSApprovalAddVenueDoPostBack() {
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog	
       
        alert('Venue added. Enter Venue title next.');
        __doPostBack(ctrlid, '');

    }
    function CONOPSApprovalAddVenueFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
    }

    //======


//----------CONOPSApprovalAddActivityEventButton--------------

    function ggetCurrentUser6() {

        this.clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        this.user2 = oWeb.get_currentUser();

        clientContext.load(user2);
        clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded6), Function.createDelegate(this, onQueryFailed));
    }
    function ggetCurrentUserSucceeded6() {

        gCurrentUser2 = user2.get_id() + ";#" + user2.get_loginName();
        CONOPSApprovalAddActivityEventButton();
    }
    function CONOPSApprovalAddActivityEventButton() {


        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'Enter Event');
        oListItem.set_item('Venue', venueName);
        oListItem.set_item('Dates', "None");
        oListItem.set_item('People', "0");
        oListItem.set_item('Funding', "0");
        oListItem.set_item('EventLocation', "None");
        oListItem.set_item('EstTravel', "0");
        oListItem.set_item('EstLaborOvertime', "0");

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toDateString();

        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }

        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100723D11F834A847FE81D94D02BD3DF83F');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem); 
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddActivityEventButtonSucceeded), Function.createDelegate(this, this.CONOPSApprovalAddActivityEventButtonFailed));
    }

    function CONOPSApprovalAddActivityEventButtonSucceeded() {
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
        alert("Added Activity/Event. Enter Event Title next.");
        __doPostBack(ctrlid, '');
    }
    function CONOPSApprovalAddActivityEventButtonFailed(sender, args) {
        alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace());
        //SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog
    }

//----------CONOPSApprovalAddEventButton--------------

    function ggetCurrentUser7() {

        this.clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        this.user2 = oWeb.get_currentUser();

        clientContext.load(user2);
        clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded7), Function.createDelegate(this, onQueryFailed));
    }
    function ggetCurrentUserSucceeded7() {

        gCurrentUser2 = user2.get_id() + ";#" + user2.get_loginName();
        CONOPSApprovalAddEvent();
    }
    function CONOPSApprovalAddEvent() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'Enter Event Name');

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toDateString();


        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }

        oListItem.set_item('Funding', '0');
        oListItem.set_item('Remarks', 'None');
        oListItem.set_item('Dates', 'None');
        oListItem.set_item('People', '0');
        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x0100A44000B718A4438B83F9034100DD7EFB');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem); 
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddEventSucceeded), Function.createDelegate(this, this.CONOPSApprovalAddEventFailed));
    }

    function CONOPSApprovalAddEventSucceeded() {
        alert("Event added. Enter Event Name next.");
        __doPostBack(ctrlid, '');
    }
    function CONOPSApprovalAddEventFailed(sender, args) {
        alert('Request failed. ' + args.get_message());
    }

//----------CONOPSApprovalAddItemButton--------------

    function ggetCurrentUser8() {

        this.clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        this.user2 = oWeb.get_currentUser();

        clientContext.load(user2);
        clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded8), Function.createDelegate(this, onQueryFailed));
    }
    function ggetCurrentUserSucceeded8() {

        gCurrentUser2 = user2.get_id() + ";#" + user2.get_loginName();
        CONOPSApprovalAddItem();
    }
    function CONOPSApprovalAddItem() {

        var clientContext = new SP.ClientContext.get_current();
        var oWeb = clientContext.get_web();
        var oList = clientContext.get_web().get_lists().getByTitle("CONOPSDevWS" + getParameterByName("otashort"));

        var itemCreateInfo = new SP.ListItemCreationInformation();
        this.oListItem = oList.addItem(itemCreateInfo);

        oListItem.set_item('Title', 'Enter Item');

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toDateString();


        var tab;
        if (getParameterByName("tab") == "AOReview") {
            tab = "AO Recommendation";
        }
        if (getParameterByName("tab") == "PMReview") {
            tab = "PM Preapproval";
        }
        if (getParameterByName("tab") == "DeputyDirectorReviewandApproval") {
            tab = "Deputy Director Approval";
        }

        oListItem.set_item('Funding', '0');
        oListItem.set_item('Remarks', 'None');
        oListItem.set_item('Number', '0');
        oListItem.set_item('OTA', getParameterByName('otashort'));
        oListItem.set_item('FY', getParameterByName('fy'));
        oListItem.set_item('CONOPSApproval', tab);
        oListItem.set_item('ContentTypeId', '0x01007ABBDC3DF7EE4D0C84E26CE68A88E02A');
        oListItem.set_item('DateDraftSaved', datedraftsaveddate);
        oListItem.set_item('TimeDraftSaved', TimeDraftSaved);
        oListItem.set_item('DraftSavedBy', gCurrentUser2);

        oListItem.update();

        clientContext.load(oListItem); 
        clientContext.executeQueryAsync(Function.createDelegate(this, this.CONOPSApprovalAddItemSucceeded), Function.createDelegate(this, this.CONOPSApprovalAddItemFailed));
    }

    function CONOPSApprovalAddItemSucceeded() {
        alert("Item added. Enter Item Description next.");
        __doPostBack(ctrlid, '');
    }
    function CONOPSApprovalAddItemFailed(sender, args) {
        alert('Request failed. ' + args.get_message());
    }

