﻿function getWorksheetData(wsListForOTA, fytofilteron, wsNumFromPageName){ 
	var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Retrieving data", "Please wait..."); 
	if(wsNumFromPageName == "1"){
		getWorksheetDataWS1(wsListForOTA, fytofilteron, wsNumFromPageName);
	}
	else if(wsNumFromPageName == "2"){
		getWorksheetDataWS2(wsListForOTA, fytofilteron, wsNumFromPageName);
	}
	else {
		getWorksheetDataWS3And4(wsListForOTA, fytofilteron, wsNumFromPageName);
	}

}

function getWorksheetDataWS1(wsListForOTA, fytofilteron, wsNumFromPageName){ 
    var clientContext = new SP.ClientContext.get_current();    
    var oList = clientContext.get_web().get_lists().getByTitle(wsListForOTA);
	this.wsListForOTA= wsListForOTA;
	this.worksheetNum = wsNumFromPageName;
	this.fytofilteron = fytofilteron;
	var ct = "WS"+wsNumFromPageName; 
    var camlQueryContracts = new SP.CamlQuery(); // worksheet #1
    camlQueryContracts.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + fytofilteron + "</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">" + ct + "</Value></Eq></And><Eq><FieldRef Name=\"CONOPSApproval\"/><Value Type=\"Text\">Baseline OTA Submission</Value></Eq></And></Where></Query></View>");
    
	this.collListItemContracts = oList.getItems(camlQueryContracts);	
    
    clientContext.load(collListItemContracts);    
    clientContext.executeQueryAsync(Function.createDelegate(this, this.getWorksheetDataSucceeded), Function.createDelegate(this, this.onQueryFailed));


}
function getWorksheetDataWS2(wsListForOTA, fytofilteron, wsNumFromPageName){ 
    var clientContext = new SP.ClientContext.get_current();  
    var oList = clientContext.get_web().get_lists().getByTitle(wsListForOTA);
	this.wsListForOTA= wsListForOTA;
	this.worksheetNum = wsNumFromPageName;
	this.fytofilteron = fytofilteron;
	var ct = "WS"+wsNumFromPageName; 
    var camlQueryVenue = new SP.CamlQuery(); // worksheet #2
    camlQueryVenue.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">"+fytofilteron+"</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">"+ct+"</Value></Eq></And></Where></Query></View>");

	this.collListItemVenue = oList.getItems(camlQueryVenue);
    
    clientContext.load(collListItemVenue);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.getWorksheetDataSucceeded), Function.createDelegate(this, this.onQueryFailed));

}
function getWorksheetDataWS3And4(wsListForOTA, fytofilteron, wsNumFromPageName){ 
    var clientContext = new SP.ClientContext.get_current();  
    var oList = clientContext.get_web().get_lists().getByTitle(wsListForOTA);
	this.wsListForOTA= wsListForOTA;
	this.worksheetNum = wsNumFromPageName;
	this.fytofilteron = fytofilteron;
	var ct = "WS"+wsNumFromPageName; 
    var camlQuery = new SP.CamlQuery();
    // returns items in descending order by id for worksheets #3 and #4
    camlQuery.set_viewXml("<View><Query><OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + fytofilteron + "</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">" + ct + "</Value></Eq></And><Eq><FieldRef Name=\"CONOPSApproval\"/><Value Type=\"Text\">Baseline OTA Submission</Value></Eq></And></Where></Query></View>");

    this.collListItem = oList.getItems(camlQuery);
    
    clientContext.load(collListItem);
    clientContext.executeQueryAsync(Function.createDelegate(this, this.getWorksheetDataSucceeded), Function.createDelegate(this, this.onQueryFailed));

}

function getWorksheetDataSucceeded(sender, args){

    var DutyTitlePosition = "";
    var DateDraftSaved = "";
    var Title = "";
    var Status = "";
    var Remarks = "";
    var ContractorRate = "";
    var GSLevel = "";
    var Funding = "";
    var GovLaborMonth = "";
    var Employer = "";
    var Contract = "";
    var ContractFee = "";
    var ContractTotal = "";
    var AdditionalLineItem = "";
    var MilitarySubTotal = "";
    var Total = "";
    var ContractsSubTotal = "";
    var HoursPerYear = "";

    var Dates = "";
    var People = "";
    var EventLocation = "";
    var EstTravel = "";
    var EstLaborOvertime = "";
    var Venue = "";
    var VenueSubTotal = "";

    var ven = "";
	
    if(worksheetNum == "1"){ // worksheet #1
        var commonRowsEverythingElse = new Array();
        var contractRange = new Array();
        var AdditionalLineItemRowsWithDataContractIdContractSubTotalId = new Array();
        var commonRowsContract = new Array();
        var commonRowsAdditionalLineItem = new Array();
        var commonRowsHoursPerYearAmount = new Array();
        var commonRowsContractFee = new Array();
        var commonRowsContractsSubTotal = new Array();
        var commonRowsContractTotal = new Array();
        var firstRows = new Array();
        var firstRowsRow = new Array();
        var GovLaborMonthId;
        var fromId;
        var listItemInfoContracts = "";
        var listItemEnumeratorContracts = collListItemContracts.getEnumerator();
        while(listItemEnumeratorContracts.moveNext()){	
            var oListItem = listItemEnumeratorContracts.get_current();		
            var oListItemId = oListItem.get_id().toString();	

            // break if DateDraftSaved is different (we just want the latest set of items with the same DateDraftSaved value)
            if(DateDraftSaved !== oListItem.get_item("DateDraftSaved") && DateDraftSaved !== ""){
                fromId = oListItem.get_id()+1;
                break;
            } else {
                DateDraftSaved = oListItem.get_item("DateDraftSaved");			
            }
			
            if(oListItem.get_item("Title")=="Total"){			
                $("#Total").val(oListItem.get_item("Total"));
                $("#Total").closest("tr").find($("input#Title:hidden")).val("Total");		
            }
			
                // contracts
            else if(oListItem.get_item("Title")=="ContractsSubTotal"){		
                
                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Contract") !== null && oListItem.get_item("Contract") !== "null") { Contract = oListItem.get_item("Contract"); }
                if (oListItem.get_item("ContractsSubTotal") !== null && oListItem.get_item("ContractsSubTotal") !== "null") { ContractsSubTotal = oListItem.get_item("ContractsSubTotal"); }

                commonRowsContractsSubTotal.push(oListItem.get_id().toString() + ']]]' + Title + ']]]' + Contract + ']]]' + ContractsSubTotal);
            }			
            else if(oListItem.get_item("Title")=="ContractTotal"){
				
                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Contract") !== null && oListItem.get_item("Contract") !== "null") { Contract = oListItem.get_item("Contract"); }
                if (oListItem.get_item("ContractTotal") !== null && oListItem.get_item("ContractTotal") !== "null") { ContractTotal = oListItem.get_item("ContractTotal"); }

                commonRowsContractTotal.push(Title + ']]]' + Contract + ']]]' + ContractTotal);
            }
            else if(oListItem.get_item("Title")=="ContractFee"){

                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Contract") !== null && oListItem.get_item("Contract") !== "null") { Contract = oListItem.get_item("Contract"); }
                if (oListItem.get_item("ContractFee") !== null && oListItem.get_item("ContractFee") !== "null") { ContractFee = oListItem.get_item("ContractFee"); }

                commonRowsContractFee.push(Title + ']]]' + Contract + ']]]' +  ContractFee); 
            }
            else if(oListItem.get_item("Title")=="HoursPerYear"){
				
                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Contract") !== null && oListItem.get_item("Contract") !== "null") { Contract = oListItem.get_item("Contract"); }
                if (oListItem.get_item("HoursPerYear") !== null && oListItem.get_item("HoursPerYear") !== "null") { HoursPerYear = oListItem.get_item("HoursPerYear"); }			    

                commonRowsHoursPerYearAmount.push(Title + ']]]' + Contract + ']]]' + HoursPerYear);
            }
            else if (oListItem.get_item("AdditionalLineItem") !== null) {

                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Contract") !== null && oListItem.get_item("Contract") !== "null") { Contract = oListItem.get_item("Contract"); }
                if (oListItem.get_item("AdditionalLineItem") !== null && oListItem.get_item("AdditionalLineItem") !== "null") { AdditionalLineItem = oListItem.get_item("AdditionalLineItem"); }

                commonRowsAdditionalLineItem.push(oListItem.get_id().toString() + ']]]' + Title + ']]]' + Contract + ']]]' + AdditionalLineItem);
            }	
            else if(oListItem.get_item("Title")=="Contract"){

                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Contract") !== null && oListItem.get_item("Contract") !== "null") { Contract = oListItem.get_item("Contract"); }

                commonRowsContract.push(oListItem.get_id().toString() + ']]]' + Title + ']]]' + Contract);
            }	
			
                // top rows
            else if(oListItem.get_item("Title")=="MilitarySubTotal"){			
                $("#MilitarySubTotal").val(oListItem.get_item("MilitarySubTotal"));
                $("#MilitarySubTotal").closest("tr").find($("input#Title:hidden")).val("MilitarySubTotal");		
            }
            else if(oListItem.get_item("Title")=="GovLaborYear"){			
                $("#GovLaborYear").val(oListItem.get_item("GovLaborYear"));
                $("#GovLaborYear").closest("tr").find($("input#Title:hidden")).val("GovLaborYear");		
            }
            else if(oListItem.get_item("Title")=="GovLaborMonth"){			
                GovLaborMonthId = oListItem.get_id();
                $("#GovLaborMonth").val(oListItem.get_item("GovLaborMonth"));
                $("#GovLaborMonth").closest("tr").find($("input#Title:hidden")).val("GovLaborMonth");		
            }
            else if (GovLaborMonthId > oListItem.get_id()) {
			    
                if (oListItem.get_item("DutyTitlePosition") !== null && oListItem.get_item("DutyTitlePosition") !== "null") { DutyTitlePosition = oListItem.get_item("DutyTitlePosition"); }
                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Status") !== null && oListItem.get_item("Status") !== "null") { Status = oListItem.get_item("Status"); }
                if (oListItem.get_item("Remarks") !== null && oListItem.get_item("Remarks") !== "null") { Remarks = oListItem.get_item("Remarks"); }
                if (oListItem.get_item("GSLevel") !== null && oListItem.get_item("GSLevel") !== "null") { GSLevel = oListItem.get_item("GSLevel"); }
                if (oListItem.get_item("Funding") !== null && oListItem.get_item("Funding") !== "null") { Funding = oListItem.get_item("Funding"); }
                //if (oListItem.get_item("Employer") !== null && oListItem.get_item("Employer") !== "null") { Employer = oListItem.get_item("Employer"); }
                Employer = "MilitaryOrGovernmentCivilian";

                firstRows.push(Title + ']]]' + DutyTitlePosition + ']]]' +  Status + ']]]' + Remarks + ']]]' + GSLevel + ']]]' + Employer + ']]]' + Funding);

            }
			
                // everything else
            else {

                if (oListItem.get_item("DutyTitlePosition") !== null && oListItem.get_item("DutyTitlePosition") !== "null") { DutyTitlePosition = oListItem.get_item("DutyTitlePosition"); }
                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Status") !== null && oListItem.get_item("Status") !== "null") { Status = oListItem.get_item("Status"); }
                if (oListItem.get_item("Remarks") !== null && oListItem.get_item("Remarks") !== "null") { Remarks = oListItem.get_item("Remarks"); }
                if (oListItem.get_item("ContractorRate") !== null && oListItem.get_item("ContractorRate") !== "null") { ContractorRate = oListItem.get_item("ContractorRate"); }
                if (oListItem.get_item("Funding") !== null && oListItem.get_item("Funding") !== "null") { Funding = oListItem.get_item("Funding"); }
                //if (oListItem.get_item("Employer") !== null && oListItem.get_item("Employer") !== "null") { Employer = oListItem.get_item("Employer"); }
                if (oListItem.get_item("Contract") !== null && oListItem.get_item("Contract") !== "null") { Contract = oListItem.get_item("Contract"); }
                Employer = "Contractor";

                commonRowsEverythingElse.push(Title + ']]]' + Contract + ']]]' + ContractorRate + ']]]' + DutyTitlePosition + ']]]' + Employer + ']]]' + Funding + ']]]' + Remarks + ']]]' + Status);

            }


        } // end while
		
        firstRows.reverse();
        commonRowsContractsSubTotal.reverse();
        commonRowsContractTotal.reverse();
        commonRowsContractFee.reverse();
        commonRowsHoursPerYearAmount.reverse();
        commonRowsAdditionalLineItem.reverse();
        commonRowsContract.reverse();
        commonRowsEverythingElse.reverse();
		
        // firstRows
        for(i=0; i < firstRows.length; i++){			
            if(i>0){
                $("input#Employer[value='MilitaryOrGovernmentCivilian']").eq(i-1).closest("tr").find(".WSBtnAddRow").click();
            } 
        }

        for(i=0; i < firstRows.length; i++){
            firstRowsRow = firstRows[i].toString().split(']]]');
            setfirstRowsRowWithData(firstRowsRow, i);
        }
        function setfirstRowsRowWithData(firstRowsRow, i){
            var firstRowsRowToSet = $("input#Employer[value='MilitaryOrGovernmentCivilian']").eq(i).closest("tr");
            $(firstRowsRowToSet).find("#Title").val(firstRowsRow[0]).end().find("#DutyTitlePosition").val(firstRowsRow[1]).end().find("#Status").val(firstRowsRow[2]).end().find("#Remarks").val(firstRowsRow[3]).end().find("#GSLevel").val(firstRowsRow[4]).end().find("#Employer").val(firstRowsRow[5]).end().find("#Funding").val(firstRowsRow[6]);			
        }	
        // commonRowsContractsSubTotal
        for(i=0; i < commonRowsContractsSubTotal.length; i++){			
            if(i>0){
                $(".WSBtnAddGroup").eq(i-1).click();				
            } 
        }
        for(i=0; i < commonRowsContractsSubTotal.length; i++){			
            var commonRowsContractsSubTotalRow = commonRowsContractsSubTotal[i].toString().split(']]]');
            setContractsSubTotalRowWithData(commonRowsContractsSubTotalRow, i);
        }
        function setContractsSubTotalRowWithData(commonRowsContractsSubTotalRow, i){
            var contractRowToSet = $("input#Contract:visible").eq(i).closest("tr");
            $(contractRowToSet).find("#Title").val("Contract").end().find("#Contract").val(commonRowsContractsSubTotalRow[2]);			      
            $("tr.ContractItem").eq(i).attr("title",commonRowsContractsSubTotalRow[2]);
            $("input#ContractsSubTotal").eq(i).closest("tr").find("#Title").val(commonRowsContractsSubTotalRow[1]).end().find("#Contract").val(commonRowsContractsSubTotalRow[2]).end().find("#ContractsSubTotal").val(commonRowsContractsSubTotalRow[3]);			
        }	
		
		
		
        // commonRowsContractTotal
        for(i=0; i < commonRowsContractTotal.length; i++){			
            var commonRowsContractTotalRow = commonRowsContractTotal[i].toString().split(']]]');
            setContractTotalRowWithData(commonRowsContractTotalRow, i);
        }
        function setContractTotalRowWithData(commonRowsContractTotalRow, i){
            $("input#ContractTotal").eq(i).closest("tr").find("#Title").val(commonRowsContractTotalRow[0]).end().find("#Contract").val(commonRowsContractTotalRow[1]).end().find("#ContractTotal").val(commonRowsContractTotalRow[2]);			
        }	
		
        // commonRowsContractFee
        for(i=0; i < commonRowsContractFee.length; i++){			
            var commonRowsContractFeeRow = commonRowsContractFee[i].toString().split(']]]');
            setContractFeeRowWithData(commonRowsContractFeeRow, i);
        }
        function setContractFeeRowWithData(commonRowsContractFeeRow, i){
            $("input#ContractFee").eq(i).closest("tr").find("#Title").val(commonRowsContractFeeRow[0]).end().find("#Contract").val(commonRowsContractFeeRow[1]).end().find("#ContractFee").val(commonRowsContractFeeRow[2]); // .end().find("#ContractFeePercentage").val(commonRowsContractFeeRow[3]);			
        }	
		
        // commonRowsHoursPerYearAmount
        for(i=0; i < commonRowsHoursPerYearAmount.length; i++){			
            var commonRowsHoursPerYearAmountRow = commonRowsHoursPerYearAmount[i].toString().split(']]]');
            setHoursPerYearAmountRowWithData(commonRowsHoursPerYearAmountRow, i);
        }
        function setHoursPerYearAmountRowWithData(commonRowsHoursPerYearAmountRow, i){
            $("input#HoursPerYear").eq(i).closest("tr").find("#Title").val(commonRowsHoursPerYearAmountRow[0]).end().find("#Contract").val(commonRowsHoursPerYearAmountRow[1]).end().find("#HoursPerYear").val(commonRowsHoursPerYearAmountRow[2]); // .end().find("#HoursPerYearAmount").val(commonRowsHoursPerYearAmountRow[3]);			
        }	
	
        // commonRowsAdditionalLineItem 
        $("input#AdditionalLineItem").closest('tr').addClass("FirstAdditionalLineItem");
					
        var contractRangeInc = 0;
		
        for(i=0; i < commonRowsContract.length; i++){ // set contractRage		
            var commonRowsContractRow = commonRowsContract[i].toString().split(']]]');
            var commonRowsContractsSubTotalRow = commonRowsContractsSubTotal[i].toString().split(']]]');
            var ContractId = commonRowsContractRow[0];
            var ContractSubTotalId = commonRowsContractsSubTotalRow[0];
            contractRange.push(parseInt(ContractId)+'|'+parseInt(ContractSubTotalId));
        }		
        var ss = 0;
        for(i=0; i < commonRowsAdditionalLineItem.length; i++){		
			
            var thiscontractRange = contractRange[contractRangeInc].toString().split('|');
            var ContractId = thiscontractRange[0];
            var ContractSubTotalId = thiscontractRange[1];
			
            var commonRowsAdditionalLineItemRow = commonRowsAdditionalLineItem[i].toString().split(']]]');
            var AdditionalLineItemId = commonRowsAdditionalLineItemRow[0];
			
            if(parseInt(AdditionalLineItemId) > parseInt(ContractId) && parseInt(AdditionalLineItemId) < parseInt(ContractSubTotalId)){
                if(ss>0){
                    $(".FirstAdditionalLineItem").eq(contractRangeInc).find(".WSBtnAddRow").click();
                } 
                ss++;

            } else {
                contractRangeInc++;
                ss=0;
                i=i-1;
            }							
        }
		
        for(i=0; i < commonRowsAdditionalLineItem.length; i++){			
            var commonRowsAdditionalLineItemRow = commonRowsAdditionalLineItem[i].toString().split(']]]');
            setAdditionalLineItemRowWithData(commonRowsAdditionalLineItemRow, i);
        }
        function setAdditionalLineItemRowWithData(commonRowsAdditionalLineItemRow, i){
            $("input#AdditionalLineItem").eq(i).closest("tr").find("#Title").val(commonRowsAdditionalLineItemRow[1]).end().find("#Contract").val(commonRowsAdditionalLineItemRow[2]).end().find("#AdditionalLineItem").val(commonRowsAdditionalLineItemRow[3]);			
        }	
				

        // commonRowsEverythingElse
				
        var contractEverythingElseRowIndexA;
        var contractEverythingElseRowIndexB;
        for(i=0; i < commonRowsEverythingElse.length; i++){
            var commonRowsEverythingElseRow = commonRowsEverythingElse[i].toString().split(']]]');
            createEverythingElseRows(commonRowsEverythingElseRow, i);
        }
        function createEverythingElseRows(commonRowsEverythingElseRow, i){
            var contract = commonRowsEverythingElseRow[1];
            var contractEverythingElseRowToSet;
								
			
            $(".WSGroupStartRow").find("input#Contract").each(function(){
                if($(this).val() == contract){
                    contractEverythingElseRowToSet = $(this).closest('tr').next();
                    contractEverythingElseRowIndexA = contractEverythingElseRowToSet.index(); // alert(contractEverythingElseRowIndexA );
                }	
            });
			 
            if(contractEverythingElseRowIndexA == contractEverythingElseRowIndexB){
			
                $(contractEverythingElseRowToSet).find(".WSBtnAddRow").click();
			
            } else {
                contractEverythingElseRowIndexB = contractEverythingElseRowIndexA;
            }
 
			 
        }
		
        for(i=0; i < commonRowsEverythingElse.length; i++){
            var commonRowsEverythingElseRow = commonRowsEverythingElse[i].toString().split(']]]');
            setsEverythingElseRowWithData(commonRowsEverythingElseRow, i);
        }
        function setsEverythingElseRowWithData(commonRowsEverythingElseRow, i){
            var commonRowsEverythingElseRowToSet = $(".ContractItem").eq(i).closest("tr");
            $(commonRowsEverythingElseRowToSet).find("#Title").val(commonRowsEverythingElseRow[0]).end().find("#Contract").val(commonRowsEverythingElseRow[1]).end().find("#ContractorRate").val(commonRowsEverythingElseRow[2]).end().find("#DutyTitlePosition").val(commonRowsEverythingElseRow[3]).end().find("#Employer").val(commonRowsEverythingElseRow[4]).end().find("#Funding").val(commonRowsEverythingElseRow[5]).end().find("#Remarks").val(commonRowsEverythingElseRow[6]).end().find("#Status").val(commonRowsEverythingElseRow[7]);

        }
		
    } 

	
	
    if(worksheetNum == "2"){ // worksheet #2
        //	builds blank venue groups of rows first and gets set of items
        var commonRowsRaw = new Array();
        var commonRows = new Array();
        var commonRowsVenueSubTotal = new Array();
        var commonRowsWithData = new Array();
        var commonRowWithData = new Array();
        var commonRowsWithDataCount = 0;
        var fromId;
        var listItemInfoVenue = "";
        var listItemEnumeratorVenue = collListItemVenue.getEnumerator();
        while(listItemEnumeratorVenue.moveNext()){	
            var oListItem = listItemEnumeratorVenue.get_current();		
            var oListItemId = oListItem.get_id().toString();	
			 

            // break if DateDraftSaved is different (we just want the latest set of items with the same DateDraftSaved value)
            if(DateDraftSaved !== oListItem.get_item("DateDraftSaved") && DateDraftSaved !== ""){
                fromId = oListItem.get_id()+1;
                break;
            } else {
                DateDraftSaved = oListItem.get_item("DateDraftSaved");			
            }			
            if(oListItem.get_item("Title")=="Total"){			
                $("#Total").val(oListItem.get_item("Total"));
                $("#Total").closest("tr").find($("input#Title:hidden")).val("Total");
			
            }
			
            else if (oListItem.get_item("VenueSubTotal") !== null) {
        
                if (oListItem.get_item("VenueSubTotal") !== null && oListItem.get_item("VenueSubTotal") !== "null") { VenueSubTotal = oListItem.get_item("VenueSubTotal"); }

                commonRowsVenueSubTotal.push(VenueSubTotal);
            }
			
            else {			

                if (oListItem.get_item("Title") !== null && oListItem.get_item("Title") !== "null") { Title = oListItem.get_item("Title"); }
                if (oListItem.get_item("Dates") !== null && oListItem.get_item("Dates") !== "null") { Dates = oListItem.get_item("Dates"); }
                if (oListItem.get_item("People") !== null && oListItem.get_item("People") !== "null") { People = oListItem.get_item("People"); }
                if (oListItem.get_item("EventLocation") !== null && oListItem.get_item("EventLocation") !== "null") { EventLocation = oListItem.get_item("EventLocation"); }
                if (oListItem.get_item("EstTravel") !== null && oListItem.get_item("EstTravel") !== "null") { EstTravel = oListItem.get_item("EstTravel"); }
                if (oListItem.get_item("EstLaborOvertime") !== null && oListItem.get_item("EstLaborOvertime") !== "null") { EstLaborOvertime = oListItem.get_item("EstLaborOvertime"); }
                if (oListItem.get_item("Venue") !== null && oListItem.get_item("Venue") !== "null") { Venue = oListItem.get_item("Venue"); }
                if (oListItem.get_item("Funding") !== null && oListItem.get_item("Funding") !== "null") { Funding = oListItem.get_item("Funding"); }

                commonRowsWithData.push(Title + ']]]' + Dates + ']]]' + People + ']]]' + EventLocation + ']]]' + EstTravel + ']]]' + EstLaborOvertime + ']]]' + Funding + ']]]' + Venue );
				
            }
			
			
			
            if(oListItem.get_item("Venue")!==null){
                if(ven == oListItem.get_item("Venue")){		
                    if (oListItem.get_item("Venue") !== null && oListItem.get_item("Venue") !== "null") { Venue = oListItem.get_item("Venue"); }
                    commonRows.push(oListItem.get_item("Venue"));
                    commonRowsRaw.push(oListItem.get_item("Venue"));
					
                } else if (ven !=="") {					
                    $(".WSBtnAddGroup:last").click();	
                    // alert('clicked');
                }
                ven = oListItem.get_item("Venue");
            }
								
        } // end while
		
        commonRowsRaw.reverse(); 	
        commonRows.reverse(); 		
        commonRowsVenueSubTotal.reverse();
        commonRowsWithData.reverse();

        var commonRowsUnique = jQuery.unique(commonRows);
        for(i=0; i < commonRowsUnique.length; i++){
            $("tr.WSGroupStartRow").eq(i).find("input#Venue").val(commonRowsUnique[i]);
            $("tr.WSGroupEndRow").eq(i).find("input#VenueSubTotal").val(commonRowsVenueSubTotal[i]).end().find("input#Venue").val(commonRowsUnique[i]).end().find($("input#Title:hidden")).val("VenueSubTotal");
        }
		
        var commonRowsVal = "";
        for(i=0; i < commonRowsRaw.length; i++){
            a = jQuery.inArray(commonRowsRaw[i],commonRowsUnique); // 0 or 1 etc
			
            if(commonRowsVal==commonRowsRaw[i] ){
                $("tr.WSGroupStartRow").eq(a).find(".WSBtnAddRow").click();
            } 
            else {
				
                commonRowsVal=commonRowsRaw[i];
            }
        }
        for(i=0; i < commonRowsWithData.length; i++){
			
            commonRowWithData = commonRowsWithData[i].toString().split(']]]');
            setRowWithData(commonRowWithData, i);
        }
        function setRowWithData(commonRowWithData, i){
            // $("input#Title:visible").eq(i).val(i+'kkk');
            var rowToSet = $("input#Title:visible").eq(i).closest("tr");
            $(rowToSet).find("#Title").val(commonRowWithData[0]).end().find("#Dates").val(commonRowWithData[1]).end().find("#People").val(commonRowWithData[2]).end().find("#EventLocation").val(commonRowWithData[3]).end().find("#EstTravel").val(commonRowWithData[4]).end().find("#EstLaborOvertime").val(commonRowWithData[5]).end().find("#Funding").val(commonRowWithData[6]).end().find("#Venue").val(commonRowWithData[7]);
			

        }	
    } // end if worksheet #2
	
	
	
    if(worksheetNum == "3" || worksheetNum == "4"){ // worksheet #3 or 4
        // alert('worksheetNum 3 or 4: '+worksheetNum);
        var listItemInfo = "";
		
        var listItemEnumerator = collListItem.getEnumerator();	
        while(listItemEnumerator.moveNext()){	
            var oListItem = listItemEnumerator.get_current();		
            var oListItemId = oListItem.get_id().toString();	
            //alert("Title: "+oListItem.get_item("Title")  ); 
			
            if(DateDraftSaved !== oListItem.get_item("DateDraftSaved") && DateDraftSaved !== ""){
                // alert('listItemInfo: \n'+listItemInfo+'did not pass test. DateDraftSaved var : '+ DateDraftSaved+ " DateDraftSaved: " +oListItem.get_item("DateDraftSaved"));
                break;
            } else {			
                DateDraftSaved = oListItem.get_item("DateDraftSaved");
	
                // Field data was collected based on row and input id. If row has one field use hidden input to set Title. example: Total row has hidden input with id Title and value of Total.				
                if(worksheetNum == "3"){ // worksheet #3
                    if(oListItem.get_item("Title")=="Total"){$("#Total").val(oListItem.get_item("Total"));}
                    else {var tvals = ""; $(".WSBtnAddRow:first").closest('tr').find('input:text').each(function(){var tval = $(this).val(); tvals += tval;});
                        if(tvals.length){ $(".WSBtnAddRow:first").click(); tvals = "";}
                        $("#Title:first").val(oListItem.get_item("Title")); $("#People:first").val(oListItem.get_item("People")); $("#Dates:first").val(oListItem.get_item("Dates")); $("#Remarks:first").val(oListItem.get_item("Remarks")); $("#Funding:first").val(oListItem.get_item("Funding"));}
                }
                if (worksheetNum == "4") { // worksheet #4
                    listItemInfo += "oListItemId: " + oListItemId + "\n";
                    if(oListItem.get_item("Title")=="Total"){$("#Total").val(oListItem.get_item("Total"));}
                    else {var tvals = ""; $(".WSBtnAddRow:first").closest('tr').find('input:text').each(function(){var tval = $(this).val(); tvals += tval;});
                        if(tvals.length){ $(".WSBtnAddRow:first").click(); tvals = "";}
                        $("#Title:first").val(oListItem.get_item("Title")); $("#Number:first").val(oListItem.get_item("Number")); $("#Remarks:first").val(oListItem.get_item("Remarks")); $("#Funding:first").val(oListItem.get_item("Funding"));}
                }			
            }

        }
        //alert(listItemInfo);
    }



    SP.UI.ModalDialog.commonModalDialogClose(null, null); // closes dialog

}
