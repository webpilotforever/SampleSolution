﻿
$(document).ready(function () {
    var print = "no";
    if (getParameterByName("print") != "") { print = getParameterByName("print"); }
    var ota = "ATEC";
    if (getParameterByName("ota") != "") { ota = getParameterByName("ota"); }
    var fy = "16";
    if (getParameterByName("fy") != "") { fy = getParameterByName("fy"); }
    var urlToPage = location.href;
    var urlSearch = location.search;
    urlToPage = urlToPage.replace(urlSearch, ""); //alert("urlToPage: "+urlToPage);
    var urlToSite = location.href.substr(0, location.href.lastIndexOf("/") + 1);
    $(".CONOPSDevWSColHeaderDesc").children().hide();

    //$(".CONOPSDevWSColHeaderDesc").hide();
    $(".CONOPSDevWSColHeaders").click(function () {
        $(".CONOPSDevWSColHeaderDesc").children().slideToggle("fast");
    });



//$(".CONOPSDevWSColCell").hover(function () {
//        $(".CONOPSDevWSColHeaderDesc").children().fadeIn(1000);
//    }, function () {
//        $(".CONOPSDevWSColHeaderDesc").children().fadeOut(1000);

//    });


    //$(".CONOPSDevWSColHeaders").hide();
    //$(".CONOPSDevWSColCell").hover(function () {
    //    $(".CONOPSDevWSColHeaderDesc").fadeIn(500);
    //}, function () {
    //    $(".CONOPSDevWSColHeaderDesc").fadeOut(100);

    //});
    //$(".CONOPSDevWSColHeaders").mouseover(function () {

    //    $(".CONOPSDevWSColHeaderDesc").show();

    //});
    //$(".CONOPSDevWSColHeaders").mouseout(function () {

    //    $(".CONOPSDevWSColHeaderDesc").hide();

    //});

    if (print == "yes") {
        window.print();
    }
    getmsdlgTitleBtns(urlToSite);















});
function getParameterByName(name) { name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"); var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search); return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
function getmsdlgTitleBtns(urlToSite) {

    //var wsPrintUrl = "WS1.aspx?ota=Army Test and Evaluation Command&otashort=ATEC&fy=16&ws=4&submitted=no&IsDlg=1&print=yes";

    var formElem = document.getElementById("aspnetForm");
    var wsPrintUrl = formElem.getAttribute("action");
    wsPrintUrl = urlToSite + wsPrintUrl + "&print=yes";

    var printBtn = parent.document.createElement("A");
    printBtn.setAttribute("class", "ms-dlgCloseBtn");
    printBtn.setAttribute("title", "Print");
    printBtn.setAttribute("target", "_blank");
    printBtn.setAttribute("href", wsPrintUrl);
    printBtn.innerHTML = "<SPAN style=\"POSITION: relative; WIDTH: 18px; DISPLAY: inline-block; HEIGHT: 18px; OVERFLOW: hidden\" class=\"s4-clust\"><IMG class=\"ms-dlgCloseBtnImg\" src=\"/_layouts/Images/DCAPXSolution/print.png\"></SPAN>";


    var spans = parent.document.getElementsByTagName("SPAN");
  
    for (i = 0; i < spans.length; i++) {

        if (spans[i].getAttribute("class") == "ms-dlgTitleBtns") {

            if (spans[i].hasChildNodes()) {
                
                var spansChildren = spans[i].childNodes;

                for (ii = 0; ii < spansChildren.length; ii++) {
                    if (spansChildren[ii].nodeName == "A") {

                        spansChildren[ii].setAttribute("style", "display: none;");

                        spans[i].insertBefore(printBtn, spansChildren[ii]);

                        break;
                    }
                }

            }
            
        }
    }

 


}
