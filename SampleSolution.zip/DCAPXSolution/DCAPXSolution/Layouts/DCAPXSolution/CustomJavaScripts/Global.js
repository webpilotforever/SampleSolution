﻿
var gCurrentUserr;








//function deletingSiteCollection() {
//    if ($("input[id*='HiddenField1']").val() == "Done") {


//    }
//    else{
//        //pleaseWaitNoClose("Deleting site collection", null);
//    }

//}
//function pleaseWaitNoClose(dialogTitle, dialogMessage) {
//    if (dialogTitle == null) {
//        dialogTitle = "Retrieving data";
//    }
//    if (dialogMessage == null) {
//        dialogMessage = "Please wait...";
//    }

//    SP.UI.ModalDialog.showWaitScreenWithNoClose(dialogTitle, dialogMessage);
//}

///var locationUpToSite = window.location.toString().substr(0, window.location.toString().indexOf(window.location.pathname));
var gCurrentUser = "";// domain\\username
var sites = "/sites/";
var indexOfSites = window.location.toString().indexOf("/sites/") + 7;
var indexOfDCAPX = window.location.toString().substr(indexOfSites);

var urlPastSite = indexOfDCAPX.substr(indexOfDCAPX.indexOf("/"));
//alert('urlPastSite: ' + urlPastSite);

var locationUpToSite = window.location.toString().substr(0, window.location.toString().indexOf(urlPastSite));
//alert("locationUpToSite: "+locationUpToSite);


//  Cyber Security Assessment Database
var currentUserFromUpperRight, ws1ContentTypeId, ws2ContentTypeId, ws3ContentTypeId, ws4ContentTypeId, wsNumFromPageName, wsListForOTA;
var OTAtitleKey = { AFOTEC: "Air Force Operational Test and Evaluation Center", ATEC: "Army Test and Evaluation Command", COTF: "Commander Operational Test and Evaluation Force", JITC: "Joint Interoperability Test Command", MCOTEA: "Marine Corps Operational Test and Evaluation Activity" };
var progressListCols = { 1: "WS1Progress", 2: "WS2Progress", 3: "WS3Progress", 4: "WS4Progress", 5: "WSReview" };
var ourLocation = window.location.href.toString();  var atLocation = ourLocation.substr(0, ourLocation.indexOf(".aspx") + 5); var siteRelURLtopage = window.location.pathname; var atPage = atLocation.substr(atLocation.lastIndexOf("/") + 1); var worksheetPageName = siteRelURLtopage.substr(siteRelURLtopage.lastIndexOf("/") + 1); var OTA = ""; var OTAtitle = ""; worksheetPageName = worksheetPageName.substr(0, worksheetPageName.indexOf(".aspx")); var docRef = window.document.referrer.toString(); docRef = docRef.replace(locationUpToSite, ""); var CurrentFYforAcceptingCONOPS; var ws1; var ws2; var ws3; var ws4; var wsReviewSubmit; var wsToReviewTitle, wsToReviewUrl; var ws1t; var ws2t; var ws3t; var ws4t; if (!window.console) console = { log: function () { } };

// CONOPS Dev worksheet titles and urls defined here
var worksheetTitlesAndUrls = { ws1t: "Worksheet #1", ws1: locationUpToSite + "/SitePages/CONOPSDevWS1.aspx", ws2t: "Worksheet #2", ws2: locationUpToSite + "/SitePages/CONOPSDevWS2.aspx", ws3t: "Worksheet #3", ws3: locationUpToSite + "/SitePages/CONOPSDevWS3.aspx", ws4t: "Worksheet #4", ws4: locationUpToSite + "/SitePages/CONOPSDevWS4.aspx", wsRt: "Review/Submit Worksheets", wsR: locationUpToSite + "/SitePages/CONOPSDevReviewSubmitWorksheets.aspx" };
var dialogTitleText;
var paramReview, paramShowTable;
var ct = "";


$(document).ready(function () {
    $.ajaxSetup({ cache: true }); // so js loaded with getScript function will be cached

    
    

    $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CalendarDashboard.js', function () { });
    $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevGetWorksheetData.js', function () { });
    $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevWSListsUpdate.js', function () { });
    $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevDialogs.js', function () { });

    //start CONOPSDevReviewSubmit
    
    //end CONOPSDevReviewSubmit



       if (location.host.indexOf(".smil") < 0) {
        // NIPR Net
        $(".classBannerBottom").addClass("niprclassBannerColor");
        $(".classBannerBottom").text("UNCLASSIFIED");
        $(".classBannerTop").addClass("niprclassBannerColor");
        $(".classBannerTop").text("UNCLASSIFIED");
    }

    if (location.href.indexOf("/sites/") < 0) {
        $(".DCAPXPOCs").find("a").each(function () {
            var linkTitle = $(this).attr("title");
            linkTitle = linkTitle.replace(" ", "\n");
            $(this).attr("href", "javascript:alert('" + linkTitle + "')");

            //$(this).attr("href", "javascript:alert('" + linkTitle + "')\;void(0)\;");
    
        });
    }
    else {
        var dcapxpocslinkAA = location.href.substr(location.href.indexOf("/sites/") + 7);
        dcapxpocslinkAA = dcapxpocslinkAA.substr(dcapxpocslinkAA.indexOf("/") + 1);
        var dcapxpocslink = location.href.replace(dcapxpocslinkAA, "");
        $(".DCAPXPOCs").find("a").each(function () {
            var dcapxpocslinkRaw = $(this).attr("href");
            dcapxpocslinkRaw = dcapxpocslinkRaw.replace("/Lists", dcapxpocslink + "Lists");
            $(this).attr("href", dcapxpocslinkRaw);
        });
    }

    if (siteRelURLtopage.indexOf("/SitePages/DCAPXInfo.aspx")>-1) {
        //$("#onetidPageTitleSeparator").hide();
        $(".menu-item-text").text("DCAPX Info");
        $("#ctl00_MSO_ContentDiv").css("padding-left", "20px");
        $("#ctl00_MSO_ContentDiv").css("padding-top", "20px");
        $("#ctl00_MSO_ContentDiv").css("margin-left", "155px");
        $("#s4-leftpanel").show();
        $(".s4-ca").css("background", "none");
        $("#s4-leftpanel-content").html("<DIV class=\"ms-quicklaunchouter\"><DIV class=\"ms-quickLaunch\"><DIV id=\"ctl00_PlaceHolderLeftNavBar_QuickLaunchNavigationManager\" class=\"ms-quicklaunch-navmgr\"><DIV><DIV id=\"zz17_V4QuickLaunchMenu\" class=\"s4-ql\"><DIV class=\"menu vertical menu-vertical\"><UL class=\"root static\"><LI class=\"static\"><A class=\"static menu-item\" href=\"/sites/DCAPXObjects\"><SPAN class=\"additional-background\"><SPAN class=\"menu-item-text\">DCAPXObjects</SPAN></SPAN></A></LI></UL></DIV></DIV></DIV></DIV><UL class=\"s4-specialNavLinkList\"><LI><A id=\"ctl00_PlaceHolderLeftNavBar_PlaceHolderQuickLaunchBottom_PlaceHolderQuickLaunchBottomV4_idNavLinkRecycleBin\" class=\"s4-rcycl\" href=\"/_layouts/recyclebin.aspx\"><SPAN style=\"POSITION: relative; WIDTH: 16px; DISPLAY: inline-block; HEIGHT: 16px; OVERFLOW: hidden\" class=\"s4-clust s4-specialNavIcon\"><IMG style=\"POSITION: absolute; BORDER-RIGHT-WIDTH: 0px; BORDER-TOP-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; TOP: -428px !important; LEFT: 0px !important\" src=\"/_layouts/images/fgimg.png\"></SPAN>&nbsp;<SPAN class=ms-splinkbutton-text>Recycle Bin</SPAN></A> </LI><LI><A accessKey=\"3\" id=\"ctl00_PlaceHolderLeftNavBar_PlaceHolderQuickLaunchBottom_PlaceHolderQuickLaunchBottomV4_idNavLinkViewAllV4\" href=\"/_layouts/viewlsts.aspx\"><SPAN style=\"POSITION: relative; WIDTH: 16px; DISPLAY: inline-block; HEIGHT: 16px; OVERFLOW: hidden\" class=\"s4-clust s4-specialNavIcon\"><IMG style=\"POSITION: absolute; BORDER-RIGHT-WIDTH: 0px; BORDER-TOP-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; TOP: 0px !important; LEFT: 0px !important\" src=\"/_layouts/images/fgimg.png\"></SPAN>&nbsp;<SPAN class=ms-splinkbutton-text>All Site Content</SPAN></A> </LI></UL></DIV></DIV>");
        ExecuteOrDelayUntilScriptLoaded(buildQuicklaunch, "sp.js");



    }
    

    currentUserFromUpperRight = $("#zz15_Menu").text();
    if (getParameterByName("ws1Prog") == "1") { ct = "WS1"; }
    else if (getParameterByName("ws2Prog") == "1") { ct = "WS2"; }
    else if (getParameterByName("ws3Prog") == "1") { ct = "WS3"; }
    else if (getParameterByName("ws4Prog") == "1") { ct = "WS4"; }
    paramReview = getParameterByName("review");
    paramShowTable = getParameterByName("showTable");
    if (getParameterByName("otaTitle") !== "" && OTA == "") { OTAtitle = getParameterByName("otaTitle"); OTA = getParameterByName("ota"); } $("#RibbonContainer").on('click', 'a[title="Edit"]', function () { return false; }); var inDesignMode = $("#MSOSPWebPartManager_DisplayModeName").val();
    if (inDesignMode == "Design") { return false; } else {
        Home(); AOAdministrationDashboards(); CONOPSDevAODashboard(); CONOPSDevelopmentModule(); ViewCONOPSWebPart(); AssessmentDashboardWebPart(); QuickLaunchMenu(); CONOPSDevWorksheets(); ReviewSubmitWorksheets();
        // AttachDocs();
    } $("#ctl00_onetidHeadbnnr2").attr("src", "/_layouts/Images/DCAPXSolution/doteseal.gif").css("display", "inline"); $("img[style*='-585px']").css("top", "-607px").css("filter", "alpha(opacity=60)").css("opacity", "0.6"); if (getParameterByName("IsDlg") == "1") { $(".ms-cui-tt-a").css("display", "none"); }

    function ViewCONOPSWebPart() {
        if (siteRelURLtopage.indexOf("/SitePages/Home.aspx") > -1) {
            $("span:contains(CONOPS Dashboard)").closest(".s4-wpTopTable").addClass("WebPart");
        }
    }
    function AssessmentDashboardWebPart() { if (siteRelURLtopage.indexOf("/SitePages/Home.aspx")>-1 || siteRelURLtopage.indexOf("/SitePages/AssessmentDashboardWebPart.aspx")>-1 || siteRelURLtopage.indexOf("/aad/Home.aspx")>-1) { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/AssessmentDashboardWebPart.js', function () { }); } }
    function QuickLaunchMenu() { if (getParameterByName("IsDlg") == "") { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/QuickLaunchMenu.js', function () { }); } }
    //function CalendarDasbboard() { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CalendarDashboard.js', function () { }); } 
    function Home() { if (siteRelURLtopage.indexOf("/SitePages/Home.aspx") > -1) { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/Home.js', function () { }); } }
    function AOAdministrationDashboards() { if (siteRelURLtopage.indexOf("/aad/Home.aspx") > -1) { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/AOAdminDashboards.js', function () { }); } }
    function CONOPSDevAODashboard() { if (getParameterByName("IsDlg") == "1") { if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevelopmentModuleAODashboard.aspx") > -1) { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevAODashboard.js', function () { }); } } }
    function CONOPSDevelopmentModule() { if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevelopment.aspx")>-1) { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevelopmentModule.js', function () { }); } }
    function CONOPSDevWorksheets() {
        if (getParameterByName("IsDlg") == "1") {
            if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS1.aspx") > -1 || siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS2.aspx") > -1 || siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS3.aspx") > -1 || siteRelURLtopage.indexOf("/SitePages/CONOPSDevWS4.aspx") > -1) {
                //$(".WSOTADiv").hide(); $(".WSTitle").hide();
                parent.document.getElementById("dialogTitleSpan").style.visibility = "hidden";
                ExecuteOrDelayUntilScriptLoaded(getCONOPSDevWSContentTypeIds, "sp.js");
                function getCONOPSDevWSContentTypeIds() {
                    var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Loading Worksheet", "Please wait...");

                    var clientContext = new SP.ClientContext.get_current();
                    var oWeb = clientContext.get_web();
                    this.collContentTypes = oWeb.get_contentTypes();
                    clientContext.load(collContentTypes);
                    clientContext.executeQueryAsync(Function.createDelegate(this, getCONOPSDevWSContentTypeIdsSucceeded), Function.createDelegate(this, this.onQueryFailed));
                }
                function getCONOPSDevWSContentTypeIdsSucceeded() {
                    var collContentTypesEnumerator = collContentTypes.getEnumerator();
                    while (collContentTypesEnumerator.moveNext()) {
                        var oContentTypeCurrent = collContentTypesEnumerator.get_current();
                        var oContentTypeName = oContentTypeCurrent.get_name();
                        var oContentTypeId = oContentTypeCurrent.get_id();
                        if (oContentTypeName == "WS1") {
                            ws1ContentTypeId = oContentTypeId;
                        } else if (oContentTypeName == "WS2") {
                            ws2ContentTypeId = oContentTypeId;
                        } else if (oContentTypeName == "WS3") {
                            ws3ContentTypeId = oContentTypeId;
                        } else if (oContentTypeName == "WS4") {
                            ws4ContentTypeId = oContentTypeId;
                        }
                    }

                    //alert('\nws1ContentTypeId: '+ws1ContentTypeId + '\nws2ContentTypeId: '+ws2ContentTypeId + '\nws3ContentTypeId: '+ws3ContentTypeId + '\nws4ContentTypeId: '+ws4ContentTypeId);
                    $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevWorksheets.js', function () { }); $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevUpdateTotals.js', function () { }); $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevWorksheetsButtons.js', function () { });
                    $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevWSPrePop.js', function () { });
                }

            }
        }
    }
    //function ReviewSubmitWorksheets() { if (getParameterByName("IsDlg") == "1") { if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevReviewSubmitWorksheets.aspx")>-1) { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevReviewSubmit.js', function () { }); } } }
    function ReviewSubmitWorksheets() { if (getParameterByName("IsDlg") == "1") { if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevReviewSubmitWorksheets.aspx")>-1) { $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevReviewSubmit.js', function () { }); $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevReviewSubmitAttachments.js', function () { }); } } }

    function AttachDocs() { // using RWEP so not calling this
        if (getParameterByName("IsDlg") == "1" && getParameterByName("Mode") == "Upload" || siteRelURLtopage.indexOf("/_layouts/Upload.aspx") > -1 || siteRelURLtopage.indexOf("/_layouts/UploadEx.aspx") > -1) {
            if (siteRelURLtopage.indexOf("/_layouts/Upload.aspx") > -1 || siteRelURLtopage.indexOf("/_layouts/UploadEx.aspx") > -1) {
                var dest = $("input#destination").val();
                dest = dest.substr(dest.lastIndexOf("/")+1);
                //alert("dest: " + dest);
                if (dest.indexOf("CONOPSDevAFOTEC") > -1 || dest.indexOf("CONOPSDevATEC") > -1 || dest.indexOf("CONOPSDevCOTF") > -1 || dest.indexOf("CONOPSDevJITC") > -1 || dest.indexOf("CONOPSDevMCOTEA") > -1) {
                    $("a[id*='UploadMultipleLink']").closest("tr").hide(); 
                    $("input[id*='OverwriteSingle']").closest("tr").hide();
                    $("tr#ctl00_PlaceHolderMain_VersionCommentSection").hide();


                    $("input[id*='btnOK']").parent().prepend("<input type=\"button\" title=\"Attach file\" id=\"UploadOKBtn\" class=\"ms-ButtonHeightWidth\" disabled=\"disabled\" value=\"OK\" />").end().hide();
                    $.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevUpload.js', function () { $("input[id='UploadOKBtn']").removeAttr("disabled"); });


                    $("input[id='UploadOKBtn']").click(function () {

                        var fileName = $("input[id*='InputFile']").val();
                        if (fileName.length) {
                            fileName = fileName.substr(fileName.lastIndexOf("\\") + 1);
                            var pleaseWait = SP.UI.ModalDialog.showWaitScreenWithNoClose("Validating", "Please wait...");
                            ExecuteOrDelayUntilScriptLoaded(calluploadValidation, "sp.js");
                            function calluploadValidation() {

                                //uploadValidation(dest.substr(1), fileName);
                                uploadValidation(dest, fileName);
                            }
                        }
                        else {
                            alert("No file to upload.");
                        }


                    });
                }

            }
            // Edit
            if (siteRelURLtopage.indexOf("/CONOPSDevAFOTEC/Forms/EditForm.aspx") > -1 || siteRelURLtopage.indexOf("/CONOPSDevATEC/Forms/EditForm.aspx") > -1 || siteRelURLtopage.indexOf("/CONOPSDevCOTF/Forms/EditForm.aspx") > -1 || siteRelURLtopage.indexOf("/CONOPSDevJITC/Forms/EditForm.aspx") > -1 || siteRelURLtopage.indexOf("/CONOPSDevMCOTEA/Forms/EditForm.aspx") > -1) {

                var summaryWSparam = getParameterByName("summaryWS");
                var summaryFYparam = getParameterByName("summaryFY");
                $("div#s4-ribbonrow").hide();
                $("td#onetidinfoblockV").closest("table").hide();
                $("select[title='Content Type']").closest("tr").hide();
                $("input[title='Submitted']").closest("tr").hide();
              
                $("input[title='DateDraftSaved']").closest("tr").hide();
                $("input[title='SubmittedFY']").closest("tr").hide();
                $("input[title='OTA']").closest("tr").hide();
                $("input[title='OTA']").val(getParameterByName("ota"));
                $("h3.ms-standardheader:contains(SubmittedBy)").closest("tr").hide();
                $("h3.ms-standardheader:contains(DraftSavedBy)").closest("tr").hide(); // fill out
                $("h3.ms-standardheader:contains(CONOPSApproval)").closest("tr").hide();
                $("h3.ms-standardheader:contains(TimeDraftSaved)").closest("tr").hide(); // fill out
                $("h3.ms-standardheader:contains(Title)").closest("tr").hide();
                $("input[title='SubmittedOn']").closest("tr").hide();
                $("input[title='Name Required Field']").attr("disabled", "disabled");
                $("input[title='FY']").val(summaryFYparam).closest("tr").hide();
                $("input[title='WS']").val(summaryWSparam).closest("tr").hide();
                var datedraftsaveddate = new Date();
                var TimeDraftSaved = datedraftsaveddate.getTime();
                datedraftsaveddate = datedraftsaveddate.toLocaleString();

                $("input[title='DateDraftSaved']").val(datedraftsaveddate);
                $("input[title='TimeDraftSaved']").val(TimeDraftSaved);

                // currentUserFromUpperRight or _spUserId=1;
                // set DraftSavedBy in event receiver so will be compatible with sp2013 -- or try the following
                // People Picker
                // DOTEDRESOURCE\danielnw-p
                var DraftSavedByTR = $("h3.ms-standardheader:contains(DraftSavedBy)").closest("tr");
                //DraftSavedByTR.find($("div[title*='People Picker']")).text("DOTEDRESOURCE\danielnw-p");
                ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser, "sp.js");
                function ggetCurrentUser() {

                    this.clientContext = new SP.ClientContext.get_current();
                    var oWeb = clientContext.get_web();
                    this.user = oWeb.get_currentUser();

                    clientContext.load(user);
                    clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded), Function.createDelegate(this, onQueryFailed));
                }
                function ggetCurrentUserSucceeded() {
                    //user.get_id();
                    gCurrentUser = user.get_loginName();
                    gotgCurrentUser(gCurrentUser);
                }
                function gotgCurrentUser(gCurrentUser) {
                    alert("gCurrentUser: " + gCurrentUser);
                    DraftSavedByTR.find($("div[title*='People Picker']")).text(gCurrentUser);

                }


                $("input[value='Save']").mousedown(function () {
                    // alert('mousedown');
                    $("input[title='Name Required Field']").removeAttr("disabled");
                    $(this).click();
                });

                //$("input[title='Name Required Field']").removeAttr("disabled");
                //$("input[value='Save']").click();

            }

        }
    }

    //========= CONOPSApproval upload attachments=========
   
    if (location.href.indexOf("EditForm.aspx?Mode=Upload") > -1 && location.href.indexOf("module=CONOPSApproval") > -1) {
        //Hide rows
        $(".ms-formlabel").each(function () {

            var doesNotContainShowFields = true;
            if ($(this).find("h3:contains(Name)").length || $(this).find("h3:contains(Title)").length) {
                doesNotContainShowFields = false;
            }
            if (doesNotContainShowFields) {
                $(this).closest("tr").hide();
            }

        });
      
        var url = location.href;
        var tab = url.substr(url.indexOf("tab=") + 4); // tab=AOReview&
        tab = tab.substr(0, tab.indexOf("&"));
        var fy = url.substr(url.indexOf("fy=") + 3); //fy=17&
        fy = fy.substr(0, fy.indexOf("&"));
        var otashort = url.substr(url.indexOf("otashort=") + 9); //otashort=ATEC&
        otashort = otashort.substr(0, otashort.indexOf("&"));
        var ws = url.substr(url.indexOf("ws=") + 3); //ws=1&
        ws = ws.substr(0, ws.indexOf("&"));
      

        var conopsapproval = { AOReview:"AO Recommendation" , PMReview:"PM Preapproval", DRReview:"Deputy Director Approval"};
       

        var datedraftsaveddate = new Date();
        var TimeDraftSaved = datedraftsaveddate.getTime();
        datedraftsaveddate = datedraftsaveddate.toLocaleString();

        $("input[title='DateDraftSaved']").val(datedraftsaveddate);
        $("input[title='TimeDraftSaved']").val(TimeDraftSaved);
        $("input[title='FY']").val(fy);
        $("input[title='OTA']").val(otashort);
        $("input[title='WS']").val("WS" + ws);
        $(".ms-RadioText:contains(" + conopsapproval[tab] + ")").find("input").attr("checked", "checked");

        var DraftSavedByTR = $("h3.ms-standardheader:contains(DraftSavedBy)").closest("tr");
        //DraftSavedByTR.find($("div[title*='People Picker']")).text("DOTEDRESOURCE\danielnw-p");
        ExecuteOrDelayUntilScriptLoaded(ggetCurrentUser, "sp.js");
        function ggetCurrentUser() {

            this.clientContext = new SP.ClientContext.get_current();
            var oWeb = clientContext.get_web();
            this.user = oWeb.get_currentUser();

            clientContext.load(user);
            clientContext.executeQueryAsync(Function.createDelegate(this, ggetCurrentUserSucceeded), Function.createDelegate(this, onQueryFailed));
        }
        function ggetCurrentUserSucceeded() {
            //user.get_id();
            gCurrentUser = user.get_loginName();
            gotgCurrentUser(gCurrentUser);
        }
        function gotgCurrentUser(gCurrentUser) {
            //alert("gCurrentUser: " + gCurrentUser);
            DraftSavedByTR.find($("div[title*='People Picker']")).text(gCurrentUser);

        }

      


    }

    //append ?wsClosed=true to Development link http://dotersrcndapp5:46689/sites/DCAPXObjects/SitePages/CONOPSDevelopment.aspx?wsClosed=true
    //if user is not a contributing OTA
    var lastPartLocationUpToSite = locationUpToSite.substr(locationUpToSite.lastIndexOf('/'));
    if (lastPartLocationUpToSite.indexOf('/DCAPX') > -1) {
        ///alert(lastPartLocationUpToSite);
       // ExecuteOrDelayUntilScriptLoaded(appendDevLink2, 'sp.js');
    }
    
    //
  
    
});

//$.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevGetWorksheetData.js', function () { });
//$.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevWSListsUpdate.js', function () { });
//$.getScript('/_layouts/DCAPXSolution/CustomJavaScripts/CONOPSDevDialogs.js', function () { });


//function AddFeedbackAndComments() { var options = { url: $("input[id*='PlaceHolderSearchArea']").val() + "/Lists/Feedback/NewForm.aspx?ContentTypeId=0x0100D3A9314F82EE4C0D885E2A3D8C72C48100E40C97613CA19D40BD3D013849255ADB", dialogReturnValueCallback: AddFeedbackAndCommentsThanks }; SP.UI.ModalDialog.showModalDialog(options); }

//function AddFeedbackAndCommentsThanks(dialogResult, returnValue) { if (dialogResult == '1') { alert("Thank you. Your feedback and comments will help us improve this site."); } }
function showProgramPOC(id) { var options = { url: "/Lists/ProgramContacts/DispForm.aspx?ID=" + id }; SP.UI.ModalDialog.showModalDialog(options); }
function showAssessment(id) { var options = { url: "/Lists/Assessment/DispForm.aspx?ID=" + id }; SP.UI.ModalDialog.showModalDialog(options); }
// ----- UTILITIES -----
function getCurrentFYforAcceptingCONOPS() { var d = new Date(); var n = d.getFullYear() + 1; n = n.toString(); n = n.substr(2); return n; }
function numberAsTwoDigits(num) { var Num = num; return (Num < 10 ? '0' : '') + Num; }
function getParameterByName(name) { name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]"); var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"), results = regex.exec(location.search); return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " ")); }
function onQueryFailed(sender, args) { alert('Request failed. ' + args.get_message() + '\n' + args.get_stackTrace()); }
function buildQuicklaunch() {
    var quickLaunchNodeCollection = null;
    var nnci = null;
    var clientContext = new SP.ClientContext.get_current();
    if (clientContext != undefined && clientContext != null) {
        var web = clientContext.get_web();
        this.quickLaunchNodeCollection = web.get_navigation().get_quickLaunch();

        clientContext.load(this.quickLaunchNodeCollection);
        clientContext.executeQueryAsync(Function.createDelegate(this, this.buildQuicklaunchSucceeded), Function.createDelegate(this, this.onQueryFailed));
    }



}
function buildQuicklaunchSucceeded() {
    var nodeInfo = '';
    var nodeEnumerator = this.quickLaunchNodeCollection.getEnumerator();
    var nodeIndex = 0;
    while(nodeEnumerator.moveNext()){
        var node = nodeEnumerator.get_current();

        nodeInfo += node.get_title() + '\n' + node.get_url() + '\n';
        if (siteRelURLtopage.indexOf("/SitePages/DCAPXInfo.aspx") > -1) {
            $(".ms-quickLaunch").find(".menu-item-text").text(node.get_title());
            $(".ms-quickLaunch").find(".menu-item").attr("href", node.get_url());
        }
        if (siteRelURLtopage.indexOf("/SitePages/CONOPSDevelopment.aspx") > -1) {
            if(nodeIndex < 1){

                $(".ms-quickLaunch").find("UL").append("<li class='static selected'><a class='static selected menu-item' href='" + node.get_url() + "'><span class='additional-background'><span class='menu-item-text'>" + node.get_title() + "</span></span></a></li>");

            }

            else {

                $(".ms-quickLaunch").find("UL").append("<li class='static'><a class='static menu-item' href='" + node.get_url() + "'><span class='additional-background'><span class='menu-item-text'>" + node.get_title() + "</span></span></a></li>");


            }

            

        }
        nodeIndex = nodeIndex + 1;
    }





    //alert("Current nodes: \n\n" + nodeInfo);
}

function refreshPage() {
    location.replace(location.href);
}




//function appendDevLink() {

//    this.clientContext = new SP.ClientContext.get_current();
//    var oWeb = clientContext.get_web();
//    this.t = oWeb.get_title();
//    alert(t);
//    clientContext.load(t);
//    clientContext.executeQueryAsync(Function.createDelegate(this, appendDevLinkSucceeded), Function.createDelegate(this, onQueryFailed));
//}
//function appendDevLink() {
//    alert("yep");
//    //var clientContext = new SP.ClientContext.get_current();
//    //this.oWebTitle = clientContext.get_web().get_title();
//    //clientContext.load(oWebTitle);
//    //clientContext.executeQueryAsync(Function.createDelegate(this, this.appendDevLinkSucceeded2), Function.createDelegate(this, this.onQueryFailed));

//}
//function appendDevLinkSucceeded() {
//    if (t.indexOf("DCAPX")>-1) {
//        appendDevLink2();
//    }
    
//}
//function appendDevLink2() {
//    this.clientContext = new SP.ClientContext.get_current();
//    var oList = clientContext.get_web().get_lists().getByTitle('ProgramContacts');
//    var camlQuery = new SP.CamlQuery();
//    camlQuery.set_viewXml('<View><Query><Where><Eq><FieldRef Name="Account"/><Value Type="Integer"><UserID/></Value></Eq></Where></Query></View>');

//    this.collListItem = oList.getItems(camlQuery);
//    clientContext.load(collListItem);
//    clientContext.executeQueryAsync(Function.createDelegate(this, appendDevLinkSucceeded2), Function.createDelegate(this, onQueryFailed));

//}
//function appendDevLinkSucceeded2() {
//    var listItemEnumerator = collListItem.getEnumerator();
//    while (listItemEnumerator.moveNext()) {
//        var oListItem = listItemEnumerator.get_current(); 
//        var oListItemIModuleAccess = oListItem.get_item('ModuleAccess').toString();
//        alert(oListItemIModuleAccess);
//        //if (oListItemIModuleAccess.indexOf("Submitters") > -1) {

//        //    //update Development link 
//        //    var linkHref = $(".menu-item-text:contains(Development)").closest("a").attr("href") + "?wsClosed=true";
//        //    $(".menu-item-text:contains(Development)").closest("a").attr("href", linkHref);
//        //}

//    }


//}




