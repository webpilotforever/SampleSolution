﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;
using System.Collections.Generic; 

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    public partial class WS3 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var traceInfo = "template WS3";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

               

                enableTabs();



                //----------LinkButtonAdddocument-----

                //string uName = Page.User.Identity.Name;

                //QueryStrings requiring Page object reference
                string qs_submitted = Page.Request.QueryString["submitted"];
                string qs_ota = Page.Request.QueryString["ota"];
                string qs_otashort = Page.Request.QueryString["otashort"];
                string qs_fy = Page.Request.QueryString["fy"];
                string qs_tab = Page.Request.QueryString["tab"];
                string qs_ws = Page.Request.QueryString["ws"];

                string urlFirstPart = Page.Request.RawUrl;
                urlFirstPart = urlFirstPart.Substring(0, urlFirstPart.IndexOf("/_layouts"));

                traceInfo = "urlFirstPart: " + urlFirstPart;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPList oLibb = SPContext.Current.Web.Lists["CONOPSDev" + qs_otashort];
                string oLibbID = oLibb.ID.ToString();

                traceInfo = "oLibbID: " + oLibbID;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                LinkButtonAdddocument.OnClientClick = "javascript:NewItem2(event, \'" + urlFirstPart + "/_layouts/Upload.aspx?List={" + oLibbID + "}&tab=" + qs_tab + "&fy=" + qs_fy + "&otashort=" + qs_otashort + "&ws=" + qs_ws + "&module=CONOPSApproval&RootFolder=\');javascript:return false;";

                //--end LinkButtonAdddocument--------------



                LabelOTA.Text = Page.Request.QueryString["ota"];
                LabelWSFY.Text = Page.Request.QueryString["fy"];

                //Table rows-----------------------------------------------------------------------------------

                TableRow headerTitleRow = new TableRow();
                TableRow headerRow = new TableRow();
                TableRow headerDescRow = new TableRow();
                TableRow eventRow = new TableRow();
                TableRow totalRow = new TableRow();
                TableRow attachmentsRow = new TableRow();
                TableRow attachmentsValRow = new TableRow(); 
                TableRow attachDocRow = new TableRow();

                headerTitleRow.Style.Add("text-align", "center");
                headerRow.CssClass = "CONOPSDevWSColHeaders";
                headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
                headerDescRow.Style.Add("text-align", "center");
                eventRow.Style.Add("text-align", "center");
                totalRow.Style.Add("text-align", "center");
                attachmentsRow.Style.Add("text-align", "center");
                attachmentsValRow.Style.Add("text-align", "center");

                //Table cells------------------------------------------------------------------------------------------

                TableCell headerTitleCell = new TableCell();
                headerTitleCell.ColumnSpan = 5;

                headerTitleCell.Controls.Add(headerTitleCellDiv);

                headerTitleRow.Cells.Add(headerTitleCell);

                CONOPSDevWSTable.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTable

                TableCell wsColCell1 = new TableCell();
                TableCell wsColCell2 = new TableCell();
                TableCell wsColCell3 = new TableCell();
                TableCell wsColCell4 = new TableCell();
                TableCell wsColCell5 = new TableCell();

                TableCell wsColCell6 = new TableCell();
                TableCell wsColCell7 = new TableCell();

                wsColCell1.CssClass = "CONOPSDevWSColCell";
                wsColCell2.CssClass = "CONOPSDevWSColCell";
                wsColCell3.CssClass = "CONOPSDevWSColCell";
                wsColCell4.CssClass = "CONOPSDevWSColCell";
                wsColCell5.CssClass = "CONOPSDevWSColCell";


                wsColCell6.CssClass = "CONOPSApprovalColCell";
                wsColCell7.CssClass = "CONOPSApprovalColCell";
                wsColCell6.Style.Add("width", "163px");
                wsColCell7.Style.Add("width", "163px");
                wsColCell6.Style.Add("font-weight", "bold");
                wsColCell7.Style.Add("font-weight", "bold");

                wsColCell1.Style.Add("width", "200px");
                wsColCell2.Style.Add("width", "155px");
                wsColCell3.Style.Add("width", "155px");
                wsColCell4.Style.Add("width", "155px");
                wsColCell5.Style.Add("width", "155px");


                wsColCell1.Style.Add("font-weight", "bold");
                wsColCell2.Style.Add("font-weight", "bold");
                wsColCell3.Style.Add("font-weight", "bold");
                wsColCell4.Style.Add("font-weight", "bold");
                wsColCell5.Style.Add("font-weight", "bold");


                wsColCell1.Text = "Event Name​";
                wsColCell2.Text = "People";
                wsColCell3.Text = "Dates​";
                wsColCell4.Text = "Remarks​";
                wsColCell5.Text = "Funding";


                headerRow.Cells.Add(wsColCell1);
                headerRow.Cells.Add(wsColCell2);
                headerRow.Cells.Add(wsColCell3);
                headerRow.Cells.Add(wsColCell4);
                headerRow.Cells.Add(wsColCell5);


                CONOPSDevWSTable.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTable

                TableCell headerDescRowCell1 = new TableCell();
                TableCell headerDescRowCell2 = new TableCell();
                TableCell headerDescRowCell3 = new TableCell();
                TableCell headerDescRowCell4 = new TableCell();
                TableCell headerDescRowCell5 = new TableCell();

                TableCell headerDescRowCell6 = new TableCell();
                TableCell headerDescRowCell7 = new TableCell();

                headerDescRowCell1.Style.Add("font-style", "italic");
                headerDescRowCell2.Style.Add("font-style", "italic");
                headerDescRowCell3.Style.Add("font-style", "italic");
                headerDescRowCell4.Style.Add("font-style", "italic");
                headerDescRowCell5.Style.Add("font-style", "italic");

                headerDescRowCell6.Style.Add("font-style", "italic");
                headerDescRowCell7.Style.Add("font-style", "italic");

                headerDescRowCell1.Text = "Identify each event";
                headerDescRowCell2.Text = "List the number of people attending each event​";
                headerDescRowCell3.Text = "List the dates for each event​";
                headerDescRowCell4.Text = "Provide any comments to help clarify your cost estimates";
                headerDescRowCell5.Text = "Estimated cost for each event​";

                headerDescRowCell6.Text = "Reviewer approval";
                headerDescRowCell7.Text = "Reviewer comments";

                headerDescRow.Cells.Add(headerDescRowCell1);
                headerDescRow.Cells.Add(headerDescRowCell2);
                headerDescRow.Cells.Add(headerDescRowCell3);
                headerDescRow.Cells.Add(headerDescRowCell4);
                headerDescRow.Cells.Add(headerDescRowCell5);


                CONOPSDevWSTable.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTable

                TableCell eventValCell1 = new TableCell();
                TableCell eventValCell2 = new TableCell();
                TableCell eventValCell3 = new TableCell();
                TableCell eventValCell4 = new TableCell();
                TableCell eventValCell5 = new TableCell();

                TableCell eventValCell6 = new TableCell();
                TableCell eventValCell7 = new TableCell();

                eventValCell1.Style["padding-left"] = "3px";
                eventValCell2.Style["text-align"] = "center";
                eventValCell3.Style["text-align"] = "center";
                eventValCell4.Style["padding-left"] = "3px";
                eventValCell5.Style["text-align"] = "center";

                eventValCell1.Text = "Text";
                eventValCell2.Text = "00";
                eventValCell3.Text = "Text";
                eventValCell4.Text = "Text";
                eventValCell5.Text = "0000";



                eventRow.Cells.Add(eventValCell1);
                eventRow.Cells.Add(eventValCell2);
                eventRow.Cells.Add(eventValCell3);
                eventRow.Cells.Add(eventValCell4);
                eventRow.Cells.Add(eventValCell5);


                CONOPSDevWSTable.Rows.Add(eventRow); //-----------------eventRow added to CONOPSDevWSTable

                TableCell totalRowCell1 = new TableCell();
                TableCell totalRowCell2 = new TableCell();

                TableCell totalRowCell3 = new TableCell();
                TableCell totalRowCell4 = new TableCell();

                totalRowCell1.ColumnSpan = 4;
                totalRowCell1.Style.Add("text-align", "right");
                totalRowCell1.Style.Add("font-weight", "bold");
                totalRowCell1.Style.Add("background-color", "#d0ffbc");
                //totalRowCell1.Text = "Total:";

                //------------------------------------Add Event button --------
                Button AddEventBtn = new Button();
                AddEventBtn.Text = "Add Event";
                AddEventBtn.Style.Add("float", "left");
                AddEventBtn.Style.Add("clear", "right");
                AddEventBtn.CssClass = "CONOPSApprovalAddEventButton";
                AddEventBtn.ToolTip = "Add Event";
                AddEventBtn.UseSubmitBehavior = false;
                AddEventBtn.OnClientClick = "return false";
                totalRowCell1.Controls.Add(AddEventBtn);

                Label LabelTotal = new Label();
                LabelTotal.Text = "Total:";
                totalRowCell1.Controls.Add(LabelTotal);
                //-----------------------------------------
                
                totalRowCell2.Text = "0000";
                totalRowCell2.Style.Add("background-color", "#d0ffbc");

                totalRow.Cells.Add(totalRowCell1);
                totalRow.Cells.Add(totalRowCell2);

                CONOPSDevWSTable.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTable

                TableCell attachmentsRowCell = new TableCell();

                TableCell attachmentsRowCell2 = new TableCell();
                TableCell attachmentsRowCell3 = new TableCell();

                attachmentsRowCell.ColumnSpan = 5;
                attachmentsRowCell.Style.Add("font-weight", "bold");
                attachmentsRowCell.Text = "Attachments";

                attachmentsRow.Cells.Add(attachmentsRowCell);

                CONOPSDevWSTable.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTable

                TableCell attachmentsValRowCell = new TableCell();

                TableCell attachmentsValRowCell2 = new TableCell();
                TableCell attachmentsValRowCell3 = new TableCell();

                attachmentsValRowCell.ColumnSpan = 5;
                attachmentsValRowCell.Text = "attachment1.text";
                attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

                attachmentsValRow.Cells.Add(attachmentsValRowCell);

                CONOPSDevWSTable.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTable

                TableCell attachDocRowCell = new TableCell();

                TableCell attachDocRowCell2 = new TableCell();
                TableCell attachDocRowCell3 = new TableCell();

                attachDocRowCell.ColumnSpan = 5;
                attachDocRowCell.Controls.Add(LiteralAdddocument);
                attachDocRowCell.Controls.Add(LinkButtonAdddocument);
                attachDocRowCell.Style.Add("padding-left", "10px");


                attachDocRow.Cells.Add(attachDocRowCell);


                CONOPSDevWSTable.Rows.Add(attachDocRow); //-----------------attachDocRow added to CONOPSDevWSTable
                //================= END OF TABLE TEMPLATE ====================

                if (Page.Request.QueryString["tab"] == "OTASubmission")
                {

                    totalRowCell1.Controls.Remove(AddEventBtn);
                    CONOPSDevWSTable.Controls.Remove(attachDocRow);
                    makeViewOrFormForOTASubmission(attachmentsRow, attachmentsValRow, totalRowCell2, eventRow, totalRowCell3, totalRowCell4);
                }
                if (Page.Request.QueryString["tab"] == "AOReview")
                {
                    headerTitleCell.ColumnSpan = 7;

                 

                    wsColCell6.Text = "AO Approval​";
                    wsColCell7.Text = "AO Comments​";

                    headerRow.Cells.Add(wsColCell6);
                    headerRow.Cells.Add(wsColCell7);

                    headerDescRow.Cells.Add(headerDescRowCell6);
                    headerDescRow.Cells.Add(headerDescRowCell7);

                    totalRow.Cells.Add(totalRowCell3);
                    totalRow.Cells.Add(totalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);

                    //CONOPSDevWSTable.Rows.Add(attachDocRow);



                    makeViewOrFormForAOReview(attachmentsRow, attachmentsValRow, totalRowCell1, AddEventBtn, totalRowCell2, eventRow, totalRowCell3, totalRowCell4, attachDocRow);
                }
                if (Page.Request.QueryString["tab"] == "PMReview")
                {
                    headerTitleCell.ColumnSpan = 7;

                   

                    wsColCell6.Text = "PM Approval​";
                    wsColCell7.Text = "PM Comments​";

                    headerRow.Cells.Add(wsColCell6);
                    headerRow.Cells.Add(wsColCell7);

                    headerDescRow.Cells.Add(headerDescRowCell6);
                    headerDescRow.Cells.Add(headerDescRowCell7);

                    totalRow.Cells.Add(totalRowCell3);
                    totalRow.Cells.Add(totalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);
                    //CONOPSDevWSTable.Rows.Add(attachDocRow);

                    makeViewOrFormForPMReview(attachmentsRow, attachmentsValRow, totalRowCell1, AddEventBtn, totalRowCell2, eventRow, totalRowCell3, totalRowCell4, attachDocRow);
                }
                if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
                {
                    headerTitleCell.ColumnSpan = 7;

                 

                    wsColCell6.Text = "DD Approval​";
                    wsColCell7.Text = "DD Comments​";

                    headerRow.Cells.Add(wsColCell6);
                    headerRow.Cells.Add(wsColCell7);

                    headerDescRow.Cells.Add(headerDescRowCell6);
                    headerDescRow.Cells.Add(headerDescRowCell7);

                    totalRow.Cells.Add(totalRowCell3);
                    totalRow.Cells.Add(totalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);
                    //CONOPSDevWSTable.Rows.Add(attachDocRow);

                    makeViewOrFormForDeputyDirectorReviewandApproval(attachmentsRow, attachmentsValRow, totalRowCell1, AddEventBtn, totalRowCell2, eventRow, totalRowCell3, totalRowCell4, attachDocRow);
        
                }
            }
            if (Page.IsPostBack)
            {
                string rawUrl = "1";
                if (Page.Request.RawUrl.ToString().Length > 0)
                {
                    rawUrl = Page.Request.RawUrl.ToString();
                }

                var traceInfo = "IsPostBack is true: " + Page.IsPostBack + " So closeDialog. url is: " + Page.Request.RawUrl.ToString();
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPostback", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose('OK', '" + rawUrl + "');</script>");

               
            }

        }
        private void makeViewOrFormForDeputyDirectorReviewandApproval(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell1, Button AddEventBtn, TableCell totalRowCell2, TableRow eventRow, TableCell totalRowCell3, TableCell totalRowCell4, TableRow attachDocRow)
        {
            var traceInfo = "makeViewOrFormForDRReview WS3";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_submitted = Page.Request.QueryString["submitted"];
            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_tab = Page.Request.QueryString["tab"];

            SPWeb oWeb = SPContext.Current.Web;




            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);


            SPQuery oQuery1 = new SPQuery();
            oQuery1.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                        "<And>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"OTA\"/>" +
                                            "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                        "</Eq>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"FY\"/>" +
                                            "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"CONOPSApproval\"/>" +
                                        "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Eq>" +
                                "<FieldRef Name=\"ContentType\"/>" +
                                "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                            "</Eq>" +
                        "</And>" +
                    "</Where>";

            SPListItemCollection collListItems1 = oList.GetItems(oQuery1);

             
            if (collListItems1.Count > 0)
            {

                //HasPMPreapprovalItems is true so query where Submitted is Yes and display as view with no form controls
                CONOPSApprovalSaveButton.Visible = false;
                CheckBox1.Visible = false;
                CONOPSApprovalSaveButton1.Visible = false;
                CheckBox2.Visible = false;
                SaveDiv1.Visible = false;
                SaveDiv2.Visible = false;
                try
                {
                    TableRowCollection rows = CONOPSDevWSTable.Rows;

                    int eventRowIndex = 4;
                    int attachmentIndex = 6;
                    Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");


                    //------------- lib -----------------
                    SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);


                    SPQuery oLibQuery = new SPQuery();


                    oLibQuery.Query = "" +
                         "<OrderBy>" +
                             "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                         "</OrderBy>" +
                         "<Where>" +
                             "<And>" +
                                 "<Eq>" +
                                     "<FieldRef Name=\"FY\"/>" +
                                     "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                 "</Eq>" +
                                  "<Eq>" +
                                     "<FieldRef Name=\"WS\"/>" +
                                     "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                                 "</Eq>" +
                             "</And>" +
                         "</Where>";

                    SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                    if (collLibItems.Count > 0)
                    {
                        bool removeAttachmentRow = true;

                        foreach (SPListItem oLibItem in collLibItems)
                        {


                            SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                            foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                            {
                                if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                                {
                                    traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    TableRow attachmentsValRw = new TableRow();

                                    TableCell attachmentsValRwCell = new TableCell();

                                    TableCell attachmentsValRwCell2 = new TableCell();
                                    TableCell attachmentsValRwCell3 = new TableCell();

                                    attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                    attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                    attachmentsValRwCell.ColumnSpan = 5;
                                    attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                    attachmentsValRwCell.Style.Add("text-align", "center");

                                    string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                    traceInfo = versionUrl;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    Literal LiteralattachmentsValRwCell = new Literal();
                                    LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                    attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                    attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                    string id = oLibItem.ID.ToString();

                                    //Approval

                                    string attachmentsValRwCell2Text = "";
                                    string attachmentsValRwCell3Text = "";
                                    try
                                    {
                                        attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalDRReview"];
                                        attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalDRComments"];
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }


                                    attachmentsValRwCell2.Text = attachmentsValRwCell2Text;
                                    attachmentsValRwCell3.Text = attachmentsValRwCell3Text;

                                    //---------------

                                    attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                    attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                    attachmentsValRw.ID = id;

                                    CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                    removeAttachmentRow = false;

                                    break;

                                }
                            }

                        }

                        if (removeAttachmentRow)
                        {
                            CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                        }

                        CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                    }
                    else
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                        CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                    }


                    SPQuery oQuery = new SPQuery();
                    oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                     "<Eq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems = oList.GetItems(oQuery);
                    foreach (SPListItem oListItem in collListItems)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        if (oListItem[TotalGUID] != null)
                        {
                            try
                            {
                                traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                totalRowCell2.Text = oListItem[TotalGUID].ToString();
                                totalRowCell1.Controls.Remove(AddEventBtn);
                                //try
                                //{
                                //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                                //    {
                                //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                                //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                //        totalRowCell2.Style.Add("border-bottom", "solid");
                                //        totalRowCell2.Style.Add("border-top", "solid");
                                //        totalRowCell2.Style.Add("border-left", "solid");
                                //        totalRowCell2.Style.Add("border-right", "solid");
                                //        totalRowCell2.Style.Add("border-color", bdrcolor);
                                //    }
                                //}
                                //catch (Exception ex)
                                //{
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                //}


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents5", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string totalRowCell3Text = "";
                            string totalRowCell4Text = "";
                            try
                            {
                                totalRowCell3Text = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                                totalRowCell4Text = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents6", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            totalRowCell3.Text = totalRowCell3Text;
                            totalRowCell4.Text = totalRowCell4Text;

                            totalRowCell3.CssClass = "CONOPSApprovalCell";
                            totalRowCell4.CssClass = "CONOPSApprovalCell";
                        }

                        
                    }

                    SPQuery oQuery3 = new SPQuery();
                    oQuery3.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                     "<Neq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems3 = oList.GetItems(oQuery3);
                    foreach (SPListItem oListItem in collListItems3)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        TableCell EventNameCell = new TableCell();
                        TableCell PeopleCell = new TableCell();
                        TableCell DatesCell = new TableCell();
                        TableCell RemarksCell = new TableCell();
                        TableCell FundingCell = new TableCell();

                        TableCell ApprovalCell = new TableCell();
                        TableCell CommentsCell = new TableCell();

                        EventNameCell.Style["padding-left"] = "3px";
                        PeopleCell.Style["text-align"] = "center";
                        DatesCell.Style["text-align"] = "center";
                        RemarksCell.Style["padding-left"] = "3px";
                        FundingCell.Style["text-align"] = "center";

                        string EventName = "";
                        string People = "";
                        string Dates = "";
                        string Remarks = "";
                        string Funding = "";

                        EventName += oListItem.Title.ToString();
                        try { People += oListItem["People"].ToString(); }
                        catch { }
                        try { Dates += oListItem["Dates"].ToString(); }
                        catch { }
                        try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                        catch { }
                        try { Funding += oListItem["Funding"].ToString(); }
                        catch { }



                        EventNameCell.Text = EventName;
                        PeopleCell.Text = People;
                        DatesCell.Text = Dates;
                        RemarksCell.Text = Remarks;
                        FundingCell.Text = Funding;





                        rw.Cells.Add(EventNameCell);
                        rw.Cells.Add(PeopleCell);
                        rw.Cells.Add(DatesCell);
                        rw.Cells.Add(RemarksCell);
                        rw.Cells.Add(FundingCell);

                        try
                        {
                            //traceInfo = "call to IsDiff: " + IsDiff("Title", EventName, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            string srcID = "0";
                            if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                            string srcIDAO = "0";
                            if (oListItem["AOReviewID"] != null) { srcIDAO = oListItem["AOReviewID"].ToString(); }


                            if (IsDiff("Title", EventName, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Title", EventName, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                EventNameCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                EventNameCell.Style.Add("border-bottom", "solid");
                                EventNameCell.Style.Add("border-top", "solid");
                                EventNameCell.Style.Add("border-left", "solid");
                                EventNameCell.Style.Add("border-right", "solid");
                                EventNameCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                PeopleCell.Style.Add("border-bottom", "solid");
                                PeopleCell.Style.Add("border-top", "solid");
                                PeopleCell.Style.Add("border-left", "solid");
                                PeopleCell.Style.Add("border-right", "solid");
                                PeopleCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                DatesCell.Style.Add("border-bottom", "solid");
                                DatesCell.Style.Add("border-top", "solid");
                                DatesCell.Style.Add("border-left", "solid");
                                DatesCell.Style.Add("border-right", "solid");
                                DatesCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Remarks", Remarks, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                RemarksCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                RemarksCell.Style.Add("border-bottom", "solid");
                                RemarksCell.Style.Add("border-top", "solid");
                                RemarksCell.Style.Add("border-left", "solid");
                                RemarksCell.Style.Add("border-right", "solid");
                                RemarksCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                FundingCell.Style.Add("border-bottom", "solid");
                                FundingCell.Style.Add("border-top", "solid");
                                FundingCell.Style.Add("border-left", "solid");
                                FundingCell.Style.Add("border-right", "solid");
                                FundingCell.Style.Add("border-color", bdrcolor);
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        //Approval

                        string ApprovalCellText = "";
                        string CommentsCellText = "";
                        try
                        {
                            ApprovalCellText = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                            CommentsCellText = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        ApprovalCell.CssClass = "CONOPSApprovalCell";
                        CommentsCell.CssClass = "CONOPSApprovalCell";
                        ApprovalCell.Text = ApprovalCellText;
                        CommentsCell.Text = CommentsCellText;

                        //---------------


                        rw.Cells.Add(ApprovalCell);
                        rw.Cells.Add(CommentsCell);

                        CONOPSDevWSTable.Rows.AddAt(eventRowIndex, rw);
                    }




                    try
                    {
                        CONOPSDevWSTable.Controls.Remove(attachDocRow);
                        CONOPSDevWSTable.Controls.Remove(eventRow);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }




                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }

            else
            {
                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int eventRowIndex = 4;

                int attachmentIndex = 6;



                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 5;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalDRReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalDRComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem attachmentsValRwCell2ListItem1 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem2 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem3 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem4 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem5 = new ListItem();

                                attachmentsValRwCell2ListItem1.Value = "Pending";
                                attachmentsValRwCell2ListItem1.Text = "Pending";
                                attachmentsValRwCell2ListItem1.Selected = true;

                                attachmentsValRwCell2ListItem2.Value = "Approved";
                                attachmentsValRwCell2ListItem2.Text = "Approved";

                                attachmentsValRwCell2ListItem3.Value = "Approved With Comments";
                                attachmentsValRwCell2ListItem3.Text = "Approved With Comments";

                                attachmentsValRwCell2ListItem4.Value = "Approved With Revisions";
                                attachmentsValRwCell2ListItem4.Text = "Approved With Revisions";

                                attachmentsValRwCell2ListItem5.Value = "Not Approved";
                                attachmentsValRwCell2ListItem5.Text = "Not Approved";


                                DropDownList attachmentsValRwCell2DropDownList = new DropDownList();
                                attachmentsValRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                                attachmentsValRwCell2DropDownList.ID = "attId" + id + "CONOPSApprovalDRReview";

                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem1);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem2);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem3);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem4);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem5);


                                TextBox attachmentsValRwCell3TextBox = new TextBox();
                                attachmentsValRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                                attachmentsValRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";

                                attachmentsValRwCell2DropDownList.SelectedValue = attachmentsValRwCell2Text;
                                attachmentsValRwCell3TextBox.Text = attachmentsValRwCell3Text;
                                attachmentsValRwCell3TextBox.ID = "attId" + id + "CONOPSApprovalDRComments";

                                attachmentsValRwCell2.Controls.Add(attachmentsValRwCell2DropDownList);
                                attachmentsValRwCell3.Controls.Add(attachmentsValRwCell3TextBox);

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }


                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                               "<OrderBy>" +
                                   "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                               "</OrderBy>" +
                               "<Where>" +
                                 "<And>" +
                               "<And>" +
                                   "<And>" +
                                       "<And>" +
                                           "<And>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"OTA\"/>" +
                                                   "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                               "</Eq>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"FY\"/>" +
                                                   "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                               "</Eq>" +
                                           "</And>" +
                                           "<Eq>" +
                                               "<FieldRef Name=\"CONOPSApproval\"/>" +
                                               "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                           "</Eq>" +
                                       "</And>" +
                                       "<Neq>" +
                                           "<FieldRef Name=\"Submitted\"/>" +
                                           "<Value Type=\"Text\">Yes</Value>" +
                                       "</Neq>" +
                                   "</And>" +
                                        "<Eq>" +
                                         "<FieldRef Name=\"ContentType\"/>" +
                                         "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                        "</Eq>" +
                                   "</And>" +
                                       "<Eq>" +
                                           "<FieldRef Name=\"Title\"/>" +
                                           "<Value Type=\"Text\">Total</Value>" +
                                       "</Eq>" +
                                   "</And>" +
                           "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //Total first, then get set of items minus total but including those items added during conopsapproval


                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");
                string totalAsText = "Total";
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();
                    //Only one Total
                    string id = oListItem.ID.ToString();

                    if (totalRowCell2.Text == "0000")
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = "";

                            TextBox totalRowCell2TextBox = new TextBox();
                            totalRowCell2TextBox.Width = 80;
                            totalRowCell2TextBox.Text = oListItem[TotalGUID].ToString();
                            totalRowCell2TextBox.ID = "rowId" + id + "Total";

                            totalRowCell2.Controls.Add(totalRowCell2TextBox);



                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                            //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", bdrcolor);
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}


                            if (totalAsText == oListItem.Title.ToString())
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem totalRowCell3ListItem1 = new ListItem();
                                ListItem totalRowCell3ListItem2 = new ListItem();
                                ListItem totalRowCell3ListItem3 = new ListItem();
                                ListItem totalRowCell3ListItem4 = new ListItem();
                                ListItem totalRowCell3ListItem5 = new ListItem();

                                totalRowCell3ListItem1.Value = "Pending";
                                totalRowCell3ListItem1.Text = "Pending";
                                totalRowCell3ListItem1.Selected = true;

                                totalRowCell3ListItem2.Value = "Approved";
                                totalRowCell3ListItem2.Text = "Approved";

                                totalRowCell3ListItem3.Value = "Approved With Comments";
                                totalRowCell3ListItem3.Text = "Approved With Comments";

                                totalRowCell3ListItem4.Value = "Approved With Revisions";
                                totalRowCell3ListItem4.Text = "Approved With Revisions";

                                totalRowCell3ListItem5.Value = "Not Approved";
                                totalRowCell3ListItem5.Text = "Not Approved";



                                DropDownList totalRowCell3DropDownList = new DropDownList();
                                totalRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                                totalRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalDRReview";

                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem1);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem2);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem3);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem4);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem5);

                                TextBox totalRowCell4TextBox = new TextBox();
                                totalRowCell4TextBox.TextMode = TextBoxMode.MultiLine;

                                totalRowCell3DropDownList.SelectedValue = totalRowCell3Text;
                                totalRowCell4TextBox.Text = totalRowCell4Text;
                                totalRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalDRComments";

                                totalRowCell3.Controls.Add(totalRowCell3DropDownList);
                                totalRowCell4.Controls.Add(totalRowCell4TextBox);

                                //---------------
                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("add total row", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }
                //end Total------------




                SPQuery oQuery2 = new SPQuery();
                oQuery2.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                             "<And>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                 "<Neq>" +
                                        "<FieldRef Name=\"Title\"/>" +
                                        "<Value Type=\"Text\">Total</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItems2 = oList.GetItems(oQuery2);

                foreach (SPListItem oListItem in collListItems2)
                {
                    string id = oListItem.ID.ToString();

                    string title = "" + oListItem.Title.ToString();
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    TableRow rw = new TableRow();

                    TableCell EventNameCell = new TableCell();
                    TableCell PeopleCell = new TableCell();
                    TableCell DatesCell = new TableCell();
                    TableCell RemarksCell = new TableCell();
                    TableCell FundingCell = new TableCell();

                    TableCell ApprovalCell = new TableCell();
                    TableCell CommentsCell = new TableCell();

                    EventNameCell.Style["padding-left"] = "3px";
                    PeopleCell.Style["text-align"] = "center";
                    DatesCell.Style["text-align"] = "center";
                    RemarksCell.Style["padding-left"] = "3px";
                    FundingCell.Style["text-align"] = "center";

                    string EventName = "";
                    string People = "";
                    string Dates = "";
                    string Remarks = "";
                    string Funding = "";

                    EventName += oListItem.Title.ToString();
                    try { People += oListItem["People"].ToString(); }
                    catch { }
                    try { Dates += oListItem["Dates"].ToString(); }
                    catch { }
                    try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                    catch { }
                    try { Funding += oListItem["Funding"].ToString(); }
                    catch { }

                    TextBox EventNameCellTextBox = new TextBox();
                    TextBox PeopleCellTextBox = new TextBox();
                    TextBox DatesCellTextBox = new TextBox();
                    TextBox RemarksCellTextBox = new TextBox();
                    TextBox FundingCellTextBox = new TextBox();

                    EventNameCellTextBox.Width = 80;
                    PeopleCellTextBox.Width = 80;
                    DatesCellTextBox.Width = 80;
                    RemarksCellTextBox.Width = 80;
                    FundingCellTextBox.Width = 80;

                    EventNameCellTextBox.ID = "rowId" + id + "Title";
                    PeopleCellTextBox.ID = "rowId" + id + "People";
                    DatesCellTextBox.ID = "rowId" + id + "Dates";
                    RemarksCellTextBox.ID = "rowId" + id + "Remarks";
                    FundingCellTextBox.ID = "rowId" + id + "Funding";

                    EventNameCellTextBox.Text = EventName;
                    PeopleCellTextBox.Text = People;
                    DatesCellTextBox.Text = Dates;
                    RemarksCellTextBox.Text = Remarks;
                    FundingCellTextBox.Text = Funding;

                    EventNameCell.Controls.Add(EventNameCellTextBox);
                    PeopleCell.Controls.Add(PeopleCellTextBox);
                    DatesCell.Controls.Add(DatesCellTextBox);
                    RemarksCell.Controls.Add(RemarksCellTextBox);
                    FundingCell.Controls.Add(FundingCellTextBox);



                    rw.Cells.Add(EventNameCell);
                    rw.Cells.Add(PeopleCell);
                    rw.Cells.Add(DatesCell);
                    rw.Cells.Add(RemarksCell);
                    rw.Cells.Add(FundingCell);

                    try
                    {
                        //traceInfo = "call to IsDiff: " + IsDiff("Title", EventName, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string srcID = "0";
                        if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                        string srcIDAO = "0";
                        if (oListItem["AOReviewID"] != null) { srcIDAO = oListItem["AOReviewID"].ToString(); }


                        if (IsDiff("Title", EventName, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Title", EventName, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            EventNameCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            EventNameCell.Style.Add("border-bottom", "solid");
                            EventNameCell.Style.Add("border-top", "solid");
                            EventNameCell.Style.Add("border-left", "solid");
                            EventNameCell.Style.Add("border-right", "solid");
                            EventNameCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            PeopleCell.Style.Add("border-bottom", "solid");
                            PeopleCell.Style.Add("border-top", "solid");
                            PeopleCell.Style.Add("border-left", "solid");
                            PeopleCell.Style.Add("border-right", "solid");
                            PeopleCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            DatesCell.Style.Add("border-bottom", "solid");
                            DatesCell.Style.Add("border-top", "solid");
                            DatesCell.Style.Add("border-left", "solid");
                            DatesCell.Style.Add("border-right", "solid");
                            DatesCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Remarks", Remarks, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            RemarksCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            RemarksCell.Style.Add("border-bottom", "solid");
                            RemarksCell.Style.Add("border-top", "solid");
                            RemarksCell.Style.Add("border-left", "solid");
                            RemarksCell.Style.Add("border-right", "solid");
                            RemarksCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            FundingCell.Style.Add("border-bottom", "solid");
                            FundingCell.Style.Add("border-top", "solid");
                            FundingCell.Style.Add("border-left", "solid");
                            FundingCell.Style.Add("border-right", "solid");
                            FundingCell.Style.Add("border-color", bdrcolor);
                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    //Approval

                    string ApprovalCellText = "";
                    string CommentsCellText = "";
                    try
                    {
                        ApprovalCellText = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                        CommentsCellText = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }


                    ListItem ApprovalCellListItem1 = new ListItem();
                    ListItem ApprovalCellListItem2 = new ListItem();
                    ListItem ApprovalCellListItem3 = new ListItem();
                    ListItem ApprovalCellListItem4 = new ListItem();
                    ListItem ApprovalCellListItem5 = new ListItem();

                    ApprovalCellListItem1.Value = "Pending";
                    ApprovalCellListItem1.Text = "Pending";
                    ApprovalCellListItem1.Selected = true;

                    ApprovalCellListItem2.Value = "Approved";
                    ApprovalCellListItem2.Text = "Approved";

                    ApprovalCellListItem3.Value = "Approved With Comments";
                    ApprovalCellListItem3.Text = "Approved With Comments";

                    ApprovalCellListItem4.Value = "Approved With Revisions";
                    ApprovalCellListItem4.Text = "Approved With Revisions";

                    ApprovalCellListItem5.Value = "Not Approved";
                    ApprovalCellListItem5.Text = "Not Approved";



                    DropDownList ApprovalCellDropDownList = new DropDownList();
                    ApprovalCellDropDownList.CssClass = "CONOPSApprovalSelect";

                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem1);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem2);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem3);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem4);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem5);
                    ApprovalCellDropDownList.ID = "rowId" + id + "CONOPSApprovalDRReview";

                    TextBox CommentsCellTextBox = new TextBox();
                    CommentsCellTextBox.TextMode = TextBoxMode.MultiLine;

                    ApprovalCellDropDownList.SelectedValue = ApprovalCellText;
                    CommentsCellTextBox.Text = CommentsCellText;
                    CommentsCellTextBox.ID = "rowId" + id + "CONOPSApprovalDRComments";

                    ApprovalCell.Controls.Add(ApprovalCellDropDownList);
                    CommentsCell.Controls.Add(CommentsCellTextBox);
                    ApprovalCell.CssClass = "CONOPSApprovalCell";
                    CommentsCell.CssClass = "CONOPSApprovalCell";

                    //---------------


                    rw.Cells.Add(ApprovalCell);
                    rw.Cells.Add(CommentsCell);

                    CONOPSDevWSTable.Rows.AddAt(eventRowIndex, rw);

                }
                try
                {
                    CONOPSDevWSTable.Controls.Remove(eventRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }
        }


        private void makeViewOrFormForPMReview(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell1, Button AddEventBtn, TableCell totalRowCell2, TableRow eventRow, TableCell totalRowCell3, TableCell totalRowCell4, TableRow attachDocRow)
        {

            var traceInfo = "makeViewOrFormForPMReview WS3";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_submitted = Page.Request.QueryString["submitted"];
            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_tab = Page.Request.QueryString["tab"];

            SPWeb oWeb = SPContext.Current.Web;

            bool HasDDApprovalItems = false;

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And><Eq><FieldRef Name='CONOPSApproval'/><Value Type='Text'>Deputy Director Approval</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);
            if (collListItemsCONOPSApprovalProgress.Count > 0) { HasDDApprovalItems = true; }

            traceInfo = "HasDDApprovalItems: " + HasDDApprovalItems;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("WS4makeViewOrFormForPMReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            if (HasDDApprovalItems)
            {
                //HasDDApprovalItems is true so query where Submitted is Yes and display as view with no form controls
                CONOPSApprovalSaveButton.Visible = false;
                CheckBox1.Visible = false;
                CONOPSApprovalSaveButton1.Visible = false;
                CheckBox2.Visible = false;
                SaveDiv1.Visible = false;
                SaveDiv2.Visible = false;
                try
                {
                    TableRowCollection rows = CONOPSDevWSTable.Rows;

                    int eventRowIndex = 4;
                    int attachmentIndex = 6;
                    Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");


                    //------------- lib -----------------
                    SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);


                    SPQuery oLibQuery = new SPQuery();


                    oLibQuery.Query = "" +
                         "<OrderBy>" +
                             "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                         "</OrderBy>" +
                         "<Where>" +
                             "<And>" +
                                 "<Eq>" +
                                     "<FieldRef Name=\"FY\"/>" +
                                     "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                 "</Eq>" +
                                  "<Eq>" +
                                     "<FieldRef Name=\"WS\"/>" +
                                     "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                                 "</Eq>" +
                             "</And>" +
                         "</Where>";

                    SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                    if (collLibItems.Count > 0)
                    {
                        bool removeAttachmentRow = true;

                        foreach (SPListItem oLibItem in collLibItems)
                        {


                            SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                            foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                            {
                                if ((string)oListItemVersion["CONOPSApproval"] == "PM Preapproval")
                                {
                                    traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    TableRow attachmentsValRw = new TableRow();

                                    TableCell attachmentsValRwCell = new TableCell();

                                    TableCell attachmentsValRwCell2 = new TableCell();
                                    TableCell attachmentsValRwCell3 = new TableCell();

                                    attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                    attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                    attachmentsValRwCell.ColumnSpan = 5;
                                    attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                    attachmentsValRwCell.Style.Add("text-align", "center");

                                    string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                    traceInfo = versionUrl;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    Literal LiteralattachmentsValRwCell = new Literal();
                                    LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                    attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                    attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                    string id = oLibItem.ID.ToString();

                                    //Approval

                                    string attachmentsValRwCell2Text = "";
                                    string attachmentsValRwCell3Text = "";
                                    try
                                    {
                                        attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalPMReview"];
                                        attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalPMComments"];
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }


                                    attachmentsValRwCell2.Text = attachmentsValRwCell2Text;
                                    attachmentsValRwCell3.Text = attachmentsValRwCell3Text;

                                    //---------------

                                    attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                    attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                    attachmentsValRw.ID = id;

                                    CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                    removeAttachmentRow = false;

                                    break;

                                }
                            }

                        }

                        if (removeAttachmentRow)
                        {
                            CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                        }

                        CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                    }
                    else
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                        CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                    }

                    SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);

                    SPQuery oQuery = new SPQuery();
                    oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">PM Preapproval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                     "<Eq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems = oList.GetItems(oQuery);
                    foreach (SPListItem oListItem in collListItems)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        if (oListItem[TotalGUID] != null)
                        {
                            try
                            {
                                traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                totalRowCell2.Text = oListItem[TotalGUID].ToString();
                                totalRowCell1.Controls.Remove(AddEventBtn);
                                //try
                                //{
                                //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                                //    {
                                //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                                //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                //        totalRowCell2.Style.Add("border-bottom", "solid");
                                //        totalRowCell2.Style.Add("border-top", "solid");
                                //        totalRowCell2.Style.Add("border-left", "solid");
                                //        totalRowCell2.Style.Add("border-right", "solid");
                                //        totalRowCell2.Style.Add("border-color", bdrcolor);
                                //    }
                                //}
                                //catch (Exception ex)
                                //{
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                //}


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents5", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string totalRowCell3Text = "";
                            string totalRowCell4Text = "";
                            try
                            {
                                totalRowCell3Text = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                                totalRowCell4Text = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents6", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            totalRowCell3.Text = totalRowCell3Text;
                            totalRowCell4.Text = totalRowCell4Text;

                            totalRowCell3.CssClass = "CONOPSApprovalCell";
                            totalRowCell4.CssClass = "CONOPSApprovalCell";
                        }


                    }

                    SPQuery oQuery3 = new SPQuery();
                    oQuery3.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">PM Preapproval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                     "<Neq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems3 = oList.GetItems(oQuery3);
                    foreach (SPListItem oListItem in collListItems3)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        TableCell EventNameCell = new TableCell();
                        TableCell PeopleCell = new TableCell();
                        TableCell DatesCell = new TableCell();
                        TableCell RemarksCell = new TableCell();
                        TableCell FundingCell = new TableCell();

                        TableCell ApprovalCell = new TableCell();
                        TableCell CommentsCell = new TableCell();

                        EventNameCell.Style["padding-left"] = "3px";
                        PeopleCell.Style["text-align"] = "center";
                        DatesCell.Style["text-align"] = "center";
                        RemarksCell.Style["padding-left"] = "3px";
                        FundingCell.Style["text-align"] = "center";

                        string EventName = "";
                        string People = "";
                        string Dates = "";
                        string Remarks = "";
                        string Funding = "";

                        EventName += oListItem.Title.ToString();
                        try { People += oListItem["People"].ToString(); }
                        catch { }
                        try { Dates += oListItem["Dates"].ToString(); }
                        catch { }
                        try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                        catch { }
                        try { Funding += oListItem["Funding"].ToString(); }
                        catch { }



                        EventNameCell.Text = EventName;
                        PeopleCell.Text = People;
                        DatesCell.Text = Dates;
                        RemarksCell.Text = Remarks;
                        FundingCell.Text = Funding;





                        rw.Cells.Add(EventNameCell);
                        rw.Cells.Add(PeopleCell);
                        rw.Cells.Add(DatesCell);
                        rw.Cells.Add(RemarksCell);
                        rw.Cells.Add(FundingCell);

                        try
                        {
                            //traceInfo = "call to IsDiff: " + IsDiff("Title", EventName, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            string srcID = "0";
                            if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                            string srcIDAO = "0";
                            if (oListItem["AOReviewID"] != null) { srcIDAO = oListItem["AOReviewID"].ToString(); }


                            if (IsDiff("Title", EventName, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Title", EventName, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                EventNameCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                EventNameCell.Style.Add("border-bottom", "solid");
                                EventNameCell.Style.Add("border-top", "solid");
                                EventNameCell.Style.Add("border-left", "solid");
                                EventNameCell.Style.Add("border-right", "solid");
                                EventNameCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                PeopleCell.Style.Add("border-bottom", "solid");
                                PeopleCell.Style.Add("border-top", "solid");
                                PeopleCell.Style.Add("border-left", "solid");
                                PeopleCell.Style.Add("border-right", "solid");
                                PeopleCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                DatesCell.Style.Add("border-bottom", "solid");
                                DatesCell.Style.Add("border-top", "solid");
                                DatesCell.Style.Add("border-left", "solid");
                                DatesCell.Style.Add("border-right", "solid");
                                DatesCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Remarks", Remarks, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                RemarksCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                RemarksCell.Style.Add("border-bottom", "solid");
                                RemarksCell.Style.Add("border-top", "solid");
                                RemarksCell.Style.Add("border-left", "solid");
                                RemarksCell.Style.Add("border-right", "solid");
                                RemarksCell.Style.Add("border-color", bdrcolor);
                            }
                            if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                            {
                                string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                                string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                FundingCell.Style.Add("border-bottom", "solid");
                                FundingCell.Style.Add("border-top", "solid");
                                FundingCell.Style.Add("border-left", "solid");
                                FundingCell.Style.Add("border-right", "solid");
                                FundingCell.Style.Add("border-color", bdrcolor);
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        //Approval

                        string ApprovalCellText = "";
                        string CommentsCellText = "";
                        try
                        {
                            ApprovalCellText = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                            CommentsCellText = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        ApprovalCell.CssClass = "CONOPSApprovalCell";
                        CommentsCell.CssClass = "CONOPSApprovalCell";
                        ApprovalCell.Text = ApprovalCellText;
                        CommentsCell.Text = CommentsCellText;

                        //---------------


                        rw.Cells.Add(ApprovalCell);
                        rw.Cells.Add(CommentsCell);

                        CONOPSDevWSTable.Rows.AddAt(eventRowIndex, rw);
                    }




                    try
                    {
                        CONOPSDevWSTable.Controls.Remove(attachDocRow);
                        CONOPSDevWSTable.Controls.Remove(eventRow);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }




                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }

            else
            {
                //HasDDApprovalItems is false so query where Submitted is not Yes and display form controls


                traceInfo = "HasDDApprovalItems is false: " + HasDDApprovalItems;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("WS3HasDDApprovalItemsFalse", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int eventRowIndex = 4;

                int attachmentIndex = 6;



                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "PM Preapproval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 5;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalPMReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalPMComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem attachmentsValRwCell2ListItem1 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem2 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem3 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem4 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem5 = new ListItem();

                                attachmentsValRwCell2ListItem1.Value = "Pending";
                                attachmentsValRwCell2ListItem1.Text = "Pending";
                                attachmentsValRwCell2ListItem1.Selected = true;

                                attachmentsValRwCell2ListItem2.Value = "Approved";
                                attachmentsValRwCell2ListItem2.Text = "Approved";

                                attachmentsValRwCell2ListItem3.Value = "Approved With Comments";
                                attachmentsValRwCell2ListItem3.Text = "Approved With Comments";

                                attachmentsValRwCell2ListItem4.Value = "Approved With Revisions";
                                attachmentsValRwCell2ListItem4.Text = "Approved With Revisions";

                                attachmentsValRwCell2ListItem5.Value = "Not Approved";
                                attachmentsValRwCell2ListItem5.Text = "Not Approved";


                                DropDownList attachmentsValRwCell2DropDownList = new DropDownList();
                                attachmentsValRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                                attachmentsValRwCell2DropDownList.ID = "attId" + id + "CONOPSApprovalPMReview";

                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem1);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem2);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem3);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem4);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem5);


                                TextBox attachmentsValRwCell3TextBox = new TextBox();
                                attachmentsValRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                                attachmentsValRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";

                                attachmentsValRwCell2DropDownList.SelectedValue = attachmentsValRwCell2Text;
                                attachmentsValRwCell3TextBox.Text = attachmentsValRwCell3Text;
                                attachmentsValRwCell3TextBox.ID = "attId" + id + "CONOPSApprovalPMComments";

                                attachmentsValRwCell2.Controls.Add(attachmentsValRwCell2DropDownList);
                                attachmentsValRwCell3.Controls.Add(attachmentsValRwCell3TextBox);

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }


                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                               "<OrderBy>" +
                                   "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                               "</OrderBy>" +
                               "<Where>" +
                                 "<And>" +
                               "<And>" +
                                   "<And>" +
                                       "<And>" +
                                           "<And>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"OTA\"/>" +
                                                   "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                               "</Eq>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"FY\"/>" +
                                                   "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                               "</Eq>" +
                                           "</And>" +
                                           "<Eq>" +
                                               "<FieldRef Name=\"CONOPSApproval\"/>" +
                                               "<Value Type=\"Text\">PM Preapproval</Value>" +
                                           "</Eq>" +
                                       "</And>" +
                                       "<Neq>" +
                                           "<FieldRef Name=\"Submitted\"/>" +
                                           "<Value Type=\"Text\">Yes</Value>" +
                                       "</Neq>" +
                                   "</And>" +
                                        "<Eq>" +
                                         "<FieldRef Name=\"ContentType\"/>" +
                                         "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                        "</Eq>" +
                                   "</And>" +
                                       "<Eq>" +
                                           "<FieldRef Name=\"Title\"/>" +
                                           "<Value Type=\"Text\">Total</Value>" +
                                       "</Eq>" +
                                   "</And>" +
                           "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //Total first, then get set of items minus total but including those items added during conopsapproval


                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");
                string totalAsText = "Total";
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();
                    //Only one Total
                    string id = oListItem.ID.ToString();

                    if (totalRowCell2.Text == "0000")
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = "";

                            TextBox totalRowCell2TextBox = new TextBox();
                            totalRowCell2TextBox.Width = 80;
                            totalRowCell2TextBox.Text = oListItem[TotalGUID].ToString();
                            totalRowCell2TextBox.ID = "rowId" + id + "Total";

                            totalRowCell2.Controls.Add(totalRowCell2TextBox);



                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                            //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", bdrcolor);
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}


                            if (totalAsText == oListItem.Title.ToString())
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem totalRowCell3ListItem1 = new ListItem();
                                ListItem totalRowCell3ListItem2 = new ListItem();
                                ListItem totalRowCell3ListItem3 = new ListItem();
                                ListItem totalRowCell3ListItem4 = new ListItem();
                                ListItem totalRowCell3ListItem5 = new ListItem();

                                totalRowCell3ListItem1.Value = "Pending";
                                totalRowCell3ListItem1.Text = "Pending";
                                totalRowCell3ListItem1.Selected = true;

                                totalRowCell3ListItem2.Value = "Approved";
                                totalRowCell3ListItem2.Text = "Approved";

                                totalRowCell3ListItem3.Value = "Approved With Comments";
                                totalRowCell3ListItem3.Text = "Approved With Comments";

                                totalRowCell3ListItem4.Value = "Approved With Revisions";
                                totalRowCell3ListItem4.Text = "Approved With Revisions";

                                totalRowCell3ListItem5.Value = "Not Approved";
                                totalRowCell3ListItem5.Text = "Not Approved";



                                DropDownList totalRowCell3DropDownList = new DropDownList();
                                totalRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                                totalRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalPMReview";

                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem1);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem2);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem3);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem4);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem5);

                                TextBox totalRowCell4TextBox = new TextBox();
                                totalRowCell4TextBox.TextMode = TextBoxMode.MultiLine;

                                totalRowCell3DropDownList.SelectedValue = totalRowCell3Text;
                                totalRowCell4TextBox.Text = totalRowCell4Text;
                                totalRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalPMComments";

                                totalRowCell3.Controls.Add(totalRowCell3DropDownList);
                                totalRowCell4.Controls.Add(totalRowCell4TextBox);

                                //---------------
                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("add total row", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }
                //end Total------------




                SPQuery oQuery2 = new SPQuery();
                oQuery2.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                             "<And>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">PM Preapproval</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                 "<Neq>" +
                                        "<FieldRef Name=\"Title\"/>" +
                                        "<Value Type=\"Text\">Total</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItems2 = oList.GetItems(oQuery2);

                foreach (SPListItem oListItem in collListItems2)
                {
                    string id = oListItem.ID.ToString();

                    string title = "" + oListItem.Title.ToString();
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    TableRow rw = new TableRow();

                    TableCell EventNameCell = new TableCell();
                    TableCell PeopleCell = new TableCell();
                    TableCell DatesCell = new TableCell();
                    TableCell RemarksCell = new TableCell();
                    TableCell FundingCell = new TableCell();

                    TableCell ApprovalCell = new TableCell();
                    TableCell CommentsCell = new TableCell();

                    EventNameCell.Style["padding-left"] = "3px";
                    PeopleCell.Style["text-align"] = "center";
                    DatesCell.Style["text-align"] = "center";
                    RemarksCell.Style["padding-left"] = "3px";
                    FundingCell.Style["text-align"] = "center";

                    string EventName = "";
                    string People = "";
                    string Dates = "";
                    string Remarks = "";
                    string Funding = "";

                    EventName += oListItem.Title.ToString();
                    try { People += oListItem["People"].ToString(); }
                    catch { }
                    try { Dates += oListItem["Dates"].ToString(); }
                    catch { }
                    try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                    catch { }
                    try { Funding += oListItem["Funding"].ToString(); }
                    catch { }

                    TextBox EventNameCellTextBox = new TextBox();
                    TextBox PeopleCellTextBox = new TextBox();
                    TextBox DatesCellTextBox = new TextBox();
                    TextBox RemarksCellTextBox = new TextBox();
                    TextBox FundingCellTextBox = new TextBox();

                    EventNameCellTextBox.Width = 80;
                    PeopleCellTextBox.Width = 80;
                    DatesCellTextBox.Width = 80;
                    RemarksCellTextBox.Width = 80;
                    FundingCellTextBox.Width = 80;

                    EventNameCellTextBox.ID = "rowId" + id + "Title";
                    PeopleCellTextBox.ID = "rowId" + id + "People";
                    DatesCellTextBox.ID = "rowId" + id + "Dates";
                    RemarksCellTextBox.ID = "rowId" + id + "Remarks";
                    FundingCellTextBox.ID = "rowId" + id + "Funding";

                    EventNameCellTextBox.Text = EventName;
                    PeopleCellTextBox.Text = People;
                    DatesCellTextBox.Text = Dates;
                    RemarksCellTextBox.Text = Remarks;
                    FundingCellTextBox.Text = Funding;

                    EventNameCell.Controls.Add(EventNameCellTextBox);
                    PeopleCell.Controls.Add(PeopleCellTextBox);
                    DatesCell.Controls.Add(DatesCellTextBox);
                    RemarksCell.Controls.Add(RemarksCellTextBox);
                    FundingCell.Controls.Add(FundingCellTextBox);



                    rw.Cells.Add(EventNameCell);
                    rw.Cells.Add(PeopleCell);
                    rw.Cells.Add(DatesCell);
                    rw.Cells.Add(RemarksCell);
                    rw.Cells.Add(FundingCell);

                    try
                    {
                        //traceInfo = "call to IsDiff: " + IsDiff("Title", EventName, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string srcID = "0";
                        if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                        string srcIDAO = "0";
                        if (oListItem["AOReviewID"] != null) { srcIDAO = oListItem["AOReviewID"].ToString(); }


                        if (IsDiff("Title", EventName, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Title", EventName, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            EventNameCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            EventNameCell.Style.Add("border-bottom", "solid");
                            EventNameCell.Style.Add("border-top", "solid");
                            EventNameCell.Style.Add("border-left", "solid");
                            EventNameCell.Style.Add("border-right", "solid");
                            EventNameCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            PeopleCell.Style.Add("border-bottom", "solid");
                            PeopleCell.Style.Add("border-top", "solid");
                            PeopleCell.Style.Add("border-left", "solid");
                            PeopleCell.Style.Add("border-right", "solid");
                            PeopleCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            DatesCell.Style.Add("border-bottom", "solid");
                            DatesCell.Style.Add("border-top", "solid");
                            DatesCell.Style.Add("border-left", "solid");
                            DatesCell.Style.Add("border-right", "solid");
                            DatesCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Remarks", Remarks, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            RemarksCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            RemarksCell.Style.Add("border-bottom", "solid");
                            RemarksCell.Style.Add("border-top", "solid");
                            RemarksCell.Style.Add("border-left", "solid");
                            RemarksCell.Style.Add("border-right", "solid");
                            RemarksCell.Style.Add("border-color", bdrcolor);
                        }
                        if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                        {
                            string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                            FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            FundingCell.Style.Add("border-bottom", "solid");
                            FundingCell.Style.Add("border-top", "solid");
                            FundingCell.Style.Add("border-left", "solid");
                            FundingCell.Style.Add("border-right", "solid");
                            FundingCell.Style.Add("border-color", bdrcolor);
                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    //Approval

                    string ApprovalCellText = "";
                    string CommentsCellText = "";
                    try
                    {
                        ApprovalCellText = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                        CommentsCellText = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }


                    ListItem ApprovalCellListItem1 = new ListItem();
                    ListItem ApprovalCellListItem2 = new ListItem();
                    ListItem ApprovalCellListItem3 = new ListItem();
                    ListItem ApprovalCellListItem4 = new ListItem();
                    ListItem ApprovalCellListItem5 = new ListItem();

                    ApprovalCellListItem1.Value = "Pending";
                    ApprovalCellListItem1.Text = "Pending";
                    ApprovalCellListItem1.Selected = true;

                    ApprovalCellListItem2.Value = "Approved";
                    ApprovalCellListItem2.Text = "Approved";

                    ApprovalCellListItem3.Value = "Approved With Comments";
                    ApprovalCellListItem3.Text = "Approved With Comments";

                    ApprovalCellListItem4.Value = "Approved With Revisions";
                    ApprovalCellListItem4.Text = "Approved With Revisions";

                    ApprovalCellListItem5.Value = "Not Approved";
                    ApprovalCellListItem5.Text = "Not Approved";



                    DropDownList ApprovalCellDropDownList = new DropDownList();
                    ApprovalCellDropDownList.CssClass = "CONOPSApprovalSelect";

                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem1);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem2);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem3);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem4);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem5);
                    ApprovalCellDropDownList.ID = "rowId" + id + "CONOPSApprovalPMReview";

                    TextBox CommentsCellTextBox = new TextBox();
                    CommentsCellTextBox.TextMode = TextBoxMode.MultiLine;

                    ApprovalCellDropDownList.SelectedValue = ApprovalCellText;
                    CommentsCellTextBox.Text = CommentsCellText;
                    CommentsCellTextBox.ID = "rowId" + id + "CONOPSApprovalPMComments";

                    ApprovalCell.Controls.Add(ApprovalCellDropDownList);
                    CommentsCell.Controls.Add(CommentsCellTextBox);
                    ApprovalCell.CssClass = "CONOPSApprovalCell";
                    CommentsCell.CssClass = "CONOPSApprovalCell";

                    //---------------


                    rw.Cells.Add(ApprovalCell);
                    rw.Cells.Add(CommentsCell);

                    CONOPSDevWSTable.Rows.AddAt(eventRowIndex, rw);

                }
                try
                {
                    CONOPSDevWSTable.Controls.Remove(eventRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }
        }


        private void enableTabs()
        {
            var traceInfo = "enableTabs";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("enableTabs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];

            SPWeb oWeb = SPContext.Current.Web;        

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            foreach (SPListItem oListItem in collListItemsCONOPSApprovalProgress)
            {

                string PMPreapproval = "PM Preapproval";
                string DeputyDirectorApproval = "Deputy Director Approval";

                try
                {
                    if (oListItem["CONOPSApproval"].ToString() == PMPreapproval )
                    {
                        DisablePMReview.Value = "No";
                    }
                    if (oListItem["CONOPSApproval"].ToString() == DeputyDirectorApproval)
                    {
                        DisablePMReview.Value = "No"; 
                        DisableDeputyDirectorReviewandApproval.Value = "No";
                    }
                    if ((string)oListItem["Submitted"] == "Yes")
                    {
                        AllTabsChecked.Value = "Yes";

                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("enableTabs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

            }
        }

        private void makeViewOrFormForOTASubmission(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell2, TableRow eventRow, TableCell totalRowCell3, TableCell totalRowCell4)
        {

            var traceInfo = "";
            int itemRowIndex = 4;
            int attachmentIndex = 6;
            SPWeb oWeb = SPContext.Current.Web;
            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);
            SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);


            //oLib            
            traceInfo = "oLib for attachments";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPQuery oLibQuery = new SPQuery();
            try
            {

                oLibQuery.Query = "" +
                       "<OrderBy>" +
                           "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                       "</OrderBy>" +
                       "<Where>" +
                           "<Or>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"FY\"/>" +
                                        "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                    "</Eq>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"WS\"/>" +
                                        "<Value Type=\"Text\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                    "</Eq>" +
                                "</And>" +

                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"FY\"/>" +
                                        "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                    "</Eq>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Title\"/>" +
                                        "<Value Type=\"Text\">Approval Memo</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Or>" +
                        "</Where>";
                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;
                    string approvalMemoStr = "";

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Baseline OTA Submission" && oListItemVersion.VersionLabel != "1.0")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                
                                if (oListItemVersion["Title"] != null)
                                {
                                    if ((string)oListItemVersion["Title"] == "Approval Memo")
                                    {
                                        approvalMemoStr = "Approval Memo: ";
                                    }
                                }

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();

                                attachmentsValRwCell.ColumnSpan = 5;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + approvalMemoStr + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
           

            try
            {
                //oList
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + Page.Request.QueryString["otashort"] + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">Baseline OTA Submission</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);


                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");


                foreach (SPListItem oListItem in collListItems)
                {
                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = oListItem[TotalGUID].ToString();
                            
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                    else
                    {
                        TableRow rw = new TableRow();

                        TableCell EventNameCell = new TableCell();
                        TableCell PeopleCell = new TableCell();
                        TableCell DatesCell = new TableCell();
                        TableCell RemarksCell = new TableCell();
                        TableCell FundingCell = new TableCell();

                        EventNameCell.Style["padding-left"] = "3px";
                        PeopleCell.Style["text-align"] = "center";
                        DatesCell.Style["text-align"] = "center";
                        RemarksCell.Style["padding-left"] = "3px";
                        FundingCell.Style["text-align"] = "center";

                        string EventName = "";
                        string People = "";
                        string Dates = "";
                        string Remarks = "";
                        string Funding = "";

                        EventName += oListItem.Title.ToString();
                        try { People += oListItem["People"].ToString(); }
                        catch { }
                        try { Dates += oListItem["Dates"].ToString(); }
                            catch { }
                        try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                            catch { }
                        try { Funding += oListItem["Funding"].ToString(); }
                        catch { }

                        EventNameCell.Text = EventName;
                        PeopleCell.Text = People;
                        DatesCell.Text = Dates;
                        RemarksCell.Text = Remarks;
                        FundingCell.Text = Funding;

                        rw.Cells.Add(EventNameCell);
                        rw.Cells.Add(PeopleCell);
                        rw.Cells.Add(DatesCell);
                        rw.Cells.Add(RemarksCell);
                        rw.Cells.Add(FundingCell);

                        CONOPSDevWSTable.Rows.AddAt(itemRowIndex, rw);

                    }


                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }

            try
            {

                CONOPSDevWSTable.Controls.Remove(eventRow);
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }


        private void makeViewOrFormForAOReview(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell1, Button AddEventBtn, TableCell totalRowCell2, TableRow eventRow, TableCell totalRowCell3, TableCell totalRowCell4, TableRow attachDocRow)
        {

            var traceInfo = "makeViewOrFormForAOReview WS3";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_submitted = Page.Request.QueryString["submitted"];
            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_tab = Page.Request.QueryString["tab"];

            SPWeb oWeb = SPContext.Current.Web;
            bool HasPMPreapprovalItems = false;

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And><Eq><FieldRef Name='CONOPSApproval'/><Value Type='Text'>PM Preapproval</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);
            if (collListItemsCONOPSApprovalProgress.Count > 0) { HasPMPreapprovalItems = true; }
            SPQuery oQueryCONOPSApprovalProgress2 = new SPQuery();
            oQueryCONOPSApprovalProgress2.Query = "<Where><And><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And><Eq><FieldRef Name='CONOPSApproval'/><Value Type='Text'>Deputy Director Approval</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress2 = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress2);
            if (collListItemsCONOPSApprovalProgress2.Count > 0) { HasPMPreapprovalItems = true; }
            if (HasPMPreapprovalItems)
            {
                //HasPMPreapprovalItems is true so query where Submitted is Yes and display as view with no form controls
                CONOPSApprovalSaveButton.Visible = false;
                CheckBox1.Visible = false;
                CONOPSApprovalSaveButton1.Visible = false;
                CheckBox2.Visible = false;
                SaveDiv1.Visible = false;
                SaveDiv2.Visible = false;
                try
                {
                    TableRowCollection rows = CONOPSDevWSTable.Rows;

                    int eventRowIndex = 4;
                    int attachmentIndex = 6;
                    Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");


                    //------------- lib -----------------
                    SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);


                    SPQuery oLibQuery = new SPQuery();


                    oLibQuery.Query = "" +
                         "<OrderBy>" +
                             "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                         "</OrderBy>" +
                         "<Where>" +
                             "<And>" +
                                 "<Eq>" +
                                     "<FieldRef Name=\"FY\"/>" +
                                     "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                 "</Eq>" +
                                  "<Eq>" +
                                     "<FieldRef Name=\"WS\"/>" +
                                     "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                                 "</Eq>" +
                             "</And>" +
                         "</Where>";

                    SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                    if (collLibItems.Count > 0)
                    {
                        bool removeAttachmentRow = true;

                        foreach (SPListItem oLibItem in collLibItems)
                        {


                            SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                            foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                            {
                                if ((string)oListItemVersion["CONOPSApproval"] == "AO Recommendation")
                                {
                                    traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    TableRow attachmentsValRw = new TableRow();

                                    TableCell attachmentsValRwCell = new TableCell();

                                    TableCell attachmentsValRwCell2 = new TableCell();
                                    TableCell attachmentsValRwCell3 = new TableCell();

                                    attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                    attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                    attachmentsValRwCell.ColumnSpan = 5;
                                    attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                    attachmentsValRwCell.Style.Add("text-align", "center");

                                    string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                    traceInfo = versionUrl;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    Literal LiteralattachmentsValRwCell = new Literal();
                                    LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                    attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                    attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                    string id = oLibItem.ID.ToString();

                                    //Approval

                                    string attachmentsValRwCell2Text = "";
                                    string attachmentsValRwCell3Text = "";
                                    try
                                    {
                                        attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalAOReview"];
                                        attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalAOComments"];
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }


                                    attachmentsValRwCell2.Text = attachmentsValRwCell2Text;
                                    attachmentsValRwCell3.Text = attachmentsValRwCell3Text;

                                    //---------------

                                    attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                    attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                    attachmentsValRw.ID = id;

                                    CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                    removeAttachmentRow = false;

                                    break;

                                }
                            }

                        }

                        if (removeAttachmentRow)
                        {
                            CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                        }

                        CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                    }
                    else
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                        CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                    }

                    SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);

                    SPQuery oQuery = new SPQuery();
                    oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" + 
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">AO Recommendation</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                     "<Eq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems = oList.GetItems(oQuery);
                    foreach (SPListItem oListItem in collListItems)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        if (oListItem[TotalGUID] != null)
                        {
                            try
                            {
                                traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                totalRowCell2.Text = oListItem[TotalGUID].ToString();
                                totalRowCell1.Controls.Remove(AddEventBtn);
                                //try
                                //{
                                //    traceInfo = "call to IsDiff: " + IsDiff("Total", totalRowCell2.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //    if (IsDiff("Total", totalRowCell2.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                                //    {
                                //        totalRowCell2.Style.Add("border-bottom", "solid"); totalRowCell2.Style.Add("border-top", "solid"); totalRowCell2.Style.Add("border-left", "solid"); totalRowCell2.Style.Add("border-right", "solid"); totalRowCell2.Style.Add("border-color", "#ffdf73"); totalRowCell2.ToolTip = "See AO Review";
                                //    }
                                //}
                                //catch (Exception ex)
                                //{
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                //}


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents5", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string totalRowCell3Text = "";
                            string totalRowCell4Text = "";
                            try
                            {
                                totalRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                totalRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents6", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            totalRowCell3.Text = totalRowCell3Text;
                            totalRowCell4.Text = totalRowCell4Text;

                            totalRowCell3.CssClass = "CONOPSApprovalCell";
                            totalRowCell4.CssClass = "CONOPSApprovalCell";
                        }

                    }

                    SPQuery oQuery3 = new SPQuery();
                    oQuery3.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" + 
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">AO Recommendation</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                     "<Neq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems3 = oList.GetItems(oQuery3);
                    foreach (SPListItem oListItem in collListItems3)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        TableCell EventNameCell = new TableCell();
                        TableCell PeopleCell = new TableCell();
                        TableCell DatesCell = new TableCell();
                        TableCell RemarksCell = new TableCell();
                        TableCell FundingCell = new TableCell();

                        TableCell ApprovalCell = new TableCell();
                        TableCell CommentsCell = new TableCell();

                        EventNameCell.Style["padding-left"] = "3px";
                        PeopleCell.Style["text-align"] = "center";
                        DatesCell.Style["text-align"] = "center";
                        RemarksCell.Style["padding-left"] = "3px";
                        FundingCell.Style["text-align"] = "center";

                        string EventName = "";
                        string People = "";
                        string Dates = "";
                        string Remarks = "";
                        string Funding = "";

                        EventName += oListItem.Title.ToString();
                        try { People += oListItem["People"].ToString(); }
                        catch { }
                        try { Dates += oListItem["Dates"].ToString(); }
                        catch { }
                        try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                        catch { }
                        try { Funding += oListItem["Funding"].ToString(); }
                        catch { }



                        EventNameCell.Text = EventName;
                        PeopleCell.Text = People;
                        DatesCell.Text = Dates;
                        RemarksCell.Text = Remarks;
                        FundingCell.Text = Funding;





                        rw.Cells.Add(EventNameCell);
                        rw.Cells.Add(PeopleCell);
                        rw.Cells.Add(DatesCell);
                        rw.Cells.Add(RemarksCell);
                        rw.Cells.Add(FundingCell);

                        try
                        {
                            //traceInfo = "call to IsDiff: " + IsDiff("Title", EventName, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            string srcID = "0";
                            if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                            string srcIDAO = "0";
                            if (oListItem["AOReviewID"] != null) { srcIDAO = oListItem["AOReviewID"].ToString(); }


                            if (IsDiff("Title", EventName, oList, qs_fy, qs_ws, srcID))
                            {
                                EventNameCell.Style.Add("border-bottom", "solid");
                                EventNameCell.Style.Add("border-top", "solid");
                                EventNameCell.Style.Add("border-left", "solid");
                                EventNameCell.Style.Add("border-right", "solid");
                                EventNameCell.Style.Add("border-color", "#ffdf73");
                                EventNameCell.ToolTip = "See AO Review";
                            }
                            if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                            {
                                PeopleCell.Style.Add("border-bottom", "solid");
                                PeopleCell.Style.Add("border-top", "solid");
                                PeopleCell.Style.Add("border-left", "solid");
                                PeopleCell.Style.Add("border-right", "solid");
                                PeopleCell.Style.Add("border-color", "#ffdf73");
                                PeopleCell.ToolTip = "See AO Review";
                            }
                            if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                            {
                                DatesCell.Style.Add("border-bottom", "solid");
                                DatesCell.Style.Add("border-top", "solid");
                                DatesCell.Style.Add("border-left", "solid");
                                DatesCell.Style.Add("border-right", "solid");
                                DatesCell.Style.Add("border-color", "#ffdf73");
                                DatesCell.ToolTip = "See AO Review";
                            }
                            if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                            {
                                RemarksCell.Style.Add("border-bottom", "solid");
                                RemarksCell.Style.Add("border-top", "solid");
                                RemarksCell.Style.Add("border-left", "solid");
                                RemarksCell.Style.Add("border-right", "solid");
                                RemarksCell.Style.Add("border-color", "#ffdf73");
                                RemarksCell.ToolTip = "See AO Review";
                            }
                            if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                            {
                                FundingCell.Style.Add("border-bottom", "solid");
                                FundingCell.Style.Add("border-top", "solid");
                                FundingCell.Style.Add("border-left", "solid");
                                FundingCell.Style.Add("border-right", "solid");
                                FundingCell.Style.Add("border-color", "#ffdf73");
                                FundingCell.ToolTip = "See AO Review";
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        //Approval

                        string ApprovalCellText = "";
                        string CommentsCellText = "";
                        try
                        {
                            ApprovalCellText = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            CommentsCellText = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        ApprovalCell.CssClass = "CONOPSApprovalCell";
                        CommentsCell.CssClass = "CONOPSApprovalCell";
                        ApprovalCell.Text = ApprovalCellText;
                        CommentsCell.Text = CommentsCellText;

                        //---------------


                        rw.Cells.Add(ApprovalCell);
                        rw.Cells.Add(CommentsCell);

                        CONOPSDevWSTable.Rows.AddAt(eventRowIndex, rw);
                    }




                    try
                    {
                        CONOPSDevWSTable.Controls.Remove(attachDocRow);
                        CONOPSDevWSTable.Controls.Remove(eventRow);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }




                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }

            else
            {
                //HasPMPreapprovalItems is false so query where Submitted is not Yes and display form controls


                traceInfo = "HasPMPreapprovalItems is false: " + HasPMPreapprovalItems;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("WS3HasPMPreapprovalItemsFalse", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int eventRowIndex = 4;

                int attachmentIndex = 6;



                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "AO Recommendation")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 5;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalAOReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalAOComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem attachmentsValRwCell2ListItem1 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem2 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem3 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem4 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem5 = new ListItem();

                                attachmentsValRwCell2ListItem1.Value = "Pending";
                                attachmentsValRwCell2ListItem1.Text = "Pending";
                                attachmentsValRwCell2ListItem1.Selected = true;

                                attachmentsValRwCell2ListItem2.Value = "Approved";
                                attachmentsValRwCell2ListItem2.Text = "Approved";

                                attachmentsValRwCell2ListItem3.Value = "Approved With Comments";
                                attachmentsValRwCell2ListItem3.Text = "Approved With Comments";

                                attachmentsValRwCell2ListItem4.Value = "Approved With Revisions";
                                attachmentsValRwCell2ListItem4.Text = "Approved With Revisions";

                                attachmentsValRwCell2ListItem5.Value = "Not Approved";
                                attachmentsValRwCell2ListItem5.Text = "Not Approved";


                                DropDownList attachmentsValRwCell2DropDownList = new DropDownList();
                                attachmentsValRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                                attachmentsValRwCell2DropDownList.ID = "attId" + id + "CONOPSApprovalAOReview";

                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem1);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem2);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem3);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem4);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem5);


                                TextBox attachmentsValRwCell3TextBox = new TextBox();
                                attachmentsValRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                                attachmentsValRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";

                                attachmentsValRwCell2DropDownList.SelectedValue = attachmentsValRwCell2Text;
                                attachmentsValRwCell3TextBox.Text = attachmentsValRwCell3Text;
                                attachmentsValRwCell3TextBox.ID = "attId" + id + "CONOPSApprovalAOComments";

                                attachmentsValRwCell2.Controls.Add(attachmentsValRwCell2DropDownList);
                                attachmentsValRwCell3.Controls.Add(attachmentsValRwCell3TextBox);

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }


                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                               "<OrderBy>" +
                                   "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                               "</OrderBy>" +
                               "<Where>" +
                                 "<And>" +
                               "<And>" +
                                   "<And>" +
                                       "<And>" +
                                           "<And>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"OTA\"/>" +
                                                   "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                               "</Eq>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"FY\"/>" +
                                                   "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                               "</Eq>" +
                                           "</And>" +
                                           "<Eq>" +
                                               "<FieldRef Name=\"CONOPSApproval\"/>" +
                                               "<Value Type=\"Text\">AO Recommendation</Value>" +
                                           "</Eq>" +
                                       "</And>" +
                                       "<Neq>" +
                                           "<FieldRef Name=\"Submitted\"/>" +
                                           "<Value Type=\"Text\">Yes</Value>" +
                                       "</Neq>" +
                                   "</And>" +
                                        "<Eq>" +
                                         "<FieldRef Name=\"ContentType\"/>" +
                                         "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                        "</Eq>" +
                                   "</And>" +
                                       "<Eq>" +
                                           "<FieldRef Name=\"Title\"/>" +
                                           "<Value Type=\"Text\">Total</Value>" +
                                       "</Eq>" +
                                   "</And>" +
                           "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //Total first, then get set of items minus total but including those items added during conopsapproval


                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");
                string totalAsText = "Total";
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();
                    //Only one Total
                    string id = oListItem.ID.ToString();

                    if (totalRowCell2.Text == "0000")
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = "";

                            TextBox totalRowCell2TextBox = new TextBox();
                            totalRowCell2TextBox.Width = 80;
                            totalRowCell2TextBox.Text = oListItem[TotalGUID].ToString();
                            totalRowCell2TextBox.ID = "rowId" + id + "Total";

                            totalRowCell2.Controls.Add(totalRowCell2TextBox);



                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", "#ffdf73");
                            //        totalRowCell2.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}


                            if (totalAsText == oListItem.Title.ToString())
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem totalRowCell3ListItem1 = new ListItem();
                                ListItem totalRowCell3ListItem2 = new ListItem();
                                ListItem totalRowCell3ListItem3 = new ListItem();
                                ListItem totalRowCell3ListItem4 = new ListItem();
                                ListItem totalRowCell3ListItem5 = new ListItem();

                                totalRowCell3ListItem1.Value = "Pending";
                                totalRowCell3ListItem1.Text = "Pending";
                                totalRowCell3ListItem1.Selected = true;

                                totalRowCell3ListItem2.Value = "Approved";
                                totalRowCell3ListItem2.Text = "Approved";

                                totalRowCell3ListItem3.Value = "Approved With Comments";
                                totalRowCell3ListItem3.Text = "Approved With Comments";

                                totalRowCell3ListItem4.Value = "Approved With Revisions";
                                totalRowCell3ListItem4.Text = "Approved With Revisions";

                                totalRowCell3ListItem5.Value = "Not Approved";
                                totalRowCell3ListItem5.Text = "Not Approved";



                                DropDownList totalRowCell3DropDownList = new DropDownList();
                                totalRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                                totalRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem1);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem2);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem3);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem4);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem5);

                                TextBox totalRowCell4TextBox = new TextBox();
                                totalRowCell4TextBox.TextMode = TextBoxMode.MultiLine;

                                totalRowCell3DropDownList.SelectedValue = totalRowCell3Text;
                                totalRowCell4TextBox.Text = totalRowCell4Text;
                                totalRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                                totalRowCell3.Controls.Add(totalRowCell3DropDownList);
                                totalRowCell4.Controls.Add(totalRowCell4TextBox);

                                //---------------
                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("add total row", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }
                //end Total------------




                SPQuery oQuery2 = new SPQuery();
                oQuery2.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                             "<And>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">AO Recommendation</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                 "<Neq>" +
                                        "<FieldRef Name=\"Title\"/>" +
                                        "<Value Type=\"Text\">Total</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItems2 = oList.GetItems(oQuery2);

                foreach (SPListItem oListItem in collListItems2)
                {
                    string id = oListItem.ID.ToString();

                    string title = "" + oListItem.Title.ToString();
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    TableRow rw = new TableRow();

                    TableCell EventNameCell = new TableCell();
                    TableCell PeopleCell = new TableCell();
                    TableCell DatesCell = new TableCell();
                    TableCell RemarksCell = new TableCell();
                    TableCell FundingCell = new TableCell();

                    TableCell ApprovalCell = new TableCell();
                    TableCell CommentsCell = new TableCell();

                    EventNameCell.Style["padding-left"] = "3px";
                    PeopleCell.Style["text-align"] = "center";
                    DatesCell.Style["text-align"] = "center";
                    RemarksCell.Style["padding-left"] = "3px";
                    FundingCell.Style["text-align"] = "center";

                    string EventName = "";
                    string People = "";
                    string Dates = "";
                    string Remarks = "";
                    string Funding = "";

                    EventName += oListItem.Title.ToString();
                    try { People += oListItem["People"].ToString(); }
                    catch { }
                    try { Dates += oListItem["Dates"].ToString(); }
                    catch { }
                    try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                    catch { }
                    try { Funding += oListItem["Funding"].ToString(); }
                    catch { }

                    TextBox EventNameCellTextBox = new TextBox();
                    TextBox PeopleCellTextBox = new TextBox();
                    TextBox DatesCellTextBox = new TextBox();
                    TextBox RemarksCellTextBox = new TextBox();
                    TextBox FundingCellTextBox = new TextBox();

                    EventNameCellTextBox.Width = 80;
                    PeopleCellTextBox.Width = 80;
                    DatesCellTextBox.Width = 80;
                    RemarksCellTextBox.Width = 80;
                    FundingCellTextBox.Width = 80;

                    EventNameCellTextBox.ID = "rowId" + id + "Title";
                    PeopleCellTextBox.ID = "rowId" + id + "People";
                    DatesCellTextBox.ID = "rowId" + id + "Dates";
                    RemarksCellTextBox.ID = "rowId" + id + "Remarks";
                    FundingCellTextBox.ID = "rowId" + id + "Funding";

                    EventNameCellTextBox.Text = EventName;
                    PeopleCellTextBox.Text = People;
                    DatesCellTextBox.Text = Dates;
                    RemarksCellTextBox.Text = Remarks;
                    FundingCellTextBox.Text = Funding;

                    EventNameCell.Controls.Add(EventNameCellTextBox);
                    PeopleCell.Controls.Add(PeopleCellTextBox);
                    DatesCell.Controls.Add(DatesCellTextBox);
                    RemarksCell.Controls.Add(RemarksCellTextBox);
                    FundingCell.Controls.Add(FundingCellTextBox);



                    rw.Cells.Add(EventNameCell);
                    rw.Cells.Add(PeopleCell);
                    rw.Cells.Add(DatesCell);
                    rw.Cells.Add(RemarksCell);
                    rw.Cells.Add(FundingCell);

                    try
                    {
                        //traceInfo = "call to IsDiff: " + IsDiff("Title", EventName, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string srcID = "0";
                        if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                        string srcIDAO = "0";
                        if (oListItem["AOReviewID"] != null) { srcIDAO = oListItem["AOReviewID"].ToString(); }


                        if (IsDiff("Title", EventName, oList, qs_fy, qs_ws, srcID))
                        {
                            EventNameCell.Style.Add("border-bottom", "solid");
                            EventNameCell.Style.Add("border-top", "solid");
                            EventNameCell.Style.Add("border-left", "solid");
                            EventNameCell.Style.Add("border-right", "solid");
                            EventNameCell.Style.Add("border-color", "#ffdf73");
                            EventNameCell.ToolTip = "See AO Review";
                        }
                        if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                        {
                            PeopleCell.Style.Add("border-bottom", "solid");
                            PeopleCell.Style.Add("border-top", "solid");
                            PeopleCell.Style.Add("border-left", "solid");
                            PeopleCell.Style.Add("border-right", "solid");
                            PeopleCell.Style.Add("border-color", "#ffdf73");
                            PeopleCell.ToolTip = "See AO Review";
                        }
                        if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                        {
                            DatesCell.Style.Add("border-bottom", "solid");
                            DatesCell.Style.Add("border-top", "solid");
                            DatesCell.Style.Add("border-left", "solid");
                            DatesCell.Style.Add("border-right", "solid");
                            DatesCell.Style.Add("border-color", "#ffdf73");
                            DatesCell.ToolTip = "See AO Review";
                        }
                        if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                        {
                            RemarksCell.Style.Add("border-bottom", "solid");
                            RemarksCell.Style.Add("border-top", "solid");
                            RemarksCell.Style.Add("border-left", "solid");
                            RemarksCell.Style.Add("border-right", "solid");
                            RemarksCell.Style.Add("border-color", "#ffdf73");
                            RemarksCell.ToolTip = "See AO Review";
                        }
                        if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                        {
                            FundingCell.Style.Add("border-bottom", "solid");
                            FundingCell.Style.Add("border-top", "solid");
                            FundingCell.Style.Add("border-left", "solid");
                            FundingCell.Style.Add("border-right", "solid");
                            FundingCell.Style.Add("border-color", "#ffdf73");
                            FundingCell.ToolTip = "See AO Review";
                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    //Approval

                    string ApprovalCellText = "";
                    string CommentsCellText = "";
                    try
                    {
                        ApprovalCellText = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                        CommentsCellText = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }


                    ListItem ApprovalCellListItem1 = new ListItem();
                    ListItem ApprovalCellListItem2 = new ListItem();
                    ListItem ApprovalCellListItem3 = new ListItem();
                    ListItem ApprovalCellListItem4 = new ListItem();
                    ListItem ApprovalCellListItem5 = new ListItem();

                    ApprovalCellListItem1.Value = "Pending";
                    ApprovalCellListItem1.Text = "Pending";
                    ApprovalCellListItem1.Selected = true;

                    ApprovalCellListItem2.Value = "Approved";
                    ApprovalCellListItem2.Text = "Approved";

                    ApprovalCellListItem3.Value = "Approved With Comments";
                    ApprovalCellListItem3.Text = "Approved With Comments";

                    ApprovalCellListItem4.Value = "Approved With Revisions";
                    ApprovalCellListItem4.Text = "Approved With Revisions";

                    ApprovalCellListItem5.Value = "Not Approved";
                    ApprovalCellListItem5.Text = "Not Approved";



                    DropDownList ApprovalCellDropDownList = new DropDownList();
                    ApprovalCellDropDownList.CssClass = "CONOPSApprovalSelect";

                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem1);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem2);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem3);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem4);
                    ApprovalCellDropDownList.Items.Add(ApprovalCellListItem5);
                    ApprovalCellDropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                    TextBox CommentsCellTextBox = new TextBox();
                    CommentsCellTextBox.TextMode = TextBoxMode.MultiLine;

                    ApprovalCellDropDownList.SelectedValue = ApprovalCellText;
                    CommentsCellTextBox.Text = CommentsCellText;
                    CommentsCellTextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                    ApprovalCell.Controls.Add(ApprovalCellDropDownList);
                    CommentsCell.Controls.Add(CommentsCellTextBox);
                    ApprovalCell.CssClass = "CONOPSApprovalCell";
                    CommentsCell.CssClass = "CONOPSApprovalCell";

                    //---------------


                    rw.Cells.Add(ApprovalCell);
                    rw.Cells.Add(CommentsCell);

                    CONOPSDevWSTable.Rows.AddAt(eventRowIndex, rw);

                }
                try
                {
                    CONOPSDevWSTable.Controls.Remove(eventRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }
        }

        protected void CONOPSApprovalSaveButton_Click(object sender, EventArgs e)
        {
            //var traceInfo = "CONOPSApprovalSaveButton_Click " + Page.Request.QueryString["otashort"];
            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //SPWeb oWeb = SPContext.Current.Web;
            //SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

            //traceInfo = "oWeb: " + oWeb.Title + " oList: " + oList.Title;
            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            var traceInfo = "CONOPSApprovalSaveButton_Click " + Page.Request.QueryString["otashort"];
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPWeb oWeb = SPContext.Current.Web;
            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

            traceInfo = "oWeb: " + oWeb.Title + " oList: " + oList.Title;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_tab = Page.Request.QueryString["tab"];


            if (Page.Request.QueryString["tab"] == "AOReview")
            {
                qs_tab = "AO Recommendation";
            }
            if (Page.Request.QueryString["tab"] == "PMReview")
            {
                qs_tab = "PM Preapproval";
            }
            if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
            {
                qs_tab = "Deputy Director Approval";
            }  



            if (HttpContext.Current != null)
            {
                if (Page.Response != null)
                {

                    var response = Page.Response;
                    var request = HttpContext.Current.Request;
                    NameValueCollection coll;
                    coll = request.Form;

                    traceInfo = "got coll.Count: " + coll.Count;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                    string pattern = @"\D";
                    Regex rgx = new Regex(pattern);
                    string pattern2 = @"\d";
                    Regex rgx2 = new Regex(pattern2);

                    foreach (String s in coll.AllKeys)
                    {

                        traceInfo = "s: " + s + " coll[s] " + coll[s];
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (s.Contains("rowId"))
                        {

                            string rowId = s.Substring(s.IndexOf("rowId") + 5);

                            string fieldName = rgx2.Replace(rowId, "");

                            rowId = rgx.Replace(rowId, "");

                            string fieldValue = coll[s];

                            traceInfo = "rowId: " + rowId + " fieldName: " + fieldName + " fieldValue: " + fieldValue;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        }
                        //attachments must update oLib not oList
                        if (s.Contains("attId"))
                        {
                            string attId = s.Substring(s.IndexOf("attId") + 5);

                            string attfieldName = rgx2.Replace(attId, "");

                            attId = rgx.Replace(attId, "");

                            string attfieldValue = coll[s];

                            updateoLibItem(attId, attfieldName, attfieldValue);

                        }
                    }
                    //traceInfo = "itemIDFirstHidden.Value: " + itemIDFirstHidden.Value;
                    //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    //traceInfo = "itemIDLastHidden.Value: " + itemIDLastHidden.Value;
                    //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            

                    //SPQuery oQuery2 = new SPQuery();

                    //oQuery2.Query = "" +
                    //            "<OrderBy>" +
                    //                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                    //            "</OrderBy>" +
                    //            "<Where>" +
                    //                "<And>" +
                    //                    "<Geq>" +
                    //                        "<FieldRef Name=\"ID\"/>" +
                    //                        "<Value Type=\"Integer\">" + itemIDFirstHidden.Value + "</Value>" +
                    //                    "</Geq>" +
                    //                     "<Leq>" +
                    //                        "<FieldRef Name=\"ID\"/>" +
                    //                        "<Value Type=\"Integer\">" + itemIDLastHidden.Value + "</Value>" + // include Total for update
                    //                    "</Leq>" +
                    //                "</And>" +
                    //            "</Where>";

                    //SPListItemCollection collListItems2 = oList.GetItems(oQuery2);
                    SPQuery oQuery2 = new SPQuery();
                    oQuery2.Query = "" +
                               "<OrderBy>" +
                                   "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                               "</OrderBy>" +
                               "<Where>" +
                               "<And>" +
                                   "<And>" +
                                       "<And>" +
                                           "<And>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"OTA\"/>" +
                                                   "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                               "</Eq>" +
                                               "<Eq>" +
                                                   "<FieldRef Name=\"FY\"/>" +
                                                   "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                               "</Eq>" +
                                           "</And>" +
                                           "<Eq>" +
                                               "<FieldRef Name=\"CONOPSApproval\"/>" +
                                               "<Value Type=\"Text\">" + qs_tab + "</Value>" +
                                           "</Eq>" +
                                       "</And>" +
                                       "<Neq>" +
                                           "<FieldRef Name=\"Submitted\"/>" +
                                           "<Value Type=\"Text\">Yes</Value>" +
                                       "</Neq>" +
                                   "</And>" +
                                   "<Eq>" +
                                       "<FieldRef Name=\"ContentType\"/>" +
                                       "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                   "</Eq>" +
                               "</And>" +
                           "</Where>";

                    SPListItemCollection collListItems2 = oList.GetItems(oQuery2);
                    foreach (SPListItem oListItem in collListItems2)
                    {

                        string id = oListItem.ID.ToString();
                        string rrowId = "rowId" + id;

                        Dictionary<string, string> worksheetFieldsDictionary = new Dictionary<string, string>();

                        foreach (String s in coll.AllKeys)
                        {

                            if (s.Contains(rrowId))
                            {

                                string fieldNameValue = s.Substring(s.IndexOf("rowId") + 5);

                                string fieldName = rgx2.Replace(fieldNameValue, "");
                                string fieldValue = coll[s];

                                worksheetFieldsDictionary.Add(fieldName, fieldValue);


                            }

                        }

                        updateoListItem(id, worksheetFieldsDictionary);

                    }

                }
            }



        }

        private void updateoLibItem(string attId, string attfieldName, string attfieldValue)
        {
            try
            {
                int iid = Int32.Parse(attId);

                SPWeb oWeb = SPContext.Current.Web;
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);

                SPListItem oLibItem = oLib.GetItemById(iid);

                oLibItem[attfieldName] = attfieldValue;
                oWeb.AllowUnsafeUpdates = true;
                oLibItem.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoLibItem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

        private void updateoListItem(string id, Dictionary<string, string> worksheetFieldsDictionary)
        {
            try
            {
                int iid = Int32.Parse(id);

                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPListItem oListItem = oList.GetItemById(iid);

                foreach (KeyValuePair<string, string> kvp in worksheetFieldsDictionary)
                {
                    oListItem[kvp.Key] = kvp.Value;
                }
                oWeb.AllowUnsafeUpdates = true;
                oListItem.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoListItem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

                protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox submitCheckBox = sender as CheckBox;
            var traceInfo = "submitCheckBox.Checked: " + submitCheckBox.Checked;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_ws = Page.Request.QueryString["ws"];

            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16

            SPUser user;

            DateTime DateDraftSaved = DateTime.Now;

        

            if (submitCheckBox.Checked)
            {

                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);

                traceInfo = "oWeb: " + oWeb.Title + " oList: " + oList.Title;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                HasNoPendingItems.Value = "true";


                if (HttpContext.Current != null)
                {
                    if (Page.Response != null)
                    {

                        var response = Page.Response;
                        var request = HttpContext.Current.Request;
                        NameValueCollection coll;
                        coll = request.Form;

                        traceInfo = "got coll.Count: " + coll.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string pattern = @"\D";
                        Regex rgx = new Regex(pattern);
                        string pattern2 = @"\d";
                        Regex rgx2 = new Regex(pattern2);

                        foreach (String s in coll.AllKeys)
                        {

                            //traceInfo = "s: " + s + " coll[s] " + coll[s];
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            if (coll[s] == "Pending")
                            {
                                traceInfo = "s: " + s + " coll[s] " + coll[s];
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                HasNoPendingItems.Value = "false";

                            }



                        }


                    }

                    if (HasNoPendingItems.Value == "true")
                    {
                        //do ops

                        user = oWeb.CurrentUser;

                        string tab = "";
                        string nexttab = "";
                        string AORecommendation = "AO Recommendation";
                        string PMPreapproval = "PM Preapproval";
                        string DRApproval = "Deputy Director Approval";

                        if (Page.Request.QueryString["tab"] == "AOReview")
                        {
                            tab = AORecommendation; nexttab = PMPreapproval;
                        }
                        if (Page.Request.QueryString["tab"] == "PMReview")
                        {
                            tab = PMPreapproval; nexttab = DRApproval;
                        }
                        if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
                        {
                            tab = DRApproval;
                        }


                        
                        try
                        {

                        //------------- lib -----------------
                        //return the docs, not the versions, in this case
                        SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);

                        SPQuery oLibQuery = new SPQuery();

                        oLibQuery.Query = "" +
                             "<OrderBy>" +
                                 "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                             "</OrderBy>" +
                             "<Where>" +

                             "<And><And>" +
                                     "<Eq>" +
                                         "<FieldRef Name=\"FY\"/>" +
                                         "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                     "</Eq>" +
                                      "<Eq>" +
                                         "<FieldRef Name=\"WS\"/>" +
                                         "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                                     "</Eq>" +
                                 "</And>" +
                                   "<Neq>" +
                                         "<FieldRef Name=\"Submitted\"/>" +
                                         "<Value Type=\"Text\">Yes</Value>" +
                                     "</Neq>" +
                                 "</And>" +
                             "</Where>";

                        SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                        List<string> itemsForSecondPass = new List<string>();

                        foreach (SPListItem oListItem in collLibItems)
                        {
                            itemsForSecondPass.Add(oListItem.ID.ToString());

                            oListItem["Submitted"] = "Yes";
                            oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                            string SubmittedBy = user.ID + ";#" + user.LoginName;
                            oListItem["SubmittedBy"] = SubmittedBy;
                            oListItem["SubmittedOn"] = DateDraftSaved;
                            oListItem["CONOPSApproval"] = tab;

                            oWeb.AllowUnsafeUpdates = true;

                            oListItem.Update();
                        }
                        //=====UPDATE METADATA AGAIN ====
                        if (Page.Request.QueryString["tab"] != "DeputyDirectorReviewandApproval") //DeputyDirectorReviewandApproval
                        {
                            foreach (string itemForSecondPass in itemsForSecondPass)
                            {
                                SPListItem oitemForSecondPass = oLib.GetItemById(Int32.Parse(itemForSecondPass));

                                oitemForSecondPass["Submitted"] = "";
                                oitemForSecondPass["SubmittedFY"] = "";
                                oitemForSecondPass["SubmittedBy"] = "";
                                oitemForSecondPass["SubmittedOn"] = "";
                                oitemForSecondPass["CONOPSApproval"] = nexttab;

                                oWeb.AllowUnsafeUpdates = true;

                                oitemForSecondPass.Update();
                            }
                        }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("submitAttachments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }









                        //List
                        SPQuery oQuery = new SPQuery();
                        oQuery.Query = "" +
                                    "<OrderBy>" +
                                        "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                    "</OrderBy>" +
                                    "<Where>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<And>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"OTA\"/>" +
                                                        "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                    "</Eq>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"FY\"/>" +
                                                        "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                    "</Eq>" +
                                                "</And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                    "<Value Type=\"Text\">" + tab + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Neq>" +
                                                "<FieldRef Name=\"Submitted\"/>" +
                                                "<Value Type=\"Text\">Yes</Value>" +
                                            "</Neq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"ContentType\"/>" +
                                            "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                "</Where>";


                        SPListItemCollection collListItems = oList.GetItems(oQuery);

                        foreach (SPListItem oListItem in collListItems)
                        {

                            try
                            {
                                traceInfo = "Item ID being marked Submitted is Yes: " + oListItem.ID;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                             

                                oListItem["Submitted"] = "Yes";
                                oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                string SubmittedBy = user.ID + ";#" + user.LoginName;
                                oListItem["SubmittedBy"] = SubmittedBy;
                                oListItem["SubmittedOn"] = DateDraftSaved;
                                oWeb.AllowUnsafeUpdates = true;
                                oListItem.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                        if (Page.Request.QueryString["tab"] != "DeputyDirectorReviewandApproval")
                        {

                            traceInfo = "CONOPSDevDuplicate";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            try
                            {



                                SPQuery oQuery2 = new SPQuery();
                                oQuery2.Query = "" +
                                            "<OrderBy>" +
                                                "<FieldRef Name=\"ID\" Ascending=\"TRUE\"/>" +
                                            "</OrderBy>" +
                                            "<Where>" +
                                            "<And>" +
                                                "<And>" +
                                                    "<And>" +
                                                        "<And>" +
                                                            "<Eq>" +
                                                                "<FieldRef Name=\"OTA\"/>" +
                                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                            "</Eq>" +
                                                            "<Eq>" +
                                                                "<FieldRef Name=\"FY\"/>" +
                                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                            "</Eq>" +
                                                        "</And>" +
                                                        "<Eq>" +
                                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                            "<Value Type=\"Text\">" + tab + "</Value>" +
                                                        "</Eq>" +
                                                    "</And>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"Submitted\"/>" +
                                                        "<Value Type=\"Text\">Yes</Value>" +
                                                    "</Eq>" +
                                                "</And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"ContentType\"/>" +
                                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                        "</Where>";

                                SPListItemCollection collListItems2 = oList.GetItems(oQuery2);
                                foreach (SPListItem oListItem in collListItems2)
                                {

                                    SPListItem newListItem = oList.Items.Add();
                                    newListItem["ContentTypeId"] = oListItem.ContentTypeId;
                                    newListItem["Title"] = oListItem["Title"].ToString();
                                    newListItem["CONOPSApproval"] = nexttab;


                                    if (oListItem["People"] != null) { newListItem["People"] = oListItem["People"].ToString(); }
                                    if (oListItem["Dates"] != null) { newListItem["Dates"] = oListItem["Dates"].ToString(); }
                                    if (oListItem["Remarks"] != null) { newListItem["Remarks"] = oListItem["Remarks"].ToString(); }
                                    if (oListItem["Funding"] != null) { newListItem["Funding"] = oListItem["Funding"].ToString(); }
                                    if (oListItem["Total"] != null) { newListItem["Total"] = oListItem["Total"].ToString(); }
                                    if (oListItem["OTA"] != null) { newListItem["OTA"] = oListItem["OTA"].ToString(); }
                                    if (oListItem["FY"] != null) { newListItem["FY"] = oListItem["FY"].ToString(); }

                                    if (oListItem["DateDraftSaved"] != null) { newListItem["DateDraftSaved"] = oListItem["DateDraftSaved"]; }
                                    if (oListItem["TimeDraftSaved"] != null) { newListItem["TimeDraftSaved"] = oListItem["TimeDraftSaved"]; }
                                    if (oListItem["DraftSavedBy"] != null) { newListItem["DraftSavedBy"] = oListItem["DraftSavedBy"]; }


                                    if (oListItem["OTASubmissionID"] != null) { newListItem["OTASubmissionID"] = oListItem["OTASubmissionID"].ToString(); }
                                    if (oListItem["AOReviewID"] != null) { newListItem["AOReviewID"] = oListItem["AOReviewID"].ToString(); }
                                    if (oListItem["PMReviewID"] != null) { newListItem["PMReviewID"] = oListItem["PMReviewID"].ToString(); }


                                    ////Set Approvals to selected value
                                    //if (Page.Request.QueryString["tab"] == "AOReview")
                                    //{
                                    //    newListItem["AOReviewID"] = oListItem.ID.ToString();
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalPMReview"] = oListItem["CONOPSApprovalAOReview"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AOReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalPMComments"] = oListItem["CONOPSApprovalAOComments"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AOReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //}
                                    //if (Page.Request.QueryString["tab"] == "PMReview")
                                    //{
                                    //    newListItem["PMReviewID"] = oListItem.ID.ToString();
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalDRReview"] = oListItem["CONOPSApprovalPMReview"].ToString();

                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("PMReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalDRComments"] = oListItem["CONOPSApprovalPMComments"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("PMReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //}


                                    oWeb.AllowUnsafeUpdates = true;

                                    newListItem.Update();

                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //----- CONOPSAPPROVALPROGRESS update -----

                            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];

                            traceInfo = "got CONOPSApprovalProgress: " + CONOPSApprovalProgress.Title;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
                                oQueryCONOPSApprovalProgress.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

                                foreach (SPListItem oListItem in collListItemsCONOPSApprovalProgress)
                                {
                                    oListItem["CONOPSApproval"] = nexttab;

                                    traceInfo = "Update CONOPSApprovalProgress list for OTA: " + qs_otashort + " and WS: " + oListItem.Title;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    oWeb.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }
                        else //tab is DeputyDirectorReviewandApproval
                        {
                            //update CONOPSApprovalProgress to show submitted

                            SPList oListCONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
                            try
                            {
                                SPQuery oQueryCONOPSApprovalProgressGeneral = new SPQuery();
                                oQueryCONOPSApprovalProgressGeneral.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";

                                SPListItemCollection collItemsSubmittedGeneral = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressGeneral);

                                foreach (SPListItem oListItem in collItemsSubmittedGeneral)
                                {


                                    traceInfo = "Update to Submitted CONOPSApprovalProgress list for OTA: " + qs_otashort + " and WS: " + oListItem.Title;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oWeb.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmitDDtab", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }





                    }

                }









            }
        }


                private static string getBdrcolor(string fieldName, string fieldValue, SPList oList, string qs_fy, string qs_ws, string qs_tab, string OTASubmissionID, string AOReviewID, string PMReviewID)
                {
                    var traceInfo = "call to getBdrcolor fieldName: " + fieldName + " fieldValue: " + fieldValue + " AOReviewID:" + AOReviewID;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("getBdrcolor", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string colorHex = "";
                    if (qs_tab == "PMReview")
                    {
                        colorHex = "#b5a2c6See PM Review"; //PM Review blue
                        SPQuery oQuery = new SPQuery();
                        oQuery.Query = "" +
                            "<Where>" +
                            "<Eq><FieldRef Name='ID'/><Value Type='Text'>" + AOReviewID + "</Value></Eq>" +
                            "</Where>";
                        SPListItemCollection collistitems = oList.GetItems(oQuery);
                        foreach (SPListItem oListItem in collistitems)
                        {
                            if (oListItem[fieldName].ToString() == fieldValue)
                            {
                                colorHex = "#ffdf73See AO Review"; // yellow AOReview 
                                traceInfo = "yep";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("getBdrcolor", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                        }

                    }


                    if (qs_tab == "DeputyDirectorReviewandApproval")
                    {
                        colorHex = "#94cb5aSee Deputy Director Review and Approval"; //DeputyDirectorReviewandApproval green               
                        SPQuery oQuery = new SPQuery();
                        oQuery.Query = "" +
                            "<Where>" +
                            "<Eq><FieldRef Name='ID'/><Value Type='Text'>" + PMReviewID + "</Value></Eq>" +
                            "</Where>";
                        SPListItemCollection collistitems = oList.GetItems(oQuery);
                        foreach (SPListItem oListItem in collistitems)
                        {
                            if (oListItem[fieldName].ToString() == fieldValue)
                            {
                                colorHex = "#b5a2c6See PM Review"; //PM Review blue                    
                            }
                        }

                    }


                    return colorHex;
                }


                private static bool IsDiff(string fieldName, string fieldValue, SPList oList, string qs_fy, string qs_ws, string srcItemID)
                {




                    // since this is called from PM Review as well if PM returns value back to OTASubmission there will be no border
                    bool IsDiff = false;

                    var traceInfo = "start IsDiff: " + IsDiff + " fieldName: " + fieldName + " fieldValue: " + fieldValue;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (srcItemID != "0")
                    {

                        try
                        {

                            SPQuery oQuery = new SPQuery();

                            if (fieldValue.Length > 0)
                            {
                                oQuery.Query = "" +
                                    "<Where>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"ID\"/>" +
                                                "<Value Type=\"Text\">" + srcItemID + "</Value>" +
                                            "</Eq>" +
                                             "<Eq>" +
                                                "<FieldRef Name=\"" + fieldName + "\"/>" +
                                                "<Value Type=\"Text\">" + fieldValue + "</Value>" +
                                              "</Eq>" +
                                        "</And>" +
                                    "</Where>";
                            }
                            else
                            {
                                oQuery.Query = "" +
                                    "<Where>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"ID\"/>" +
                                                "<Value Type=\"Text\">" + srcItemID + "</Value>" +
                                            "</Eq>" +
                                             "<IsNull>" +
                                                "<FieldRef Name=\"" + fieldName + "\"/>" +
                                              "</IsNull>" +
                                        "</And>" +
                                    "</Where>";
                            }



                            SPListItemCollection collListItems = oList.GetItems(oQuery);

                            if (collListItems.Count > 0)
                            {
                                IsDiff = false;
                            }
                            else { IsDiff = true; }


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                    else
                    {
                        IsDiff = true;
                    }
                    traceInfo = "end IsDiff: " + IsDiff;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    return IsDiff;
                }


    }
}
