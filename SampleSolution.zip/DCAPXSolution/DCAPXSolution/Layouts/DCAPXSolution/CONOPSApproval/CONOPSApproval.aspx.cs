﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Collections.Generic;
using System.Web.UI;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    public partial class CONOPSApproval : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16
            CurrentFY.Value = CurrentFYforAcceptingCONOPS;

            var traceInfo = "CONOPSApprovalPage";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //Are you supposed to be here?
           
            bool IsListContributor = false;
            
            try
            {
               

                string oUser = Page.User.Identity.Name;
             
                SPUser oSPUser = this.Site.RootWeb.AllUsers[oUser];
               
                SPGroupCollection currentUsersGroups = oSPUser.Groups;

                foreach (SPGroup group in currentUsersGroups)
                {
                    string groupName = group.Name;
                    if ( groupName.Contains("CONOPSApproval") || groupName.Contains("DCAPXAO") || groupName.Contains("DCAPXOwners"))
                    {
                        IsListContributor = true;
                    }
                }

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
            if (!IsListContributor)
            { 
                Container.Visible = false;

                DivNotAuthorized.Visible = true;

                LabelNotAuthorized.Visible = true;
                LinkButtonNotAuthorized.PostBackUrl = this.Site.ServerRelativeUrl;
                LinkButtonNotAuthorized.Visible = true;
            }


            //=====CONOPSApprovalStatusOverview=============

            LabelFY.Text = CurrentFYforAcceptingCONOPS;
            Label1FY.Text = CurrentFYforAcceptingCONOPS;
            Label2FY.Text = CurrentFYforAcceptingCONOPS;
            Label3FY.Text = CurrentFYforAcceptingCONOPS;
            Label4FY.Text = CurrentFYforAcceptingCONOPS;


            List<string> otaList = new List<string>();
            otaList.Add("AFOTEC");
            otaList.Add("ATEC");
            otaList.Add("COTF");
            otaList.Add("JITC");
            otaList.Add("MCOTEA");

            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];
            

            foreach (string ota in otaList)
            {
                try
                {
                    traceInfo = "ota: " + ota;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("otaOTAlist", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    SPList oListWS = SPContext.Current.Web.Lists["CONOPSDevWS" + ota];

                    traceInfo = "oListWS.Title: " + oListWS.Title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("titleForList", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    SPQuery oQueryListWS1 = new SPQuery();
                    SPQuery oQueryListWS2 = new SPQuery();
                    SPQuery oQueryListWS3 = new SPQuery();
                    SPQuery oQueryListWS4 = new SPQuery();

                    oQueryListWS1.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy>" +
                        "<Where>" +
                            "<And>"+
                                "<Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS1</Value></Eq>" +
                            
                            "<Neq>" +
                                    "<FieldRef Name='CONOPSApproval'/>" +
                                    "<Value Type='Choice'>Baseline OTA Submission</Value>" +
                                "</Neq>" +
                            "</And>"+
                        "</Where>";
                    oQueryListWS2.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy>" +
                       "<Where>" +
                           "<And>" +
                               "<Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS2</Value></Eq>" +

                           "<Neq>" +
                                   "<FieldRef Name='CONOPSApproval'/>" +
                                   "<Value Type='Choice'>Baseline OTA Submission</Value>" +
                               "</Neq>" +
                           "</And>" +
                       "</Where>";
                    oQueryListWS3.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy>" +
                                           "<Where>" +
                                               "<And>" +
                                                   "<Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS3</Value></Eq>" +

                                               "<Neq>" +
                                                       "<FieldRef Name='CONOPSApproval'/>" +
                                                       "<Value Type='Choice'>Baseline OTA Submission</Value>" +
                                                   "</Neq>" +
                                               "</And>" +
                                           "</Where>";
                    oQueryListWS4.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy>" +
                                           "<Where>" +
                                               "<And>" +
                                                   "<Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS4</Value></Eq>" +

                                               "<Neq>" +
                                                       "<FieldRef Name='CONOPSApproval'/>" +
                                                       "<Value Type='Choice'>Baseline OTA Submission</Value>" +
                                                   "</Neq>" +
                                               "</And>" +
                                           "</Where>";

                    
                    traceInfo = "oListWS.ItemCount: " + oListWS.ItemCount;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("lastModifiedByItemCount", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListWS.ItemCount > 0)
                    {

                        SPListItemCollection collListWS1 = oListWS.GetItems(oQueryListWS1);
                        SPListItemCollection collListWS2 = oListWS.GetItems(oQueryListWS2);
                        SPListItemCollection collListWS3 = oListWS.GetItems(oQueryListWS3);
                        SPListItemCollection collListWS4 = oListWS.GetItems(oQueryListWS4);

                        //traceInfo = "collListWS1.Count: " + collListWS1.Count;
                        //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("lastModifiedBy", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (collListWS1.Count > 0)
                        {


                            foreach (SPListItem oListItem in collListWS1)
                            {


                                string editorr = (string)oListItem["Editor"]; //1;#DOTEDRESOURCE\danielnw-p

                                int editorri = editorr.IndexOf(";#");
                                editorr = editorr.Substring(0, editorri);

                                SPUser editor = null;
                                editor = SPContext.Current.Web.AllUsers.GetByID(Int32.Parse(editorr));
                                string editorName = editorr;
                                if (editor != null) { editorName = editor.Name; }
                                string lastModBy = "Last Modified by " + editorName;


                                if (lastModByWS1AFOTEC.ID.Contains(ota))
                                {
                                    lastModByWS1AFOTEC.Text = lastModBy;
                                    lastModByWS1AFOTEC.Visible = true;
                                }
                                if (lastModByWS1ATEC.ID.Contains(ota))
                                {
                                    lastModByWS1ATEC.Text = lastModBy;
                                    lastModByWS1ATEC.Visible = true;
                                }
                                if (lastModByWS1COTF.ID.Contains(ota))
                                {
                                    lastModByWS1COTF.Text = lastModBy;
                                    lastModByWS1COTF.Visible = true;
                                }
                                if (lastModByWS1JITC.ID.Contains(ota))
                                {
                                    lastModByWS1JITC.Text = lastModBy;
                                    lastModByWS1JITC.Visible = true;
                                }
                                if (lastModByWS1MCOTEA.ID.Contains(ota))
                                {
                                    lastModByWS1MCOTEA.Text = lastModBy;
                                    lastModByWS1MCOTEA.Visible = true;
                                }

                                break;
                            }
                        }
                        if (collListWS2.Count > 0)
                        {


                            foreach (SPListItem oListItem in collListWS2)
                            {


                                string editorr = (string)oListItem["Editor"]; //1;#DOTEDRESOURCE\danielnw-p

                                int editorri = editorr.IndexOf(";#");
                                editorr = editorr.Substring(0, editorri);

                                SPUser editor = null;
                                editor = SPContext.Current.Web.AllUsers.GetByID(Int32.Parse(editorr));
                                string editorName = editorr;
                                if (editor != null) { editorName = editor.Name; }
                                string lastModBy = "Last Modified by " + editorName;


                                if (lastModByWS2AFOTEC.ID.Contains(ota))
                                {
                                    lastModByWS2AFOTEC.Text = lastModBy;
                                    lastModByWS2AFOTEC.Visible = true;
                                }
                                if (lastModByWS2ATEC.ID.Contains(ota))
                                {
                                    lastModByWS2ATEC.Text = lastModBy;
                                    lastModByWS2ATEC.Visible = true;
                                }
                                if (lastModByWS2COTF.ID.Contains(ota))
                                {
                                    lastModByWS2COTF.Text = lastModBy;
                                    lastModByWS2COTF.Visible = true;
                                }
                                if (lastModByWS2JITC.ID.Contains(ota))
                                {
                                    lastModByWS2JITC.Text = lastModBy;
                                    lastModByWS2JITC.Visible = true;
                                }
                                if (lastModByWS2MCOTEA.ID.Contains(ota))
                                {
                                    lastModByWS2MCOTEA.Text = lastModBy;
                                    lastModByWS2MCOTEA.Visible = true;
                                }

                                break;
                            }
                        }
                        if (collListWS3.Count > 0)
                        {


                            foreach (SPListItem oListItem in collListWS3)
                            {


                                string editorr = (string)oListItem["Editor"]; //1;#DOTEDRESOURCE\danielnw-p

                                int editorri = editorr.IndexOf(";#");
                                editorr = editorr.Substring(0, editorri);

                                SPUser editor = null;
                                editor = SPContext.Current.Web.AllUsers.GetByID(Int32.Parse(editorr));
                                string editorName = editorr;
                                if (editor != null) { editorName = editor.Name; }
                                string lastModBy = "Last Modified by " + editorName;


                                if (lastModByWS3AFOTEC.ID.Contains(ota))
                                {
                                    lastModByWS3AFOTEC.Text = lastModBy;
                                    lastModByWS3AFOTEC.Visible = true;
                                }
                                if (lastModByWS3ATEC.ID.Contains(ota))
                                {
                                    lastModByWS3ATEC.Text = lastModBy;
                                    lastModByWS3ATEC.Visible = true;
                                }
                                if (lastModByWS3COTF.ID.Contains(ota))
                                {
                                    lastModByWS3COTF.Text = lastModBy;
                                    lastModByWS3COTF.Visible = true;
                                }
                                if (lastModByWS3JITC.ID.Contains(ota))
                                {
                                    lastModByWS3JITC.Text = lastModBy;
                                    lastModByWS3JITC.Visible = true;
                                }
                                if (lastModByWS3MCOTEA.ID.Contains(ota))
                                {
                                    lastModByWS3MCOTEA.Text = lastModBy;
                                    lastModByWS3MCOTEA.Visible = true;
                                }

                                break;
                            }
                        }
                        if (collListWS4.Count > 0)
                        {


                            foreach (SPListItem oListItem in collListWS4)
                            {


                                string editorr = (string)oListItem["Editor"]; //1;#DOTEDRESOURCE\danielnw-p

                                int editorri = editorr.IndexOf(";#");
                                editorr = editorr.Substring(0, editorri);

                                SPUser editor = null;
                                editor = SPContext.Current.Web.AllUsers.GetByID(Int32.Parse(editorr));
                                string editorName = editorr;
                                if (editor != null) { editorName = editor.Name; }
                                string lastModBy = "Last Modified by " + editorName;


                                if (lastModByWS4AFOTEC.ID.Contains(ota))
                                {
                                    lastModByWS4AFOTEC.Text = lastModBy;
                                    lastModByWS4AFOTEC.Visible = true;
                                }
                                if (lastModByWS4ATEC.ID.Contains(ota))
                                {
                                    lastModByWS4ATEC.Text = lastModBy;
                                    lastModByWS4ATEC.Visible = true;
                                }
                                if (lastModByWS4COTF.ID.Contains(ota))
                                {
                                    lastModByWS4COTF.Text = lastModBy;
                                    lastModByWS4COTF.Visible = true;
                                }
                                if (lastModByWS4JITC.ID.Contains(ota))
                                {
                                    lastModByWS4JITC.Text = lastModBy;
                                    lastModByWS4JITC.Visible = true;
                                }
                                if (lastModByWS4MCOTEA.ID.Contains(ota))
                                {
                                    lastModByWS4MCOTEA.Text = lastModBy;
                                    lastModByWS4MCOTEA.Visible = true;
                                }

                                break;
                            }
                        }
                    }

                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("StatusOverviewLastModBy", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

               
                //query CONOPSApprovalProgress
                SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
                oQueryCONOPSApprovalProgress.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\" /></OrderBy><Where>" +

                        "<Eq>" +
                            "<FieldRef Name='OperationalTestAgency'/>" +
                                "<Value Type='Choice'>" + ota + "</Value>" +
                         "</Eq>" +

                "</Where>";
                SPListItemCollection collListItemsq = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);


                Dictionary<string, string> colorKey = new Dictionary<string, string>();
               
                colorKey.Add("Baseline OTA Submission", "lightcoral");
                colorKey.Add("AO Recommendation", "lemonchiffon");
                colorKey.Add("PM Preapproval", "thistle");
                colorKey.Add("Deputy Director Approval", "lightgreen");
                colorKey.Add("Completed", "lightgreen");

                foreach (SPListItem oListItem in collListItemsq)
                {
                    
                    string status = (string)oListItem["CONOPSApproval"];
                    string btnID = oListItem.Title + ota;
                    string submitted = "";

                    try
                    {
                        if (oListItem["SubmittedFY"] != null) { submitted = (string)oListItem["SubmittedFY"]; }
                        
                        traceInfo = "Look for Control with id: " + btnID + " status: " + status;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("StatusOverview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (btnID == WS1AFOTEC.ID) { if (status == "Baseline OTA Submission") { Label1AFOTEC.Text = "OTA Submission Pending"; WS1AFOTEC.Visible = false; Label1AFOTEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label1AFOTEC.Text = "Completed"; WS1AFOTEC.Visible = false; Label1AFOTEC.Visible = true; } else { WS1AFOTEC.Text = status; WS1AFOTEC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS2AFOTEC.ID) { if (status == "Baseline OTA Submission") { Label6AFOTEC.Text = "OTA Submission Pending"; WS2AFOTEC.Visible = false; Label6AFOTEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label6AFOTEC.Text = "Completed"; WS2AFOTEC.Visible = false; Label6AFOTEC.Visible = true; } else { WS2AFOTEC.Text = status; WS2AFOTEC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS3AFOTEC.ID) { if (status == "Baseline OTA Submission") { Label11AFOTEC.Text = "OTA Submission Pending"; WS3AFOTEC.Visible = false; Label11AFOTEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label11AFOTEC.Text = "Completed"; WS3AFOTEC.Visible = false; Label11AFOTEC.Visible = true; } else { WS3AFOTEC.Text = status; WS3AFOTEC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS4AFOTEC.ID) { if (status == "Baseline OTA Submission") { Label16AFOTEC.Text = "OTA Submission Pending"; WS4AFOTEC.Visible = false; Label16AFOTEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label16AFOTEC.Text = "Completed"; WS4AFOTEC.Visible = false; Label16AFOTEC.Visible = true; } else { WS4AFOTEC.Text = status; WS4AFOTEC.Style.Add("background-color", colorKey[status]); } }

                        if (btnID == WS1ATEC.ID) { if (status == "Baseline OTA Submission") { Label2ATEC.Text = "OTA Submission Pending"; WS1ATEC.Visible = false; Label2ATEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label2ATEC.Text = "Completed"; WS1ATEC.Visible = false; Label2ATEC.Visible = true; } else { WS1ATEC.Text = status; WS1ATEC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS2ATEC.ID) { if (status == "Baseline OTA Submission") { Label7ATEC.Text = "OTA Submission Pending"; WS2ATEC.Visible = false; Label7ATEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label7ATEC.Text = "Completed"; WS2ATEC.Visible = false; Label7ATEC.Visible = true; } else { WS2ATEC.Text = status; WS2ATEC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS3ATEC.ID) { if (status == "Baseline OTA Submission") { Label12ATEC.Text = "OTA Submission Pending"; WS3ATEC.Visible = false; Label12ATEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label12ATEC.Text = "Completed"; WS3ATEC.Visible = false; Label12ATEC.Visible = true; } else { WS3ATEC.Text = status; WS3ATEC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS4ATEC.ID) { if (status == "Baseline OTA Submission") { Label17ATEC.Text = "OTA Submission Pending"; WS4ATEC.Visible = false; Label17ATEC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label17ATEC.Text = "Completed"; WS4ATEC.Visible = false; Label17ATEC.Visible = true; } else { WS4ATEC.Text = status; WS4ATEC.Style.Add("background-color", colorKey[status]); } }

                        if (btnID == WS1COTF.ID) { if (status == "Baseline OTA Submission") { Label3COTF.Text = "OTA Submission Pending"; WS1COTF.Visible = false; Label3COTF.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label3COTF.Text = "Completed"; WS1COTF.Visible = false; Label3COTF.Visible = true; } else { WS1COTF.Text = status; WS1COTF.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS2COTF.ID) { if (status == "Baseline OTA Submission") { Label8COTF.Text = "OTA Submission Pending"; WS2COTF.Visible = false; Label8COTF.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label8COTF.Text = "Completed"; WS2COTF.Visible = false; Label8COTF.Visible = true; } else { WS2COTF.Text = status; WS2COTF.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS3COTF.ID) { if (status == "Baseline OTA Submission") { Label13COTF.Text = "OTA Submission Pending"; WS3COTF.Visible = false; Label13COTF.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label13COTF.Text = "Completed"; WS3COTF.Visible = false; Label13COTF.Visible = true; } else { WS3COTF.Text = status; WS3COTF.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS4COTF.ID) { if (status == "Baseline OTA Submission") { Label18COTF.Text = "OTA Submission Pending"; WS4COTF.Visible = false; Label18COTF.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label18COTF.Text = "Completed"; WS4COTF.Visible = false; Label18COTF.Visible = true; } else { WS4COTF.Text = status; WS4COTF.Style.Add("background-color", colorKey[status]); } }

                        if (btnID == WS1JITC.ID) { if (status == "Baseline OTA Submission") { Label4JITC.Text = "OTA Submission Pending"; WS1JITC.Visible = false; Label4JITC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label4JITC.Text = "Completed"; WS1JITC.Visible = false; Label4JITC.Visible = true; } else { WS1JITC.Text = status; WS1JITC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS2JITC.ID) { if (status == "Baseline OTA Submission") { Label9JITC.Text = "OTA Submission Pending"; WS2JITC.Visible = false; Label9JITC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label9JITC.Text = "Completed"; WS2JITC.Visible = false; Label9JITC.Visible = true; } else { WS2JITC.Text = status; WS2JITC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS3JITC.ID) { if (status == "Baseline OTA Submission") { Label14JITC.Text = "OTA Submission Pending"; WS3JITC.Visible = false; Label14JITC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label14JITC.Text = "Completed"; WS3JITC.Visible = false; Label14JITC.Visible = true; } else { WS3JITC.Text = status; WS3JITC.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS4JITC.ID) { if (status == "Baseline OTA Submission") { Label19JITC.Text = "OTA Submission Pending"; WS4JITC.Visible = false; Label19JITC.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label19JITC.Text = "Completed"; WS4JITC.Visible = false; Label19JITC.Visible = true; } else { WS4JITC.Text = status; WS4JITC.Style.Add("background-color", colorKey[status]); } }

                        if (btnID == WS1MCOTEA.ID) { if (status == "Baseline OTA Submission") { Label5MCOTEA.Text = "OTA Submission Pending"; WS1MCOTEA.Visible = false; Label5MCOTEA.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label5MCOTEA.Text = "Completed"; WS1MCOTEA.Visible = false; Label5MCOTEA.Visible = true; } else { WS1MCOTEA.Text = status; WS1MCOTEA.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS2MCOTEA.ID) { if (status == "Baseline OTA Submission") { Label10MCOTEA.Text = "OTA Submission Pending"; WS2MCOTEA.Visible = false; Label10MCOTEA.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label10MCOTEA.Text = "Completed"; WS2MCOTEA.Visible = false; Label10MCOTEA.Visible = true; } else { WS2MCOTEA.Text = status; WS2MCOTEA.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS3MCOTEA.ID) { if (status == "Baseline OTA Submission") { Label15MCOTEA.Text = "OTA Submission Pending"; WS3MCOTEA.Visible = false; Label15MCOTEA.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label15MCOTEA.Text = "Completed"; WS3MCOTEA.Visible = false; Label15MCOTEA.Visible = true; } else { WS3MCOTEA.Text = status; WS3MCOTEA.Style.Add("background-color", colorKey[status]); } }
                        if (btnID == WS4MCOTEA.ID) { if (status == "Baseline OTA Submission") { Label20MCOTEA.Text = "OTA Submission Pending"; WS4MCOTEA.Visible = false; Label20MCOTEA.Visible = true; } else if (submitted == CurrentFYforAcceptingCONOPS) { Label20MCOTEA.Text = "Completed"; WS4MCOTEA.Visible = false; Label20MCOTEA.Visible = true; } else { WS4MCOTEA.Text = status; WS4MCOTEA.Style.Add("background-color", colorKey[status]); } }

                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("StatusOverview", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }

            
            
            
            
            
            }

            

            //=====end CONOPSApprovalStatusOverview=============


            if (IsPostBack)
            {
                //if (Page.Request.QueryString["filterSelected"] == "1") { RadioButton1.Checked=true; }
                //if (Page.Request.QueryString["filterSelected"] == "2") { RadioButton2.Checked=true; }
                //if (Page.Request.QueryString["filterSelected"] == "3") { RadioButton3.Checked=true; }

                
        


                if (RadioButton1.Checked)
                {
                    filterSelectB.Visible = true;
                    filterSelectC.Visible = false;
                    CONOPSApprovalSelectOTADropDownList.Visible = true;
                    CONOPSApprovalSelectStatusDropDownList.Visible = false;
                    CONOPSApprovalSelectStatusDropDownList.SelectedIndex = 0;
                    CONOPSApprovalSelectStatusDropDownList_SelectedIndexChanged(CONOPSApprovalSelectStatusDropDownList, EventArgs.Empty);

                    //submittedULAFOTECLiteral.Text = "";
                    //submittedULATECLiteral.Text = "";
                    //submittedULCOTFLiteral.Text = "";
                    //submittedULJITCLiteral.Text = "";
                    //submittedULMCOTEALiteral.Text = "";

                    //viewByOTA();
                }
                if (RadioButton2.Checked)
                {

                    filterSelectB.Visible = true;
                    filterSelectC.Visible = false;
                    CONOPSApprovalSelectOTADropDownList.Visible = false;
                    CONOPSApprovalSelectOTADropDownList.SelectedIndex = 0;
                    CONOPSApprovalSelectOTADropDownList_SelectedIndexChanged(CONOPSApprovalSelectOTADropDownList, EventArgs.Empty);
                    CONOPSApprovalSelectStatusDropDownList.Visible = true;

                    //submittedULAFOTECLiteral.Text = "";
                    //submittedULATECLiteral.Text = "";
                    //submittedULCOTFLiteral.Text = "";
                    //submittedULJITCLiteral.Text = "";
                    //submittedULMCOTEALiteral.Text = "";

                    //viewByStatus();
                }
                if (RadioButton3.Checked)
                {


                    filterSelectB.Visible = false;
                    filterSelectC.Visible = true;
                    CONOPSApprovalSelectOTADropDownList.Visible = false;
                    CONOPSApprovalSelectOTADropDownList.SelectedIndex = 0;
                    CONOPSApprovalSelectOTADropDownList_SelectedIndexChanged(CONOPSApprovalSelectOTADropDownList, EventArgs.Empty);

                    CONOPSApprovalSelectStatusDropDownList.Visible = false;
                    CONOPSApprovalSelectStatusDropDownList.SelectedIndex = 0;
                    CONOPSApprovalSelectStatusDropDownList_SelectedIndexChanged(CONOPSApprovalSelectStatusDropDownList, EventArgs.Empty);




                    submittedULAFOTECLiteral.Text = "";
                    submittedULATECLiteral.Text = "";
                    submittedULCOTFLiteral.Text = "";
                    submittedULJITCLiteral.Text = "";
                    submittedULMCOTEALiteral.Text = "";

                    divAFOTEC.Visible = false;
                    divATEC.Visible = false;
                    divCOTF.Visible = false;
                    divJITC.Visible = false;
                    divMCOTEA.Visible = false;

                    viewAllorFilterByOTA(false, "None");
                }

                overviewButtonLinks();
            }
            else
            {
                
            
                try
                {
                    if (FilterControlSelected.Value != "")
                    {
                        if (FilterControlSelected.Value.Contains("CONOPSApprovalSelectOTADropDownList"))
                        {
                            CONOPSApprovalSelectOTADropDownList.Items[Int32.Parse(FilterControlSelectedIndex.Value)].Selected = true;
                        }
                        if (FilterControlSelected.Value.Contains("CONOPSApprovalSelectStatusDropDownList"))
                        {
                            CONOPSApprovalSelectStatusDropDownList.Items[Int32.Parse(FilterControlSelectedIndex.Value)].Selected = true;
                        }
                    }

                    //When selected Deputy Director Approval from CONOPSApprovalSelectStatusDropDownList errored with Cannot have multiple selections for a dropdown after postback induced, so maybe look for this
                }
                catch { }
                
                overviewButtonLinks();











            }
            
        }

        private void viewAllorFilterByOTA(bool filterByOTA, string selectedOTAString)
        {
            var traceInfo = "viewAllorFilterByOTA";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("viewAllorFilterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            Dictionary<string, string> WSDictionary = new Dictionary<string, string>();
            WSDictionary.Add("WS1", "Budget Worksheet #1: Core Personnel Costs");
            WSDictionary.Add("WS2", "Budget Worksheet #2: Assessment Costs");
            WSDictionary.Add("WS3", "Budget Worksheet #3: Non-Assessment Travel");
            WSDictionary.Add("WS4", "Budget Worksheet #4: Non-Assessment Support");

            string dcapx = SPContext.Current.Site.RootWeb.ServerRelativeUrl;
            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16

            Dictionary<string, string> OTADictionary = new Dictionary<string, string>();
            OTADictionary.Add("AFOTEC", "Air Force Operational Test and Evaluation Center");
            OTADictionary.Add("ATEC", "Army Test and Evaluation Command");
            OTADictionary.Add("COTF", "Commander Operational Test and Evaluation Force");
            OTADictionary.Add("JITC", "Joint Interoperability Test Command");
            OTADictionary.Add("MCOTEA", "Marine Corps Operational Test and Evaluation Activity");

            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];

            if (filterByOTA)
            {
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>" +
                                        selectedOTAString +
                                    "</Value>" +
                             "</Eq>" +
                             "<Neq>" +
                                "<FieldRef Name='CONOPSApproval'/>" +
                                    "<Value Type='Choice'>" +
                                        "Baseline OTA Submission" +
                                    "</Value>" +
                                "</Neq>" +
                        "</And>" +
                    "</Where>";

                try
                {
                    SPListItemCollection oListCONOPSApprovalProgressItems = oListCONOPSApprovalProgress.GetItems(oQuery);

                    traceInfo = "oListCONOPSApprovalProgressItems.Count : " + oListCONOPSApprovalProgressItems.Count;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListCONOPSApprovalProgressItems.Count > 0)
                    {
                        string otaShort = selectedOTAString;
                        string otaLong = OTADictionary[selectedOTAString];
                        string worksheet = "";
                        if (selectedOTAString == "AFOTEC")
                        {

                            SPQuery oQueryCONOPSApprovalProgressAFOTEC = new SPQuery();
                            oQueryCONOPSApprovalProgressAFOTEC.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>AFOTEC</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedAFOTEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressAFOTEC);

                            if (collItemsSubmittedAFOTEC.Count > 0)
                            {
                                //Show worksheetsListDivB
                                worksheetsListDivBAFOTEC.Visible = true;

                            }

                            //-- end Query --


                            divAFOTEC.Visible = true;

                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //If approved use tinytick.gif for li image by adding class 'approved'
                                string liClassIfApproved = "";
                                if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                {
                                    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                }

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                            }

                        }
                        if (selectedOTAString == "ATEC")
                        {

                            SPQuery oQueryCONOPSApprovalProgressATEC = new SPQuery();
                            oQueryCONOPSApprovalProgressATEC.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>ATEC</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedATEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressATEC);

                            if (collItemsSubmittedATEC.Count > 0)
                            {
                                traceInfo = "Show worksheetsListDivBATEC";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //Show worksheetsListDivB
                                worksheetsListDivBATEC.Visible = true;
                            }

                            //-- end Query --



                            divATEC.Visible = true;
                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //If approved use tinytick.gif for li image by adding class 'approved'
                                string liClassIfApproved = "";
                                if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                {
                                    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                }

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                            }
                        }
                        if (selectedOTAString == "COTF")
                        {
                            SPQuery oQueryCONOPSApprovalProgressCOTF = new SPQuery();
                            oQueryCONOPSApprovalProgressCOTF.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>COTF</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedCOTF = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressCOTF);

                            if (collItemsSubmittedCOTF.Count > 0)
                            {
                                //Show worksheetsListDivB
                                worksheetsListDivBCOTF.Visible = true;
                            }

                            //-- end Query --
                            divCOTF.Visible = true;
                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //If approved use tinytick.gif for li image by adding class 'approved'
                                string liClassIfApproved = "";
                                if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                {
                                    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                }

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                            }
                        }
                        if (selectedOTAString == "JITC")
                        {
                            SPQuery oQueryCONOPSApprovalProgressJITC = new SPQuery();
                            oQueryCONOPSApprovalProgressJITC.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>JITC</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedJITC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressJITC);

                            if (collItemsSubmittedJITC.Count > 0)
                            {
                                //Show worksheetsListDivB
                                worksheetsListDivBJITC.Visible = true;
                            }

                            //-- end Query --

                            divJITC.Visible = true;
                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //If approved use tinytick.gif for li image by adding class 'approved'
                                string liClassIfApproved = "";
                                if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                {
                                    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                }

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                            }
                        }
                        if (selectedOTAString == "MCOTEA")
                        {
                            SPQuery oQueryCONOPSApprovalProgressMCOTEA = new SPQuery();
                            oQueryCONOPSApprovalProgressMCOTEA.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>MCOTEA</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedMCOTEA = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressMCOTEA);

                            if (collItemsSubmittedMCOTEA.Count > 0)
                            {
                                //Show worksheetsListDivB
                                worksheetsListDivBMCOTEA.Visible = true;
                            }

                            //-- end Query --

                            divMCOTEA.Visible = true;
                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {

                                //If approved use tinytick.gif for li image by adding class 'approved'
                                string liClassIfApproved = "";
                                if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                {
                                    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                }

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("filterByOTA", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }
            else
            {
                foreach (KeyValuePair<string, string> kvp in OTADictionary)
                {
                    traceInfo = "kvp.Key: " + kvp.Key;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    SPQuery oQuery = new SPQuery();
                    oQuery.Query = "<Where>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name='OperationalTestAgency'/>" +
                                        "<Value Type='Choice'>" +
                                            kvp.Key +
                                        "</Value>" +
                                 "</Eq>" +
                                 "<Neq>" +
                                    "<FieldRef Name='CONOPSApproval'/>" +
                                        "<Value Type='Choice'>" +
                                            "Baseline OTA Submission" +
                                        "</Value>" +
                                    "</Neq>" +
                            "</And>" +
                        "</Where>";
                    try
                    {
                        SPListItemCollection oListCONOPSApprovalProgressItems = oListCONOPSApprovalProgress.GetItems(oQuery);

                        traceInfo = "oListCONOPSApprovalProgressItems.Count : " + oListCONOPSApprovalProgressItems.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (oListCONOPSApprovalProgressItems.Count > 0)
                        {
                            string otaShort = kvp.Key;
                            string otaLong = kvp.Value;
                            string worksheet = "";

                            if (kvp.Key == "AFOTEC")
                            {





                                //-- Query CONOPSApprovalProgress where OperationalTestAgency equals AFOTEC and Submitted equals Yes.
                                //            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];

                                SPQuery oQueryCONOPSApprovalProgressAFOTEC = new SPQuery();
                                oQueryCONOPSApprovalProgressAFOTEC.Query = "<Where>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name='OperationalTestAgency'/>" +
                                                "<Value Type='Choice'>AFOTEC</Value>" +
                                         "</Eq>" +
                                         "<Eq>" +
                                            "<FieldRef Name='Submitted'/>" +
                                                "<Value Type='Text'>Yes</Value>" +
                                            "</Eq>" +
                                    "</And>" +
                                "</Where>";

                                SPListItemCollection collItemsSubmittedAFOTEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressAFOTEC);

                                if (collItemsSubmittedAFOTEC.Count > 0)
                                {
                                    //Show worksheetsListDivB
                                    worksheetsListDivBAFOTEC.Visible = true;

                                }

                                //-- end Query --


                                divAFOTEC.Visible = true;

                                foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                                {
                                    //If approved use tinytick.gif for li image by adding class 'approved'
                                    string liClassIfApproved = "";
                                    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                    {
                                        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                    }

                                    worksheet = oListItem.Title;
                                    string WSTitle = WSDictionary[worksheet];
                                    traceInfo = "WSTitle : " + WSTitle;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    worksheet = worksheet.Replace("WS", "");

                                    string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                    string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                    string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                    submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                                }

                            }
                            if (kvp.Key == "ATEC")
                            {




                                //-- Query CONOPSApprovalProgress where OperationalTestAgency equals ATEC and Submitted equals Yes.
                                SPQuery oQueryCONOPSApprovalProgressATEC = new SPQuery();
                                oQueryCONOPSApprovalProgressATEC.Query = "<Where>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name='OperationalTestAgency'/>" +
                                                "<Value Type='Choice'>ATEC</Value>" +
                                         "</Eq>" +
                                         "<Eq>" +
                                            "<FieldRef Name='Submitted'/>" +
                                                "<Value Type='Text'>Yes</Value>" +
                                            "</Eq>" +
                                    "</And>" +
                                "</Where>";

                                SPListItemCollection collItemsSubmittedATEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressATEC);

                                if (collItemsSubmittedATEC.Count > 0)
                                {
                                    traceInfo = "Show worksheetsListDivBATEC";
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    //Show worksheetsListDivB
                                    worksheetsListDivBATEC.Visible = true;
                                }

                                //-- end Query --



                                divATEC.Visible = true;
                                foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                                {
                                    //If approved use tinytick.gif for li image by adding class 'approved'
                                    string liClassIfApproved = "";
                                    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                    {
                                        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                    }

                                    worksheet = oListItem.Title;
                                    string WSTitle = WSDictionary[worksheet];
                                    traceInfo = "WSTitle : " + WSTitle;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    worksheet = worksheet.Replace("WS", "");

                                    string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                    string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                    //string wslink = "javascript:openWorksheet('" + wslinkhref + "', " + otaShort + ", " + worksheet + ")";
                                    string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                    submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                                }
                            }
                            if (kvp.Key == "COTF")
                            {
                                //-- Query CONOPSApprovalProgress where OperationalTestAgency equals COTF and Submitted equals Yes.
                                SPQuery oQueryCONOPSApprovalProgressCOTF = new SPQuery();
                                oQueryCONOPSApprovalProgressCOTF.Query = "<Where>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name='OperationalTestAgency'/>" +
                                                "<Value Type='Choice'>COTF</Value>" +
                                         "</Eq>" +
                                         "<Eq>" +
                                            "<FieldRef Name='Submitted'/>" +
                                                "<Value Type='Text'>Yes</Value>" +
                                            "</Eq>" +
                                    "</And>" +
                                "</Where>";

                                SPListItemCollection collItemsSubmittedCOTF = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressCOTF);

                                if (collItemsSubmittedCOTF.Count > 0)
                                {
                                    //Show worksheetsListDivB
                                    worksheetsListDivBCOTF.Visible = true;
                                }

                                //-- end Query --
                                divCOTF.Visible = true;
                                foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                                {
                                    //If approved use tinytick.gif for li image by adding class 'approved'
                                    string liClassIfApproved = "";
                                    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                    {
                                        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                    }

                                    worksheet = oListItem.Title;
                                    string WSTitle = WSDictionary[worksheet];
                                    traceInfo = "WSTitle : " + WSTitle;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    worksheet = worksheet.Replace("WS", "");

                                    string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                    string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                    string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                    submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                                }
                            }
                            if (kvp.Key == "JITC")
                            {
                                //-- Query CONOPSApprovalProgress where OperationalTestAgency equals JITC and Submitted equals Yes.
                                SPQuery oQueryCONOPSApprovalProgressJITC = new SPQuery();
                                oQueryCONOPSApprovalProgressJITC.Query = "<Where>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name='OperationalTestAgency'/>" +
                                                "<Value Type='Choice'>JITC</Value>" +
                                         "</Eq>" +
                                         "<Eq>" +
                                            "<FieldRef Name='Submitted'/>" +
                                                "<Value Type='Text'>Yes</Value>" +
                                            "</Eq>" +
                                    "</And>" +
                                "</Where>";

                                SPListItemCollection collItemsSubmittedJITC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressJITC);

                                if (collItemsSubmittedJITC.Count > 0)
                                {
                                    //Show worksheetsListDivB
                                    worksheetsListDivBJITC.Visible = true;
                                }

                                //-- end Query --

                                divJITC.Visible = true;
                                foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                                {
                                    //If approved use tinytick.gif for li image by adding class 'approved'
                                    string liClassIfApproved = "";
                                    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                    {
                                        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                    }

                                    worksheet = oListItem.Title;
                                    string WSTitle = WSDictionary[worksheet];
                                    traceInfo = "WSTitle : " + WSTitle;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    worksheet = worksheet.Replace("WS", "");

                                    string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                    string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                    string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                    submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                                }
                            }
                            if (kvp.Key == "MCOTEA")
                            {
                                //-- Query CONOPSApprovalProgress where OperationalTestAgency equals MCOTEA and Submitted equals Yes.
                                SPQuery oQueryCONOPSApprovalProgressMCOTEA = new SPQuery();
                                oQueryCONOPSApprovalProgressMCOTEA.Query = "<Where>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name='OperationalTestAgency'/>" +
                                                "<Value Type='Choice'>MCOTEA</Value>" +
                                         "</Eq>" +
                                         "<Eq>" +
                                            "<FieldRef Name='Submitted'/>" +
                                                "<Value Type='Text'>Yes</Value>" +
                                            "</Eq>" +
                                    "</And>" +
                                "</Where>";

                                SPListItemCollection collItemsSubmittedMCOTEA = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressMCOTEA);

                                if (collItemsSubmittedMCOTEA.Count > 0)
                                {
                                    //Show worksheetsListDivB
                                    worksheetsListDivBMCOTEA.Visible = true;
                                }

                                //-- end Query --

                                divMCOTEA.Visible = true;
                                foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                                {

                                    //If approved use tinytick.gif for li image by adding class 'approved'
                                    string liClassIfApproved = "";
                                    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                    {
                                        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                    }

                                    worksheet = oListItem.Title;
                                    string WSTitle = WSDictionary[worksheet];
                                    traceInfo = "WSTitle : " + WSTitle;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    worksheet = worksheet.Replace("WS", "");

                                    string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no";
                                    string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                    string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                    submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                                }
                            }




                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }



        }


        private void overviewButtonLinks()
        {
            var traceInfo = "overviewButtonLinks";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("overviewButtonLinks", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            Dictionary<string, string> WSDictionary = new Dictionary<string, string>();
            WSDictionary.Add("WS1", "Budget Worksheet #1: Core Personnel Costs");
            WSDictionary.Add("WS2", "Budget Worksheet #2: Assessment Costs");
            WSDictionary.Add("WS3", "Budget Worksheet #3: Non-Assessment Travel");
            WSDictionary.Add("WS4", "Budget Worksheet #4: Non-Assessment Support");

            string dcapx = SPContext.Current.Site.RootWeb.ServerRelativeUrl;
            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16

            Dictionary<string, string> OTADictionary = new Dictionary<string, string>();
            OTADictionary.Add("AFOTEC", "Air Force Operational Test and Evaluation Center");
            OTADictionary.Add("ATEC", "Army Test and Evaluation Command");
            OTADictionary.Add("COTF", "Commander Operational Test and Evaluation Force");
            OTADictionary.Add("JITC", "Joint Interoperability Test Command");
            OTADictionary.Add("MCOTEA", "Marine Corps Operational Test and Evaluation Activity");

            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];

            foreach (KeyValuePair<string, string> kvp in OTADictionary)
            {
                traceInfo = "kvp.Key: " + kvp.Key;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>" +
                                        kvp.Key +
                                    "</Value>" +
                             "</Eq>" +
                             "<Neq>" +
                                "<FieldRef Name='CONOPSApproval'/>" +
                                    "<Value Type='Choice'>" +
                                        "Baseline OTA Submission" +
                                    "</Value>" +
                                "</Neq>" +
                        "</And>" +
                    "</Where>";
                try
                {
                    SPListItemCollection oListCONOPSApprovalProgressItems = oListCONOPSApprovalProgress.GetItems(oQuery);

                    traceInfo = "oListCONOPSApprovalProgressItems.Count : " + oListCONOPSApprovalProgressItems.Count;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListCONOPSApprovalProgressItems.Count > 0)
                    {
                        string otaShort = kvp.Key;
                        string otaLong = kvp.Value;
                        string worksheet = "";

                        if (kvp.Key == "AFOTEC")
                        {

                            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals AFOTEC and Submitted equals Yes.
                            //            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];

                            SPQuery oQueryCONOPSApprovalProgressAFOTEC = new SPQuery();
                            oQueryCONOPSApprovalProgressAFOTEC.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>AFOTEC</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedAFOTEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressAFOTEC);

                         

                            //-- end Query --



                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //string liClassIfApproved = "";
                                //if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                //{
                                //    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                //}

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("overviewButtonLinks", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no&fromPanel=1";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                //submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                                try
                                {
                                    //=======CONOPSApprovalStatusOverviewBtn=======
                                    if (worksheet == "1") { WS1AFOTEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "2") { WS2AFOTEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "3") { WS3AFOTEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "4") { WS4AFOTEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalStatusOverviewBtn", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                            }

                        }
                        if (kvp.Key == "ATEC")
                        {




                            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals ATEC and Submitted equals Yes.
                            SPQuery oQueryCONOPSApprovalProgressATEC = new SPQuery();
                            oQueryCONOPSApprovalProgressATEC.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>ATEC</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedATEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressATEC);

                    

                            //-- end Query --



                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //string liClassIfApproved = "";
                                //if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                //{
                                //    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                //}

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("overviewButtonLinks", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no&fromPanel=1";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                //submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                                try
                                {
                                    //=======CONOPSApprovalStatusOverviewBtn=======
                                    if (worksheet == "1") { WS1ATEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "2") { WS2ATEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "3") { WS3ATEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "4") { WS4ATEC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalStatusOverviewBtn", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                            }
                        }
                        if (kvp.Key == "COTF")
                        {
                            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals COTF and Submitted equals Yes.
                            SPQuery oQueryCONOPSApprovalProgressCOTF = new SPQuery();
                            oQueryCONOPSApprovalProgressCOTF.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>COTF</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedCOTF = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressCOTF);


                            //-- end Query --
                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //string liClassIfApproved = "";
                                //if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                //{
                                //    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                //}

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no&fromPanel=1";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                //submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                                try
                                {
                                    //=======CONOPSApprovalStatusOverviewBtn=======
                                    if (worksheet == "1") { WS1COTF.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "2") { WS2COTF.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "3") { WS3COTF.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "4") { WS4COTF.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalStatusOverviewBtn", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                            }
                        }
                        if (kvp.Key == "JITC")
                        {
                            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals JITC and Submitted equals Yes.
                            SPQuery oQueryCONOPSApprovalProgressJITC = new SPQuery();
                            oQueryCONOPSApprovalProgressJITC.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>JITC</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedJITC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressJITC);

                         

                            //-- end Query --

                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {
                                //string liClassIfApproved = "";
                                //if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                //{
                                //    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                //}

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no&fromPanel=1";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                //submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                                try
                                {
                                    //=======CONOPSApprovalStatusOverviewBtn=======
                                    if (worksheet == "1") { WS1JITC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "2") { WS2JITC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "3") { WS3JITC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "4") { WS4JITC.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalStatusOverviewBtn", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                            }
                        }
                        if (kvp.Key == "MCOTEA")
                        {
                            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals MCOTEA and Submitted equals Yes.
                            SPQuery oQueryCONOPSApprovalProgressMCOTEA = new SPQuery();
                            oQueryCONOPSApprovalProgressMCOTEA.Query = "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name='OperationalTestAgency'/>" +
                                            "<Value Type='Choice'>MCOTEA</Value>" +
                                     "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name='Submitted'/>" +
                                            "<Value Type='Text'>Yes</Value>" +
                                        "</Eq>" +
                                "</And>" +
                            "</Where>";

                            SPListItemCollection collItemsSubmittedMCOTEA = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressMCOTEA);

                          

                            //-- end Query --

                            foreach (SPListItem oListItem in oListCONOPSApprovalProgressItems)
                            {

                                //string liClassIfApproved = "";
                                //if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                                //{
                                //    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                                //}

                                worksheet = oListItem.Title;
                                string WSTitle = WSDictionary[worksheet];
                                traceInfo = "WSTitle : " + WSTitle;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewAll", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                worksheet = worksheet.Replace("WS", "");

                                string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS" + worksheet + ".aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + SPHttpUtility.HtmlEncode(otaShort) + "&fy=" + CurrentFYforAcceptingCONOPS + "&ws=" + worksheet + "&submitted=no&fromPanel=1";
                                string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                                string wslinkText = "FY " + CurrentFYforAcceptingCONOPS + " " + WSTitle;
                                //submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                                try
                                {
                                    //=======CONOPSApprovalStatusOverviewBtn=======
                                    if (worksheet == "1") { WS1MCOTEA.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "2") { WS2MCOTEA.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "3") { WS3MCOTEA.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                    if (worksheet == "4") { WS4MCOTEA.OnClientClick = "openWorksheet('" + wslinkhref + "'); return false"; }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalStatusOverviewBtn", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                            }
                        }




                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("overviewButtonLinks", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

            }




        }




        protected void CONOPSApprovalSelectOTADropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            //submittedULAFOTECLiteral.Text = "";
            //submittedULATECLiteral.Text = "";
            //submittedULCOTFLiteral.Text = "";
            //submittedULJITCLiteral.Text = "";
            //submittedULMCOTEALiteral.Text = "";

            //DateTime dCurrent = DateTime.Now;
            //dCurrent = dCurrent.AddYears(1);
            //int dCurrentYear = dCurrent.Year;
            //string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16
            //var traceInfo = "CurrentFYforAcceptingCONOPS: " + CurrentFYforAcceptingCONOPS;
            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            
            //string fy1 = CurrentFYforAcceptingCONOPS;

            //string ws1 = "WS1";
            //string ws2 = "WS2";
            //string ws3 = "WS3";
            //string ws4 = "WS4";



            //string dcapx = SPContext.Current.Site.RootWeb.ServerRelativeUrl;

            DropDownList otaSelected = sender as DropDownList;
            
            if(RadioButton1.Checked)
            {
                FilterControlSelected.Value = otaSelected.ID;
                FilterControlSelectedIndex.Value = otaSelected.SelectedIndex.ToString();
            }
            if (RadioButton3.Checked)
            {
                FilterControlSelected.Value = "";
                FilterControlSelectedIndex.Value = "";
            }
            
            
            string selectedOTAString = otaSelected.SelectedValue;

            //string selectedOTALongString = otaSelected.SelectedItem.Text;
            
            //SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];

            //===========
            //REPLACE OLIST METHOD BELOW WITH THIS IF IT WORKS FOR FILTER BY OTA
            //do as you did for View All to restore checkmark

            viewAllorFilterByOTA(true, selectedOTAString);

            //===========



            //SPList oList = null;


            //if(selectedOTAString != "(None)")
            //{
            //    oList = SPContext.Current.Web.Lists["CONOPSDevWS" + selectedOTAString];
            //}

           

            if (selectedOTAString == "(None)")
            {
                divAFOTEC.Visible = false;
                divATEC.Visible = false;
                divCOTF.Visible = false;
                divJITC.Visible = false;
                divMCOTEA.Visible = false;

            }
            if (selectedOTAString == "AFOTEC")
            {
                divAFOTEC.Visible = true;
                divATEC.Visible = false;
                divCOTF.Visible = false;
                divJITC.Visible = false;
                divMCOTEA.Visible = false;

            }
            if (selectedOTAString == "ATEC")
            {
                divAFOTEC.Visible = false;
                divATEC.Visible = true;
                divCOTF.Visible = false;
                divJITC.Visible = false;
                divMCOTEA.Visible = false;
            }
            if (selectedOTAString == "COTF")
            {
                divAFOTEC.Visible = false;
                divATEC.Visible = false;
                divCOTF.Visible = true;
                divJITC.Visible = false;
                divMCOTEA.Visible = false;
            }
            if (selectedOTAString == "JITC")
            {
                divAFOTEC.Visible = false;
                divATEC.Visible = false;
                divCOTF.Visible = false;
                divJITC.Visible = true;
                divMCOTEA.Visible = false;
            }
            if (selectedOTAString == "MCOTEA")
            {
                divAFOTEC.Visible = false;
                divATEC.Visible = false;
                divCOTF.Visible = false;
                divJITC.Visible = false;
                divMCOTEA.Visible = true;
            }
            
            
            //traceInfo = "oQuery next...";
            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //SPQuery oQuery = new SPQuery();
            //oQuery.Query = "<Where>" +
            //        "<And><And>" +
            //            "<Eq>" +
            //                "<FieldRef Name='OTA'/>" +
            //                    "<Value Type='Text'>" +
            //                        selectedOTAString +
            //                    "</Value>" +
            //             "</Eq>" +
            //             "<Eq>" +
            //                "<FieldRef Name='FY'/>" +
            //                    "<Value Type='Text'>" +
            //                        CurrentFYforAcceptingCONOPS +
            //                    "</Value>" +
            //                "</Eq>" +
            //        "</And>" +
            //             "<Neq>" +
            //                "<FieldRef Name='CONOPSApproval'/>" +
            //                    "<Value Type='Choice'>" +
            //                        "Baseline OTA Submission" +
            //                    "</Value>" +
            //                "</Neq>" +
            //        "</And>" +
            //    "</Where>";

            //if (oList != null)
            //{
            //    SPListItemCollection collItems = oList.GetItems(oQuery);


            //    if (collItems.Count > 0)
            //    {

            //        if (selectedOTAString == "AFOTEC")
            //        {
            //            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals AFOTEC and Submitted equals Yes.
            //            SPQuery oQueryCONOPSApprovalProgressAFOTEC = new SPQuery();
            //            oQueryCONOPSApprovalProgressAFOTEC.Query = "<Where>" +
            //                "<And>" +
            //                    "<Eq>" +
            //                        "<FieldRef Name='OperationalTestAgency'/>" +
            //                            "<Value Type='Choice'>AFOTEC</Value>" +
            //                     "</Eq>" +
            //                     "<Eq>" +
            //                        "<FieldRef Name='Submitted'/>" +
            //                            "<Value Type='Text'>Yes</Value>" +
            //                        "</Eq>" +
            //                "</And>" +
            //            "</Where>";

            //            SPListItemCollection collItemsSubmittedAFOTEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressAFOTEC);

            //            if (collItemsSubmittedAFOTEC.Count > 0)
            //            {
            //                //Show worksheetsListDivB
            //                worksheetsListDivBAFOTEC.Visible = true; 
                            
            //                //foreach (SPListItem oListItem in collItemsSubmittedAFOTEC)
            //                //{


            //                //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
            //                //    {
            //                //        liClassIfApprovedAFOTEC = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //                //        // " + liClassIfApproved + "
            //                //    }

            //                //}
            //            }

            //            //-- end Query --


            //            divAFOTEC.Visible = true;
            //        }
            //        if (selectedOTAString == "ATEC")
            //        {
            //            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals ATEC and Submitted equals Yes.
            //            SPQuery oQueryCONOPSApprovalProgressATEC = new SPQuery();
            //            oQueryCONOPSApprovalProgressATEC.Query = "<Where>" +
            //                "<And>" +
            //                    "<Eq>" +
            //                        "<FieldRef Name='OperationalTestAgency'/>" +
            //                            "<Value Type='Choice'>ATEC</Value>" +
            //                     "</Eq>" +
            //                     "<Eq>" +
            //                        "<FieldRef Name='Submitted'/>" +
            //                            "<Value Type='Text'>Yes</Value>" +
            //                        "</Eq>" +
            //                "</And>" +
            //            "</Where>";

            //            SPListItemCollection collItemsSubmittedATEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressATEC);

            //            if (collItemsSubmittedATEC.Count > 0)
            //            {
            //                traceInfo = "Show worksheetsListDivBATEC";
            //                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //                //Show worksheetsListDivB
            //                worksheetsListDivBATEC.Visible = true;

            //                //foreach (SPListItem oListItem in collItemsSubmittedATEC)
            //                //{


            //                //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
            //                //    {
            //                //        liClassIfApprovedATEC = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //                //        // " + liClassIfApproved + "
            //                //    }

            //                //}
            //            }

            //            //-- end Query --
            //            divATEC.Visible = true;
            //        }
            //        if (selectedOTAString == "COTF")
            //        {
            //            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals COTF and Submitted equals Yes.
            //            SPQuery oQueryCONOPSApprovalProgressCOTF = new SPQuery();
            //            oQueryCONOPSApprovalProgressCOTF.Query = "<Where>" +
            //                "<And>" +
            //                    "<Eq>" +
            //                        "<FieldRef Name='OperationalTestAgency'/>" +
            //                            "<Value Type='Choice'>COTF</Value>" +
            //                     "</Eq>" +
            //                     "<Eq>" +
            //                        "<FieldRef Name='Submitted'/>" +
            //                            "<Value Type='Text'>Yes</Value>" +
            //                        "</Eq>" +
            //                "</And>" +
            //            "</Where>";

            //            SPListItemCollection collItemsSubmittedCOTF = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressCOTF);

            //            if (collItemsSubmittedCOTF.Count > 0)
            //            {
            //                //Show worksheetsListDivB
            //                worksheetsListDivBCOTF.Visible = true;

            //                //foreach (SPListItem oListItem in collItemsSubmittedCOTF)
            //                //{


            //                //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
            //                //    {
            //                //        liClassIfApprovedCOTF = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //                //        // " + liClassIfApproved + "
            //                //    }

            //                //}
            //            }

            //            //-- end Query --
            //            divCOTF.Visible = true;
            //        }
            //        if (selectedOTAString == "JITC")
            //        {
            //            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals JITC and Submitted equals Yes.
            //            SPQuery oQueryCONOPSApprovalProgressJITC = new SPQuery();
            //            oQueryCONOPSApprovalProgressJITC.Query = "<Where>" +
            //                "<And>" +
            //                    "<Eq>" +
            //                        "<FieldRef Name='OperationalTestAgency'/>" +
            //                            "<Value Type='Choice'>JITC</Value>" +
            //                     "</Eq>" +
            //                     "<Eq>" +
            //                        "<FieldRef Name='Submitted'/>" +
            //                            "<Value Type='Text'>Yes</Value>" +
            //                        "</Eq>" +
            //                "</And>" +
            //            "</Where>";

            //            SPListItemCollection collItemsSubmittedJITC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressJITC);

            //            if (collItemsSubmittedJITC.Count > 0)
            //            {
            //                //Show worksheetsListDivB
            //                worksheetsListDivBJITC.Visible = true;

            //                //foreach (SPListItem oListItem in collItemsSubmittedJITC)
            //                //{


            //                //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
            //                //    {
            //                //        liClassIfApprovedJITC = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //                //        // " + liClassIfApproved + "
            //                //    }

            //                //}
            //            }

            //            //-- end Query --
            //            divJITC.Visible = true;
            //        }
            //        if (selectedOTAString == "MCOTEA")
            //        {
            //            //-- Query CONOPSApprovalProgress where OperationalTestAgency equals MCOTEA and Submitted equals Yes.
            //            SPQuery oQueryCONOPSApprovalProgressMCOTEA = new SPQuery();
            //            oQueryCONOPSApprovalProgressMCOTEA.Query = "<Where>" +
            //                "<And>" +
            //                    "<Eq>" +
            //                        "<FieldRef Name='OperationalTestAgency'/>" +
            //                            "<Value Type='Choice'>MCOTEA</Value>" +
            //                     "</Eq>" +
            //                     "<Eq>" +
            //                        "<FieldRef Name='Submitted'/>" +
            //                            "<Value Type='Text'>Yes</Value>" +
            //                        "</Eq>" +
            //                "</And>" +
            //            "</Where>";

            //            SPListItemCollection collItemsSubmittedMCOTEA = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressMCOTEA);

            //            if (collItemsSubmittedMCOTEA.Count > 0)
            //            {
            //                //Show worksheetsListDivB
            //                worksheetsListDivBMCOTEA.Visible = true;

            //                //foreach (SPListItem oListItem in collItemsSubmittedMCOTEA)
            //                //{


            //                //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
            //                //    {
            //                //        liClassIfApprovedMCOTEA = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //                //        // " + liClassIfApproved + "
            //                //    }

            //                //}
            //            }

            //            //-- end Query --

            //            divMCOTEA.Visible = true;
            //        }

            //        bool fy1ws1 = false; bool fy1ws2 = false; bool fy1ws3 = false; bool fy1ws4 = false;
            //        bool isapproved = false;

            //        foreach (SPListItem oListItem in collItems)
            //        {
            //            traceInfo = "oListItem.ContentType.Name: " + oListItem.ContentType.Name;
            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            //            ////If approved use tinytick.gif for li image by adding class 'approved'
            //            //string liClassIfApprovedAFOTEC = "";
            //            //string liClassIfApprovedATEC = "";
            //            //string liClassIfApprovedCOTF = "";
            //            //string liClassIfApprovedJITC = "";
            //            //string liClassIfApprovedMCOTEA = "";


            //            try
            //            {
                            
            //                    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
            //                    {
            //                        isapproved = true;
            //                    }
            //                    else { isapproved = false; }
                            
                                                    
            //            }
            //            catch (Exception ex)
            //            {
            //                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("isapproved", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            //            }


            //            if (oListItem["FY"].ToString() == fy1)
            //            {
            //                if (oListItem.ContentType.Name == ws1)
            //                {
            //                    fy1ws1 = true;
            //                }
            //                if (oListItem.ContentType.Name == ws2)
            //                {
            //                    fy1ws2 = true;
            //                }
            //                if (oListItem.ContentType.Name == ws3)
            //                {
            //                    fy1ws3 = true;
            //                }
            //                if (oListItem.ContentType.Name == ws4)
            //                {
            //                    fy1ws4 = true;
            //                }
            //            }


            //        }

            //        if (fy1ws1)
            //        {
            //            //Create <li>
            //            traceInfo = "Create <li> fy1ws1: " + fy1ws1;
            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //            string liClassIfApproved = "";
            //            if (isapproved)
            //            {
            //                liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //            }


            //            string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS1.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(selectedOTALongString) + "&otashort=" + SPHttpUtility.HtmlEncode(selectedOTAString) + "&fy=" + fy1 + "&ws=1&submitted=no";
            //            string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
            //            string wslinkText = "FY " + fy1 + " Budget Worksheet #1: Core Personnel Costs";

            //            if (selectedOTAString == "AFOTEC")
            //            {
            //                submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "ATEC")
            //            {
            //                submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "COTF")
            //            {
            //                submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "JITC")
            //            {
            //                submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "MCOTEA")
            //            {
            //                submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }

            //        }
            //        if (fy1ws2)
            //        {
            //            //Create <li>
            //            traceInfo = "Create <li> fy1ws2: " + fy1ws2;
            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            //            string liClassIfApproved = "";
            //            if (isapproved)
            //            {
            //                liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //            }

            //            string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS2.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(selectedOTALongString) + "&otashort=" + SPHttpUtility.HtmlEncode(selectedOTAString) + "&fy=" + fy1 + "&ws=2&submitted=no";
            //            string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
            //            string wslinkText = "FY " + fy1 + " Budget Worksheet #2: Assessment Costs";

            //            if (selectedOTAString == "AFOTEC")
            //            {
            //                submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "ATEC")
            //            {
            //                submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "COTF")
            //            {
            //                submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "JITC")
            //            {
            //                submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "MCOTEA")
            //            {
            //                submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //        }

            //        if (fy1ws3)
            //        {
            //            //Create <li>
            //            traceInfo = "Create <li> fy1ws3: " + fy1ws3;
            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            //            string liClassIfApproved = "";
            //            if (isapproved)
            //            {
            //                liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //            }

            //            string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS3.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(selectedOTALongString) + "&otashort=" + SPHttpUtility.HtmlEncode(selectedOTAString) + "&fy=" + fy1 + "&ws=3&submitted=no";
            //            string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
            //            string wslinkText = "FY " + fy1 + " Budget Worksheet #3: Non-Assessment Travel";

            //            if (selectedOTAString == "AFOTEC")
            //            {
            //                submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "ATEC")
            //            {
            //                submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "COTF")
            //            {
            //                submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "JITC")
            //            {
            //                submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "MCOTEA")
            //            {
            //                submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //        }

            //        if (fy1ws4)
            //        {
            //            //Create <li>
            //            traceInfo = "Create <li> fy1ws4: " + fy1ws4;
            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //            string liClassIfApproved = "";
            //            if (isapproved)
            //            {
            //                liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
            //            }


            //            string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS4.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode(selectedOTALongString) + "&otashort=" + SPHttpUtility.HtmlEncode(selectedOTAString) + "&fy=" + fy1 + "&ws=4&submitted=no";
            //            string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
            //            string wslinkText = "FY " + fy1 + " Budget Worksheet #4: Non-Assessment Support";

            //            if (selectedOTAString == "AFOTEC")
            //            {
            //                submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "ATEC")
            //            {
            //                submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "COTF")
            //            {
            //                submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "JITC")
            //            {
            //                submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //            if (selectedOTAString == "MCOTEA")
            //            {
            //                submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
            //            }
            //        }

            //    }
            //    else
            //    {
            //        if (selectedOTAString == "AFOTEC")
            //        {
            //            divAFOTEC.Visible = false;
            //        }
            //        if (selectedOTAString == "ATEC")
            //        {
            //            divATEC.Visible = false;
            //        }
            //        if (selectedOTAString == "COTF")
            //        {
            //            divCOTF.Visible = false;
            //        }
            //        if (selectedOTAString == "JITC")
            //        {
            //            divJITC.Visible = false;
            //        }
            //        if (selectedOTAString == "MCOTEA")
            //        {
            //            divMCOTEA.Visible = false;
            //        }
            //    }
            //}

            

        }

        private bool statusCheck(string selectedOTAString, string ws, string status)
        {

            bool IsThisStatus = false;



            var traceInfo = "statusCheck";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("statusCheck", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            SPWeb oWeb = SPContext.Current.Web;

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + selectedOTAString + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>" + ws + "</Value></Eq></And><Eq><FieldRef Name='CONOPSApproval'/><Value Type='Choice'>" + status + "</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            if (collListItemsCONOPSApprovalProgress.Count>0)
            { IsThisStatus = true; }

            return IsThisStatus;

            
        }

        protected void CONOPSApprovalSelectStatusDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            submittedULAFOTECLiteral.Text = "";
            submittedULATECLiteral.Text = "";
            submittedULCOTFLiteral.Text = "";
            submittedULJITCLiteral.Text = "";
            submittedULMCOTEALiteral.Text = "";




            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16
            var traceInfo = "CurrentFYforAcceptingCONOPS: " + CurrentFYforAcceptingCONOPS;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            
            string fy1 = CurrentFYforAcceptingCONOPS;
          
            string ws1 = "WS1";
            string ws2 = "WS2";
            string ws3 = "WS3";
            string ws4 = "WS4";

            string dcapx = SPContext.Current.Site.RootWeb.ServerRelativeUrl;

            
            DropDownList selectedStatus = sender as DropDownList;

            if(RadioButton2.Checked)
            {
                FilterControlSelected.Value = selectedStatus.ID;
                FilterControlSelectedIndex.Value = selectedStatus.SelectedIndex.ToString();
            }
            if (RadioButton3.Checked)
            {
                FilterControlSelected.Value = "";
                FilterControlSelectedIndex.Value = "";
            }

            string selectedStatusString = selectedStatus.SelectedValue;

            if (selectedStatusString == "(None)")
            {
                divAFOTEC.Visible = false;
                divATEC.Visible = false;
                divCOTF.Visible = false;
                divJITC.Visible = false;
                divMCOTEA.Visible = false;
            }
            else
            {
                string liClassIfApproved = "";

                if (selectedStatusString == "Deputy Director Approval")
                {
                    
                    liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";

                }




                SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];
               
                SPList oListWSAFOTEC = SPContext.Current.Web.Lists["CONOPSDevWSAFOTEC"];
                SPList oListWSATEC = SPContext.Current.Web.Lists["CONOPSDevWSATEC"];
                SPList oListWSCOTF = SPContext.Current.Web.Lists["CONOPSDevWSCOTF"];
                SPList oListWSJITC = SPContext.Current.Web.Lists["CONOPSDevWSJITC"];
                SPList oListWSMCOTEA = SPContext.Current.Web.Lists["CONOPSDevWSMCOTEA"];

                //Query for items with CONOPSApproval of selectedStatusString

                SPQuery oQuery = new SPQuery(); 
                oQuery.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='CONOPSApproval'/>" +
                                    "<Value Type='Choice'>" +
                                        selectedStatusString +
                                    "</Value>" +
                             "</Eq>" + 
                             "<Eq>"+
                                "<FieldRef Name='FY'/>" + 
                                    "<Value Type='Text'>" +
                                        CurrentFYforAcceptingCONOPS + 
                                    "</Value>" +
                                "</Eq>"+
                        "</And>" +
                    "</Where>";



                SPListItemCollection collItemsAFOTEC = oListWSAFOTEC.GetItems(oQuery);
                SPListItemCollection collItemsATEC = oListWSATEC.GetItems(oQuery);
                SPListItemCollection collItemsCOTF = oListWSCOTF.GetItems(oQuery);
                SPListItemCollection collItemsJITC = oListWSJITC.GetItems(oQuery);
                SPListItemCollection collItemsMCOTEA = oListWSMCOTEA.GetItems(oQuery);

                if (collItemsAFOTEC.Count > 0)
                {
                    //-- Query CONOPSApprovalProgress where OperationalTestAgency equals AFOTEC and Submitted equals Yes.
                    SPQuery oQueryCONOPSApprovalProgressAFOTEC = new SPQuery();
                    oQueryCONOPSApprovalProgressAFOTEC.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>AFOTEC</Value>" +
                             "</Eq>" + 
                             "<Eq>"+
                                "<FieldRef Name='Submitted'/>" + 
                                    "<Value Type='Text'>Yes</Value>" +
                                "</Eq>"+
                        "</And>" +
                    "</Where>";

                    SPListItemCollection collItemsSubmittedAFOTEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressAFOTEC);

                    //If approved use tinytick.gif for li image by adding class 'approved' NEEDS TO BE TIED TO WS OR ELSE ANY SUBMITTED WS WILL MAKE ALL MARKED WITH THE CHECKMARK
                    //string liClassIfApproved = "";

                    if (collItemsSubmittedAFOTEC.Count > 0)
                    {
                        //Show worksheetsListDivB
                        worksheetsListDivBAFOTEC.Visible = true;

                        //foreach (SPListItem oListItem in collItemsSubmittedAFOTEC)
                        //{


                        //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                        //    {
                        //        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                        //        // " + liClassIfApproved + "
                        //    }

                        //}
                    }

                    //-- end Query --





                    bool fy1ws1 = false; bool fy1ws2 = false; bool fy1ws3 = false; bool fy1ws4 = false;


                    divAFOTEC.Visible = true;

                    foreach (SPListItem oListItemAFOTEC in collItemsAFOTEC)
                    {
                        traceInfo = "oListItem.ContentType.Name: " + oListItemAFOTEC.ContentType.Name;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        if (oListItemAFOTEC["FY"].ToString() == fy1)
                        {
                            if (oListItemAFOTEC.ContentType.Name == ws1)
                            {
                                //attempt to confirm status matches with CONOPSApprovalProgress for this ota/ws

                                fy1ws1 = statusCheck("AFOTEC", "WS1", selectedStatusString);
                            }
                            if (oListItemAFOTEC.ContentType.Name == ws2)
                            {
                                fy1ws2 = statusCheck("AFOTEC", "WS2", selectedStatusString); 
                            }
                            if (oListItemAFOTEC.ContentType.Name == ws3)
                            {
                                fy1ws3 = statusCheck("AFOTEC", "WS3", selectedStatusString); 
                            }
                            if (oListItemAFOTEC.ContentType.Name == ws4)
                            {
                                fy1ws4 = statusCheck("AFOTEC", "WS4", selectedStatusString); 
                            }
                        }
                       

                    }

                    if (fy1ws1)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws1: " + fy1ws1;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS1.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Air Force Operational Test and Evaluation Center") + "&otashort=" + SPHttpUtility.HtmlEncode("AFOTEC") + "&fy=" + fy1 + "&ws=1&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #1: Core Personnel Costs";

                        submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                    }
                    if (fy1ws2)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws2: " + fy1ws2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS2.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Air Force Operational Test and Evaluation Center") + "&otashort=" + SPHttpUtility.HtmlEncode("AFOTEC") + "&fy=" + fy1 + "&ws=2&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #2: Assessment Costs";

                        submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws3)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws3: " + fy1ws3;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS3.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Air Force Operational Test and Evaluation Center") + "&otashort=" + SPHttpUtility.HtmlEncode("AFOTEC") + "&fy=" + fy1 + "&ws=3&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #3: Non-Assessment Travel";

                        submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws4)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws4: " + fy1ws4;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS4.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Air Force Operational Test and Evaluation Center") + "&otashort=" + SPHttpUtility.HtmlEncode("AFOTEC") + "&fy=" + fy1 + "&ws=4&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #4: Non-Assessment Support";

                        submittedULAFOTECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                }
                else
                {
                    divAFOTEC.Visible = false; worksheetsListDivBAFOTEC.Visible = false;

                }
                if (collItemsATEC.Count > 0)
                {
                    traceInfo = "Items found collItemsATEC";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    //-- Query CONOPSApprovalProgress where OperationalTestAgency equals ATEC and Submitted equals Yes.
                    SPQuery oQueryCONOPSApprovalProgressATEC = new SPQuery();
                    oQueryCONOPSApprovalProgressATEC.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>ATEC</Value>" +
                             "</Eq>" +
                             "<Eq>" +
                                "<FieldRef Name='Submitted'/>" +
                                    "<Value Type='Text'>Yes</Value>" +
                                "</Eq>" +
                        "</And>" +
                    "</Where>";

                    SPListItemCollection collItemsSubmittedATEC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressATEC);
                    
                    //If approved use tinytick.gif for li image by adding class 'approved'
                    //string liClassIfApproved = "";

                    if (collItemsSubmittedATEC.Count > 0)
                    {
                        traceInfo = "Show worksheetsListDivBATEC";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //Show worksheetsListDivB
                        worksheetsListDivBATEC.Visible = true;

                        //foreach(SPListItem oListItem in collItemsSubmittedATEC)
                        //{

                            
                        //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                        //    {
                        //        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                        //        // " + liClassIfApproved + "
                        //    }

                        //}
                    }

                    //-- end Query --



                    bool fy1ws1 = false; bool fy1ws2 = false; bool fy1ws3 = false; bool fy1ws4 = false;

        
                    divATEC.Visible = true;

                    foreach (SPListItem oListItemATEC in collItemsATEC)
                    {
                        traceInfo = "oListItem.ContentType.Name: " + oListItemATEC.ContentType.Name;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        if (oListItemATEC["FY"].ToString() == fy1)
                        {
                            if (oListItemATEC.ContentType.Name == ws1)
                            {
                                fy1ws1 = statusCheck("ATEC", "WS1", selectedStatusString);
                            }
                            if (oListItemATEC.ContentType.Name == ws2)
                            {
                                fy1ws2 = statusCheck("ATEC", "WS2", selectedStatusString);
                            }
                            if (oListItemATEC.ContentType.Name == ws3)
                            {
                                fy1ws3 = statusCheck("ATEC", "WS3", selectedStatusString);
                            }
                            if (oListItemATEC.ContentType.Name == ws4)
                            {
                                fy1ws4 = statusCheck("ATEC", "WS4", selectedStatusString);
                            }
                        }
                       

                    }

                    if (fy1ws1)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws1: " + fy1ws1;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                      

                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS1.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Army Test and Evaluation Command") + "&otashort=" + SPHttpUtility.HtmlEncode("ATEC") + "&fy=" + fy1 + "&ws=1&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #1: Core Personnel Costs";

                        submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                        
                    }
                    if (fy1ws2)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws2: " + fy1ws2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                      

                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS2.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Army Test and Evaluation Command") + "&otashort=" + SPHttpUtility.HtmlEncode("ATEC") + "&fy=" + fy1 + "&ws=2&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #2: Assessment Costs";

                        submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws3)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws3: " + fy1ws3;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                      

                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS3.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Army Test and Evaluation Command") + "&otashort=" + SPHttpUtility.HtmlEncode("ATEC") + "&fy=" + fy1 + "&ws=3&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #3: Non-Assessment Travel";

                        submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws4)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws4: " + fy1ws4;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                      

                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS4.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Army Test and Evaluation Command") + "&otashort=" + SPHttpUtility.HtmlEncode("ATEC") + "&fy=" + fy1 + "&ws=4&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #4: Non-Assessment Support";

                        submittedULATECLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }



                }
                else
                {
                    divATEC.Visible = false; worksheetsListDivBATEC.Visible = false;
                }
                if (collItemsCOTF.Count > 0)
                {
                    //-- Query CONOPSApprovalProgress where OperationalTestAgency equals COTF and Submitted equals Yes.
                    SPQuery oQueryCONOPSApprovalProgressCOTF = new SPQuery();
                    oQueryCONOPSApprovalProgressCOTF.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>COTF</Value>" +
                             "</Eq>" +
                             "<Eq>" +
                                "<FieldRef Name='Submitted'/>" +
                                    "<Value Type='Text'>Yes</Value>" +
                                "</Eq>" +
                        "</And>" +
                    "</Where>";

                    SPListItemCollection collItemsSubmittedCOTF = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressCOTF);

                    //If approved use tinytick.gif for li image by adding class 'approved'
                    //string liClassIfApproved = "";

                    if (collItemsSubmittedCOTF.Count > 0)
                    {
                        //Show worksheetsListDivB
                        worksheetsListDivBCOTF.Visible = true;

                        //foreach (SPListItem oListItem in collItemsSubmittedCOTF)
                        //{


                        //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                        //    {
                        //        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                        //        // " + liClassIfApproved + "
                        //    }

                        //}
                    }

                    //-- end Query --



                    bool fy1ws1 = false; bool fy1ws2 = false; bool fy1ws3 = false; bool fy1ws4 = false;
                   
        
                    divCOTF.Visible = true;

                    foreach (SPListItem oListItemCOTF in collItemsCOTF)
                    {
                        if (oListItemCOTF["FY"].ToString() == fy1)
                        {
                            if (oListItemCOTF.ContentType.Name == ws1)
                            {
                                fy1ws1 = statusCheck("COTF", "WS1", selectedStatusString);
                            }
                            if (oListItemCOTF.ContentType.Name == ws2)
                            {
                                fy1ws2 = statusCheck("COTF", "WS2", selectedStatusString);
                            }
                            if (oListItemCOTF.ContentType.Name == ws3)
                            {
                                fy1ws3 = statusCheck("COTF", "WS3", selectedStatusString);
                            }
                            if (oListItemCOTF.ContentType.Name == ws4)
                            {
                                fy1ws4 = statusCheck("COTF", "WS4", selectedStatusString);
                            }
                        }
                       
                    }
                    if (fy1ws1)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws1: " + fy1ws1;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS1.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Commander Operational Test and Evaluation Force") + "&otashort=" + SPHttpUtility.HtmlEncode("COTF") + "&fy=" + fy1 + "&ws=1&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #1: Core Personnel Costs";

                        submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                    }
                    if (fy1ws2)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws2: " + fy1ws2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS2.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Commander Operational Test and Evaluation Force") + "&otashort=" + SPHttpUtility.HtmlEncode("COTF") + "&fy=" + fy1 + "&ws=2&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #2: Assessment Costs";

                        submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws3)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws3: " + fy1ws3;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS3.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Commander Operational Test and Evaluation Force") + "&otashort=" + SPHttpUtility.HtmlEncode("COTF") + "&fy=" + fy1 + "&ws=3&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #3: Non-Assessment Travel";

                        submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws4)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws4: " + fy1ws4;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS4.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Commander Operational Test and Evaluation Force") + "&otashort=" + SPHttpUtility.HtmlEncode("COTF") + "&fy=" + fy1 + "&ws=4&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #4: Non-Assessment Support";

                        submittedULCOTFLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }


                }
                else
                {
                    divCOTF.Visible = false; worksheetsListDivBCOTF.Visible = false;
                }
                if (collItemsJITC.Count > 0)
                {
                    //-- Query CONOPSApprovalProgress where OperationalTestAgency equals JITC and Submitted equals Yes.
                    SPQuery oQueryCONOPSApprovalProgressJITC = new SPQuery();
                    oQueryCONOPSApprovalProgressJITC.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>JITC</Value>" +
                             "</Eq>" +
                             "<Eq>" +
                                "<FieldRef Name='Submitted'/>" +
                                    "<Value Type='Text'>Yes</Value>" +
                                "</Eq>" +
                        "</And>" +
                    "</Where>";

                    SPListItemCollection collItemsSubmittedJITC = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressJITC);

                    //If approved use tinytick.gif for li image by adding class 'approved'
                    //string liClassIfApproved = "";

                    if (collItemsSubmittedJITC.Count > 0)
                    {
                        //Show worksheetsListDivB
                        worksheetsListDivBJITC.Visible = true;

                        //foreach (SPListItem oListItem in collItemsSubmittedJITC)
                        //{


                        //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                        //    {
                        //        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                        //        // " + liClassIfApproved + "
                        //    }

                        //}
                    }

                    //-- end Query --

                    bool fy1ws1 = false; bool fy1ws2 = false; bool fy1ws3 = false; bool fy1ws4 = false;

        
                    divJITC.Visible = true;

                    foreach (SPListItem oListItemJITC in collItemsJITC)
                    {
                        if (oListItemJITC["FY"].ToString() == fy1)
                        {
                            if (oListItemJITC.ContentType.Name == ws1)
                            {
                                fy1ws1 = statusCheck("JITC", "WS1", selectedStatusString);
                            }
                            if (oListItemJITC.ContentType.Name == ws2)
                            {
                                fy1ws2 = statusCheck("JITC", "WS2", selectedStatusString);
                            }
                            if (oListItemJITC.ContentType.Name == ws3)
                            {
                                fy1ws3 = statusCheck("JITC", "WS3", selectedStatusString);
                            }
                            if (oListItemJITC.ContentType.Name == ws4)
                            {
                                fy1ws4 = statusCheck("JITC", "WS4", selectedStatusString);
                            }
                        }
                       

                    }

                    if (fy1ws1)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws1: " + fy1ws1;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS1.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Joint Interoperability Test Command") + "&otashort=" + SPHttpUtility.HtmlEncode("JITC") + "&fy=" + fy1 + "&ws=1&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #1: Core Personnel Costs";

                        submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                    }
                    if (fy1ws2)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws2: " + fy1ws2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS2.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Joint Interoperability Test Command") + "&otashort=" + SPHttpUtility.HtmlEncode("JITC") + "&fy=" + fy1 + "&ws=2&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #2: Assessment Costs";

                        submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws3)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws3: " + fy1ws3;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS3.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Joint Interoperability Test Command") + "&otashort=" + SPHttpUtility.HtmlEncode("JITC") + "&fy=" + fy1 + "&ws=3&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #3: Non-Assessment Travel";

                        submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws4)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws4: " + fy1ws4;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS4.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Joint Interoperability Test Command") + "&otashort=" + SPHttpUtility.HtmlEncode("JITC") + "&fy=" + fy1 + "&ws=4&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #4: Non-Assessment Support";

                        submittedULJITCLiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }


                }
                else
                {
                    divJITC.Visible = false; worksheetsListDivBJITC.Visible = false;
                }
                if (collItemsMCOTEA.Count > 0)
                {
                    //-- Query CONOPSApprovalProgress where OperationalTestAgency equals MCOTEA and Submitted equals Yes.
                    SPQuery oQueryCONOPSApprovalProgressMCOTEA = new SPQuery();
                    oQueryCONOPSApprovalProgressMCOTEA.Query = "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>MCOTEA</Value>" +
                             "</Eq>" +
                             "<Eq>" +
                                "<FieldRef Name='Submitted'/>" +
                                    "<Value Type='Text'>Yes</Value>" +
                                "</Eq>" +
                        "</And>" +
                    "</Where>";

                    SPListItemCollection collItemsSubmittedMCOTEA = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressMCOTEA);

                    //If approved use tinytick.gif for li image by adding class 'approved'
                    //string liClassIfApproved = "";

                    if (collItemsSubmittedMCOTEA.Count > 0)
                    {
                        //Show worksheetsListDivB
                        worksheetsListDivBMCOTEA.Visible = true;

                        //foreach (SPListItem oListItem in collItemsSubmittedMCOTEA)
                        //{


                        //    if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval" && (string)oListItem["ForFY"] == "Current" && (string)oListItem["SubmittedFY"] == CurrentFYforAcceptingCONOPS)
                        //    {
                        //        liClassIfApproved = "class=\"approved\" title=\"Has Deputy Director Approval\"";
                        //        // " + liClassIfApproved + "
                        //    }

                        //}
                    }

                    //-- end Query --

                    bool fy1ws1 = false; bool fy1ws2 = false; bool fy1ws3 = false; bool fy1ws4 = false;

        
                    divMCOTEA.Visible = true;

                    foreach (SPListItem oListItemMCOTEA in collItemsMCOTEA)
                    {
                        if (oListItemMCOTEA["FY"].ToString() == fy1)
                        {
                            if (oListItemMCOTEA.ContentType.Name == ws1)
                            {
                                fy1ws1 = statusCheck("MCOTEA", "WS1", selectedStatusString);
                            }
                            if (oListItemMCOTEA.ContentType.Name == ws2)
                            {
                                fy1ws2 = statusCheck("MCOTEA", "WS2", selectedStatusString);
                            }
                            if (oListItemMCOTEA.ContentType.Name == ws3)
                            {
                                fy1ws3 = statusCheck("MCOTEA", "WS3", selectedStatusString);
                            }
                            if (oListItemMCOTEA.ContentType.Name == ws4)
                            {
                                fy1ws4 = statusCheck("MCOTEA", "WS4", selectedStatusString);
                            }
                        }
                       

                    }

                    if (fy1ws1)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws1: " + fy1ws1;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS1.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Marine Corps Operational Test and Evaluation Activity") + "&otashort=" + SPHttpUtility.HtmlEncode("MCOTEA") + "&fy=" + fy1 + "&ws=1&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #1: Core Personnel Costs";

                        submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";


                    }
                    if (fy1ws2)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws2: " + fy1ws2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS2.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Marine Corps Operational Test and Evaluation Activity") + "&otashort=" + SPHttpUtility.HtmlEncode("MCOTEA") + "&fy=" + fy1 + "&ws=2&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #2: Assessment Costs";

                        submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws3)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws3: " + fy1ws3;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS3.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Marine Corps Operational Test and Evaluation Activity") + "&otashort=" + SPHttpUtility.HtmlEncode("MCOTEA") + "&fy=" + fy1 + "&ws=3&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #3: Non-Assessment Travel";

                        submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                    if (fy1ws4)
                    {
                        //Create <li>
                        traceInfo = "Create <li> fy1ws4: " + fy1ws4;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPageEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                        string wslinkhref = dcapx + "/_layouts/DCAPXSolution/CONOPSApproval/WS4.aspx?tab=OTASubmission&ota=" + SPHttpUtility.HtmlEncode("Marine Corps Operational Test and Evaluation Activity") + "&otashort=" + SPHttpUtility.HtmlEncode("MCOTEA") + "&fy=" + fy1 + "&ws=4&submitted=no";
                        string wslink = "javascript:openWorksheet('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy1 + " Budget Worksheet #4: Non-Assessment Support";

                        submittedULMCOTEALiteral.Text += "<li " + liClassIfApproved + "><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";

                    }

                }
                else
                {
                    divMCOTEA.Visible = false; worksheetsListDivBMCOTEA.Visible = false;
                }



            }
        }





    }
}
