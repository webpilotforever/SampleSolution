﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;
using System.Collections.Generic; 

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval 
{
    public partial class WS2 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var traceInfo = "template WS2";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                
                
                enableTabs();


                 
                //----------LinkButtonAdddocument-----

                //string uName = Page.User.Identity.Name;

                //QueryStrings requiring Page object reference
                string qs_submitted = Page.Request.QueryString["submitted"];
                string qs_ota = Page.Request.QueryString["ota"];
                string qs_otashort = Page.Request.QueryString["otashort"];
                string qs_fy = Page.Request.QueryString["fy"];
                string qs_tab = Page.Request.QueryString["tab"];
                string qs_ws = Page.Request.QueryString["ws"];

                string urlFirstPart = Page.Request.RawUrl;
                urlFirstPart = urlFirstPart.Substring(0, urlFirstPart.IndexOf("/_layouts"));

                traceInfo = "urlFirstPart: " + urlFirstPart;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPList oLibb = SPContext.Current.Web.Lists["CONOPSDev" + qs_otashort];
                string oLibbID = oLibb.ID.ToString();

                traceInfo = "oLibbID: " + oLibbID;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                LinkButtonAdddocument.OnClientClick = "javascript:NewItem2(event, \'" + urlFirstPart + "/_layouts/Upload.aspx?List={" + oLibbID + "}&tab=" + qs_tab + "&fy=" + qs_fy + "&otashort=" + qs_otashort + "&ws=" + qs_ws + "&module=CONOPSApproval&RootFolder=\');javascript:return false;";

                //--end LinkButtonAdddocument--------------



                LabelOTA.Text = Page.Request.QueryString["ota"];
                LabelWSFY.Text = Page.Request.QueryString["fy"];

                //Table rows-----------------------------------------------------------------------------------

                TableRow headerTitleRow = new TableRow();
                TableRow headerRow = new TableRow();
                TableRow headerDescRow = new TableRow();
                TableRow venueRow = new TableRow();
                TableRow venueSubTotalRow = new TableRow();
                TableRow totalRow = new TableRow();
                TableRow attachmentsRow = new TableRow();
                TableRow attachmentsValRow = new TableRow(); 
                TableRow attachDocRow = new TableRow();

                headerTitleRow.Style.Add("text-align", "center");
                headerRow.CssClass = "CONOPSDevWSColHeaders";
                headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
                headerDescRow.Style.Add("text-align", "center");
                headerDescRow.ID = "headerDescRow";
                venueRow.Style.Add("text-align", "center");
                venueRow.CssClass = "WSGroupStartRow";
                venueSubTotalRow.Style.Add("text-align", "center");
                totalRow.Style.Add("text-align", "center");
                totalRow.ToolTip = "Total";
                totalRow.ID = "totalRow";
                attachmentsRow.Style.Add("text-align", "center");
                attachmentsValRow.Style.Add("text-align", "center");
                attachmentsValRow.ID = "attachmentsValRow";

                //Table cells------------------------------------------------------------------------------------------

                TableCell headerTitleCell = new TableCell();
                headerTitleCell.ColumnSpan = 8;

                headerTitleCell.Controls.Add(headerTitleCellDiv);

                headerTitleRow.Cells.Add(headerTitleCell);

                CONOPSDevWSTable.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTable

                TableCell wsColCell1 = new TableCell();
                TableCell wsColCell2 = new TableCell();
                TableCell wsColCell3 = new TableCell();
                TableCell wsColCell4 = new TableCell();
                TableCell wsColCell5 = new TableCell();
                TableCell wsColCell6 = new TableCell();
                TableCell wsColCell7 = new TableCell();
                TableCell wsColCell8 = new TableCell();

                TableCell wsColCell9 = new TableCell();
                TableCell wsColCell10 = new TableCell();


                wsColCell9.CssClass = "CONOPSApprovalColCell";
                wsColCell10.CssClass = "CONOPSApprovalColCell";
                wsColCell9.Style.Add("width", "163px");
                wsColCell10.Style.Add("width", "163px");
                wsColCell9.Style.Add("font-weight", "bold");
                wsColCell10.Style.Add("font-weight", "bold");

                wsColCell1.CssClass = "CONOPSDevWSColCell";
                wsColCell2.CssClass = "CONOPSDevWSColCell";
                wsColCell3.CssClass = "CONOPSDevWSColCell";
                wsColCell4.CssClass = "CONOPSDevWSColCell";
                wsColCell5.CssClass = "CONOPSDevWSColCell";
                wsColCell6.CssClass = "CONOPSDevWSColCell";
                wsColCell7.CssClass = "CONOPSDevWSColCell";
                wsColCell8.CssClass = "CONOPSDevWSColCell";

                wsColCell1.Style.Add("width", "200px");
                wsColCell2.Style.Add("width", "155px");
                wsColCell3.Style.Add("width", "155px");
                wsColCell4.Style.Add("width", "155px");
                wsColCell5.Style.Add("width", "155px");
                wsColCell6.Style.Add("width", "155px");
                wsColCell7.Style.Add("width", "155px");
                wsColCell8.Style.Add("width", "155px");

                wsColCell1.Style.Add("font-weight", "bold");
                wsColCell2.Style.Add("font-weight", "bold");
                wsColCell3.Style.Add("font-weight", "bold");
                wsColCell4.Style.Add("font-weight", "bold");
                wsColCell5.Style.Add("font-weight", "bold");
                wsColCell6.Style.Add("font-weight", "bold");
                wsColCell7.Style.Add("font-weight", "bold");
                wsColCell8.Style.Add("font-weight", "bold");

                wsColCell1.Text = "Venue​";
                wsColCell2.Text = "Activity/Event​​";
                wsColCell3.Text = "Dates​";
                wsColCell4.Text = "People​";
                wsColCell5.Text = "Location";
                wsColCell6.Text = "Estimated Travel Costs​​";
                wsColCell7.Text = "Estimated Labor Overtime Costs";
                wsColCell8.Text = "Funding​";

                headerRow.Cells.Add(wsColCell1);
                headerRow.Cells.Add(wsColCell2);
                headerRow.Cells.Add(wsColCell3);
                headerRow.Cells.Add(wsColCell4);
                headerRow.Cells.Add(wsColCell5);
                headerRow.Cells.Add(wsColCell6);
                headerRow.Cells.Add(wsColCell7);
                headerRow.Cells.Add(wsColCell8);

                CONOPSDevWSTable.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTable

                TableCell headerDescRowCell1 = new TableCell();
                TableCell headerDescRowCell2 = new TableCell();
                TableCell headerDescRowCell3 = new TableCell();
                TableCell headerDescRowCell4 = new TableCell();
                TableCell headerDescRowCell5 = new TableCell();
                TableCell headerDescRowCell6 = new TableCell();
                TableCell headerDescRowCell7 = new TableCell();
                TableCell headerDescRowCell8 = new TableCell();

                TableCell headerDescRowCell9 = new TableCell();
                TableCell headerDescRowCell10 = new TableCell();

                headerDescRowCell1.Style.Add("font-style", "italic");
                headerDescRowCell2.Style.Add("font-style", "italic");
                headerDescRowCell3.Style.Add("font-style", "italic");
                headerDescRowCell4.Style.Add("font-style", "italic");
                headerDescRowCell5.Style.Add("font-style", "italic");
                headerDescRowCell6.Style.Add("font-style", "italic");
                headerDescRowCell7.Style.Add("font-style", "italic");
                headerDescRowCell8.Style.Add("font-style", "italic");

                headerDescRowCell9.Style.Add("font-style", "italic");
                headerDescRowCell10.Style.Add("font-style", "italic");

                headerDescRowCell1.Text = "List the proposed assessment value​";
                headerDescRowCell2.Text = "List every activity/event associated with the proposed assessment​";
                headerDescRowCell3.Text = "List the dates for each activity/event​";
                headerDescRowCell4.Text = "List the number of people attending each activity/event​";
                headerDescRowCell5.Text = "Identify the location for each activity/event (List location by military base, not by the city)";
                headerDescRowCell6.Text = "Estimated travel cost for each activity/event​";
                headerDescRowCell7.Text = "Estimated labor overtime cost for each activity/event";
                headerDescRowCell8.Text = "Total proposed funding level for each activity/event";

                headerDescRowCell9.Text = "Reviewer approval";
                headerDescRowCell10.Text = "Reviewer comments";

                headerDescRow.Cells.Add(headerDescRowCell1);
                headerDescRow.Cells.Add(headerDescRowCell2);
                headerDescRow.Cells.Add(headerDescRowCell3);
                headerDescRow.Cells.Add(headerDescRowCell4);
                headerDescRow.Cells.Add(headerDescRowCell5);
                headerDescRow.Cells.Add(headerDescRowCell6);
                headerDescRow.Cells.Add(headerDescRowCell7);
                headerDescRow.Cells.Add(headerDescRowCell8);

                CONOPSDevWSTable.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTable

                TableCell venueValCell1 = new TableCell();
                TableCell venueValCell2 = new TableCell();
                TableCell venueValCell3 = new TableCell();
                TableCell venueValCell4 = new TableCell();
                TableCell venueValCell5 = new TableCell();
                TableCell venueValCell6 = new TableCell();
                TableCell venueValCell7 = new TableCell();
                TableCell venueValCell8 = new TableCell();

                TableCell venueValCell9 = new TableCell();
                TableCell venueValCell10 = new TableCell();

                venueValCell1.RowSpan = 2;
                venueValCell1.Style.Add("vertical-align", "middle");
                venueValCell1.Style.Add("text-align", "center");
                venueValCell2.Style.Add("text-align", "center");
                venueValCell3.Style.Add("text-align", "center");
                venueValCell4.Style.Add("text-align", "center");
                venueValCell5.Style.Add("text-align", "center");
                venueValCell6.Style.Add("text-align", "center");
                venueValCell7.Style.Add("text-align", "center");
                venueValCell8.Style.Add("text-align", "center");


                venueValCell1.Text = "Text";
                venueValCell2.Text = "Text";
                venueValCell3.Text = "Text";
                venueValCell4.Text = "00";
                venueValCell5.Text = "Text";
                venueValCell6.Text = "0";
                venueValCell7.Text = "0";
                venueValCell8.Text = "0000";


                venueRow.Cells.Add(venueValCell1);
                venueRow.Cells.Add(venueValCell2);
                venueRow.Cells.Add(venueValCell3);
                venueRow.Cells.Add(venueValCell4);
                venueRow.Cells.Add(venueValCell5);
                venueRow.Cells.Add(venueValCell6);
                venueRow.Cells.Add(venueValCell7);
                venueRow.Cells.Add(venueValCell8);

                CONOPSDevWSTable.Rows.Add(venueRow); //-----------------venueRow added to CONOPSDevWSTable

                TableCell venueSubTotalCell1 = new TableCell();
                TableCell venueSubTotalCell2 = new TableCell();
                TableCell venueSubTotalCell3 = new TableCell();

                TableCell venueSubTotalCell4 = new TableCell();
                TableCell venueSubTotalCell5 = new TableCell();

                venueSubTotalCell1.ColumnSpan = 5;
                venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");
                venueSubTotalCell1.Style.Add("text-align", "left");
                
                venueSubTotalCell2.Style.Add("text-align", "right");
                venueSubTotalCell2.Style.Add("font-weight", "bold");
                venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                venueSubTotalCell2.Text = "Sub-Total:​";

                venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                venueSubTotalCell3.Text = "0000";

                venueSubTotalRow.Cells.Add(venueSubTotalCell1);
                venueSubTotalRow.Cells.Add(venueSubTotalCell2);
                venueSubTotalRow.Cells.Add(venueSubTotalCell3);

                CONOPSDevWSTable.Rows.Add(venueSubTotalRow); //-----------------venueSubTotalRow added to CONOPSDevWSTable

                TableCell totalRowCell1 = new TableCell();
                TableCell totalRowCell2 = new TableCell();

                TableCell totalRowCell3 = new TableCell();
                TableCell totalRowCell4 = new TableCell();

                totalRowCell1.ColumnSpan = 7;
                totalRowCell1.Style.Add("text-align", "right");
                totalRowCell1.Style.Add("font-weight", "bold");
                totalRowCell1.Style.Add("background-color", "#d0ffbc");
                //totalRowCell1.Text = "Total:";
                //------------------------------------Add Venue button --------
                Button AddVenueBtn = new Button();
                AddVenueBtn.Text = "Add Venue";
                AddVenueBtn.Style.Add("float", "left");
                AddVenueBtn.Style.Add("clear", "right");
                AddVenueBtn.CssClass = "CONOPSApprovalAddVenueButton";
                AddVenueBtn.ToolTip = "Add Venue";
                AddVenueBtn.UseSubmitBehavior = false;
                AddVenueBtn.OnClientClick = "return false";
                totalRowCell1.Controls.Add(AddVenueBtn);



                Label LabelTotal = new Label();
                LabelTotal.Text = "Total:";
                totalRowCell1.Controls.Add(LabelTotal);
                //-----------------------------------------

                totalRowCell2.Text = "0000";
                totalRowCell2.Style.Add("background-color", "#d0ffbc");

                totalRow.Cells.Add(totalRowCell1);
                totalRow.Cells.Add(totalRowCell2);

                CONOPSDevWSTable.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTable

                TableCell attachmentsRowCell = new TableCell();

                TableCell attachmentsRowCell2 = new TableCell();
                TableCell attachmentsRowCell3 = new TableCell();

                attachmentsRowCell.ColumnSpan = 8;
                attachmentsRowCell.Style.Add("font-weight", "bold");
                attachmentsRowCell.Text = "Attachments";

                attachmentsRow.Cells.Add(attachmentsRowCell);

                CONOPSDevWSTable.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTable

                TableCell attachmentsValRowCell = new TableCell();

                TableCell attachmentsValRowCell2 = new TableCell();
                TableCell attachmentsValRowCell3 = new TableCell();

                attachmentsValRowCell.ColumnSpan = 8;
                attachmentsValRowCell.Text = "attachment1.text";
                attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

                attachmentsValRow.Cells.Add(attachmentsValRowCell);

                CONOPSDevWSTable.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTable

                TableCell attachDocRowCell = new TableCell();

                TableCell attachDocRowCell2 = new TableCell();
                TableCell attachDocRowCell3 = new TableCell();

                attachDocRowCell.ColumnSpan = 8;
                attachDocRowCell.Controls.Add(LiteralAdddocument);
                attachDocRowCell.Controls.Add(LinkButtonAdddocument);
                attachDocRowCell.Style.Add("padding-left", "10px");


                attachDocRow.Cells.Add(attachDocRowCell);


                CONOPSDevWSTable.Rows.Add(attachDocRow); //-----------------attachDocRow added to CONOPSDevWSTable

                //================= END OF TABLE TEMPLATE ====================
                if (Page.Request.QueryString["tab"] == "OTASubmission")
                {
                    //venueSubTotalCell1.Controls.Remove(AddActivityEventBtn);
                    totalRowCell1.Controls.Remove(AddVenueBtn);
                    CONOPSDevWSTable.Controls.Remove(attachDocRow);
                    makeViewOrFormForOTASubmission(attachmentsRow, attachmentsValRow, totalRowCell2, venueRow, venueSubTotalRow, totalRowCell3, totalRowCell4);
                }
                if (Page.Request.QueryString["tab"] == "AOReview")
                {
                    headerTitleCell.ColumnSpan = 10;

                

                    wsColCell9.Text = "AO Approval​";
                    wsColCell10.Text = "AO Comments​";

                    headerRow.Cells.Add(wsColCell9);
                    headerRow.Cells.Add(wsColCell10);

                    headerDescRow.Cells.Add(headerDescRowCell9);
                    headerDescRow.Cells.Add(headerDescRowCell10);

                    totalRow.Cells.Add(totalRowCell3);
                    totalRow.Cells.Add(totalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);


                    makeViewOrFormForAOReview(attachmentsRow, attachmentsValRow, totalRowCell1, AddVenueBtn, totalRowCell2, venueRow, venueSubTotalRow, totalRowCell3, totalRowCell4, attachDocRow);
                }
                if (Page.Request.QueryString["tab"] == "PMReview")
                {
                    headerTitleCell.ColumnSpan = 10;


                    wsColCell9.Text = "PM Approval​";
                    wsColCell10.Text = "PM Comments​";

                    headerRow.Cells.Add(wsColCell9);
                    headerRow.Cells.Add(wsColCell10);

                    headerDescRow.Cells.Add(headerDescRowCell9);
                    headerDescRow.Cells.Add(headerDescRowCell10);

                    totalRow.Cells.Add(totalRowCell3);
                    totalRow.Cells.Add(totalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);

                    makeViewOrFormForPMReview(attachmentsRow, attachmentsValRow, totalRowCell1, AddVenueBtn, totalRowCell2, venueRow, venueSubTotalRow, totalRowCell3, totalRowCell4, attachDocRow);
                }
                if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
                { 
                    headerTitleCell.ColumnSpan = 10;

                  

                    wsColCell9.Text = "DD Approval​";
                    wsColCell10.Text = "DD Comments​";

                    headerRow.Cells.Add(wsColCell9);
                    headerRow.Cells.Add(wsColCell10);

                    headerDescRow.Cells.Add(headerDescRowCell9);
                    headerDescRow.Cells.Add(headerDescRowCell10);

                    totalRow.Cells.Add(totalRowCell3);
                    totalRow.Cells.Add(totalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);

                    makeViewOrFormForDeputyDirectorReviewandApproval(attachmentsRow, attachmentsValRow, totalRowCell1, AddVenueBtn, totalRowCell2, venueRow, venueSubTotalRow, totalRowCell3, totalRowCell4, attachDocRow);
                }
            }
            if (Page.IsPostBack)
            {
                string rawUrl = "1";
                if (Page.Request.RawUrl.ToString().Length > 0)
                {
                    rawUrl = Page.Request.RawUrl.ToString();
                }

                var traceInfo = "IsPostBack is true: " + Page.IsPostBack + " So closeDialog. url is: " + Page.Request.RawUrl.ToString();
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPostback", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose('OK', '" + rawUrl + "');</script>");

               
            }
        }


        private void makeViewOrFormForDeputyDirectorReviewandApproval(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell1, Button AddVenueBtn, TableCell totalRowCell2, TableRow venueRow, TableRow venueSubTotalRow, TableCell totalRowCell3, TableCell totalRowCell4, TableRow attachDocRow)
        {
            var traceInfo = "makeViewOrFormForDeputyDirectorReviewandApproval WS2";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_submitted = Page.Request.QueryString["submitted"];
            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_tab = Page.Request.QueryString["tab"];

            traceInfo = "qs_submitted: " + qs_submitted + " qs_otashort: " + qs_otashort + " qs_ws: " + qs_ws + " qs_fy: " + qs_fy + " qs_tab: " + qs_tab;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("makeViewOrFormForDeputyDirectorReviewandApproval", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPWeb oWeb = SPContext.Current.Web;
            SPList oListdd = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);

           
            SPQuery oQuery1 = new SPQuery();
            oQuery1.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                        "<And>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"OTA\"/>" +
                                            "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                        "</Eq>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"FY\"/>" +
                                            "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"CONOPSApproval\"/>" +
                                        "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Eq>" +
                                "<FieldRef Name=\"ContentType\"/>" +
                                "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                            "</Eq>" +
                        "</And>" +
                    "</Where>";

            SPListItemCollection collListItems1 = oListdd.GetItems(oQuery1);


            if (collListItems1.Count > 0)
            {                
                //display as view with no form controls
                CONOPSApprovalSaveButton.Visible = false;
                CheckBox1.Visible = false;
                CONOPSApprovalSaveButton1.Visible = false;
                CheckBox2.Visible = false;
                SaveDiv1.Visible = false;
                SaveDiv2.Visible = false;
                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int venueSubTotalRowIndex = 5;


                int attachmentIndex = 7;


                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalDRReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalDRComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }

                                attachmentsValRwCell2.Text = attachmentsValRwCell2Text;
                                attachmentsValRwCell3.Text = attachmentsValRwCell3Text;

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }





                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();

                oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +

                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +

                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";



                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //oQuery to set vars.
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                string totalAsText = "Total";

                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();

                    //Only one Total
                    string id = oListItem.ID.ToString();
                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = oListItem[TotalGUID].ToString();
                            totalRowCell1.Controls.Remove(AddVenueBtn);

                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                            //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", bdrcolor);
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}




                            if (totalAsText == title)
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents13", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                totalRowCell3.Text = totalRowCell3Text;
                                totalRowCell4.Text = totalRowCell4Text;
                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }










                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }

                //end Total------------

                //VenueSubTotal-------------this will get all Venue sections---------
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();

                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string id = oListItem.ID.ToString();

                    TableRow rw = new TableRow();
                     
                    if (oListItem.Title == "VenueSubTotal")
                    {
                        TableCell venueSubTotalCell1 = new TableCell();
                        TableCell venueSubTotalCell2 = new TableCell();
                        TableCell venueSubTotalCell3 = new TableCell();

                        TableCell venueSubTotalRwCell4 = new TableCell();
                        TableCell venueSubTotalRwCell5 = new TableCell();

                        //VenueCell.Style.Add("vertical-align", "middle");
                        //VenueCell.Style.Add("text-align", "center");

                        venueSubTotalCell1.ColumnSpan = 5;
                        venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");

                        venueSubTotalCell2.Style.Add("text-align", "right");
                        venueSubTotalCell2.Style.Add("font-weight", "bold");
                        venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell2.Text = "Sub-Total:​";

                        venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell3.Style.Add("text-align", "center");

                        //string Venue = "";
                        //try { Venue += oListItem["Venue"].ToString(); }
                        //catch { }
                        string VenueSubTotal = "";
                        try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                        catch { }

                        //VenueCell.Text = Venue;
                        venueSubTotalCell3.Text = VenueSubTotal;


                        //rw.Cells.Add(VenueCell);

                        rw.Cells.Add(venueSubTotalCell1);
                        rw.Cells.Add(venueSubTotalCell2);
                        rw.Cells.Add(venueSubTotalCell3);

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                        //        string bdrcolor = getBdrcolor("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                        //        venueSubTotalCell3.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                        //        venueSubTotalCell3.Style.Add("border-bottom", "solid");
                        //        venueSubTotalCell3.Style.Add("border-top", "solid");
                        //        venueSubTotalCell3.Style.Add("border-left", "solid");
                        //        venueSubTotalCell3.Style.Add("border-right", "solid");
                        //        venueSubTotalCell3.Style.Add("border-color", bdrcolor);
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}

                        //Approval

                        string venueSubTotalRwCell4Text = "";
                        string venueSubTotalRwCell5Text = "";
                        try
                        {
                            venueSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                            venueSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents14", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        venueSubTotalRwCell4.CssClass = "CONOPSApprovalCell";
                        venueSubTotalRwCell5.CssClass = "CONOPSApprovalCell";
                        venueSubTotalRwCell4.Text = venueSubTotalRwCell4Text;
                        venueSubTotalRwCell5.Text = venueSubTotalRwCell5Text;
                        //---------------

                        rw.Cells.Add(venueSubTotalRwCell4);
                        rw.Cells.Add(venueSubTotalRwCell5);

                        rw.ID = "rowId" + id + "VenueSubTotal";

                        rw.ToolTip = oListItem["Venue"].ToString();

                        CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                    }

                }

                traceInfo = "endVenueSubTotal";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("endVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //end VenueSubTotal-----------



                //iterate through VenueSubTotals-----
                foreach (SPListItem oListItem in collListItems)
                {
                    traceInfo = "oListItem.Title: " + oListItem.Title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("iterVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        string Venue = oListItem["Venue"].ToString();
                        int VenueRowIndexForThisCounter = 0;
                        int VenueRowIndexForThis = 0;

                        traceInfo = "VenueTableRows next";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRows", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            foreach (TableRow VenueSubTotalRow in rows)
                            {
                                try
                                {
                                    if (VenueSubTotalRow.ID.Contains("VenueSubTotal"))
                                    {
                                        try
                                        {
                                            if (VenueSubTotalRow.ToolTip == Venue)
                                            {
                                                VenueRowIndexForThis = VenueRowIndexForThisCounter;
                                                //break;
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ToolTipVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IDVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                VenueRowIndexForThisCounter = VenueRowIndexForThisCounter + 1;
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        traceInfo = "VenueRowIndexForThis " + VenueRowIndexForThis;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThisq", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPQuery VenueItemQuery = new SPQuery();
                        VenueItemQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Neq>" +
                                    "<FieldRef Name=\"Title\"/>" +
                                    "<Value Type=\"Text\">VenueSubTotal</Value>" +
                                "</Neq>" +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Venue\"/>" +
                                    "<Value Type=\"Text\">" + Venue + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                        SPListItemCollection collListItemsVenueItems = oList.GetItems(VenueItemQuery);

                        traceInfo = "collListItemsVenueItems.Count: " + collListItemsVenueItems.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CountcollListItemsVenueItems", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        foreach (SPListItem oListItemVenueItem in collListItemsVenueItems)
                        {
                            //This will get the venue items as a group and render them as rows at the venue row index
                            //traceInfo = "oListItemVenueItem Venue" + oListItemVenueItem["Venue"] + " oListItemVenueItem.Title: " + oListItemVenueItem.Title;
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oListItemVenueItemVenueItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow rw = new TableRow();

                            string iid = oListItemVenueItem.ID.ToString();

                            TableCell VenueCell = new TableCell();
                            TableCell TitleCell = new TableCell();
                            TableCell DatesCell = new TableCell();
                            TableCell PeopleCell = new TableCell();
                            TableCell EventLocationCell = new TableCell();
                            TableCell EstTravelCell = new TableCell();
                            TableCell EstLaborOvertimeCell = new TableCell();
                            TableCell FundingCell = new TableCell();

                            TableCell ApprovalCell = new TableCell();
                            TableCell CommentsCell = new TableCell();

                            VenueCell.Style.Add("vertical-align", "middle");
                            VenueCell.Style.Add("text-align", "center");
                            TitleCell.Style.Add("text-align", "center");
                            DatesCell.Style.Add("text-align", "center");
                            PeopleCell.Style.Add("text-align", "center");
                            EventLocationCell.Style.Add("text-align", "center");
                            EstTravelCell.Style.Add("text-align", "center");
                            EstLaborOvertimeCell.Style.Add("text-align", "center");
                            FundingCell.Style.Add("text-align", "center");

                            //string Venue = "";
                            string Title = "";
                            string Dates = "";
                            string People = "";
                            string EventLocation = "";
                            string EstTravel = "";
                            string EstLaborOvertime = "";
                            string Funding = "";


                            //try { Venue += oListItemVenueItem["Venue"].ToString(); }
                            //catch { }
                            Title += oListItemVenueItem.Title;
                            try { Dates += oListItemVenueItem["Dates"].ToString(); }
                            catch { }
                            try { People += oListItemVenueItem["People"].ToString(); }
                            catch { }
                            try { EventLocation += oListItemVenueItem["EventLocation"].ToString(); }
                            catch { }
                            try { EstTravel += oListItemVenueItem["EstTravel"].ToString(); }
                            catch { }
                            try { EstLaborOvertime += oListItemVenueItem["EstLaborOvertime"].ToString(); }
                            catch { }
                            try { Funding += oListItemVenueItem["Funding"].ToString(); }
                            catch { }
                            VenueCell.Text = Venue;
                            TitleCell.Text = Title;
                            DatesCell.Text = Dates;
                            PeopleCell.Text = People;
                            EventLocationCell.Text = EventLocation;
                            EstTravelCell.Text = EstTravel;
                            EstLaborOvertimeCell.Text = EstLaborOvertime;
                            FundingCell.Text = Funding;

                            rw.Cells.Add(VenueCell);
                            rw.Cells.Add(TitleCell);
                            rw.Cells.Add(DatesCell);
                            rw.Cells.Add(PeopleCell);
                            rw.Cells.Add(EventLocationCell);
                            rw.Cells.Add(EstTravelCell);
                            rw.Cells.Add(EstLaborOvertimeCell);
                            rw.Cells.Add(FundingCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Venue", Venue, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItemVenueItem["OTASubmissionID"] != null) { srcID = oListItemVenueItem["OTASubmissionID"].ToString(); }

                                string srcIDAO = "0";
                                if (oListItemVenueItem["AOReviewID"] != null) { srcIDAO = oListItemVenueItem["AOReviewID"].ToString(); }

                                if (IsDiff("Venue", Venue, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Venue", Venue, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    VenueCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    VenueCell.Style.Add("border-bottom", "solid");
                                    VenueCell.Style.Add("border-top", "solid");
                                    VenueCell.Style.Add("border-left", "solid");
                                    VenueCell.Style.Add("border-right", "solid");
                                    VenueCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Title", Title, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Title", Title, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    TitleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    TitleCell.Style.Add("border-bottom", "solid");
                                    TitleCell.Style.Add("border-top", "solid");
                                    TitleCell.Style.Add("border-left", "solid");
                                    TitleCell.Style.Add("border-right", "solid");
                                    TitleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    DatesCell.Style.Add("border-bottom", "solid");
                                    DatesCell.Style.Add("border-top", "solid");
                                    DatesCell.Style.Add("border-left", "solid");
                                    DatesCell.Style.Add("border-right", "solid");
                                    DatesCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    PeopleCell.Style.Add("border-bottom", "solid");
                                    PeopleCell.Style.Add("border-top", "solid");
                                    PeopleCell.Style.Add("border-left", "solid");
                                    PeopleCell.Style.Add("border-right", "solid");
                                    PeopleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstTravel", EstTravel, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstTravel", EstTravel, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstTravelCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstTravelCell.Style.Add("border-bottom", "solid");
                                    EstTravelCell.Style.Add("border-top", "solid");
                                    EstTravelCell.Style.Add("border-left", "solid");
                                    EstTravelCell.Style.Add("border-right", "solid");
                                    EstTravelCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EventLocation", EventLocation, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EventLocation", EventLocation, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EventLocationCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EventLocationCell.Style.Add("border-bottom", "solid");
                                    EventLocationCell.Style.Add("border-top", "solid");
                                    EventLocationCell.Style.Add("border-left", "solid");
                                    EventLocationCell.Style.Add("border-right", "solid");
                                    EventLocationCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstLaborOvertimeCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstLaborOvertimeCell.Style.Add("border-bottom", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-top", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-left", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-right", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-color", bdrcolor);
                                }
                                //if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString()))
                                //{
                                //    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                //    string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, oListItemVenueItem["OTASubmissionID"].ToString(), oListItemVenueItem["AOReviewID"].ToString(), pmid);
                                //    FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                //    FundingCell.Style.Add("border-bottom", "solid");
                                //    FundingCell.Style.Add("border-top", "solid");
                                //    FundingCell.Style.Add("border-left", "solid");
                                //    FundingCell.Style.Add("border-right", "solid");
                                //    FundingCell.Style.Add("border-color", bdrcolor);
                                //}
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string ApprovalCellText = "";
                            string CommentsCellText = "";
                            try
                            {
                                ApprovalCellText = "" + oListItemVenueItem["CONOPSApprovalDRReview"].ToString();
                                CommentsCellText = "" + oListItemVenueItem["CONOPSApprovalDRComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents15", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            ApprovalCell.CssClass = "CONOPSApprovalCell";
                            CommentsCell.CssClass = "CONOPSApprovalCell";
                            ApprovalCell.Text = ApprovalCellText;
                            CommentsCell.Text = CommentsCellText;
                            //---------------


                            rw.Cells.Add(ApprovalCell);
                            rw.Cells.Add(CommentsCell);



                            rw.ToolTip = "Item";
                            //string dds1 = oListItemVenueItem["DateDraftSaved"].ToString();


                            //if (oListItemVenueItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            //{

                            //    rw.ToolTip = "NewEvent_" + Venue;


                            //}

                            traceInfo = "Adding row at VenueRowIndexForThis: " + VenueRowIndexForThis;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThis", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            CONOPSDevWSTable.Rows.AddAt(VenueRowIndexForThis, rw);
                        }

                    }
                }
                //end iterate through VenueSubTotals----



                try
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                    CONOPSDevWSTable.Controls.Remove(attachDocRow);
                    CONOPSDevWSTable.Controls.Remove(venueRow);
                    CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                int itemCount = 0;
                TableRow itemRowToUpdate = null;
                int rspan = 2;
                try
                {
                    foreach (TableRow row in rows)
                    {

                        traceInfo = "row.ToolTip: " + row.ToolTip + " itemCount: " + itemCount;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("itemRowToUpdate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            if (row.ToolTip == "Item")
                            {

                                if (itemRowToUpdate == null && itemCount < 1)
                                {

                                    itemRowToUpdate = row;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";
                                }
                                if (itemRowToUpdate != null && itemCount > 0)
                                {
                                    rspan = rspan + 1;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";

                                    row.Cells.RemoveAt(0);
                                }


                                itemCount = itemCount + 1;

                            }
                            else
                            {
                                itemRowToUpdate = null;
                                itemCount = 0;
                                rspan = 2;
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpansItems", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpans", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }


            }
            else
            {
                //HasPMPreapprovalItems is false so query where Submitted is not Yes and display form controls

                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int venueSubTotalRowIndex = 5;


                int attachmentIndex = 7;


                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalDRReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalDRComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem attachmentsValRwCell2ListItem1 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem2 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem3 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem4 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem5 = new ListItem();

                                attachmentsValRwCell2ListItem1.Value = "Pending";
                                attachmentsValRwCell2ListItem1.Text = "Pending";
                                attachmentsValRwCell2ListItem1.Selected = true;

                                attachmentsValRwCell2ListItem2.Value = "Approved";
                                attachmentsValRwCell2ListItem2.Text = "Approved";

                                attachmentsValRwCell2ListItem3.Value = "Approved With Comments";
                                attachmentsValRwCell2ListItem3.Text = "Approved With Comments";

                                attachmentsValRwCell2ListItem4.Value = "Approved With Revisions";
                                attachmentsValRwCell2ListItem4.Text = "Approved With Revisions";

                                attachmentsValRwCell2ListItem5.Value = "Not Approved";
                                attachmentsValRwCell2ListItem5.Text = "Not Approved";


                                DropDownList attachmentsValRwCell2DropDownList = new DropDownList();
                                attachmentsValRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                                attachmentsValRwCell2DropDownList.ID = "attId" + id + "CONOPSApprovalDRReview";

                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem1);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem2);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem3);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem4);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem5);


                                TextBox attachmentsValRwCell3TextBox = new TextBox();
                                attachmentsValRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                                attachmentsValRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";

                                attachmentsValRwCell2DropDownList.SelectedValue = attachmentsValRwCell2Text;
                                attachmentsValRwCell3TextBox.Text = attachmentsValRwCell3Text;
                                attachmentsValRwCell3TextBox.ID = "attId" + id + "CONOPSApprovalDRComments";

                                attachmentsValRwCell2.Controls.Add(attachmentsValRwCell2DropDownList);
                                attachmentsValRwCell3.Controls.Add(attachmentsValRwCell3TextBox);

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }





                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();

                oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                    //"<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Neq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Neq>" +
                                    "</And>" +

                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";


                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //oQuery to set vars.
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                string totalAsText = "Total";

                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();

                    //Only one Total
                    string id = oListItem.ID.ToString();
                    if (totalRowCell2.Text == "0000")
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = "";

                            TextBox totalRowCell2TextBox = new TextBox();
                            totalRowCell2TextBox.Width = 80;
                            totalRowCell2TextBox.Text = oListItem[TotalGUID].ToString();
                            totalRowCell2TextBox.ID = "rowId" + id + "Total";
                            totalRowCell2.Controls.Add(totalRowCell2TextBox);


                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                            //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", bdrcolor);
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}




                            if (totalAsText == title)
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents13", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem totalRowCell3ListItem1 = new ListItem();
                                ListItem totalRowCell3ListItem2 = new ListItem();
                                ListItem totalRowCell3ListItem3 = new ListItem();
                                ListItem totalRowCell3ListItem4 = new ListItem();
                                ListItem totalRowCell3ListItem5 = new ListItem();

                                totalRowCell3ListItem1.Value = "Pending";
                                totalRowCell3ListItem1.Text = "Pending";
                                totalRowCell3ListItem1.Selected = true;

                                totalRowCell3ListItem2.Value = "Approved";
                                totalRowCell3ListItem2.Text = "Approved";

                                totalRowCell3ListItem3.Value = "Approved With Comments";
                                totalRowCell3ListItem3.Text = "Approved With Comments";

                                totalRowCell3ListItem4.Value = "Approved With Revisions";
                                totalRowCell3ListItem4.Text = "Approved With Revisions";

                                totalRowCell3ListItem5.Value = "Not Approved";
                                totalRowCell3ListItem5.Text = "Not Approved";



                                DropDownList totalRowCell3DropDownList = new DropDownList();
                                totalRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                                totalRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalDRReview";

                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem1);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem2);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem3);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem4);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem5);


                                TextBox totalRowCell4TextBox = new TextBox();
                                totalRowCell4TextBox.TextMode = TextBoxMode.MultiLine;

                                totalRowCell3DropDownList.SelectedValue = totalRowCell3Text;
                                totalRowCell4TextBox.Text = totalRowCell4Text;
                                totalRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalDRComments";

                                totalRowCell3.Controls.Add(totalRowCell3DropDownList);
                                totalRowCell4.Controls.Add(totalRowCell4TextBox);

                                //---------------

                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }










                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }

                //end Total------------

                //VenueSubTotal-------------this will get all Venue sections---------
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();

                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string id = oListItem.ID.ToString();

                    TableRow rw = new TableRow();

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        TableCell venueSubTotalCell1 = new TableCell();
                        TableCell venueSubTotalCell2 = new TableCell();
                        TableCell venueSubTotalCell3 = new TableCell();

                        TableCell venueSubTotalRwCell4 = new TableCell();
                        TableCell venueSubTotalRwCell5 = new TableCell();


                        venueSubTotalCell1.ColumnSpan = 5;
                        venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");


                        //----------------------AddActivityEventBtn------------
                        Button AddActivityEventBtn = new Button();
                        AddActivityEventBtn.Text = "Add Activity/Event";
                        AddActivityEventBtn.ToolTip = oListItem["Venue"].ToString();
                        AddActivityEventBtn.CssClass = "CONOPSApprovalAddActivityEventButton";
                        AddActivityEventBtn.OnClientClick = "return false";
                        AddActivityEventBtn.UseSubmitBehavior = false;
                        venueSubTotalCell1.Controls.Add(AddActivityEventBtn);
                        //-----------------------------------------------------


                        venueSubTotalCell2.Style.Add("text-align", "right");
                        venueSubTotalCell2.Style.Add("font-weight", "bold");
                        venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell2.Text = "Sub-Total:​";

                        venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell3.Style.Add("text-align", "center");


                        string VenueSubTotal = "";
                        try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                        catch { }






                        TextBox venueSubTotalCell3TextBox = new TextBox();
                        venueSubTotalCell3TextBox.Width = 80;
                        venueSubTotalCell3TextBox.Text = VenueSubTotal;
                        venueSubTotalCell3TextBox.ID = "rowId" + id + "VenueSubTotal";

                        venueSubTotalCell3.Controls.Add(venueSubTotalCell3TextBox);



                        rw.Cells.Add(venueSubTotalCell1);
                        rw.Cells.Add(venueSubTotalCell2);
                        rw.Cells.Add(venueSubTotalCell3);

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                        //        string bdrcolor = getBdrcolor("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                        //        venueSubTotalCell3.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                        //        venueSubTotalCell3.Style.Add("border-bottom", "solid");
                        //        venueSubTotalCell3.Style.Add("border-top", "solid");
                        //        venueSubTotalCell3.Style.Add("border-left", "solid");
                        //        venueSubTotalCell3.Style.Add("border-right", "solid");
                        //        venueSubTotalCell3.Style.Add("border-color", bdrcolor);
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}

                        //Approval

                        string venueSubTotalRwCell4Text = "";
                        string venueSubTotalRwCell5Text = "";
                        try
                        {
                            venueSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalDRReview"].ToString();
                            venueSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalDRComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents14", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        ListItem venueSubTotalRwCell4ListItem1 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem2 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem3 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem4 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem5 = new ListItem();

                        venueSubTotalRwCell4ListItem1.Value = "Pending";
                        venueSubTotalRwCell4ListItem1.Text = "Pending";
                        venueSubTotalRwCell4ListItem1.Selected = true;

                        venueSubTotalRwCell4ListItem2.Value = "Approved";
                        venueSubTotalRwCell4ListItem2.Text = "Approved";

                        venueSubTotalRwCell4ListItem3.Value = "Approved With Comments";
                        venueSubTotalRwCell4ListItem3.Text = "Approved With Comments";

                        venueSubTotalRwCell4ListItem4.Value = "Approved With Revisions";
                        venueSubTotalRwCell4ListItem4.Text = "Approved With Revisions";

                        venueSubTotalRwCell4ListItem5.Value = "Not Approved";
                        venueSubTotalRwCell4ListItem5.Text = "Not Approved";



                        DropDownList venueSubTotalRwCell4DropDownList = new DropDownList();
                        venueSubTotalRwCell4DropDownList.CssClass = "CONOPSApprovalSelect";

                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem1);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem2);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem3);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem4);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem5);
                        venueSubTotalRwCell4DropDownList.ID = "rowId" + id + "CONOPSApprovalDRReview";

                        TextBox venueSubTotalRwCell5TextBox = new TextBox();
                        venueSubTotalRwCell5TextBox.TextMode = TextBoxMode.MultiLine;

                        venueSubTotalRwCell4DropDownList.SelectedValue = venueSubTotalRwCell4Text;
                        venueSubTotalRwCell5TextBox.Text = venueSubTotalRwCell5Text;
                        venueSubTotalRwCell5TextBox.ID = "rowId" + id + "CONOPSApprovalDRComments";

                        venueSubTotalRwCell4.Controls.Add(venueSubTotalRwCell4DropDownList);
                        venueSubTotalRwCell5.Controls.Add(venueSubTotalRwCell5TextBox);
                        venueSubTotalRwCell4.CssClass = "CONOPSApprovalCell"; venueSubTotalRwCell5.CssClass = "CONOPSApprovalCell";
                        //---------------

                        rw.Cells.Add(venueSubTotalRwCell4);
                        rw.Cells.Add(venueSubTotalRwCell5);

                        rw.ID = "rowId" + id + "VenueSubTotal";

                        rw.ToolTip = oListItem["Venue"].ToString();
                        rw.CssClass = "WSGroupEndRow";

                        CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                    }

                }

                traceInfo = "endVenueSubTotal";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("endVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //end VenueSubTotal-----------



                //iterate through VenueSubTotals-----
                foreach (SPListItem oListItem in collListItems)
                {
                    traceInfo = "oListItem.Title: " + oListItem.Title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("iterVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        string Venue = oListItem["Venue"].ToString();
                        int VenueRowIndexForThisCounter = 0;
                        int VenueRowIndexForThis = 0;

                        traceInfo = "VenueTableRows next";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRows", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            foreach (TableRow VenueSubTotalRow in rows)
                            {
                                try
                                {
                                    if (VenueSubTotalRow.ID.Contains("VenueSubTotal"))
                                    {
                                        try
                                        {
                                            if (VenueSubTotalRow.ToolTip == Venue)
                                            {
                                                VenueRowIndexForThis = VenueRowIndexForThisCounter;
                                                //break;
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ToolTipVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IDVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                VenueRowIndexForThisCounter = VenueRowIndexForThisCounter + 1;
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        traceInfo = "VenueRowIndexForThis " + VenueRowIndexForThis;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThisq", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPQuery VenueItemQuery = new SPQuery();
                        VenueItemQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">Deputy Director Approval</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Neq>" +
                                    "<FieldRef Name=\"Title\"/>" +
                                    "<Value Type=\"Text\">VenueSubTotal</Value>" +
                                "</Neq>" +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Venue\"/>" +
                                    "<Value Type=\"Text\">" + Venue + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                        SPListItemCollection collListItemsVenueItems = oList.GetItems(VenueItemQuery);

                        traceInfo = "collListItemsVenueItems.Count: " + collListItemsVenueItems.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CountcollListItemsVenueItems", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        foreach (SPListItem oListItemVenueItem in collListItemsVenueItems)
                        {
                            //This will get the venue items as a group and render them as rows at the venue row index
                            //traceInfo = "oListItemVenueItem Venue" + oListItemVenueItem["Venue"] + " oListItemVenueItem.Title: " + oListItemVenueItem.Title;
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oListItemVenueItemVenueItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow rw = new TableRow();

                            string iid = oListItemVenueItem.ID.ToString();

                            TableCell VenueCell = new TableCell();
                            TableCell TitleCell = new TableCell();
                            TableCell DatesCell = new TableCell();
                            TableCell PeopleCell = new TableCell();
                            TableCell EventLocationCell = new TableCell();
                            TableCell EstTravelCell = new TableCell();
                            TableCell EstLaborOvertimeCell = new TableCell();
                            TableCell FundingCell = new TableCell();

                            TableCell ApprovalCell = new TableCell();
                            TableCell CommentsCell = new TableCell();

                            VenueCell.Style.Add("vertical-align", "middle");
                            VenueCell.Style.Add("text-align", "center");
                            TitleCell.Style.Add("text-align", "center");
                            DatesCell.Style.Add("text-align", "center");
                            PeopleCell.Style.Add("text-align", "center");
                            EventLocationCell.Style.Add("text-align", "center");
                            EstTravelCell.Style.Add("text-align", "center");
                            EstLaborOvertimeCell.Style.Add("text-align", "center");
                            FundingCell.Style.Add("text-align", "center");

                            //string Venue = "";
                            string Title = "";
                            string Dates = "";
                            string People = "";
                            string EventLocation = "";
                            string EstTravel = "";
                            string EstLaborOvertime = "";
                            string Funding = "";


                            //try { Venue += oListItemVenueItem["Venue"].ToString(); }
                            //catch { }
                            Title += oListItemVenueItem.Title;
                            try { Dates += oListItemVenueItem["Dates"].ToString(); }
                            catch { }
                            try { People += oListItemVenueItem["People"].ToString(); }
                            catch { }
                            try { EventLocation += oListItemVenueItem["EventLocation"].ToString(); }
                            catch { }
                            try { EstTravel += oListItemVenueItem["EstTravel"].ToString(); }
                            catch { }
                            try { EstLaborOvertime += oListItemVenueItem["EstLaborOvertime"].ToString(); }
                            catch { }
                            try { Funding += oListItemVenueItem["Funding"].ToString(); }
                            catch { }

                            TextBox VenueCellTextBox = new TextBox();
                            TextBox TitleCellTextBox = new TextBox();
                            TextBox DatesCellTextBox = new TextBox();
                            TextBox PeopleCellTextBox = new TextBox();
                            TextBox EstTravelCellTextBox = new TextBox();
                            TextBox EventLocationCellTextBox = new TextBox();
                            TextBox EstLaborOvertimeCellTextBox = new TextBox();
                            TextBox FundingCellTextBox = new TextBox();

                            VenueCellTextBox.Width = 80;
                            TitleCellTextBox.Width = 80;
                            DatesCellTextBox.Width = 80;
                            PeopleCellTextBox.Width = 80;
                            EstTravelCellTextBox.Width = 80;
                            EventLocationCellTextBox.Width = 80;
                            EstLaborOvertimeCellTextBox.Width = 80;
                            FundingCellTextBox.Width = 80;


                            VenueCellTextBox.Text = Venue;
                            TitleCellTextBox.Text = Title;
                            DatesCellTextBox.Text = Dates;
                            PeopleCellTextBox.Text = People;
                            EstTravelCellTextBox.Text = EstTravel;
                            EventLocationCellTextBox.Text = EventLocation;
                            EstLaborOvertimeCellTextBox.Text = EstLaborOvertime;
                            FundingCellTextBox.Text = Funding;

                            VenueCellTextBox.ID = "rowId" + iid + "Venue";
                            TitleCellTextBox.ID = "rowId" + iid + "Title";
                            DatesCellTextBox.ID = "rowId" + iid + "Dates";
                            PeopleCellTextBox.ID = "rowId" + iid + "People";
                            EventLocationCellTextBox.ID = "rowId" + iid + "EventLocation";
                            EstTravelCellTextBox.ID = "rowId" + iid + "EstTravel"; 
                            EstLaborOvertimeCellTextBox.ID = "rowId" + iid + "EstLaborOvertime";
                            FundingCellTextBox.ID = "rowId" + iid + "Funding";

                            EstTravelCellTextBox.ToolTip = "Estimated Travel Costs";
                            EstLaborOvertimeCellTextBox.ToolTip = "Estimated Labor Overtime Costs";

                            VenueCell.Controls.Add(VenueCellTextBox);
                            TitleCell.Controls.Add(TitleCellTextBox);
                            DatesCell.Controls.Add(DatesCellTextBox);
                            PeopleCell.Controls.Add(PeopleCellTextBox);
                            EventLocationCell.Controls.Add(EventLocationCellTextBox);
                            EstTravelCell.Controls.Add(EstTravelCellTextBox);
                            EstLaborOvertimeCell.Controls.Add(EstLaborOvertimeCellTextBox);
                            FundingCell.Controls.Add(FundingCellTextBox);




                            rw.Cells.Add(VenueCell);
                            rw.Cells.Add(TitleCell);
                            rw.Cells.Add(DatesCell);
                            rw.Cells.Add(PeopleCell);
                            rw.Cells.Add(EventLocationCell);
                            rw.Cells.Add(EstTravelCell);
                            rw.Cells.Add(EstLaborOvertimeCell);
                            rw.Cells.Add(FundingCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Venue", Venue, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItemVenueItem["OTASubmissionID"] != null) { srcID = oListItemVenueItem["OTASubmissionID"].ToString(); }

                                string srcIDAO = "0";
                                if (oListItemVenueItem["AOReviewID"] != null) { srcIDAO = oListItemVenueItem["AOReviewID"].ToString(); }

                                if (IsDiff("Venue", Venue, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Venue", Venue, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    VenueCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    VenueCell.Style.Add("border-bottom", "solid");
                                    VenueCell.Style.Add("border-top", "solid");
                                    VenueCell.Style.Add("border-left", "solid");
                                    VenueCell.Style.Add("border-right", "solid");
                                    VenueCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Title", Title, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Title", Title, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    TitleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    TitleCell.Style.Add("border-bottom", "solid");
                                    TitleCell.Style.Add("border-top", "solid");
                                    TitleCell.Style.Add("border-left", "solid");
                                    TitleCell.Style.Add("border-right", "solid");
                                    TitleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    DatesCell.Style.Add("border-bottom", "solid");
                                    DatesCell.Style.Add("border-top", "solid");
                                    DatesCell.Style.Add("border-left", "solid");
                                    DatesCell.Style.Add("border-right", "solid");
                                    DatesCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    PeopleCell.Style.Add("border-bottom", "solid");
                                    PeopleCell.Style.Add("border-top", "solid");
                                    PeopleCell.Style.Add("border-left", "solid");
                                    PeopleCell.Style.Add("border-right", "solid");
                                    PeopleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstTravel", EstTravel, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstTravel", EstTravel, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstTravelCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstTravelCell.Style.Add("border-bottom", "solid");
                                    EstTravelCell.Style.Add("border-top", "solid");
                                    EstTravelCell.Style.Add("border-left", "solid");
                                    EstTravelCell.Style.Add("border-right", "solid");
                                    EstTravelCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EventLocation", EventLocation, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EventLocation", EventLocation, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EventLocationCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EventLocationCell.Style.Add("border-bottom", "solid");
                                    EventLocationCell.Style.Add("border-top", "solid");
                                    EventLocationCell.Style.Add("border-left", "solid");
                                    EventLocationCell.Style.Add("border-right", "solid");
                                    EventLocationCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstLaborOvertimeCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstLaborOvertimeCell.Style.Add("border-bottom", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-top", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-left", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-right", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-color", bdrcolor);
                                }
                                //if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString()))
                                //{
                                //    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                //    string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, oListItemVenueItem["OTASubmissionID"].ToString(), oListItemVenueItem["AOReviewID"].ToString(), pmid);
                                //    FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                //    FundingCell.Style.Add("border-bottom", "solid");
                                //    FundingCell.Style.Add("border-top", "solid");
                                //    FundingCell.Style.Add("border-left", "solid");
                                //    FundingCell.Style.Add("border-right", "solid");
                                //    FundingCell.Style.Add("border-color", bdrcolor);
                                //}
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string ApprovalCellText = "";
                            string CommentsCellText = "";
                            try
                            {
                                ApprovalCellText = "" + oListItemVenueItem["CONOPSApprovalDRReview"].ToString();
                                CommentsCellText = "" + oListItemVenueItem["CONOPSApprovalDRComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents15", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem ApprovalCellListItem1 = new ListItem();
                            ListItem ApprovalCellListItem2 = new ListItem();
                            ListItem ApprovalCellListItem3 = new ListItem();
                            ListItem ApprovalCellListItem4 = new ListItem();
                            ListItem ApprovalCellListItem5 = new ListItem();

                            ApprovalCellListItem1.Value = "Pending";
                            ApprovalCellListItem1.Text = "Pending";
                            ApprovalCellListItem1.Selected = true;

                            ApprovalCellListItem2.Value = "Approved";
                            ApprovalCellListItem2.Text = "Approved";

                            ApprovalCellListItem3.Value = "Approved With Comments";
                            ApprovalCellListItem3.Text = "Approved With Comments";

                            ApprovalCellListItem4.Value = "Approved With Revisions";
                            ApprovalCellListItem4.Text = "Approved With Revisions";

                            ApprovalCellListItem5.Value = "Not Approved";
                            ApprovalCellListItem5.Text = "Not Approved";



                            DropDownList ApprovalCellDropDownList = new DropDownList();
                            ApprovalCellDropDownList.CssClass = "CONOPSApprovalSelect";

                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem1);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem2);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem3);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem4);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem5);
                            ApprovalCellDropDownList.ID = "rowId" + iid + "CONOPSApprovalDRReview";


                            TextBox CommentsCellTextBox = new TextBox();
                            CommentsCellTextBox.TextMode = TextBoxMode.MultiLine;
                            CommentsCellTextBox.ID = "rowId" + iid + "CONOPSApprovalDRComments";


                            ApprovalCellDropDownList.SelectedValue = ApprovalCellText;
                            CommentsCellTextBox.Text = CommentsCellText;

                            ApprovalCell.Controls.Add(ApprovalCellDropDownList);
                            CommentsCell.Controls.Add(CommentsCellTextBox);
                            ApprovalCell.CssClass = "CONOPSApprovalCell";
                            CommentsCell.CssClass = "CONOPSApprovalCell";
                            //---------------


                            rw.Cells.Add(ApprovalCell);
                            rw.Cells.Add(CommentsCell);



                            rw.ToolTip = "Item";
                            //string dds1 = oListItemVenueItem["DateDraftSaved"].ToString();


                            //if (oListItemVenueItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            //{

                            //    rw.ToolTip = "NewEvent_" + Venue;


                            //}

                            traceInfo = "Adding row at VenueRowIndexForThis: " + VenueRowIndexForThis;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThis", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            CONOPSDevWSTable.Rows.AddAt(VenueRowIndexForThis, rw);
                        }

                    }
                }
                //end iterate through VenueSubTotals----



                try
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                    CONOPSDevWSTable.Controls.Remove(venueRow);
                    CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                int itemCount = 0;
                TableRow itemRowToUpdate = null;
                int rspan = 2;
                try
                {
                    foreach (TableRow row in rows)
                    {

                        traceInfo = "row.ToolTip: " + row.ToolTip + " itemCount: " + itemCount;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("itemRowToUpdate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            if (row.ToolTip == "Item")
                            {

                                if (itemRowToUpdate == null && itemCount < 1)
                                {

                                    itemRowToUpdate = row;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";
                                }
                                if (itemRowToUpdate != null && itemCount > 0)
                                {
                                    rspan = rspan + 1;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";

                                    row.Cells.RemoveAt(0);
                                }


                                itemCount = itemCount + 1;

                            }
                            else
                            {
                                itemRowToUpdate = null;
                                itemCount = 0;
                                rspan = 2;
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpansItems", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpans", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

            }
        }



        private void enableTabs()
        {
            var traceInfo = "enableTabs";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("enableTabs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];

            SPWeb oWeb = SPContext.Current.Web;

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            foreach (SPListItem oListItem in collListItemsCONOPSApprovalProgress)
            {

                string PMPreapproval = "PM Preapproval";
                string DeputyDirectorApproval = "Deputy Director Approval";

                try
                {
                    if (oListItem["CONOPSApproval"].ToString() == PMPreapproval)
                    {
                        DisablePMReview.Value = "No";
                    }
                    if (oListItem["CONOPSApproval"].ToString() == DeputyDirectorApproval)
                    {
                        DisablePMReview.Value = "No";
                        DisableDeputyDirectorReviewandApproval.Value = "No";
                    } 
                    if ((string)oListItem["Submitted"] == "Yes")
                    {
                        AllTabsChecked.Value = "Yes";

                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("enableTabs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

            }
        }


        private void makeViewOrFormForOTASubmission(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell2, TableRow venueRow, TableRow venueSubTotalRow, TableCell totalRowCell3, TableCell totalRowCell4)
        {


            TableRowCollection rows = CONOPSDevWSTable.Rows;



            var traceInfo = "";
            int venueSubTotalRowIndex = 5;
            int attachmentIndex = 7;
            SPWeb oWeb = SPContext.Current.Web;
            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);
            SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);


            //oLib            
            traceInfo = "oLib for attachments";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPQuery oLibQuery = new SPQuery();
            try
            {


                oLibQuery.Query = "" +
                       "<OrderBy>" +
                           "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                       "</OrderBy>" +
                       "<Where>" +
                           "<Or>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"FY\"/>" +
                                        "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                    "</Eq>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"WS\"/>" +
                                        "<Value Type=\"Text\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                    "</Eq>" +
                                "</And>" +

                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"FY\"/>" +
                                        "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                    "</Eq>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Title\"/>" +
                                        "<Value Type=\"Text\">Approval Memo</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Or>" +
                        "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;
                    string approvalMemoStr = "";

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Baseline OTA Submission" && oListItemVersion.VersionLabel != "1.0")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                if (oListItemVersion["Title"] != null)
                                {
                                    if ((string)oListItemVersion["Title"] == "Approval Memo")
                                    {
                                        approvalMemoStr = "Approval Memo: ";
                                    }
                                }

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + approvalMemoStr + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
         

            try
            {
                //oList
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + Page.Request.QueryString["otashort"] + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">Baseline OTA Submission</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);


                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");


                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string id = oListItem.ID.ToString();
                    TableRow rw = new TableRow();
                    string VenueSubTotalStr = "VenueSubTotal";
                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = oListItem[TotalGUID].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }

                    else if (title == VenueSubTotalStr)
                    {
                    TableCell VenueCell = new TableCell();
                    TableCell venueSubTotalCell1 = new TableCell();
                    TableCell venueSubTotalCell2 = new TableCell();
                    TableCell venueSubTotalCell3 = new TableCell();

                    TableCell venueSubTotalRwCell4 = new TableCell();
                    TableCell venueSubTotalRwCell5 = new TableCell();

                    VenueCell.Style.Add("vertical-align", "middle");
                    VenueCell.Style.Add("text-align", "center");
                    venueSubTotalCell1.ColumnSpan = 5;
                    venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");

                    venueSubTotalCell2.Style.Add("text-align", "right");
                    venueSubTotalCell2.Style.Add("font-weight", "bold");
                    venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                    venueSubTotalCell2.Text = "Sub-Total:​";

                    venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                    venueSubTotalCell3.Style.Add("text-align", "center");

                    string Venue = "";
                    try { Venue += oListItem["Venue"].ToString(); }
                    catch { }
                    string VenueSubTotal = "";
                    try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                    catch { }
                    


                    VenueCell.Text = Venue;


                    venueSubTotalCell3.Text=VenueSubTotal;


                    rw.Cells.Add(VenueCell);
                    rw.Cells.Add(venueSubTotalCell1);
                    rw.Cells.Add(venueSubTotalCell2);
                    rw.Cells.Add(venueSubTotalCell3);



                    rw.ToolTip = "Sub-Total";

                    CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                }
               




                    else
                    {
                        TableCell VenueCell = new TableCell();
                        TableCell TitleCell = new TableCell();
                        TableCell DatesCell = new TableCell();
                        TableCell PeopleCell = new TableCell();
                        TableCell EventLocationCell = new TableCell();
                        TableCell EstTravelCell = new TableCell();
                        TableCell EstLaborOvertimeCell = new TableCell();
                        TableCell FundingCell = new TableCell();


                        VenueCell.Style.Add("vertical-align", "middle");
                        VenueCell.Style.Add("text-align", "center");
                        TitleCell.Style.Add("text-align", "center");
                        DatesCell.Style.Add("text-align", "center");
                        PeopleCell.Style.Add("text-align", "center");
                        EventLocationCell.Style.Add("text-align", "center");
                        EstTravelCell.Style.Add("text-align", "center");
                        EstLaborOvertimeCell.Style.Add("text-align", "center");
                        FundingCell.Style.Add("text-align", "center");

                        string Venue = "";
                        string Title = "";
                        string Dates = "";
                        string People = "";
                        string EventLocation = "";
                        string EstTravel = "";
                        string EstLaborOvertime = "";
                        string Funding = "";


                        try { Venue += oListItem["Venue"].ToString(); }
                        catch { }
                        Title += title;
                        try { Dates += oListItem["Dates"].ToString(); }
                        catch { }
                        try { People += oListItem["People"].ToString(); }
                        catch { }
                        try { EventLocation += oListItem["EventLocation"].ToString(); }
                        catch { }
                        try { EstTravel += oListItem["EstTravel"].ToString(); }
                        catch { }
                        try { EstLaborOvertime += oListItem["EstLaborOvertime"].ToString(); }
                        catch { }
                        try { Funding += oListItem["Funding"].ToString(); }
                        catch { }

                        VenueCell.Text = Venue;
                        TitleCell.Text = Title;
                        DatesCell.Text = Dates;
                        PeopleCell.Text = People;
                        EstTravelCell.Text = EstTravel;
                        EventLocationCell.Text = EventLocation;
                        EstLaborOvertimeCell.Text = EstLaborOvertime;
                        FundingCell.Text = Funding;

                        rw.Cells.Add(VenueCell);
                        rw.Cells.Add(TitleCell);
                        rw.Cells.Add(DatesCell);
                        rw.Cells.Add(PeopleCell);
                        rw.Cells.Add(EventLocationCell);
                        rw.Cells.Add(EstTravelCell);
                        rw.Cells.Add(EstLaborOvertimeCell);
                        rw.Cells.Add(FundingCell);
                        rw.ToolTip = "Item";
                        CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);

                    }


                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }

            try
            {

                CONOPSDevWSTable.Controls.Remove(venueRow);
                CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }






            int rowCount = 0;
            int rowSpanCount = 0;
            TableRow rowToUpdate = null;

            //RemoveCells
            //Set RowSpan
            try
            {
                foreach (TableRow row in rows)
                {
                    rowCount = rowCount + 1;

                    if (rowCount > 3)
                    {
                        rowSpanCount = rowSpanCount + 1;

                        if (row.ID == "totalRow")
                        {
                            break;
                        }
                        else if (row.ToolTip == "Sub-Total")
                        {
                            rowToUpdate.Cells[0].RowSpan = rowSpanCount;
                            rowToUpdate.Cells[0].ToolTip = "Venue";

                            row.Cells.RemoveAt(0);

                            rowSpanCount = 0;
                        }
                        else if (row.ToolTip == "Item")
                        {
                            if (rowSpanCount > 1)
                            {
                                row.Cells.RemoveAt(0);
                            }
                            else
                            {
                                rowToUpdate = row;
                            }

                        }
                    }

                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
                
        }

        private void makeViewOrFormForPMReview(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell1, Button AddVenueBtn, TableCell totalRowCell2, TableRow venueRow, TableRow venueSubTotalRow, TableCell totalRowCell3, TableCell totalRowCell4, TableRow attachDocRow)
        {
            var traceInfo = "makeViewOrFormForPMReview WS2";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_submitted = Page.Request.QueryString["submitted"];
            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_tab = Page.Request.QueryString["tab"];

            traceInfo = "qs_submitted: " + qs_submitted + " qs_otashort: " + qs_otashort + " qs_ws: " + qs_ws + " qs_fy: " + qs_fy + " qs_tab: " + qs_tab;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("makeViewOrFormForAOReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPWeb oWeb = SPContext.Current.Web;
            bool HasDDApprovalItems = false;

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And><Eq><FieldRef Name='CONOPSApproval'/><Value Type='Text'>Deputy Director Approval</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);
            if (collListItemsCONOPSApprovalProgress.Count > 0) { HasDDApprovalItems = true; }

            traceInfo = "HasDDApprovalItems: " + HasDDApprovalItems;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("WS4makeViewOrFormForPMReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            if (HasDDApprovalItems)
            {
                //HasPMPreapprovalItems is true so query where Submitted is Yes and display as view with no form controls
                CONOPSApprovalSaveButton.Visible = false;
                CheckBox1.Visible = false;
                CONOPSApprovalSaveButton1.Visible = false;
                CheckBox2.Visible = false;
                SaveDiv1.Visible = false;
                SaveDiv2.Visible = false;
                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int venueSubTotalRowIndex = 5;


                int attachmentIndex = 7;


                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "PM Preapproval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalPMReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalPMComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }

                                attachmentsValRwCell2.Text = attachmentsValRwCell2Text;
                                attachmentsValRwCell3.Text = attachmentsValRwCell3Text;

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }





                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();

                oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +

                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">PM Preapproval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +

                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";



                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //oQuery to set vars.
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                string totalAsText = "Total";

                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();

                    //Only one Total
                    string id = oListItem.ID.ToString();
                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = oListItem[TotalGUID].ToString();
                            totalRowCell1.Controls.Remove(AddVenueBtn);

                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                            //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", bdrcolor);
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}




                            if (totalAsText == title)
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents13", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                totalRowCell3.Text = totalRowCell3Text;
                                totalRowCell4.Text = totalRowCell4Text;
                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }










                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }

                //end Total------------

                //VenueSubTotal-------------this will get all Venue sections---------
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();

                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string id = oListItem.ID.ToString();

                    TableRow rw = new TableRow();

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        TableCell venueSubTotalCell1 = new TableCell();
                        TableCell venueSubTotalCell2 = new TableCell();
                        TableCell venueSubTotalCell3 = new TableCell();

                        TableCell venueSubTotalRwCell4 = new TableCell();
                        TableCell venueSubTotalRwCell5 = new TableCell();

                        //VenueCell.Style.Add("vertical-align", "middle");
                        //VenueCell.Style.Add("text-align", "center");

                        venueSubTotalCell1.ColumnSpan = 5;
                        venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");

                        venueSubTotalCell2.Style.Add("text-align", "right");
                        venueSubTotalCell2.Style.Add("font-weight", "bold");
                        venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell2.Text = "Sub-Total:​";

                        venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell3.Style.Add("text-align", "center");

                        //string Venue = "";
                        //try { Venue += oListItem["Venue"].ToString(); }
                        //catch { }
                        string VenueSubTotal = "";
                        try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                        catch { }

                        //VenueCell.Text = Venue;
                        venueSubTotalCell3.Text = VenueSubTotal;


                        //rw.Cells.Add(VenueCell);

                        rw.Cells.Add(venueSubTotalCell1);
                        rw.Cells.Add(venueSubTotalCell2);
                        rw.Cells.Add(venueSubTotalCell3);

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                        //        string bdrcolor = getBdrcolor("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                        //        venueSubTotalCell3.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                        //        venueSubTotalCell3.Style.Add("border-bottom", "solid");
                        //        venueSubTotalCell3.Style.Add("border-top", "solid");
                        //        venueSubTotalCell3.Style.Add("border-left", "solid");
                        //        venueSubTotalCell3.Style.Add("border-right", "solid");
                        //        venueSubTotalCell3.Style.Add("border-color", bdrcolor);
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}

                        //Approval

                        string venueSubTotalRwCell4Text = "";
                        string venueSubTotalRwCell5Text = "";
                        try
                        {
                            venueSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                            venueSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents14", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        venueSubTotalRwCell4.CssClass = "CONOPSApprovalCell";
                        venueSubTotalRwCell5.CssClass = "CONOPSApprovalCell";
                        venueSubTotalRwCell4.Text = venueSubTotalRwCell4Text;
                        venueSubTotalRwCell5.Text = venueSubTotalRwCell5Text;
                        //---------------

                        rw.Cells.Add(venueSubTotalRwCell4);
                        rw.Cells.Add(venueSubTotalRwCell5);

                        rw.ID = "rowId" + id + "VenueSubTotal";

                        rw.ToolTip = oListItem["Venue"].ToString();

                        CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                    }

                }

                traceInfo = "endVenueSubTotal";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("endVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //end VenueSubTotal-----------



                //iterate through VenueSubTotals-----
                foreach (SPListItem oListItem in collListItems)
                {
                    traceInfo = "oListItem.Title: " + oListItem.Title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("iterVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        string Venue = oListItem["Venue"].ToString();
                        int VenueRowIndexForThisCounter = 0;
                        int VenueRowIndexForThis = 0;

                        traceInfo = "VenueTableRows next";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRows", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            foreach (TableRow VenueSubTotalRow in rows)
                            {
                                try
                                {
                                    if (VenueSubTotalRow.ID.Contains("VenueSubTotal"))
                                    {
                                        try
                                        {
                                            if (VenueSubTotalRow.ToolTip == Venue)
                                            {
                                                VenueRowIndexForThis = VenueRowIndexForThisCounter;
                                                //break;
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ToolTipVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IDVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                VenueRowIndexForThisCounter = VenueRowIndexForThisCounter + 1;
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        traceInfo = "VenueRowIndexForThis " + VenueRowIndexForThis;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThisq", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPQuery VenueItemQuery = new SPQuery();
                        VenueItemQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">PM Preapproval</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Neq>" +
                                    "<FieldRef Name=\"Title\"/>" +
                                    "<Value Type=\"Text\">VenueSubTotal</Value>" +
                                "</Neq>" +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Venue\"/>" +
                                    "<Value Type=\"Text\">" + Venue + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                        SPListItemCollection collListItemsVenueItems = oList.GetItems(VenueItemQuery);

                        traceInfo = "collListItemsVenueItems.Count: " + collListItemsVenueItems.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CountcollListItemsVenueItems", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        foreach (SPListItem oListItemVenueItem in collListItemsVenueItems)
                        {
                            //This will get the venue items as a group and render them as rows at the venue row index
                            //traceInfo = "oListItemVenueItem Venue" + oListItemVenueItem["Venue"] + " oListItemVenueItem.Title: " + oListItemVenueItem.Title;
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oListItemVenueItemVenueItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow rw = new TableRow();

                            string iid = oListItemVenueItem.ID.ToString();

                            TableCell VenueCell = new TableCell();
                            TableCell TitleCell = new TableCell();
                            TableCell DatesCell = new TableCell();
                            TableCell PeopleCell = new TableCell();
                            TableCell EventLocationCell = new TableCell();
                            TableCell EstTravelCell = new TableCell();
                            TableCell EstLaborOvertimeCell = new TableCell();
                            TableCell FundingCell = new TableCell();

                            TableCell ApprovalCell = new TableCell();
                            TableCell CommentsCell = new TableCell();

                            VenueCell.Style.Add("vertical-align", "middle");
                            VenueCell.Style.Add("text-align", "center");
                            TitleCell.Style.Add("text-align", "center");
                            DatesCell.Style.Add("text-align", "center");
                            PeopleCell.Style.Add("text-align", "center");
                            EventLocationCell.Style.Add("text-align", "center");
                            EstTravelCell.Style.Add("text-align", "center");
                            EstLaborOvertimeCell.Style.Add("text-align", "center");
                            FundingCell.Style.Add("text-align", "center");

                            //string Venue = "";
                            string Title = "";
                            string Dates = "";
                            string People = "";
                            string EventLocation = "";
                            string EstTravel = "";
                            string EstLaborOvertime = "";
                            string Funding = "";


                            //try { Venue += oListItemVenueItem["Venue"].ToString(); }
                            //catch { }
                            Title += oListItemVenueItem.Title;
                            try { Dates += oListItemVenueItem["Dates"].ToString(); }
                            catch { }
                            try { People += oListItemVenueItem["People"].ToString(); }
                            catch { }
                            try { EventLocation += oListItemVenueItem["EventLocation"].ToString(); }
                            catch { }
                            try { EstTravel += oListItemVenueItem["EstTravel"].ToString(); }
                            catch { }
                            try { EstLaborOvertime += oListItemVenueItem["EstLaborOvertime"].ToString(); }
                            catch { }
                            try { Funding += oListItemVenueItem["Funding"].ToString(); }
                            catch { }
                            VenueCell.Text = Venue;
                            TitleCell.Text = Title;
                            DatesCell.Text = Dates;
                            PeopleCell.Text = People;
                            EstTravelCell.Text = EstTravel;
                            EventLocationCell.Text = EventLocation;
                            EstLaborOvertimeCell.Text = EstLaborOvertime;
                            FundingCell.Text = Funding;

                            rw.Cells.Add(VenueCell);
                            rw.Cells.Add(TitleCell);
                            rw.Cells.Add(DatesCell);
                            rw.Cells.Add(PeopleCell);
                            rw.Cells.Add(EventLocationCell);
                            rw.Cells.Add(EstTravelCell);
                            rw.Cells.Add(EstLaborOvertimeCell);
                            rw.Cells.Add(FundingCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Venue", Venue, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                
                                string srcID = "0";
                                if (oListItemVenueItem["OTASubmissionID"] != null) { srcID = oListItemVenueItem["OTASubmissionID"].ToString(); }

                                string srcIDAO = "0";
                                if (oListItemVenueItem["AOReviewID"] != null) { srcIDAO = oListItemVenueItem["AOReviewID"].ToString(); }

                                if (IsDiff("Venue", Venue, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Venue", Venue, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    VenueCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    VenueCell.Style.Add("border-bottom", "solid");
                                    VenueCell.Style.Add("border-top", "solid");
                                    VenueCell.Style.Add("border-left", "solid");
                                    VenueCell.Style.Add("border-right", "solid");
                                    VenueCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Title", Title, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Title", Title, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    TitleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    TitleCell.Style.Add("border-bottom", "solid");
                                    TitleCell.Style.Add("border-top", "solid");
                                    TitleCell.Style.Add("border-left", "solid");
                                    TitleCell.Style.Add("border-right", "solid");
                                    TitleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    DatesCell.Style.Add("border-bottom", "solid");
                                    DatesCell.Style.Add("border-top", "solid");
                                    DatesCell.Style.Add("border-left", "solid");
                                    DatesCell.Style.Add("border-right", "solid");
                                    DatesCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    PeopleCell.Style.Add("border-bottom", "solid");
                                    PeopleCell.Style.Add("border-top", "solid");
                                    PeopleCell.Style.Add("border-left", "solid");
                                    PeopleCell.Style.Add("border-right", "solid");
                                    PeopleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstTravel", EstTravel, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstTravel", EstTravel, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstTravelCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstTravelCell.Style.Add("border-bottom", "solid");
                                    EstTravelCell.Style.Add("border-top", "solid");
                                    EstTravelCell.Style.Add("border-left", "solid");
                                    EstTravelCell.Style.Add("border-right", "solid");
                                    EstTravelCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EventLocation", EventLocation, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EventLocation", EventLocation, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EventLocationCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EventLocationCell.Style.Add("border-bottom", "solid");
                                    EventLocationCell.Style.Add("border-top", "solid");
                                    EventLocationCell.Style.Add("border-left", "solid");
                                    EventLocationCell.Style.Add("border-right", "solid");
                                    EventLocationCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstLaborOvertimeCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstLaborOvertimeCell.Style.Add("border-bottom", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-top", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-left", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-right", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-color", bdrcolor);
                                }
                                //if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString()))
                                //{
                                //    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                //    string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, oListItemVenueItem["OTASubmissionID"].ToString(), oListItemVenueItem["AOReviewID"].ToString(), pmid);
                                //    FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                //    FundingCell.Style.Add("border-bottom", "solid");
                                //    FundingCell.Style.Add("border-top", "solid");
                                //    FundingCell.Style.Add("border-left", "solid");
                                //    FundingCell.Style.Add("border-right", "solid");
                                //    FundingCell.Style.Add("border-color", bdrcolor);
                                //}
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string ApprovalCellText = "";
                            string CommentsCellText = "";
                            try
                            {
                                ApprovalCellText = "" + oListItemVenueItem["CONOPSApprovalPMReview"].ToString();
                                CommentsCellText = "" + oListItemVenueItem["CONOPSApprovalPMComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents15", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            ApprovalCell.CssClass = "CONOPSApprovalCell";
                            CommentsCell.CssClass = "CONOPSApprovalCell";
                            ApprovalCell.Text = ApprovalCellText;
                            CommentsCell.Text = CommentsCellText;
                            //---------------


                            rw.Cells.Add(ApprovalCell);
                            rw.Cells.Add(CommentsCell);



                            rw.ToolTip = "Item";
                            //string dds1 = oListItemVenueItem["DateDraftSaved"].ToString();


                            //if (oListItemVenueItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            //{

                            //    rw.ToolTip = "NewEvent_" + Venue;


                            //}

                            traceInfo = "Adding row at VenueRowIndexForThis: " + VenueRowIndexForThis;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThis", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            CONOPSDevWSTable.Rows.AddAt(VenueRowIndexForThis, rw);
                        }

                    }
                }
                //end iterate through VenueSubTotals----



                try
                {
                    CONOPSDevWSTable.Controls.Remove(attachDocRow);
                    CONOPSDevWSTable.Controls.Remove(venueRow);
                    CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                int itemCount = 0;
                TableRow itemRowToUpdate = null;
                int rspan = 2;
                try
                {
                    foreach (TableRow row in rows)
                    {

                        traceInfo = "row.ToolTip: " + row.ToolTip + " itemCount: " + itemCount;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("itemRowToUpdate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            if (row.ToolTip == "Item")
                            {

                                if (itemRowToUpdate == null && itemCount < 1)
                                {

                                    itemRowToUpdate = row;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";
                                }
                                if (itemRowToUpdate != null && itemCount > 0)
                                {
                                    rspan = rspan + 1;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";

                                    row.Cells.RemoveAt(0);
                                }


                                itemCount = itemCount + 1;

                            }
                            else
                            {
                                itemRowToUpdate = null;
                                itemCount = 0;
                                rspan = 2;
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpansItems", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpans", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }


            }
            else
            {
                //HasDDApprovalItems is false so query where Submitted is not Yes and display form controls

                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int venueSubTotalRowIndex = 5;


                int attachmentIndex = 7;


                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "PM Preapproval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalPMReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalPMComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem attachmentsValRwCell2ListItem1 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem2 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem3 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem4 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem5 = new ListItem();

                                attachmentsValRwCell2ListItem1.Value = "Pending";
                                attachmentsValRwCell2ListItem1.Text = "Pending";
                                attachmentsValRwCell2ListItem1.Selected = true;

                                attachmentsValRwCell2ListItem2.Value = "Approved";
                                attachmentsValRwCell2ListItem2.Text = "Approved";

                                attachmentsValRwCell2ListItem3.Value = "Approved With Comments";
                                attachmentsValRwCell2ListItem3.Text = "Approved With Comments";

                                attachmentsValRwCell2ListItem4.Value = "Approved With Revisions";
                                attachmentsValRwCell2ListItem4.Text = "Approved With Revisions";

                                attachmentsValRwCell2ListItem5.Value = "Not Approved";
                                attachmentsValRwCell2ListItem5.Text = "Not Approved";


                                DropDownList attachmentsValRwCell2DropDownList = new DropDownList();
                                attachmentsValRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                                attachmentsValRwCell2DropDownList.ID = "attId" + id + "CONOPSApprovalPMReview";

                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem1);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem2);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem3);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem4);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem5);


                                TextBox attachmentsValRwCell3TextBox = new TextBox();
                                attachmentsValRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                                attachmentsValRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";

                                attachmentsValRwCell2DropDownList.SelectedValue = attachmentsValRwCell2Text;
                                attachmentsValRwCell3TextBox.Text = attachmentsValRwCell3Text;
                                attachmentsValRwCell3TextBox.ID = "attId" + id + "CONOPSApprovalPMComments";

                                attachmentsValRwCell2.Controls.Add(attachmentsValRwCell2DropDownList);
                                attachmentsValRwCell3.Controls.Add(attachmentsValRwCell3TextBox);

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }





                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();

                oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                    //"<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">PM Preapproval</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Neq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                    //"<IsNotNull>" +
                    //        "<FieldRef Name=\"OTASubmissionID\"/>" +
                    //    "</IsNotNull>" +
                    //"</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";


                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //oQuery to set vars.
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                string totalAsText = "Total";

                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();

                    //Only one Total
                    string id = oListItem.ID.ToString();
                    if (totalRowCell2.Text == "0000")
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = "";

                            TextBox totalRowCell2TextBox = new TextBox();
                            totalRowCell2TextBox.Width = 80;
                            totalRowCell2TextBox.Text = oListItem[TotalGUID].ToString();
                            totalRowCell2TextBox.ID = "rowId" + id + "Total";
                            totalRowCell2.Controls.Add(totalRowCell2TextBox);


                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                            //        string bdrcolor = getBdrcolor("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                            //        totalRowCell2.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", bdrcolor);
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}




                            if (totalAsText == title)
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents13", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem totalRowCell3ListItem1 = new ListItem();
                                ListItem totalRowCell3ListItem2 = new ListItem();
                                ListItem totalRowCell3ListItem3 = new ListItem();
                                ListItem totalRowCell3ListItem4 = new ListItem();
                                ListItem totalRowCell3ListItem5 = new ListItem();

                                totalRowCell3ListItem1.Value = "Pending";
                                totalRowCell3ListItem1.Text = "Pending";
                                totalRowCell3ListItem1.Selected = true;

                                totalRowCell3ListItem2.Value = "Approved";
                                totalRowCell3ListItem2.Text = "Approved";

                                totalRowCell3ListItem3.Value = "Approved With Comments";
                                totalRowCell3ListItem3.Text = "Approved With Comments";

                                totalRowCell3ListItem4.Value = "Approved With Revisions";
                                totalRowCell3ListItem4.Text = "Approved With Revisions";

                                totalRowCell3ListItem5.Value = "Not Approved";
                                totalRowCell3ListItem5.Text = "Not Approved";



                                DropDownList totalRowCell3DropDownList = new DropDownList();
                                totalRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                                totalRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalPMReview";

                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem1);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem2);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem3);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem4);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem5);


                                TextBox totalRowCell4TextBox = new TextBox();
                                totalRowCell4TextBox.TextMode = TextBoxMode.MultiLine;

                                totalRowCell3DropDownList.SelectedValue = totalRowCell3Text;
                                totalRowCell4TextBox.Text = totalRowCell4Text;
                                totalRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalPMComments";

                                totalRowCell3.Controls.Add(totalRowCell3DropDownList);
                                totalRowCell4.Controls.Add(totalRowCell4TextBox);

                                //---------------

                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }










                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }

                //end Total------------

                //VenueSubTotal-------------this will get all Venue sections---------
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();

                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string id = oListItem.ID.ToString();

                    TableRow rw = new TableRow();

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        TableCell venueSubTotalCell1 = new TableCell();
                        TableCell venueSubTotalCell2 = new TableCell();
                        TableCell venueSubTotalCell3 = new TableCell();

                        TableCell venueSubTotalRwCell4 = new TableCell();
                        TableCell venueSubTotalRwCell5 = new TableCell();


                        venueSubTotalCell1.ColumnSpan = 5;
                        venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");


                        //----------------------AddActivityEventBtn------------
                        Button AddActivityEventBtn = new Button();
                        AddActivityEventBtn.Text = "Add Activity/Event";
                        AddActivityEventBtn.ToolTip = oListItem["Venue"].ToString();
                        AddActivityEventBtn.CssClass = "CONOPSApprovalAddActivityEventButton";
                        AddActivityEventBtn.OnClientClick = "return false";
                        AddActivityEventBtn.UseSubmitBehavior = false;
                        venueSubTotalCell1.Controls.Add(AddActivityEventBtn);
                        //-----------------------------------------------------


                        venueSubTotalCell2.Style.Add("text-align", "right");
                        venueSubTotalCell2.Style.Add("font-weight", "bold");
                        venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell2.Text = "Sub-Total:​";

                        venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell3.Style.Add("text-align", "center");


                        string VenueSubTotal = "";
                        try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                        catch { }






                        TextBox venueSubTotalCell3TextBox = new TextBox();
                        venueSubTotalCell3TextBox.Width = 80;
                        venueSubTotalCell3TextBox.Text = VenueSubTotal;
                        venueSubTotalCell3TextBox.ID = "rowId" + id + "VenueSubTotal";

                        venueSubTotalCell3.Controls.Add(venueSubTotalCell3TextBox);



                        rw.Cells.Add(venueSubTotalCell1);
                        rw.Cells.Add(venueSubTotalCell2);
                        rw.Cells.Add(venueSubTotalCell3);

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        string pmid = ""; if (oListItem["PMReviewID"] != null) { pmid = oListItem["PMReviewID"].ToString(); }
                        //        string bdrcolor = getBdrcolor("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, qs_tab, oListItem["OTASubmissionID"].ToString(), oListItem["AOReviewID"].ToString(), pmid);
                        //        venueSubTotalCell3.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);

                        //        venueSubTotalCell3.Style.Add("border-bottom", "solid");
                        //        venueSubTotalCell3.Style.Add("border-top", "solid");
                        //        venueSubTotalCell3.Style.Add("border-left", "solid");
                        //        venueSubTotalCell3.Style.Add("border-right", "solid");
                        //        venueSubTotalCell3.Style.Add("border-color", bdrcolor);
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}

                        //Approval

                        string venueSubTotalRwCell4Text = "";
                        string venueSubTotalRwCell5Text = "";
                        try
                        {
                            venueSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalPMReview"].ToString();
                            venueSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalPMComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents14", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        ListItem venueSubTotalRwCell4ListItem1 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem2 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem3 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem4 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem5 = new ListItem();

                        venueSubTotalRwCell4ListItem1.Value = "Pending";
                        venueSubTotalRwCell4ListItem1.Text = "Pending";
                        venueSubTotalRwCell4ListItem1.Selected = true;

                        venueSubTotalRwCell4ListItem2.Value = "Approved";
                        venueSubTotalRwCell4ListItem2.Text = "Approved";

                        venueSubTotalRwCell4ListItem3.Value = "Approved With Comments";
                        venueSubTotalRwCell4ListItem3.Text = "Approved With Comments";

                        venueSubTotalRwCell4ListItem4.Value = "Approved With Revisions";
                        venueSubTotalRwCell4ListItem4.Text = "Approved With Revisions";

                        venueSubTotalRwCell4ListItem5.Value = "Not Approved";
                        venueSubTotalRwCell4ListItem5.Text = "Not Approved";



                        DropDownList venueSubTotalRwCell4DropDownList = new DropDownList();
                        venueSubTotalRwCell4DropDownList.CssClass = "CONOPSApprovalSelect";

                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem1);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem2);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem3);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem4);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem5);
                        venueSubTotalRwCell4DropDownList.ID = "rowId" + id + "CONOPSApprovalPMReview";

                        TextBox venueSubTotalRwCell5TextBox = new TextBox();
                        venueSubTotalRwCell5TextBox.TextMode = TextBoxMode.MultiLine;

                        venueSubTotalRwCell4DropDownList.SelectedValue = venueSubTotalRwCell4Text;
                        venueSubTotalRwCell5TextBox.Text = venueSubTotalRwCell5Text;
                        venueSubTotalRwCell5TextBox.ID = "rowId" + id + "CONOPSApprovalPMComments";

                        venueSubTotalRwCell4.Controls.Add(venueSubTotalRwCell4DropDownList);
                        venueSubTotalRwCell5.Controls.Add(venueSubTotalRwCell5TextBox);
                        venueSubTotalRwCell4.CssClass = "CONOPSApprovalCell"; venueSubTotalRwCell5.CssClass = "CONOPSApprovalCell";
                        //---------------

                        rw.Cells.Add(venueSubTotalRwCell4);
                        rw.Cells.Add(venueSubTotalRwCell5);

                        rw.ID = "rowId" + id + "VenueSubTotal";

                        rw.ToolTip = oListItem["Venue"].ToString();
                        rw.CssClass = "WSGroupEndRow";

                        CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                    }

                }

                traceInfo = "endVenueSubTotal";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("endVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //end VenueSubTotal-----------



                //iterate through VenueSubTotals-----
                foreach (SPListItem oListItem in collListItems)
                {
                    traceInfo = "oListItem.Title: " + oListItem.Title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("iterVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        string Venue = oListItem["Venue"].ToString();
                        int VenueRowIndexForThisCounter = 0;
                        int VenueRowIndexForThis = 0;

                        traceInfo = "VenueTableRows next";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRows", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            foreach (TableRow VenueSubTotalRow in rows)
                            {
                                try
                                {
                                    if (VenueSubTotalRow.ID.Contains("VenueSubTotal"))
                                    {
                                        try
                                        {
                                            if (VenueSubTotalRow.ToolTip == Venue)
                                            {
                                                VenueRowIndexForThis = VenueRowIndexForThisCounter;
                                                //break;
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ToolTipVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IDVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                VenueRowIndexForThisCounter = VenueRowIndexForThisCounter + 1;
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        traceInfo = "VenueRowIndexForThis " + VenueRowIndexForThis;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThisq", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPQuery VenueItemQuery = new SPQuery();
                        VenueItemQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">PM Preapproval</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Neq>" +
                                    "<FieldRef Name=\"Title\"/>" +
                                    "<Value Type=\"Text\">VenueSubTotal</Value>" +
                                "</Neq>" +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Venue\"/>" +
                                    "<Value Type=\"Text\">" + Venue + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                        SPListItemCollection collListItemsVenueItems = oList.GetItems(VenueItemQuery);

                        traceInfo = "collListItemsVenueItems.Count: " + collListItemsVenueItems.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CountcollListItemsVenueItems", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        foreach (SPListItem oListItemVenueItem in collListItemsVenueItems)
                        {
                            //This will get the venue items as a group and render them as rows at the venue row index
                            //traceInfo = "oListItemVenueItem Venue" + oListItemVenueItem["Venue"] + " oListItemVenueItem.Title: " + oListItemVenueItem.Title;
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oListItemVenueItemVenueItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow rw = new TableRow();

                            string iid = oListItemVenueItem.ID.ToString();

                            TableCell VenueCell = new TableCell();
                            TableCell TitleCell = new TableCell();
                            TableCell DatesCell = new TableCell();
                            TableCell PeopleCell = new TableCell();
                            TableCell EventLocationCell = new TableCell();
                            TableCell EstTravelCell = new TableCell();
                            TableCell EstLaborOvertimeCell = new TableCell();
                            TableCell FundingCell = new TableCell();

                            TableCell ApprovalCell = new TableCell();
                            TableCell CommentsCell = new TableCell();

                            VenueCell.Style.Add("vertical-align", "middle");
                            VenueCell.Style.Add("text-align", "center");
                            TitleCell.Style.Add("text-align", "center");
                            DatesCell.Style.Add("text-align", "center");
                            PeopleCell.Style.Add("text-align", "center");
                            EventLocationCell.Style.Add("text-align", "center");
                            EstTravelCell.Style.Add("text-align", "center");
                            EstLaborOvertimeCell.Style.Add("text-align", "center");
                            FundingCell.Style.Add("text-align", "center");

                            //string Venue = "";
                            string Title = "";
                            string Dates = "";
                            string People = "";
                            string EventLocation = "";
                            string EstTravel = "";
                            string EstLaborOvertime = "";
                            string Funding = "";


                            //try { Venue += oListItemVenueItem["Venue"].ToString(); }
                            //catch { }
                            Title += oListItemVenueItem.Title;
                            try { Dates += oListItemVenueItem["Dates"].ToString(); }
                            catch { }
                            try { People += oListItemVenueItem["People"].ToString(); }
                            catch { }
                            try { EventLocation += oListItemVenueItem["EventLocation"].ToString(); }
                            catch { }
                            try { EstTravel += oListItemVenueItem["EstTravel"].ToString(); }
                            catch { }
                            try { EstLaborOvertime += oListItemVenueItem["EstLaborOvertime"].ToString(); }
                            catch { }
                            try { Funding += oListItemVenueItem["Funding"].ToString(); }
                            catch { }

                            TextBox VenueCellTextBox = new TextBox();
                            TextBox TitleCellTextBox = new TextBox();
                            TextBox DatesCellTextBox = new TextBox();
                            TextBox PeopleCellTextBox = new TextBox();
                            TextBox EstTravelCellTextBox = new TextBox();
                            TextBox EventLocationCellTextBox = new TextBox();
                            TextBox EstLaborOvertimeCellTextBox = new TextBox();
                            TextBox FundingCellTextBox = new TextBox();

                            VenueCellTextBox.Width = 80;
                            TitleCellTextBox.Width = 80;
                            DatesCellTextBox.Width = 80;
                            PeopleCellTextBox.Width = 80;
                            EstTravelCellTextBox.Width = 80;
                            EventLocationCellTextBox.Width = 80;
                            EstLaborOvertimeCellTextBox.Width = 80;
                            FundingCellTextBox.Width = 80;


                            VenueCellTextBox.Text = Venue;
                            TitleCellTextBox.Text = Title;
                            DatesCellTextBox.Text = Dates;
                            PeopleCellTextBox.Text = People;
                            EstTravelCellTextBox.Text = EstTravel;
                            EventLocationCellTextBox.Text = EventLocation;
                            EstLaborOvertimeCellTextBox.Text = EstLaborOvertime;
                            FundingCellTextBox.Text = Funding;

                            VenueCellTextBox.ID = "rowId" + iid + "Venue";
                            TitleCellTextBox.ID = "rowId" + iid + "Title";
                            DatesCellTextBox.ID = "rowId" + iid + "Dates";
                            PeopleCellTextBox.ID = "rowId" + iid + "People"; 
                            EventLocationCellTextBox.ID = "rowId" + iid + "EventLocation";
                            EstTravelCellTextBox.ID = "rowId" + iid + "EstTravel";
                            EstLaborOvertimeCellTextBox.ID = "rowId" + iid + "EstLaborOvertime";
                            FundingCellTextBox.ID = "rowId" + iid + "Funding";

                            EstTravelCellTextBox.ToolTip = "Estimated Travel Costs";
                            EstLaborOvertimeCellTextBox.ToolTip = "Estimated Labor Overtime Costs";

                            VenueCell.Controls.Add(VenueCellTextBox);
                            TitleCell.Controls.Add(TitleCellTextBox);
                            DatesCell.Controls.Add(DatesCellTextBox);
                            PeopleCell.Controls.Add(PeopleCellTextBox);
                            EstTravelCell.Controls.Add(EstTravelCellTextBox);
                            EventLocationCell.Controls.Add(EventLocationCellTextBox);
                            EstLaborOvertimeCell.Controls.Add(EstLaborOvertimeCellTextBox);
                            FundingCell.Controls.Add(FundingCellTextBox);




                            rw.Cells.Add(VenueCell);
                            rw.Cells.Add(TitleCell);
                            rw.Cells.Add(DatesCell);
                            rw.Cells.Add(PeopleCell);
                            rw.Cells.Add(EventLocationCell);
                            rw.Cells.Add(EstTravelCell);
                            rw.Cells.Add(EstLaborOvertimeCell);
                            rw.Cells.Add(FundingCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Venue", Venue, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItemVenueItem["OTASubmissionID"] != null) { srcID = oListItemVenueItem["OTASubmissionID"].ToString(); }

                                string srcIDAO = "0";
                                if (oListItemVenueItem["AOReviewID"] != null) { srcIDAO = oListItemVenueItem["AOReviewID"].ToString(); }

                                if (IsDiff("Venue", Venue, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Venue", Venue, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    VenueCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    VenueCell.Style.Add("border-bottom", "solid");
                                    VenueCell.Style.Add("border-top", "solid");
                                    VenueCell.Style.Add("border-left", "solid");
                                    VenueCell.Style.Add("border-right", "solid");
                                    VenueCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Title", Title, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Title", Title, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    TitleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    TitleCell.Style.Add("border-bottom", "solid");
                                    TitleCell.Style.Add("border-top", "solid");
                                    TitleCell.Style.Add("border-left", "solid");
                                    TitleCell.Style.Add("border-right", "solid");
                                    TitleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("Dates", Dates, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    DatesCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    DatesCell.Style.Add("border-bottom", "solid");
                                    DatesCell.Style.Add("border-top", "solid");
                                    DatesCell.Style.Add("border-left", "solid");
                                    DatesCell.Style.Add("border-right", "solid");
                                    DatesCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("People", People, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    PeopleCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    PeopleCell.Style.Add("border-bottom", "solid");
                                    PeopleCell.Style.Add("border-top", "solid");
                                    PeopleCell.Style.Add("border-left", "solid");
                                    PeopleCell.Style.Add("border-right", "solid");
                                    PeopleCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstTravel", EstTravel, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstTravel", EstTravel, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstTravelCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstTravelCell.Style.Add("border-bottom", "solid");
                                    EstTravelCell.Style.Add("border-top", "solid");
                                    EstTravelCell.Style.Add("border-left", "solid");
                                    EstTravelCell.Style.Add("border-right", "solid");
                                    EstTravelCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EventLocation", EventLocation, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EventLocation", EventLocation, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EventLocationCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EventLocationCell.Style.Add("border-bottom", "solid");
                                    EventLocationCell.Style.Add("border-top", "solid");
                                    EventLocationCell.Style.Add("border-left", "solid");
                                    EventLocationCell.Style.Add("border-right", "solid");
                                    EventLocationCell.Style.Add("border-color", bdrcolor);
                                }
                                if (IsDiff("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, srcID))
                                {
                                    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                    string bdrcolor = getBdrcolor("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, qs_tab, srcID, srcIDAO, pmid);
                                    EstLaborOvertimeCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                    EstLaborOvertimeCell.Style.Add("border-bottom", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-top", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-left", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-right", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-color", bdrcolor);
                                }
                                //if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString()))
                                //{
                                //    string pmid = ""; if (oListItemVenueItem["PMReviewID"] != null) { pmid = oListItemVenueItem["PMReviewID"].ToString(); }
                                //    string bdrcolor = getBdrcolor("Funding", Funding, oList, qs_fy, qs_ws, qs_tab, oListItemVenueItem["OTASubmissionID"].ToString(), oListItemVenueItem["AOReviewID"].ToString(), pmid);
                                //    FundingCell.ToolTip = bdrcolor.Substring(7); bdrcolor = bdrcolor.Substring(0, 7);
                                //    FundingCell.Style.Add("border-bottom", "solid");
                                //    FundingCell.Style.Add("border-top", "solid");
                                //    FundingCell.Style.Add("border-left", "solid");
                                //    FundingCell.Style.Add("border-right", "solid");
                                //    FundingCell.Style.Add("border-color", bdrcolor);
                                //}
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string ApprovalCellText = "";
                            string CommentsCellText = "";
                            try
                            {
                                ApprovalCellText = "" + oListItemVenueItem["CONOPSApprovalPMReview"].ToString();
                                CommentsCellText = "" + oListItemVenueItem["CONOPSApprovalPMComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents15", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem ApprovalCellListItem1 = new ListItem();
                            ListItem ApprovalCellListItem2 = new ListItem();
                            ListItem ApprovalCellListItem3 = new ListItem();
                            ListItem ApprovalCellListItem4 = new ListItem();
                            ListItem ApprovalCellListItem5 = new ListItem();

                            ApprovalCellListItem1.Value = "Pending";
                            ApprovalCellListItem1.Text = "Pending";
                            ApprovalCellListItem1.Selected = true;

                            ApprovalCellListItem2.Value = "Approved";
                            ApprovalCellListItem2.Text = "Approved";

                            ApprovalCellListItem3.Value = "Approved With Comments";
                            ApprovalCellListItem3.Text = "Approved With Comments";

                            ApprovalCellListItem4.Value = "Approved With Revisions";
                            ApprovalCellListItem4.Text = "Approved With Revisions";

                            ApprovalCellListItem5.Value = "Not Approved";
                            ApprovalCellListItem5.Text = "Not Approved";



                            DropDownList ApprovalCellDropDownList = new DropDownList();
                            ApprovalCellDropDownList.CssClass = "CONOPSApprovalSelect";

                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem1);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem2);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem3);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem4);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem5);
                            ApprovalCellDropDownList.ID = "rowId" + iid + "CONOPSApprovalPMReview";


                            TextBox CommentsCellTextBox = new TextBox();
                            CommentsCellTextBox.TextMode = TextBoxMode.MultiLine;
                            CommentsCellTextBox.ID = "rowId" + iid + "CONOPSApprovalPMComments";


                            ApprovalCellDropDownList.SelectedValue = ApprovalCellText;
                            CommentsCellTextBox.Text = CommentsCellText;

                            ApprovalCell.Controls.Add(ApprovalCellDropDownList);
                            CommentsCell.Controls.Add(CommentsCellTextBox);
                            ApprovalCell.CssClass = "CONOPSApprovalCell";
                            CommentsCell.CssClass = "CONOPSApprovalCell";
                            //---------------


                            rw.Cells.Add(ApprovalCell);
                            rw.Cells.Add(CommentsCell);



                            rw.ToolTip = "Item";
                            //string dds1 = oListItemVenueItem["DateDraftSaved"].ToString();


                            //if (oListItemVenueItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            //{

                            //    rw.ToolTip = "NewEvent_" + Venue;


                            //}

                            traceInfo = "Adding row at VenueRowIndexForThis: " + VenueRowIndexForThis;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThis", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            CONOPSDevWSTable.Rows.AddAt(VenueRowIndexForThis, rw);
                        }

                    }
                }
                //end iterate through VenueSubTotals----



                try
                {
                    CONOPSDevWSTable.Controls.Remove(venueRow);
                    CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                int itemCount = 0;
                TableRow itemRowToUpdate = null;
                int rspan = 2;
                try
                {
                    foreach (TableRow row in rows)
                    {

                        traceInfo = "row.ToolTip: " + row.ToolTip + " itemCount: " + itemCount;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("itemRowToUpdate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            if (row.ToolTip == "Item")
                            {

                                if (itemRowToUpdate == null && itemCount < 1)
                                {

                                    itemRowToUpdate = row;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";
                                }
                                if (itemRowToUpdate != null && itemCount > 0)
                                {
                                    rspan = rspan + 1;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";

                                    row.Cells.RemoveAt(0);
                                }


                                itemCount = itemCount + 1;

                            }
                            else
                            {
                                itemRowToUpdate = null;
                                itemCount = 0;
                                rspan = 2;
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpansItems", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpans", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

            }
        }

        private void makeViewOrFormForAOReview(TableRow attachmentsRow, TableRow attachmentsValRow, TableCell totalRowCell1, Button AddVenueBtn, TableCell totalRowCell2, TableRow venueRow, TableRow venueSubTotalRow, TableCell totalRowCell3, TableCell totalRowCell4, TableRow attachDocRow)
        {
            var traceInfo = "makeViewOrFormForAOReview WS2";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_submitted = Page.Request.QueryString["submitted"];
            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_tab = Page.Request.QueryString["tab"];

            traceInfo = "qs_submitted: " + qs_submitted + " qs_otashort: " + qs_otashort + " qs_ws: " + qs_ws + " qs_fy: " + qs_fy + " qs_tab: " + qs_tab;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("makeViewOrFormForAOReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPWeb oWeb = SPContext.Current.Web;
            bool HasPMPreapprovalItems = false;

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And><Eq><FieldRef Name='CONOPSApproval'/><Value Type='Text'>PM Preapproval</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);
            if (collListItemsCONOPSApprovalProgress.Count > 0) { HasPMPreapprovalItems = true; }

            traceInfo = "HasPMPreapprovalItems: " + HasPMPreapprovalItems;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("makeViewOrFormForAOReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            SPQuery oQueryCONOPSApprovalProgress2 = new SPQuery();
            oQueryCONOPSApprovalProgress2.Query = "<Where><And><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And><Eq><FieldRef Name='CONOPSApproval'/><Value Type='Text'>Deputy Director Approval</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress2 = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress2);
            if (collListItemsCONOPSApprovalProgress2.Count > 0) { HasPMPreapprovalItems = true; }
            if (HasPMPreapprovalItems)
            {
                //HasPMPreapprovalItems is true so query where Submitted is Yes and display as view with no form controls
                CONOPSApprovalSaveButton.Visible = false;
                CheckBox1.Visible = false;
                CONOPSApprovalSaveButton1.Visible = false;
                CheckBox2.Visible = false;
                SaveDiv1.Visible = false;
                SaveDiv2.Visible = false;
                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int venueSubTotalRowIndex = 5;


                int attachmentIndex = 7;


                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "AO Recommendation")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalAOReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalAOComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }

                                attachmentsValRwCell2.Text = attachmentsValRwCell2Text;
                                attachmentsValRwCell3.Text = attachmentsValRwCell3Text;

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }





                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();

                oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                   
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">AO Recommendation</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                  
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

          

                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //oQuery to set vars.
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                string totalAsText = "Total";

                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();

                    //Only one Total
                    string id = oListItem.ID.ToString();
                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = oListItem[TotalGUID].ToString();
                            totalRowCell1.Controls.Remove(AddVenueBtn);

                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", totalRowCell2.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", totalRowCell2.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        totalRowCell2.Style.Add("border-bottom", "solid"); totalRowCell2.Style.Add("border-top", "solid"); totalRowCell2.Style.Add("border-left", "solid"); totalRowCell2.Style.Add("border-right", "solid"); totalRowCell2.Style.Add("border-color", "#ffdf73"); totalRowCell2.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}




                            if (totalAsText == title)
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents13", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                totalRowCell3.Text = totalRowCell3Text;
                                totalRowCell4.Text = totalRowCell4Text;
                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }










                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }

                //end Total------------

                //VenueSubTotal-------------this will get all Venue sections---------
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();

                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string id = oListItem.ID.ToString();

                    TableRow rw = new TableRow();

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        TableCell venueSubTotalCell1 = new TableCell();
                        TableCell venueSubTotalCell2 = new TableCell();
                        TableCell venueSubTotalCell3 = new TableCell();

                        TableCell venueSubTotalRwCell4 = new TableCell();
                        TableCell venueSubTotalRwCell5 = new TableCell();

                        //VenueCell.Style.Add("vertical-align", "middle");
                        //VenueCell.Style.Add("text-align", "center");

                        venueSubTotalCell1.ColumnSpan = 5;
                        venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");

                        venueSubTotalCell2.Style.Add("text-align", "right");
                        venueSubTotalCell2.Style.Add("font-weight", "bold");
                        venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell2.Text = "Sub-Total:​";

                        venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell3.Style.Add("text-align", "center");

                        //string Venue = "";
                        //try { Venue += oListItem["Venue"].ToString(); }
                        //catch { }
                        string VenueSubTotal = "";
                        try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                        catch { }

                        //VenueCell.Text = Venue;
                        venueSubTotalCell3.Text = VenueSubTotal;


                        //rw.Cells.Add(VenueCell);

                        rw.Cells.Add(venueSubTotalCell1);
                        rw.Cells.Add(venueSubTotalCell2);
                        rw.Cells.Add(venueSubTotalCell3);

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        venueSubTotalCell3.Style.Add("border-bottom", "solid");
                        //        venueSubTotalCell3.Style.Add("border-top", "solid");
                        //        venueSubTotalCell3.Style.Add("border-left", "solid");
                        //        venueSubTotalCell3.Style.Add("border-right", "solid");
                        //        venueSubTotalCell3.Style.Add("border-color", "#ffdf73");
                        //        venueSubTotalCell3.ToolTip = "See AO Review";
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}

                        //Approval

                        string venueSubTotalRwCell4Text = "";
                        string venueSubTotalRwCell5Text = "";
                        try
                        {
                            venueSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            venueSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents14", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        venueSubTotalRwCell4.CssClass = "CONOPSApprovalCell";
                        venueSubTotalRwCell5.CssClass = "CONOPSApprovalCell";
                        venueSubTotalRwCell4.Text = venueSubTotalRwCell4Text;
                        venueSubTotalRwCell5.Text = venueSubTotalRwCell5Text;
                        //---------------

                        rw.Cells.Add(venueSubTotalRwCell4);
                        rw.Cells.Add(venueSubTotalRwCell5);

                        rw.ID = "rowId" + id + "VenueSubTotal";

                        rw.ToolTip = oListItem["Venue"].ToString();

                        CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                    }

                }

                traceInfo = "endVenueSubTotal";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("endVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //end VenueSubTotal-----------



                //iterate through VenueSubTotals-----
                foreach (SPListItem oListItem in collListItems)
                {
                    traceInfo = "oListItem.Title: " + oListItem.Title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("iterVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        string Venue = oListItem["Venue"].ToString();
                        int VenueRowIndexForThisCounter = 0;
                        int VenueRowIndexForThis = 0;

                        traceInfo = "VenueTableRows next";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRows", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            foreach (TableRow VenueSubTotalRow in rows)
                            {
                                try
                                {
                                    if (VenueSubTotalRow.ID.Contains("VenueSubTotal"))
                                    {
                                        try
                                        {
                                            if (VenueSubTotalRow.ToolTip == Venue)
                                            {
                                                VenueRowIndexForThis = VenueRowIndexForThisCounter;
                                                //break;
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ToolTipVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IDVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                VenueRowIndexForThisCounter = VenueRowIndexForThisCounter + 1;
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        traceInfo = "VenueRowIndexForThis " + VenueRowIndexForThis;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThisq", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPQuery VenueItemQuery = new SPQuery();
                        VenueItemQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">AO Recommendation</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Neq>" +
                                    "<FieldRef Name=\"Title\"/>" +
                                    "<Value Type=\"Text\">VenueSubTotal</Value>" +
                                "</Neq>" +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Venue\"/>" +
                                    "<Value Type=\"Text\">" + Venue + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                        SPListItemCollection collListItemsVenueItems = oList.GetItems(VenueItemQuery);

                        traceInfo = "collListItemsVenueItems.Count: " + collListItemsVenueItems.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CountcollListItemsVenueItems", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        foreach (SPListItem oListItemVenueItem in collListItemsVenueItems)
                        {
                            //This will get the venue items as a group and render them as rows at the venue row index
                            //traceInfo = "oListItemVenueItem Venue" + oListItemVenueItem["Venue"] + " oListItemVenueItem.Title: " + oListItemVenueItem.Title;
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oListItemVenueItemVenueItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow rw = new TableRow();

                            string iid = oListItemVenueItem.ID.ToString();

                            TableCell VenueCell = new TableCell();
                            TableCell TitleCell = new TableCell();
                            TableCell DatesCell = new TableCell();
                            TableCell PeopleCell = new TableCell();
                            TableCell EventLocationCell = new TableCell();
                            TableCell EstTravelCell = new TableCell();
                            TableCell EstLaborOvertimeCell = new TableCell();
                            TableCell FundingCell = new TableCell();

                            TableCell ApprovalCell = new TableCell();
                            TableCell CommentsCell = new TableCell();

                            VenueCell.Style.Add("vertical-align", "middle");
                            VenueCell.Style.Add("text-align", "center");
                            TitleCell.Style.Add("text-align", "center");
                            DatesCell.Style.Add("text-align", "center");
                            PeopleCell.Style.Add("text-align", "center");
                            EventLocationCell.Style.Add("text-align", "center");
                            EstTravelCell.Style.Add("text-align", "center");
                            EstLaborOvertimeCell.Style.Add("text-align", "center");
                            FundingCell.Style.Add("text-align", "center");

                            //string Venue = "";
                            string Title = "";
                            string Dates = "";
                            string People = "";
                            string EventLocation = "";
                            string EstTravel = "";
                            string EstLaborOvertime = "";
                            string Funding = "";


                            //try { Venue += oListItemVenueItem["Venue"].ToString(); }
                            //catch { }
                            Title += oListItemVenueItem.Title;
                            try { Dates += oListItemVenueItem["Dates"].ToString(); }
                            catch { }
                            try { People += oListItemVenueItem["People"].ToString(); }
                            catch { }
                            try { EventLocation += oListItemVenueItem["EventLocation"].ToString(); }
                            catch { }
                            try { EstTravel += oListItemVenueItem["EstTravel"].ToString(); }
                            catch { }
                            try { EstLaborOvertime += oListItemVenueItem["EstLaborOvertime"].ToString(); }
                            catch { }
                            try { Funding += oListItemVenueItem["Funding"].ToString(); }
                            catch { }
                            VenueCell.Text = Venue;
                            TitleCell.Text = Title;
                            DatesCell.Text = Dates;
                            PeopleCell.Text = People;
                            EstTravelCell.Text = EstTravel;
                            EventLocationCell.Text = EventLocation;
                            EstLaborOvertimeCell.Text = EstLaborOvertime;
                            FundingCell.Text = Funding;

                            rw.Cells.Add(VenueCell);
                            rw.Cells.Add(TitleCell);
                            rw.Cells.Add(DatesCell);
                            rw.Cells.Add(PeopleCell);
                            rw.Cells.Add(EventLocationCell);
                            rw.Cells.Add(EstTravelCell);
                            rw.Cells.Add(EstLaborOvertimeCell);
                            rw.Cells.Add(FundingCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Venue", Venue, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                
                                string srcID = "0";
                                if (oListItemVenueItem["OTASubmissionID"] != null) { srcID = oListItemVenueItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Venue", Venue, oList, qs_fy, qs_ws, srcID))
                                {
                                    VenueCell.Style.Add("border-bottom", "solid");
                                    VenueCell.Style.Add("border-top", "solid");
                                    VenueCell.Style.Add("border-left", "solid");
                                    VenueCell.Style.Add("border-right", "solid");
                                    VenueCell.Style.Add("border-color", "#ffdf73");
                                    VenueCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Title", Title, oList, qs_fy, qs_ws, srcID))
                                {
                                    TitleCell.Style.Add("border-bottom", "solid");
                                    TitleCell.Style.Add("border-top", "solid");
                                    TitleCell.Style.Add("border-left", "solid");
                                    TitleCell.Style.Add("border-right", "solid");
                                    TitleCell.Style.Add("border-color", "#ffdf73");
                                    TitleCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                                {
                                    DatesCell.Style.Add("border-bottom", "solid");
                                    DatesCell.Style.Add("border-top", "solid");
                                    DatesCell.Style.Add("border-left", "solid");
                                    DatesCell.Style.Add("border-right", "solid");
                                    DatesCell.Style.Add("border-color", "#ffdf73");
                                    DatesCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                                {
                                    PeopleCell.Style.Add("border-bottom", "solid");
                                    PeopleCell.Style.Add("border-top", "solid");
                                    PeopleCell.Style.Add("border-left", "solid");
                                    PeopleCell.Style.Add("border-right", "solid");
                                    PeopleCell.Style.Add("border-color", "#ffdf73");
                                    PeopleCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("EstTravel", EstTravel, oList, qs_fy, qs_ws, srcID))
                                {
                                    EstTravelCell.Style.Add("border-bottom", "solid");
                                    EstTravelCell.Style.Add("border-top", "solid");
                                    EstTravelCell.Style.Add("border-left", "solid");
                                    EstTravelCell.Style.Add("border-right", "solid");
                                    EstTravelCell.Style.Add("border-color", "#ffdf73");
                                    EstTravelCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("EventLocation", EventLocation, oList, qs_fy, qs_ws, srcID))
                                {
                                    EventLocationCell.Style.Add("border-bottom", "solid");
                                    EventLocationCell.Style.Add("border-top", "solid");
                                    EventLocationCell.Style.Add("border-left", "solid");
                                    EventLocationCell.Style.Add("border-right", "solid");
                                    EventLocationCell.Style.Add("border-color", "#ffdf73");
                                    EventLocationCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, srcID))
                                {
                                    EstLaborOvertimeCell.Style.Add("border-bottom", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-top", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-left", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-right", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-color", "#ffdf73");
                                    EstLaborOvertimeCell.ToolTip = "See AO Review";
                                }
                                //if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString()))
                                //{
                                //    FundingCell.Style.Add("border-bottom", "solid");
                                //    FundingCell.Style.Add("border-top", "solid");
                                //    FundingCell.Style.Add("border-left", "solid");
                                //    FundingCell.Style.Add("border-right", "solid");
                                //    FundingCell.Style.Add("border-color", "#ffdf73");
                                //    FundingCell.ToolTip = "See AO Review";
                                //}
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string ApprovalCellText = "";
                            string CommentsCellText = "";
                            try
                            {
                                ApprovalCellText = "" + oListItemVenueItem["CONOPSApprovalAOReview"].ToString();
                                CommentsCellText = "" + oListItemVenueItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents15", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            ApprovalCell.CssClass = "CONOPSApprovalCell";
                            CommentsCell.CssClass = "CONOPSApprovalCell";
                            ApprovalCell.Text = ApprovalCellText;
                            CommentsCell.Text = CommentsCellText;
                            //---------------


                            rw.Cells.Add(ApprovalCell);
                            rw.Cells.Add(CommentsCell);



                            rw.ToolTip = "Item";
                            //string dds1 = oListItemVenueItem["DateDraftSaved"].ToString();


                            //if (oListItemVenueItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            //{

                            //    rw.ToolTip = "NewEvent_" + Venue;


                            //}

                            traceInfo = "Adding row at VenueRowIndexForThis: " + VenueRowIndexForThis;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThis", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            CONOPSDevWSTable.Rows.AddAt(VenueRowIndexForThis, rw);
                        }

                    }
                }
                //end iterate through VenueSubTotals----



                try
                {
                    CONOPSDevWSTable.Controls.Remove(attachDocRow);
                    CONOPSDevWSTable.Controls.Remove(venueRow);
                    CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                int itemCount = 0;
                TableRow itemRowToUpdate = null;
                int rspan = 2;
                try
                {
                    foreach (TableRow row in rows)
                    {

                        traceInfo = "row.ToolTip: " + row.ToolTip + " itemCount: " + itemCount;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("itemRowToUpdate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            if (row.ToolTip == "Item")
                            {

                                if (itemRowToUpdate == null && itemCount < 1)
                                {

                                    itemRowToUpdate = row;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";
                                }
                                if (itemRowToUpdate != null && itemCount > 0)
                                {
                                    rspan = rspan + 1;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";

                                    row.Cells.RemoveAt(0);
                                }


                                itemCount = itemCount + 1;

                            }
                            else
                            {
                                itemRowToUpdate = null;
                                itemCount = 0;
                                rspan = 2;
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpansItems", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpans", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                
            }
            else
            {                 
                //HasPMPreapprovalItems is false so query where Submitted is not Yes and display form controls

                TableRowCollection rows = CONOPSDevWSTable.Rows;

                int venueSubTotalRowIndex = 5;


                int attachmentIndex = 7;


                //------------- lib -----------------
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "AO Recommendation")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalAOReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalAOComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem attachmentsValRwCell2ListItem1 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem2 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem3 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem4 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem5 = new ListItem();

                                attachmentsValRwCell2ListItem1.Value = "Pending";
                                attachmentsValRwCell2ListItem1.Text = "Pending";
                                attachmentsValRwCell2ListItem1.Selected = true;

                                attachmentsValRwCell2ListItem2.Value = "Approved";
                                attachmentsValRwCell2ListItem2.Text = "Approved";

                                attachmentsValRwCell2ListItem3.Value = "Approved With Comments";
                                attachmentsValRwCell2ListItem3.Text = "Approved With Comments";

                                attachmentsValRwCell2ListItem4.Value = "Approved With Revisions";
                                attachmentsValRwCell2ListItem4.Text = "Approved With Revisions";

                                attachmentsValRwCell2ListItem5.Value = "Not Approved";
                                attachmentsValRwCell2ListItem5.Text = "Not Approved";


                                DropDownList attachmentsValRwCell2DropDownList = new DropDownList();
                                attachmentsValRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                                attachmentsValRwCell2DropDownList.ID = "attId" + id + "CONOPSApprovalAOReview";

                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem1);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem2);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem3);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem4);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem5);


                                TextBox attachmentsValRwCell3TextBox = new TextBox();
                                attachmentsValRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                                attachmentsValRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";

                                attachmentsValRwCell2DropDownList.SelectedValue = attachmentsValRwCell2Text;
                                attachmentsValRwCell3TextBox.Text = attachmentsValRwCell3Text;
                                attachmentsValRwCell3TextBox.ID = "attId" + id + "CONOPSApprovalAOComments";

                                attachmentsValRwCell2.Controls.Add(attachmentsValRwCell2DropDownList);
                                attachmentsValRwCell3.Controls.Add(attachmentsValRwCell3TextBox);

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }





                //------ list -----------------
                traceInfo = "getListItems: " + oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPQuery oQuery = new SPQuery();

                oQuery.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                                        //"<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">AO Recommendation</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Neq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                                        //"<IsNotNull>" +
                                        //        "<FieldRef Name=\"OTASubmissionID\"/>" +
                                        //    "</IsNotNull>" +
                                        //"</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                //oQuery.Query = "" +
                //            "<OrderBy>" +
                //                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                //            "</OrderBy>" +
                //            "<Where>" +
                //                "<And>" +
                //                "<And>" +
                //                    "<Eq>" +
                //                        "<FieldRef Name=\"FY\"/>" +
                //                        "<Value Type=\"Text\">" + Page.Request.QueryString["fy"] + "</Value>" +
                //                    "</Eq>" +
                //                    submittedCAML +
                //                "</And>" +
                //                    "<Eq>" +
                //                        "<FieldRef Name=\"ContentType\"/>" +
                //                        "<Value Type=\"Computed\">WS" + Page.Request.QueryString["ws"] + "</Value>" +
                //                    "</Eq>" +
                //                "</And>" +
                //            "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);

                //oQuery to set vars.
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                string totalAsText = "Total";

                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();

                    //Only one Total
                    string id = oListItem.ID.ToString();
                    if (totalRowCell2.Text == "0000")
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            totalRowCell2.Text = "";

                            TextBox totalRowCell2TextBox = new TextBox();
                            totalRowCell2TextBox.Width = 80;
                            totalRowCell2TextBox.Text = oListItem[TotalGUID].ToString();
                            totalRowCell2TextBox.ID = "rowId" + id + "Total";
                            totalRowCell2.Controls.Add(totalRowCell2TextBox);


                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", oListItem[TotalGUID].ToString(), oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        totalRowCell2.Style.Add("border-bottom", "solid");
                            //        totalRowCell2.Style.Add("border-top", "solid");
                            //        totalRowCell2.Style.Add("border-left", "solid");
                            //        totalRowCell2.Style.Add("border-right", "solid");
                            //        totalRowCell2.Style.Add("border-color", "#ffdf73");
                            //        totalRowCell2.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}




                            if (totalAsText == title)
                            {
                                //Approval

                                string totalRowCell3Text = "";
                                string totalRowCell4Text = "";
                                try
                                {
                                    totalRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                    totalRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents13", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem totalRowCell3ListItem1 = new ListItem();
                                ListItem totalRowCell3ListItem2 = new ListItem();
                                ListItem totalRowCell3ListItem3 = new ListItem();
                                ListItem totalRowCell3ListItem4 = new ListItem();
                                ListItem totalRowCell3ListItem5 = new ListItem();

                                totalRowCell3ListItem1.Value = "Pending";
                                totalRowCell3ListItem1.Text = "Pending";
                                totalRowCell3ListItem1.Selected = true;

                                totalRowCell3ListItem2.Value = "Approved";
                                totalRowCell3ListItem2.Text = "Approved";

                                totalRowCell3ListItem3.Value = "Approved With Comments";
                                totalRowCell3ListItem3.Text = "Approved With Comments";

                                totalRowCell3ListItem4.Value = "Approved With Revisions";
                                totalRowCell3ListItem4.Text = "Approved With Revisions";

                                totalRowCell3ListItem5.Value = "Not Approved";
                                totalRowCell3ListItem5.Text = "Not Approved";



                                DropDownList totalRowCell3DropDownList = new DropDownList();
                                totalRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                                totalRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem1);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem2);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem3);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem4);
                                totalRowCell3DropDownList.Items.Add(totalRowCell3ListItem5);


                                TextBox totalRowCell4TextBox = new TextBox();
                                totalRowCell4TextBox.TextMode = TextBoxMode.MultiLine;

                                totalRowCell3DropDownList.SelectedValue = totalRowCell3Text;
                                totalRowCell4TextBox.Text = totalRowCell4Text;
                                totalRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                                totalRowCell3.Controls.Add(totalRowCell3DropDownList);
                                totalRowCell4.Controls.Add(totalRowCell4TextBox);

                                //---------------

                                totalRowCell3.CssClass = "CONOPSApprovalCell";
                                totalRowCell4.CssClass = "CONOPSApprovalCell";

                            }










                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                }

                //end Total------------
           
                //VenueSubTotal-------------this will get all Venue sections---------
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();
                    
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    string id = oListItem.ID.ToString();

                    TableRow rw = new TableRow();

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        TableCell venueSubTotalCell1 = new TableCell();
                        TableCell venueSubTotalCell2 = new TableCell();
                        TableCell venueSubTotalCell3 = new TableCell();

                        TableCell venueSubTotalRwCell4 = new TableCell();
                        TableCell venueSubTotalRwCell5 = new TableCell();

               
                        venueSubTotalCell1.ColumnSpan = 5;
                        venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");


                        //----------------------AddActivityEventBtn------------
                        Button AddActivityEventBtn = new Button();
                        AddActivityEventBtn.Text = "Add Activity/Event";
                        AddActivityEventBtn.ToolTip = oListItem["Venue"].ToString();
                        AddActivityEventBtn.CssClass = "CONOPSApprovalAddActivityEventButton";
                        AddActivityEventBtn.OnClientClick = "return false";
                        AddActivityEventBtn.UseSubmitBehavior = false;
                        venueSubTotalCell1.Controls.Add(AddActivityEventBtn);
                        //-----------------------------------------------------


                        venueSubTotalCell2.Style.Add("text-align", "right");
                        venueSubTotalCell2.Style.Add("font-weight", "bold");
                        venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell2.Text = "Sub-Total:​";

                        venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                        venueSubTotalCell3.Style.Add("text-align", "center");

                     
                        string VenueSubTotal = "";
                        try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                        catch { }


                  

                  

                        TextBox venueSubTotalCell3TextBox = new TextBox();
                        venueSubTotalCell3TextBox.Width = 80;
                        venueSubTotalCell3TextBox.Text = VenueSubTotal;
                        venueSubTotalCell3TextBox.ID = "rowId" + id + "VenueSubTotal";

                        venueSubTotalCell3.Controls.Add(venueSubTotalCell3TextBox);


                      
                        rw.Cells.Add(venueSubTotalCell1);
                        rw.Cells.Add(venueSubTotalCell2);
                        rw.Cells.Add(venueSubTotalCell3);

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("VenueSubTotal", VenueSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        venueSubTotalCell3.Style.Add("border-bottom", "solid");
                        //        venueSubTotalCell3.Style.Add("border-top", "solid");
                        //        venueSubTotalCell3.Style.Add("border-left", "solid");
                        //        venueSubTotalCell3.Style.Add("border-right", "solid");
                        //        venueSubTotalCell3.Style.Add("border-color", "#ffdf73");
                        //        venueSubTotalCell3.ToolTip = "See AO Review";
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}

                        //Approval

                        string venueSubTotalRwCell4Text = "";
                        string venueSubTotalRwCell5Text = "";
                        try
                        {
                            venueSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            venueSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents14", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        ListItem venueSubTotalRwCell4ListItem1 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem2 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem3 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem4 = new ListItem();
                        ListItem venueSubTotalRwCell4ListItem5 = new ListItem();

                        venueSubTotalRwCell4ListItem1.Value = "Pending";
                        venueSubTotalRwCell4ListItem1.Text = "Pending";
                        venueSubTotalRwCell4ListItem1.Selected = true;

                        venueSubTotalRwCell4ListItem2.Value = "Approved";
                        venueSubTotalRwCell4ListItem2.Text = "Approved";

                        venueSubTotalRwCell4ListItem3.Value = "Approved With Comments";
                        venueSubTotalRwCell4ListItem3.Text = "Approved With Comments";

                        venueSubTotalRwCell4ListItem4.Value = "Approved With Revisions";
                        venueSubTotalRwCell4ListItem4.Text = "Approved With Revisions";

                        venueSubTotalRwCell4ListItem5.Value = "Not Approved";
                        venueSubTotalRwCell4ListItem5.Text = "Not Approved";



                        DropDownList venueSubTotalRwCell4DropDownList = new DropDownList();
                        venueSubTotalRwCell4DropDownList.CssClass = "CONOPSApprovalSelect";

                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem1);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem2);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem3);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem4);
                        venueSubTotalRwCell4DropDownList.Items.Add(venueSubTotalRwCell4ListItem5);
                        venueSubTotalRwCell4DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                        TextBox venueSubTotalRwCell5TextBox = new TextBox();
                        venueSubTotalRwCell5TextBox.TextMode = TextBoxMode.MultiLine;

                        venueSubTotalRwCell4DropDownList.SelectedValue = venueSubTotalRwCell4Text;
                        venueSubTotalRwCell5TextBox.Text = venueSubTotalRwCell5Text;
                        venueSubTotalRwCell5TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                        venueSubTotalRwCell4.Controls.Add(venueSubTotalRwCell4DropDownList);
                        venueSubTotalRwCell5.Controls.Add(venueSubTotalRwCell5TextBox);
                        venueSubTotalRwCell4.CssClass = "CONOPSApprovalCell"; venueSubTotalRwCell5.CssClass = "CONOPSApprovalCell";
                        //---------------

                        rw.Cells.Add(venueSubTotalRwCell4);
                        rw.Cells.Add(venueSubTotalRwCell5);

                        rw.ID = "rowId" + id + "VenueSubTotal";

                        rw.ToolTip = oListItem["Venue"].ToString();
                        rw.CssClass = "WSGroupEndRow";

                        CONOPSDevWSTable.Rows.AddAt(venueSubTotalRowIndex, rw);
                    }
                
                }
                
                traceInfo = "endVenueSubTotal";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("endVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //end VenueSubTotal-----------


                
                //iterate through VenueSubTotals-----
                foreach (SPListItem oListItem in collListItems)
                {
                    traceInfo = "oListItem.Title: " + oListItem.Title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("iterVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (oListItem.Title == "VenueSubTotal")
                    {
                        string Venue = oListItem["Venue"].ToString();
                        int VenueRowIndexForThisCounter = 0;
                        int VenueRowIndexForThis = 0;

                        traceInfo = "VenueTableRows next";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRows", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            foreach (TableRow VenueSubTotalRow in rows)
                            {
                                try
                                {
                                    if (VenueSubTotalRow.ID.Contains("VenueSubTotal"))
                                    {
                                        try
                                        {
                                            if (VenueSubTotalRow.ToolTip == Venue)
                                            {
                                                VenueRowIndexForThis = VenueRowIndexForThisCounter;
                                                //break;
                                            }
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ToolTipVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                        }
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IDVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                VenueRowIndexForThisCounter = VenueRowIndexForThisCounter + 1;
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        traceInfo = "VenueRowIndexForThis " + VenueRowIndexForThis;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThisq", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPQuery VenueItemQuery = new SPQuery();
                        VenueItemQuery.Query = ""+
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" + 
                            "<And>" +
                                "<And>" +
                                "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">AO Recommendation</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                            "<Neq>" +
                                    "<FieldRef Name=\"Title\"/>" +
                                    "<Value Type=\"Text\">VenueSubTotal</Value>" +
                                "</Neq>" +
                            "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Venue\"/>" +
                                    "<Value Type=\"Text\">" + Venue + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                        SPListItemCollection collListItemsVenueItems = oList.GetItems(VenueItemQuery);

                        traceInfo = "collListItemsVenueItems.Count: " + collListItemsVenueItems.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CountcollListItemsVenueItems", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        foreach(SPListItem oListItemVenueItem in collListItemsVenueItems)
                        {
                            //This will get the venue items as a group and render them as rows at the venue row index
                            //traceInfo = "oListItemVenueItem Venue" + oListItemVenueItem["Venue"] + " oListItemVenueItem.Title: " + oListItemVenueItem.Title;
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oListItemVenueItemVenueItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            TableRow rw = new TableRow();

                            string iid = oListItemVenueItem.ID.ToString();

                            TableCell VenueCell = new TableCell();
                            TableCell TitleCell = new TableCell();
                            TableCell DatesCell = new TableCell();
                            TableCell PeopleCell = new TableCell();
                            TableCell EventLocationCell = new TableCell();
                            TableCell EstTravelCell = new TableCell();
                            TableCell EstLaborOvertimeCell = new TableCell();
                            TableCell FundingCell = new TableCell();

                            TableCell ApprovalCell = new TableCell();
                            TableCell CommentsCell = new TableCell();

                            VenueCell.Style.Add("vertical-align", "middle");
                            VenueCell.Style.Add("text-align", "center");
                            TitleCell.Style.Add("text-align", "center");
                            DatesCell.Style.Add("text-align", "center");
                            PeopleCell.Style.Add("text-align", "center");
                            EventLocationCell.Style.Add("text-align", "center");
                            EstTravelCell.Style.Add("text-align", "center");
                            EstLaborOvertimeCell.Style.Add("text-align", "center");
                            FundingCell.Style.Add("text-align", "center");

                            //string Venue = "";
                            string Title = "";
                            string Dates = "";
                            string People = "";
                            string EventLocation = "";
                            string EstTravel = "";
                            string EstLaborOvertime = "";
                            string Funding = "";


                            //try { Venue += oListItemVenueItem["Venue"].ToString(); }
                            //catch { }
                            Title += oListItemVenueItem.Title;
                            try { Dates += oListItemVenueItem["Dates"].ToString(); }
                            catch { }
                            try { People += oListItemVenueItem["People"].ToString(); }
                            catch { }
                            try { EventLocation += oListItemVenueItem["EventLocation"].ToString(); }
                            catch { }
                            try { EstTravel += oListItemVenueItem["EstTravel"].ToString(); }
                            catch { }
                            try { EstLaborOvertime += oListItemVenueItem["EstLaborOvertime"].ToString(); }
                            catch { }
                            try { Funding += oListItemVenueItem["Funding"].ToString(); }
                            catch { }

                            TextBox VenueCellTextBox = new TextBox();
                            TextBox TitleCellTextBox = new TextBox();
                            TextBox DatesCellTextBox = new TextBox();
                            TextBox PeopleCellTextBox = new TextBox();
                            TextBox EstTravelCellTextBox = new TextBox();
                            TextBox EventLocationCellTextBox = new TextBox();
                            TextBox EstLaborOvertimeCellTextBox = new TextBox();
                            TextBox FundingCellTextBox = new TextBox();

                            VenueCellTextBox.Width = 80;
                            TitleCellTextBox.Width = 80;
                            DatesCellTextBox.Width = 80;
                            PeopleCellTextBox.Width = 80;
                            EstTravelCellTextBox.Width = 80;
                            EventLocationCellTextBox.Width = 80;
                            EstLaborOvertimeCellTextBox.Width = 80;
                            FundingCellTextBox.Width = 80;


                            VenueCellTextBox.Text = Venue;
                            TitleCellTextBox.Text = Title;
                            DatesCellTextBox.Text = Dates;
                            PeopleCellTextBox.Text = People;
                            EstTravelCellTextBox.Text = EstTravel;
                            EventLocationCellTextBox.Text = EventLocation;
                            EstLaborOvertimeCellTextBox.Text = EstLaborOvertime;
                            FundingCellTextBox.Text = Funding;

                            VenueCellTextBox.ID = "rowId" + iid + "Venue";
                            TitleCellTextBox.ID = "rowId" + iid + "Title";
                            DatesCellTextBox.ID = "rowId" + iid + "Dates";
                            PeopleCellTextBox.ID = "rowId" + iid + "People";
                            EventLocationCellTextBox.ID = "rowId" + iid + "EventLocation";
                            EstTravelCellTextBox.ID = "rowId" + iid + "EstTravel";
                            EstLaborOvertimeCellTextBox.ID = "rowId" + iid + "EstLaborOvertime";
                            FundingCellTextBox.ID = "rowId" + iid + "Funding";

                            EstTravelCellTextBox.ToolTip = "Estimated Travel Costs";
                            EstLaborOvertimeCellTextBox.ToolTip = "Estimated Labor Overtime Costs";


                            VenueCell.Controls.Add(VenueCellTextBox);
                            TitleCell.Controls.Add(TitleCellTextBox);
                            DatesCell.Controls.Add(DatesCellTextBox);
                            PeopleCell.Controls.Add(PeopleCellTextBox);
                            EstTravelCell.Controls.Add(EstTravelCellTextBox);
                            EventLocationCell.Controls.Add(EventLocationCellTextBox);
                            EstLaborOvertimeCell.Controls.Add(EstLaborOvertimeCellTextBox);
                            FundingCell.Controls.Add(FundingCellTextBox);




                            rw.Cells.Add(VenueCell);
                            rw.Cells.Add(TitleCell);
                            rw.Cells.Add(DatesCell);
                            rw.Cells.Add(PeopleCell);
                            rw.Cells.Add(EventLocationCell);
                            rw.Cells.Add(EstTravelCell);
                            rw.Cells.Add(EstLaborOvertimeCell);
                            rw.Cells.Add(FundingCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Venue", Venue, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                
                                string srcID = "0";
                                if (oListItemVenueItem["OTASubmissionID"] != null) { srcID = oListItemVenueItem["OTASubmissionID"].ToString(); }


                                if (IsDiff("Venue", Venue, oList, qs_fy, qs_ws, srcID))
                                {
                                    VenueCell.Style.Add("border-bottom", "solid");
                                    VenueCell.Style.Add("border-top", "solid");
                                    VenueCell.Style.Add("border-left", "solid");
                                    VenueCell.Style.Add("border-right", "solid");
                                    VenueCell.Style.Add("border-color", "#ffdf73");
                                    //VenueCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Title", Title, oList, qs_fy, qs_ws, srcID))
                                {
                                    TitleCell.Style.Add("border-bottom", "solid");
                                    TitleCell.Style.Add("border-top", "solid");
                                    TitleCell.Style.Add("border-left", "solid");
                                    TitleCell.Style.Add("border-right", "solid");
                                    TitleCell.Style.Add("border-color", "#ffdf73");
                                    TitleCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Dates", Dates, oList, qs_fy, qs_ws, srcID))
                                {
                                    DatesCell.Style.Add("border-bottom", "solid");
                                    DatesCell.Style.Add("border-top", "solid");
                                    DatesCell.Style.Add("border-left", "solid");
                                    DatesCell.Style.Add("border-right", "solid");
                                    DatesCell.Style.Add("border-color", "#ffdf73");
                                    DatesCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("People", People, oList, qs_fy, qs_ws, srcID))
                                {
                                    PeopleCell.Style.Add("border-bottom", "solid");
                                    PeopleCell.Style.Add("border-top", "solid");
                                    PeopleCell.Style.Add("border-left", "solid");
                                    PeopleCell.Style.Add("border-right", "solid");
                                    PeopleCell.Style.Add("border-color", "#ffdf73");
                                    PeopleCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("EstTravel", EstTravel, oList, qs_fy, qs_ws, srcID))
                                {
                                    EstTravelCell.Style.Add("border-bottom", "solid");
                                    EstTravelCell.Style.Add("border-top", "solid");
                                    EstTravelCell.Style.Add("border-left", "solid");
                                    EstTravelCell.Style.Add("border-right", "solid");
                                    EstTravelCell.Style.Add("border-color", "#ffdf73");
                                    EstTravelCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("EventLocation", EventLocation, oList, qs_fy, qs_ws, srcID))
                                {
                                    EventLocationCell.Style.Add("border-bottom", "solid");
                                    EventLocationCell.Style.Add("border-top", "solid");
                                    EventLocationCell.Style.Add("border-left", "solid");
                                    EventLocationCell.Style.Add("border-right", "solid");
                                    EventLocationCell.Style.Add("border-color", "#ffdf73");
                                    EventLocationCell.ToolTip = "See AO Review";
                                }
                                if (IsDiff("EstLaborOvertime", EstLaborOvertime, oList, qs_fy, qs_ws, srcID))
                                {
                                    EstLaborOvertimeCell.Style.Add("border-bottom", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-top", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-left", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-right", "solid");
                                    EstLaborOvertimeCell.Style.Add("border-color", "#ffdf73");
                                    EstLaborOvertimeCell.ToolTip = "See AO Review";
                                }
                                //if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, oListItemVenueItem["OTASubmissionID"].ToString()))
                                //{
                                //    FundingCell.Style.Add("border-bottom", "solid");
                                //    FundingCell.Style.Add("border-top", "solid");
                                //    FundingCell.Style.Add("border-left", "solid");
                                //    FundingCell.Style.Add("border-right", "solid");
                                //    FundingCell.Style.Add("border-color", "#ffdf73");
                                //    FundingCell.ToolTip = "See AO Review";
                                //}
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string ApprovalCellText = "";
                            string CommentsCellText = "";
                            try
                            {
                                ApprovalCellText = "" + oListItemVenueItem["CONOPSApprovalAOReview"].ToString();
                                CommentsCellText = "" + oListItemVenueItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents15", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem ApprovalCellListItem1 = new ListItem();
                            ListItem ApprovalCellListItem2 = new ListItem();
                            ListItem ApprovalCellListItem3 = new ListItem();
                            ListItem ApprovalCellListItem4 = new ListItem();
                            ListItem ApprovalCellListItem5 = new ListItem();

                            ApprovalCellListItem1.Value = "Pending";
                            ApprovalCellListItem1.Text = "Pending";
                            ApprovalCellListItem1.Selected = true;

                            ApprovalCellListItem2.Value = "Approved";
                            ApprovalCellListItem2.Text = "Approved";

                            ApprovalCellListItem3.Value = "Approved With Comments";
                            ApprovalCellListItem3.Text = "Approved With Comments";

                            ApprovalCellListItem4.Value = "Approved With Revisions";
                            ApprovalCellListItem4.Text = "Approved With Revisions";

                            ApprovalCellListItem5.Value = "Not Approved";
                            ApprovalCellListItem5.Text = "Not Approved";



                            DropDownList ApprovalCellDropDownList = new DropDownList();
                            ApprovalCellDropDownList.CssClass = "CONOPSApprovalSelect";

                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem1);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem2);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem3);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem4);
                            ApprovalCellDropDownList.Items.Add(ApprovalCellListItem5);
                            ApprovalCellDropDownList.ID = "rowId" + iid + "CONOPSApprovalAOReview";


                            TextBox CommentsCellTextBox = new TextBox();
                            CommentsCellTextBox.TextMode = TextBoxMode.MultiLine;
                            CommentsCellTextBox.ID = "rowId" + iid + "CONOPSApprovalAOComments";


                            ApprovalCellDropDownList.SelectedValue = ApprovalCellText;
                            CommentsCellTextBox.Text = CommentsCellText;

                            ApprovalCell.Controls.Add(ApprovalCellDropDownList);
                            CommentsCell.Controls.Add(CommentsCellTextBox);
                            ApprovalCell.CssClass = "CONOPSApprovalCell";
                            CommentsCell.CssClass = "CONOPSApprovalCell";
                            //---------------


                            rw.Cells.Add(ApprovalCell);
                            rw.Cells.Add(CommentsCell);


                           
                            rw.ToolTip = "Item";
                            //string dds1 = oListItemVenueItem["DateDraftSaved"].ToString();


                            //if (oListItemVenueItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            //{

                            //    rw.ToolTip = "NewEvent_" + Venue;


                            //}

                            traceInfo = "Adding row at VenueRowIndexForThis: " + VenueRowIndexForThis;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThis", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            
                            CONOPSDevWSTable.Rows.AddAt(VenueRowIndexForThis, rw);
                        }
                    
                    }
                }
                //end iterate through VenueSubTotals----

                

                try
                {
                    CONOPSDevWSTable.Controls.Remove(venueRow);
                    CONOPSDevWSTable.Controls.Remove(venueSubTotalRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                int itemCount = 0;
                TableRow itemRowToUpdate = null;
                int rspan = 2;
                try
                {
                    foreach (TableRow row in rows)
                    {

                        traceInfo = "row.ToolTip: " + row.ToolTip + " itemCount: " + itemCount;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("itemRowToUpdate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            if (row.ToolTip == "Item")
                            {
                              
                                if (itemRowToUpdate == null && itemCount < 1)
                                {

                                    itemRowToUpdate = row;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";
                                }
                                if (itemRowToUpdate != null && itemCount > 0)
                                {
                                    rspan = rspan + 1;
                                    itemRowToUpdate.Cells[0].RowSpan = rspan;
                                    itemRowToUpdate.Cells[0].ToolTip = "Venue";

                                    row.Cells.RemoveAt(0);
                                }


                                itemCount = itemCount + 1;

                            }
                            else
                            {
                                itemRowToUpdate = null;
                                itemCount = 0;
                                rspan = 2;
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpansItems", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpans", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

            }
        }


        protected void CONOPSApprovalSaveButton_Click(object sender, EventArgs e)
        {
            var traceInfo = "CONOPSApprovalSaveButton_Click " + Page.Request.QueryString["otashort"];
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPWeb oWeb = SPContext.Current.Web;
            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

            traceInfo = "oWeb: " + oWeb.Title + " oList: " + oList.Title;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_tab = Page.Request.QueryString["tab"];


            if (Page.Request.QueryString["tab"] == "AOReview")
            {
                qs_tab = "AO Recommendation";
            }
            if (Page.Request.QueryString["tab"] == "PMReview")
            {
                qs_tab = "PM Preapproval";
            }
            if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
            {
                qs_tab = "Deputy Director Approval";
            }  


            if (HttpContext.Current != null)
            {
                if (Page.Response != null)
                {

                    var response = Page.Response;
                    var request = HttpContext.Current.Request;
                    NameValueCollection coll;
                    coll = request.Form;

                    traceInfo = "got coll.Count: " + coll.Count;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                    string pattern = @"\D";
                    Regex rgx = new Regex(pattern);
                    string pattern2 = @"\d";
                    Regex rgx2 = new Regex(pattern2);

                    foreach (String s in coll.AllKeys)
                    {

                        traceInfo = "s: " + s + " coll[s] " + coll[s];
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (s.Contains("rowId"))
                        {

                            string rowId = s.Substring(s.IndexOf("rowId") + 5);

                            string fieldName = rgx2.Replace(rowId, "");

                            rowId = rgx.Replace(rowId, "");

                            string fieldValue = coll[s];

                            traceInfo = "rowId: " + rowId + " fieldName: " + fieldName + " fieldValue: " + fieldValue;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        }
                        //attachments must update oLib not oList
                        if (s.Contains("attId"))
                        {
                            string attId = s.Substring(s.IndexOf("attId") + 5);

                            string attfieldName = rgx2.Replace(attId, "");

                            attId = rgx.Replace(attId, "");

                            string attfieldValue = coll[s];

                            updateoLibItem(attId, attfieldName, attfieldValue);

                        }
                    }

                    SPQuery oQuery2 = new SPQuery();
                    oQuery2.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">" + qs_tab + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Neq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems2 = oList.GetItems(oQuery2);
                    foreach (SPListItem oListItem in collListItems2)
                    {

                        string id = oListItem.ID.ToString();
                        string rrowId = "rowId" + id;

                        Dictionary<string, string> worksheetFieldsDictionary = new Dictionary<string, string>();

                        foreach (String s in coll.AllKeys)
                        {

                            if (s.Contains(rrowId))
                            {

                                string fieldNameValue = s.Substring(s.IndexOf("rowId") + 5);

                                string fieldName = rgx2.Replace(fieldNameValue, "");
                                string fieldValue = coll[s];

                                worksheetFieldsDictionary.Add(fieldName, fieldValue);


                            }

                        }

                        updateoListItem(id, worksheetFieldsDictionary);

                    }

                }
            }



        }

        private void updateoLibItem(string attId, string attfieldName, string attfieldValue)
        {
            try
            {
                int iid = Int32.Parse(attId);

                SPWeb oWeb = SPContext.Current.Web;
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);

                SPListItem oLibItem = oLib.GetItemById(iid);

                oLibItem[attfieldName] = attfieldValue;
                oWeb.AllowUnsafeUpdates = true;
                oLibItem.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoLibItem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

        private void updateoListItem(string id, Dictionary<string, string> worksheetFieldsDictionary)
        {
            try
            {
                int iid = Int32.Parse(id);

                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPListItem oListItem = oList.GetItemById(iid);

                foreach (KeyValuePair<string, string> kvp in worksheetFieldsDictionary)
                {
                    oListItem[kvp.Key] = kvp.Value;
                }
                oWeb.AllowUnsafeUpdates = true;
                oListItem.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoListItem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox submitCheckBox = sender as CheckBox;
            var traceInfo = "submitCheckBox.Checked: " + submitCheckBox.Checked;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_ws = Page.Request.QueryString["ws"];

            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16

            SPUser user;

            DateTime DateDraftSaved = DateTime.Now;

        

            if (submitCheckBox.Checked)
            {

                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);

                traceInfo = "oWeb: " + oWeb.Title + " oList: " + oList.Title;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                HasNoPendingItems.Value = "true";


                if (HttpContext.Current != null)
                {
                    if (Page.Response != null)
                    {

                        var response = Page.Response;
                        var request = HttpContext.Current.Request;
                        NameValueCollection coll;
                        coll = request.Form;

                        traceInfo = "got coll.Count: " + coll.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string pattern = @"\D";
                        Regex rgx = new Regex(pattern);
                        string pattern2 = @"\d";
                        Regex rgx2 = new Regex(pattern2);

                        foreach (String s in coll.AllKeys)
                        {

                            //traceInfo = "s: " + s + " coll[s] " + coll[s];
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            if (coll[s] == "Pending")
                            {
                                traceInfo = "s: " + s + " coll[s] " + coll[s];
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                HasNoPendingItems.Value = "false";

                            }



                        }


                    }

                    if (HasNoPendingItems.Value == "true")
                    {
                        //do ops

                        user = oWeb.CurrentUser;

                        string tab = "";
                        string nexttab = "";
                        string AORecommendation = "AO Recommendation";
                        string PMPreapproval = "PM Preapproval";
                        string DRApproval = "Deputy Director Approval";

                        if (Page.Request.QueryString["tab"] == "AOReview")
                        {
                            tab = AORecommendation; nexttab = PMPreapproval;
                        }
                        if (Page.Request.QueryString["tab"] == "PMReview")
                        {
                            tab = PMPreapproval; nexttab = DRApproval;
                        }
                        if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
                        {
                            tab = DRApproval;
                        }


                        
                        try
                        {

                        //------------- lib -----------------
                        //return the docs, not the versions, in this case
                        SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);

                        SPQuery oLibQuery = new SPQuery();

                        oLibQuery.Query = "" +
                             "<OrderBy>" +
                                 "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                             "</OrderBy>" +
                             "<Where>" +

                             "<And><And>" +
                                     "<Eq>" +
                                         "<FieldRef Name=\"FY\"/>" +
                                         "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                     "</Eq>" +
                                      "<Eq>" +
                                         "<FieldRef Name=\"WS\"/>" +
                                         "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                                     "</Eq>" +
                                 "</And>" +
                                   "<Neq>" +
                                         "<FieldRef Name=\"Submitted\"/>" +
                                         "<Value Type=\"Text\">Yes</Value>" +
                                     "</Neq>" +
                                 "</And>" +
                             "</Where>";

                        SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                        List<string> itemsForSecondPass = new List<string>();

                        foreach (SPListItem oListItem in collLibItems)
                        {
                            itemsForSecondPass.Add(oListItem.ID.ToString());

                            oListItem["Submitted"] = "Yes";
                            oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                            string SubmittedBy = user.ID + ";#" + user.LoginName;
                            oListItem["SubmittedBy"] = SubmittedBy;
                            oListItem["SubmittedOn"] = DateDraftSaved;
                            oListItem["CONOPSApproval"] = tab;

                            oWeb.AllowUnsafeUpdates = true;

                            oListItem.Update();
                        }
                        //=====UPDATE METADATA AGAIN ====
                        if (Page.Request.QueryString["tab"] != "DeputyDirectorReviewandApproval") //DeputyDirectorReviewandApproval
                        {
                            foreach (string itemForSecondPass in itemsForSecondPass)
                            {
                                SPListItem oitemForSecondPass = oLib.GetItemById(Int32.Parse(itemForSecondPass));

                                oitemForSecondPass["Submitted"] = "";
                                oitemForSecondPass["SubmittedFY"] = "";
                                oitemForSecondPass["SubmittedBy"] = "";
                                oitemForSecondPass["SubmittedOn"] = "";
                                oitemForSecondPass["CONOPSApproval"] = nexttab;

                                oWeb.AllowUnsafeUpdates = true;

                                oitemForSecondPass.Update();
                            }
                        }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("submitAttachments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }









                        //List
                        SPQuery oQuery = new SPQuery();
                        oQuery.Query = "" +
                                    "<OrderBy>" +
                                        "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                    "</OrderBy>" +
                                    "<Where>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<And>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"OTA\"/>" +
                                                        "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                    "</Eq>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"FY\"/>" +
                                                        "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                    "</Eq>" +
                                                "</And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                    "<Value Type=\"Text\">" + tab + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Neq>" +
                                                "<FieldRef Name=\"Submitted\"/>" +
                                                "<Value Type=\"Text\">Yes</Value>" +
                                            "</Neq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"ContentType\"/>" +
                                            "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                "</Where>";


                        SPListItemCollection collListItems = oList.GetItems(oQuery);

                        foreach (SPListItem oListItem in collListItems)
                        {

                            try
                            {
                                traceInfo = "Item ID being marked Submitted is Yes: " + oListItem.ID;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                             

                                oListItem["Submitted"] = "Yes";
                                oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                string SubmittedBy = user.ID + ";#" + user.LoginName;
                                oListItem["SubmittedBy"] = SubmittedBy;
                                oListItem["SubmittedOn"] = DateDraftSaved;
                                oWeb.AllowUnsafeUpdates = true;
                                oListItem.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                        if (Page.Request.QueryString["tab"] != "DeputyDirectorReviewandApproval")
                        {

                            traceInfo = "CONOPSDevDuplicate";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            try
                            {



                                SPQuery oQuery2 = new SPQuery();
                                oQuery2.Query = "" +
                                            "<OrderBy>" +
                                                "<FieldRef Name=\"ID\" Ascending=\"TRUE\"/>" +
                                            "</OrderBy>" +
                                            "<Where>" +
                                            "<And>" +
                                                "<And>" +
                                                    "<And>" +
                                                        "<And>" +
                                                            "<Eq>" +
                                                                "<FieldRef Name=\"OTA\"/>" +
                                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                            "</Eq>" +
                                                            "<Eq>" +
                                                                "<FieldRef Name=\"FY\"/>" +
                                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                            "</Eq>" +
                                                        "</And>" +
                                                        "<Eq>" +
                                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                            "<Value Type=\"Text\">" + tab + "</Value>" +
                                                        "</Eq>" +
                                                    "</And>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"Submitted\"/>" +
                                                        "<Value Type=\"Text\">Yes</Value>" +
                                                    "</Eq>" +
                                                "</And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"ContentType\"/>" +
                                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                        "</Where>";

                                SPListItemCollection collListItems2 = oList.GetItems(oQuery2);
                                foreach (SPListItem oListItem in collListItems2)
                                {

                                    SPListItem newListItem = oList.Items.Add();
                                    newListItem["ContentTypeId"] = oListItem.ContentTypeId;
                                    newListItem["Title"] = oListItem["Title"].ToString();
                                    newListItem["CONOPSApproval"] = nexttab;


                                    if (oListItem["Dates"] != null) { newListItem["Dates"] = oListItem["Dates"].ToString(); }
                                    if (oListItem["People"] != null) { newListItem["People"] = oListItem["People"].ToString(); }
                                    if (oListItem["EventLocation"] != null) { newListItem["EventLocation"] = oListItem["EventLocation"].ToString(); }
                                    if (oListItem["EstTravel"] != null) { newListItem["EstTravel"] = oListItem["EstTravel"].ToString(); }
                                    if (oListItem["EstLaborOvertime"] != null) { newListItem["EstLaborOvertime"] = oListItem["EstLaborOvertime"].ToString(); }
                                    if (oListItem["Funding"] != null) { newListItem["Funding"] = oListItem["Funding"].ToString(); }
                                    if (oListItem["Venue"] != null) { newListItem["Venue"] = oListItem["Venue"].ToString(); }
                                    if (oListItem["Total"] != null) { newListItem["Total"] = oListItem["Total"].ToString(); }
                                    if (oListItem["VenueSubTotal"] != null) { newListItem["VenueSubTotal"] = oListItem["VenueSubTotal"].ToString(); }
                                    if (oListItem["OTA"] != null) { newListItem["OTA"] = oListItem["OTA"].ToString(); }
                                    if (oListItem["FY"] != null) { newListItem["FY"] = oListItem["FY"].ToString(); }


                                    if (oListItem["DateDraftSaved"] != null) { newListItem["DateDraftSaved"] = oListItem["DateDraftSaved"]; }
                                    if (oListItem["TimeDraftSaved"] != null) { newListItem["TimeDraftSaved"] = oListItem["TimeDraftSaved"]; }
                                    if (oListItem["DraftSavedBy"] != null) { newListItem["DraftSavedBy"] = oListItem["DraftSavedBy"]; }


                                    if (oListItem["OTASubmissionID"] != null) { newListItem["OTASubmissionID"] = oListItem["OTASubmissionID"].ToString(); }
                                    if (oListItem["AOReviewID"] != null) { newListItem["AOReviewID"] = oListItem["AOReviewID"].ToString(); }
                                    if (oListItem["PMReviewID"] != null) { newListItem["PMReviewID"] = oListItem["PMReviewID"].ToString(); }


                                    ////Set Approvals to selected value
                                    //if (Page.Request.QueryString["tab"] == "AOReview")
                                    //{
                                    //    newListItem["AOReviewID"] = oListItem.ID.ToString();
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalPMReview"] = oListItem["CONOPSApprovalAOReview"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AOReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalPMComments"] = oListItem["CONOPSApprovalAOComments"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AOReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //}
                                    //if (Page.Request.QueryString["tab"] == "PMReview")
                                    //{
                                    //    newListItem["PMReviewID"] = oListItem.ID.ToString();
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalDRReview"] = oListItem["CONOPSApprovalPMReview"].ToString();

                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("PMReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalDRComments"] = oListItem["CONOPSApprovalPMComments"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("PMReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //}


                                    oWeb.AllowUnsafeUpdates = true;

                                    newListItem.Update();

                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //----- CONOPSAPPROVALPROGRESS update -----

                            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];

                            traceInfo = "got CONOPSApprovalProgress: " + CONOPSApprovalProgress.Title;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
                                oQueryCONOPSApprovalProgress.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

                                foreach (SPListItem oListItem in collListItemsCONOPSApprovalProgress)
                                {
                                    oListItem["CONOPSApproval"] = nexttab;

                                    traceInfo = "Update CONOPSApprovalProgress list for OTA: " + qs_otashort + " and WS: " + oListItem.Title;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    oWeb.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }
                        else //tab is DeputyDirectorReviewandApproval
                        {
                            //update CONOPSApprovalProgress to show submitted

                            SPList oListCONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
                            try
                            {
                                SPQuery oQueryCONOPSApprovalProgressGeneral = new SPQuery();
                                oQueryCONOPSApprovalProgressGeneral.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";

                                SPListItemCollection collItemsSubmittedGeneral = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressGeneral);

                                foreach (SPListItem oListItem in collItemsSubmittedGeneral)
                                {


                                    traceInfo = "Update to Submitted CONOPSApprovalProgress list for OTA: " + qs_otashort + " and WS: " + oListItem.Title;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oWeb.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmitDDtab", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }





                    }

                }









            }
        }
        private static string getBdrcolor(string fieldName, string fieldValue, SPList oList, string qs_fy, string qs_ws, string qs_tab, string OTASubmissionID, string AOReviewID, string PMReviewID)
        {
            var traceInfo = "call to getBdrcolor fieldName: " + fieldName + " fieldValue: " + fieldValue + " AOReviewID:" + AOReviewID;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("getBdrcolor", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string colorHex = "";
            if (qs_tab == "PMReview")
            {
                colorHex = "#b5a2c6See PM Review"; //PM Review blue
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                    "<Where>" +
                    "<Eq><FieldRef Name='ID'/><Value Type='Text'>" + AOReviewID + "</Value></Eq>" +
                    "</Where>";
                SPListItemCollection collistitems = oList.GetItems(oQuery);
                foreach (SPListItem oListItem in collistitems)
                {
                    if (oListItem[fieldName].ToString() == fieldValue)
                    {
                        colorHex = "#ffdf73See AO Review"; // yellow AOReview 
                        traceInfo = "yep";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("getBdrcolor", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                }

            }


            if (qs_tab == "DeputyDirectorReviewandApproval")
            {
                colorHex = "#94cb5aSee Deputy Director Review and Approval"; //DeputyDirectorReviewandApproval green               
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                    "<Where>" +
                    "<Eq><FieldRef Name='ID'/><Value Type='Text'>" + PMReviewID + "</Value></Eq>" +
                    "</Where>";
                SPListItemCollection collistitems = oList.GetItems(oQuery);
                foreach (SPListItem oListItem in collistitems)
                {
                    if (oListItem[fieldName].ToString() == fieldValue)
                    {
                        colorHex = "#b5a2c6See PM Review"; //PM Review blue                    
                    }
                }

            }


            return colorHex;
        }



        private static bool IsDiff(string fieldName, string fieldValue, SPList oList, string qs_fy, string qs_ws, string srcItemID)
        {




            // since this is called from PM Review as well if PM returns value back to OTASubmission there will be no border
            bool IsDiff = false;

            var traceInfo = "start IsDiff: " + IsDiff + " fieldName: " + fieldName + " fieldValue: " + fieldValue;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            if (srcItemID != "0")
            {

                try
                {

                    SPQuery oQuery = new SPQuery();

                    if (fieldValue.Length > 0)
                    {
                        oQuery.Query = "" +
                            "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ID\"/>" +
                                        "<Value Type=\"Text\">" + srcItemID + "</Value>" +
                                    "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name=\"" + fieldName + "\"/>" +
                                        "<Value Type=\"Text\">" + fieldValue + "</Value>" +
                                      "</Eq>" +
                                "</And>" +
                            "</Where>";
                    }
                    else
                    {
                        oQuery.Query = "" +
                            "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ID\"/>" +
                                        "<Value Type=\"Text\">" + srcItemID + "</Value>" +
                                    "</Eq>" +
                                     "<IsNull>" +
                                        "<FieldRef Name=\"" + fieldName + "\"/>" +
                                      "</IsNull>" +
                                "</And>" +
                            "</Where>";
                    }



                    SPListItemCollection collListItems = oList.GetItems(oQuery);

                    if (collListItems.Count > 0)
                    {
                        IsDiff = false;
                    }
                    else { IsDiff = true; }


                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }


            }
            else
            {
                IsDiff = true;
            }
            traceInfo = "end IsDiff: " + IsDiff;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            return IsDiff;
        }




    }
}
