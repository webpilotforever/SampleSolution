﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    class Class2
     {
function updateTotals() {
    // set totals in worksheet
    if (worksheetPageName.indexOf("WS1") > -1) {
        // ws1 top
        var MilitarySubTotal = 0;
        $("input[id*='Funding']").each(function (i) {

            var fundingVal = $(this).val();
            if (fundingVal.indexOf("$") > -1) {
                fundingVal = fundingVal.substr(fundingVal.indexOf("$") + 1);
                $(this).val(fundingVal);
            }
            if ($.isNumeric(fundingVal)) {
                //var nn = Math.round(fundingVal);
                fundingVal = parseFloat(fundingVal);
                var nn = fundingVal.toFixed(2);
                $(this).val(nn);
                if ($(this).closest('tr').index() < $("input[id*='MilitarySubTotal']").closest('tr').index()) {
                    //MilitarySubTotal += parseInt($(this).val());
                    MilitarySubTotal = (MilitarySubTotal * 10 + parseFloat(nn) * 10) / 10;
                }
            }
        });

        var GovLaborMonthRound = Math.round(MilitarySubTotal / 12);
        $("input[id*='GovLaborMonth']").val(GovLaborMonthRound.toFixed(2));
        $("input[id*='MilitarySubTotal']").val(MilitarySubTotal.toFixed(2));
        // ws1 contractors

        var ContractsSubTotal = 0;

        var contractSliceStart;
        var contractSliceEnd;
        var contractSliced;

        $("tr.WSGroupStartRow").each(function (i) {
            contractSliceStart = $(this).index();
            contractSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
            contractSliced = $(this).parent().children().slice(contractSliceStart, contractSliceEnd);
            var ContractTotal = 0;
            contractSliced.find("input[id*='Funding']").each(function () {
                var fundingVal = $(this).val();
                if ($.isNumeric(fundingVal)) {
                    fundingVal = parseFloat(fundingVal);
                    var nn = fundingVal.toFixed(2);
                    $(this).val(nn);
                    //ContractTotal += parseInt($(this).val());
                    ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
                }
            });

            contractSliced.find("input[id*='AdditionalLineItem']").each(function () {
                var additionalLineItemVal = $(this).val();
                if ($.isNumeric(additionalLineItemVal)) {
                    additionalLineItemVal = parseFloat(additionalLineItemVal);
                    var nn = additionalLineItemVal.toFixed(2);
                    $(this).val(nn);
                    //ContractTotal += parseInt($(this).val());
                    ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
                }
                //if ($.isNumeric($(this).val())) {
                //    //ContractTotal += parseInt($(this).val());
                //    ContractTotal = (ContractTotal * 10 + parseFloat($(this).val()) * 10) / 10;

                //} ok use this up to here
            });

            var contractFeeVal = contractSliced.find("input[id*='ContractFee']").val();
            if ($.isNumeric(contractFeeVal)) {
                contractFeeVal = parseFloat(contractFeeVal);
                var nn = contractFeeVal.toFixed(2);
                contractSliced.find("input[id*='ContractFee']").val(nn);
                ContractTotal = (ContractTotal * 10 + parseFloat(nn) * 10) / 10;
            }

            var contractTotalStr = ContractTotal.toFixed(2);
            var contractsSubTotalStr = ContractsSubTotal.toFixed(2);

            contractSliced.find("input[id*='ContractTotal']").val(contractTotalStr);
            //ContractsSubTotal += ContractTotal;
            ContractsSubTotal = (parseFloat(contractsSubTotalStr) * 10 + parseFloat(contractTotalStr) * 10) / 10;
            contractSliced.find("input[id*='ContractsSubTotal']").val(ContractsSubTotal.toFixed(2));
        });
        var militarySubTotalStr = MilitarySubTotal.toFixed(2);
        var contractsSubTotalStr = ContractsSubTotal.toFixed(2);
        var totalCal = (parseFloat(militarySubTotalStr) * 10 + parseFloat(contractsSubTotalStr) * 10) / 10;
        //$("input[id*='Total']").last().val(MilitarySubTotal + ContractsSubTotal);
        $("input[id*='Total']").last().val(totalCal.toFixed(2));
    }
    if (worksheetPageName.indexOf("WS2") > -1) {

        var venueSliceStart;
        var venueSliceEnd;
        var venueSliced;

        var Total = 0;

        $("tr.WSGroupStartRow").each(function (i) {
            var VenueSubTotal = 0;
            venueSliceStart = $(this).index();
            venueSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
            venueSliced = $(this).parent().children().slice(venueSliceStart, venueSliceEnd);

            venueSliced.find("input[id*='Funding']").each(function () {

                var venueVal = $(this).val();
                if (venueVal.indexOf("$") > -1) {
                    venueVal = venueVal.substr(venueVal.indexOf("$") + 1);
                    $(this).val(venueVal);
                }
                if ($.isNumeric(venueVal)) {
                    //var nn = Math.round(venueVal);
                    venueVal = parseFloat(venueVal);
                    var nn = venueVal.toFixed(2);
                    $(this).val(nn);
                    //VenueSubTotal += parseInt($(this).val());
                    VenueSubTotal = (VenueSubTotal * 10 + parseFloat(nn) * 10) / 10;

                }

            });

            venueSliced.find("input[id*='VenueSubTotal']").val(VenueSubTotal.toFixed(2));

            Total += VenueSubTotal;

        });
        $("input[id*='Total']").last().val(Total.toFixed(2));

    }
    if (worksheetPageName.indexOf("WS3") > -1 || worksheetPageName.indexOf("WS4") > -1) {
        var Total = 0;










        $("input[id*='Funding']").each(function () {

            var fundingVal = $(this).val();
            if (fundingVal.indexOf("$") > -1) {
                fundingVal = fundingVal.substr(fundingVal.indexOf("$") + 1);
                $(this).val(fundingVal);
            }
            if ($.isNumeric(fundingVal)) {
                //var nn = Math.round(fundingVal);
                fundingVal = parseFloat(fundingVal);
                var nn = fundingVal.toFixed(2);
                $(this).val(nn);
                Total = (Total * 10 + parseFloat(nn) * 10) / 10;
            }
        });
        $("input[id*='Total']").val(Total.toFixed(2));
    }


}

            }
}
