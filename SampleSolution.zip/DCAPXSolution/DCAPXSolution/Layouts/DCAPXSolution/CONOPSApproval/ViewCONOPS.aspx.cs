﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;
using System.Collections.Generic; 

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    public partial class ViewCONOPS : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {   
            if(!IsPostBack)
            {
                //QueryStrings requiring Page object reference
                string qs_ota = Page.Request.QueryString["ota"];
                string qs_otashort = Page.Request.QueryString["otashort"];
                string qs_fy = Page.Request.QueryString["fy"];

                LabelOTAWS1.Text = qs_ota;
                LabelWSFYWS1.Text = qs_fy;

                LabelOTAWS2.Text = qs_ota;
                LabelWSFYWS2.Text = qs_fy;

                LabelOTAWS3.Text = qs_ota;
                LabelWSFYWS3.Text = qs_fy;

                LabelOTAWS4.Text = qs_ota;
                LabelWSFYWS4.Text = qs_fy;


                



                DCAPXSolution.CONOPSApproval.ViewCONOPSWS1.viewCONOPSforWS1(CONOPSDevWSTableWS1, headerTitleCellDivWS1, qs_otashort, qs_ota, qs_fy);
                DCAPXSolution.CONOPSApproval.ViewCONOPSWS2.viewCONOPSforWS2(CONOPSDevWSTableWS2, headerTitleCellDivWS2, qs_otashort, qs_ota, qs_fy, itemIDFirstHidden, itemIDLastHidden);
                DCAPXSolution.CONOPSApproval.ViewCONOPSWS3.viewCONOPSforWS3(CONOPSDevWSTableWS3, headerTitleCellDivWS3, qs_otashort, qs_ota, qs_fy, itemIDFirstHidden, itemIDLastHidden);
                DCAPXSolution.CONOPSApproval.ViewCONOPSWS4.viewCONOPSforWS4(CONOPSDevWSTableWS4, headerTitleCellDivWS4, qs_otashort, qs_ota, qs_fy, itemIDFirstHidden, itemIDLastHidden);

            }

             




        }

    }
}
