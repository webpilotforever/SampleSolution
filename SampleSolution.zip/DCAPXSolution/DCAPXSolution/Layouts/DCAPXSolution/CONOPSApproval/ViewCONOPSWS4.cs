﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    class ViewCONOPSWS4
    {

        internal static void viewCONOPSforWS4(Table CONOPSDevWSTableWS4, HtmlGenericControl headerTitleCellDivWS4, string qs_otashort, string qs_ota, string qs_fy, HiddenField itemIDFirstHidden, HiddenField itemIDLastHidden)
        {
            var traceInfo = "ViewCONOPSWS4";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            bool wsIsSubmitted = false;
            //Query CONOPSApprovalProgress
            //Query if submitted, then build table else update lable

            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where>" +
                "<And><And>" +
                    "<Eq>" +
                        "<FieldRef Name='OperationalTestAgency'/>" +
                            "<Value Type='Choice'>" + qs_otashort + "</Value>" +
                     "</Eq>" +
                     "<Eq>" +
                        "<FieldRef Name='Submitted'/>" +
                            "<Value Type='Text'>Yes</Value>" +
                        "</Eq>" +
                "</And>" +
                 "<Eq>" +
                        "<FieldRef Name='Title'/>" +
                            "<Value Type='Text'>WS4</Value>" +
                        "</Eq>" +
                "</And>" +
            "</Where>";

            SPListItemCollection collItemsSubmitted = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            if (collItemsSubmitted.Count > 0)
            {

                wsIsSubmitted = true;
            }


            if (wsIsSubmitted)
            {
                int itemRowIndex = 4;
                int attachmentIndex = 6;
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                //Table rows-----------------------------------------------------------------------------------

                TableRow headerTitleRow = new TableRow();
                TableRow headerRow = new TableRow();
                TableRow headerDescRow = new TableRow();
                TableRow itemRow = new TableRow();
                TableRow totalRow = new TableRow();
                TableRow attachmentsRow = new TableRow();
                TableRow attachmentsValRow = new TableRow();

                headerTitleRow.Style.Add("text-align", "center");
                headerRow.CssClass = "CONOPSDevWSColHeaders";
                headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
                headerDescRow.Style.Add("text-align", "center");
                itemRow.Style.Add("text-align", "center");
                totalRow.Style.Add("text-align", "center");
                attachmentsRow.Style.Add("text-align", "center");
                attachmentsValRow.Style.Add("text-align", "center");

                //Table cells------------------------------------------------------------------------------------------

                TableCell headerTitleCell = new TableCell();
                headerTitleCell.ColumnSpan = 4;

                headerTitleCell.Controls.Add(headerTitleCellDivWS4);

                headerTitleRow.Cells.Add(headerTitleCell);

                CONOPSDevWSTableWS4.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTableWS4

                TableCell wsColCell1 = new TableCell();
                TableCell wsColCell2 = new TableCell();
                TableCell wsColCell3 = new TableCell();
                TableCell wsColCell4 = new TableCell();

                TableCell wsColCell5 = new TableCell();
                TableCell wsColCell6 = new TableCell();

                wsColCell1.CssClass = "CONOPSDevWSColCell";
                wsColCell2.CssClass = "CONOPSDevWSColCell";
                wsColCell3.CssClass = "CONOPSDevWSColCell";
                wsColCell4.CssClass = "CONOPSDevWSColCell";


                wsColCell5.CssClass = "CONOPSDevWSColCell";
                wsColCell6.CssClass = "CONOPSDevWSColCell";
                wsColCell5.Style.Add("width", "163px");
                wsColCell6.Style.Add("width", "163px");
                wsColCell5.Style.Add("font-weight", "bold");
                wsColCell6.Style.Add("font-weight", "bold");

                wsColCell1.Style.Add("width", "200px");
                wsColCell2.Style.Add("width", "155px");
                wsColCell3.Style.Add("width", "155px");
                wsColCell4.Style.Add("width", "155px");


                wsColCell1.Style.Add("font-weight", "bold");
                wsColCell2.Style.Add("font-weight", "bold");
                wsColCell3.Style.Add("font-weight", "bold");
                wsColCell4.Style.Add("font-weight", "bold");


                wsColCell1.Text = "Item Description";
                wsColCell2.Text = "Number";
                wsColCell3.Text = "Remarks​";
                wsColCell4.Text = "Funding";


                headerRow.Cells.Add(wsColCell1);
                headerRow.Cells.Add(wsColCell2);
                headerRow.Cells.Add(wsColCell3);
                headerRow.Cells.Add(wsColCell4);


                CONOPSDevWSTableWS4.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTableWS4

                TableCell headerDescRowCell1 = new TableCell();
                TableCell headerDescRowCell2 = new TableCell();
                TableCell headerDescRowCell3 = new TableCell();
                TableCell headerDescRowCell4 = new TableCell();

                TableCell headerDescRowCell5 = new TableCell();
                TableCell headerDescRowCell6 = new TableCell();

                headerDescRowCell1.Style.Add("font-style", "italic");
                headerDescRowCell2.Style.Add("font-style", "italic");
                headerDescRowCell3.Style.Add("font-style", "italic");
                headerDescRowCell4.Style.Add("font-style", "italic");

                headerDescRowCell5.Style.Add("font-style", "italic");
                headerDescRowCell6.Style.Add("font-style", "italic");

                headerDescRowCell1.Text = "Provide a description of each item, service, or training course";
                headerDescRowCell2.Text = "Identify the number of items for purchase or the number of people attending the training​";
                headerDescRowCell3.Text = "Provide any comments to help clarify your cost estimates​";
                headerDescRowCell4.Text = "Estimated cost for each item/service/training course";

                headerDescRowCell5.Text = "Reviewer approval";
                headerDescRowCell6.Text = "Reviewer comments";

                headerDescRow.Cells.Add(headerDescRowCell1);
                headerDescRow.Cells.Add(headerDescRowCell2);
                headerDescRow.Cells.Add(headerDescRowCell3);
                headerDescRow.Cells.Add(headerDescRowCell4);


                CONOPSDevWSTableWS4.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTableWS4

                TableCell itemValCell1 = new TableCell();
                TableCell itemValCell2 = new TableCell();
                TableCell itemValCell3 = new TableCell();
                TableCell itemValCell4 = new TableCell();

                TableCell itemValCell5 = new TableCell();
                TableCell itemValCell6 = new TableCell();

                itemValCell1.Style["padding-left"] = "3px";
                itemValCell2.Style["text-align"] = "center";
                itemValCell3.Style["padding-left"] = "3px";
                itemValCell4.Style["text-align"] = "center";


                itemValCell1.Text = "Text";
                itemValCell2.Text = "00";
                itemValCell3.Text = "Text";
                itemValCell4.Text = "0";




                itemRow.Cells.Add(itemValCell1);
                itemRow.Cells.Add(itemValCell2);
                itemRow.Cells.Add(itemValCell3);
                itemRow.Cells.Add(itemValCell4);



                CONOPSDevWSTableWS4.Rows.Add(itemRow); //-----------------itemRow added to CONOPSDevWSTableWS4

                TableCell totalRowCell1 = new TableCell();
                TableCell totalRowCell2 = new TableCell();

                TableCell totalRowCell3 = new TableCell();
                TableCell totalRowCell4 = new TableCell();

                totalRowCell1.ColumnSpan = 3;
                totalRowCell1.Style.Add("text-align", "right");
                totalRowCell1.Style.Add("font-weight", "bold");
                totalRowCell1.Style.Add("background-color", "#d0ffbc");
                totalRowCell1.Text = "Total:";

                totalRowCell2.Text = "0000";
                totalRowCell2.Style.Add("background-color", "#d0ffbc");

                totalRow.Cells.Add(totalRowCell1);
                totalRow.Cells.Add(totalRowCell2);

                CONOPSDevWSTableWS4.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTableWS4

                TableCell attachmentsRowCell = new TableCell();

                TableCell attachmentsRowCell2 = new TableCell();
                TableCell attachmentsRowCell3 = new TableCell();

                attachmentsRowCell.ColumnSpan = 4;
                attachmentsRowCell.Style.Add("font-weight", "bold");
                attachmentsRowCell.Text = "Attachments";

                attachmentsRow.Cells.Add(attachmentsRowCell);

                CONOPSDevWSTableWS4.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTableWS4

                TableCell attachmentsValRowCell = new TableCell();

                TableCell attachmentsValRowCell2 = new TableCell();
                TableCell attachmentsValRowCell3 = new TableCell();

                attachmentsValRowCell.ColumnSpan = 4;
                attachmentsValRowCell.Text = "attachment1.text";
                attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

                attachmentsValRow.Cells.Add(attachmentsValRowCell);

                CONOPSDevWSTableWS4.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTableWS4


                //================= END OF TABLE TEMPLATE ====================

                SPList oLib = SPContext.Current.Web.GetList(SPContext.Current.Web.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);


                SPQuery oLibQuery = new SPQuery();

                oLibQuery.Query = "" +
                       "<OrderBy>" +
                           "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                       "</OrderBy>" +
                       "<Where>" +
                           "<And>" +
                               "<Eq>" +
                                   "<FieldRef Name=\"FY\"/>" +
                                   "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                               "</Eq>" +
                                "<Eq>" +
                                   "<FieldRef Name=\"WS\"/>" +
                                   "<Value Type=\"Text\">WS4</Value>" +
                               "</Eq>" +
                           "</And>" +
                       "</Where>";
                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();

                                attachmentsValRwCell.ColumnSpan = 4;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = SPContext.Current.Web.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                CONOPSDevWSTableWS4.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTableWS4.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTableWS4.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTableWS4.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTableWS4.Controls.Remove(attachmentsValRow);
                }



                SPList oList = SPContext.Current.Web.Lists["CONOPSDevWS" + qs_otashort];

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy><Where>" +
                    "<And><And><And><And>" +
                        "<Eq>" +
                            "<FieldRef Name='CONOPSApproval'/>" +
                                "<Value Type='Choice'>Deputy Director Approval</Value>" +
                         "</Eq>" +
                         "<Eq>" +
                            "<FieldRef Name='ContentType'/>" +
                                "<Value Type='Computed'>WS4</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Eq>" +
                            "<FieldRef Name='FY'/>" +
                                "<Value Type='Text'>" + qs_fy + "</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Not Approved</Value>" +
                            "</Neq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Pending</Value>" +
                            "</Neq>" +
                    "</And>" +
                "</Where>";
                traceInfo = "collListItems next...";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPListItemCollection collListItems = oList.GetItems(oQuery);



                if (collListItems.Count > 0)
                {

                    foreach (SPListItem oListItem in collListItems)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        if (oListItem[TotalGUID] != null)
                        {
                            try
                            {
                                traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                totalRowCell2.Text = oListItem[TotalGUID].ToString();



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents5", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                        }

                    }


                    SPQuery oQuery3 = new SPQuery();
                    oQuery3.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy><Where>" +
                    "<And><And><And><And><And>" +
                        "<Eq>" +
                            "<FieldRef Name='CONOPSApproval'/>" +
                                "<Value Type='Choice'>Deputy Director Approval</Value>" +
                         "</Eq>" +
                         "<Eq>" +
                            "<FieldRef Name='ContentType'/>" +
                                "<Value Type='Computed'>WS4</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Eq>" +
                            "<FieldRef Name='FY'/>" +
                                "<Value Type='Text'>" + qs_fy + "</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Not Approved</Value>" +
                            "</Neq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Pending</Value>" +
                            "</Neq>" +
                    "</And>" +
                    "<Neq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">Total</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                "</Where>";
                    SPListItemCollection collListItems3 = oList.GetItems(oQuery3);
                    foreach (SPListItem oListItem in collListItems3)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        TableRow rw = new TableRow();



                        TableCell ItemDescriptionCell = new TableCell();
                        TableCell NumberCell = new TableCell();
                        TableCell RemarksCell = new TableCell();
                        TableCell FundingCell = new TableCell();


                        ItemDescriptionCell.Style["padding-left"] = "3px";
                        NumberCell.Style["text-align"] = "center";
                        RemarksCell.Style["padding-left"] = "3px";
                        FundingCell.Style["text-align"] = "center";

                        string ItemDescription = "";
                        string Number = "";
                        string Remarks = "";
                        string Funding = "";

                        try
                        {
                            ItemDescription += title;
                            try { Number += oListItem["Number"].ToString(); }
                            catch { }
                            try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); } }
                            catch { }
                            try { Funding += oListItem["Funding"].ToString(); }
                            catch { }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents5b", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        ItemDescriptionCell.Text = ItemDescription;
                        NumberCell.Text = Number;
                        RemarksCell.Text = Remarks;
                        FundingCell.Text = Funding;

                        rw.Cells.Add(ItemDescriptionCell);
                        rw.Cells.Add(NumberCell);
                        rw.Cells.Add(RemarksCell);
                        rw.Cells.Add(FundingCell);


                        CONOPSDevWSTableWS4.Rows.AddAt(itemRowIndex, rw);
                    }




                    try
                    {
                        CONOPSDevWSTableWS4.Controls.Remove(attachmentsValRow);

                        CONOPSDevWSTableWS4.Controls.Remove(itemRow);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                } // end if


            }
            else
            {
                TableRow headerTitleRow = new TableRow();
                TableRow msgRow = new TableRow();
                TableCell msgCell = new TableCell();
                TableCell headerTitleCell = new TableCell();

                headerTitleRow.Style.Add("text-align", "center");
                msgCell.Text = "Worksheet Pending Approval";
                msgCell.CssClass = "msgCell";
                msgCell.Style.Add("font-size", "14px");

                headerTitleCell.Controls.Add(headerTitleCellDivWS4);
                headerTitleRow.Cells.Add(headerTitleCell);
                msgRow.Cells.Add(msgCell);

                CONOPSDevWSTableWS4.Rows.Add(headerTitleRow);
                CONOPSDevWSTableWS4.Rows.Add(msgRow);
            }
        }

       
    }
}
