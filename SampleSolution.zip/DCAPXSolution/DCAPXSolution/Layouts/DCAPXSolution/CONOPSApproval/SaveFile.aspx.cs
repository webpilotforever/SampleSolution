﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Web;
using System.Collections.Specialized;
using System.Net;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Text.RegularExpressions;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Collections.Generic;
using System.IO;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    public partial class SaveFile : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //  If user overwrites last year's file then FY will be different, but also Submitted needs to be set to No.
            //  so in CONOPSDevUploadDocs must set Submitted as well as FY every time.
            //  Next year does last year's FY 18 files of same name just get Submitted reset to No?
            //  I guess the rule is if FY changes, then Submitted must be reset to No always.
            //  So when iterating in ASC order through SPListItemVersionCollection the first SPListItemVersion in a set with FYs of a unique value should be Submitted set to No.
            //  So if current version FY is not same as one being uploaded, then Submitted is always No. (using and EventReceiver)
            //  Duh! The answer is to always set Submitted to No unless 
            //      FY is the same 
            //      and 
            //      the item is being submitted.
            //  So, is there anything other than an EventReceiver that could enforce this?
            //  Nah. Just use an ER and convert it to the app madel if we must go to sp2013.
            //  Is there an event for creating a new version outside the context of an ER?
            //  No, and ER is supported in SP2013, just must be farm solution
            //  So, Bob is right, we will never be using 2013 for this product if farm solutions are disallowed
            //  cause we would have to have additional servers and security protocols for a remote app web, which would be overkill. 
            //  cause I cant see this solution being on our servers and also being allowed to tap into a dod centrally-hosted place for a remove app web where we would have asp.net page.
            //  So no big deal, we would just have to upgrade to 2013 and this product would have to continue to be a farm (our farm) solution. 
            //      '....doing SP2013 farm solutions only, no apps"
            //  Conclusion - use EventReceiver!
            //  Above is not a concern as we query for fy ws and we update metadata alone the way.


            // Use 2 Methods to get list items, and then get versions of item.
            //  Each document will have a minimum set of 12 version.
            //  1.0 initial upload during CONOPSDev
            //  2.0 metadata added programatically, initial upload during CONOPSDev: Baseline OTA Submission | 17 | No | WS1

            //  Then in rapid succession...
            //  3.0 submitted during CONOPSDev: BaseName appended with ID | Baseline OTA Submission | 17 | Yes | WS1
            //  4.0 initial CONOPSApproval: AO Recommendation | 17 | No | WS1

            //  5.0 items approved during CONOPSApproval: AO Recommendation | 17 | No | WS1

            //  Then in rapid succession...
            //  6.0 submitted during CONOPSApproval: AO Recommendation | 17 | Yes | WS1
            //  7.0 CONOPSApproval: PM Preapproval | 17 | No | WS1

            //  8.0 items approved during CONOPSApproval: PM Preapproval | 17 | No | WS1

            //  Then in rapid succession...
            //  9.0 submitted during CONOPSApproval: PM Preapproval | 17 | Yes | WS1
            //  10.0 CONOPSApproval: Deputy Director Approval | 17 | No | WS1

            //  11.0 items approved during CONOPSApproval: Deputy Director Approval | 17 | No | WS1

            //  Then in rapid succession...
            //  12.0 submitted during CONOPSApproval: Deputy Director Approval | 17 | Yes | WS1
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string qs_id = "2";
            //qs_id = Page.Request.QueryString["id"];

            string qs_status = "Baseline OTA Submission";
            //qs_status = Page.Request.QueryString["status"];

            string qs_otashort = "AFOTEC";
            //qs_otashort = Page.Request.QueryString["otashort"];



            SPList oLib = SPContext.Current.Web.Lists["CONOPSDev" + qs_otashort];

            SPListItem oLibItem = oLib.GetItemById(Int32.Parse(qs_id));

            SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

            foreach (SPListItemVersion oListItemVersion in collListItemVersions)
            {
                if ((string)oListItemVersion["CONOPSApproval"] == qs_status)
                {
                    var traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("app2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    SPFile myFile = oListItemVersion.ListItem.File;

                    saveFileToMyDocs(myFile);

                    break;

                }
            }
        }

        private void saveFileToMyDocs(SPFile myFile)
        {
            try
            {

                //string myDesktop = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments); //C:\Users\DanielNW-p.DOTEDRESOURCE\Desktop

                string myDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                //string myDesktop = @"C:\Users\DanielNW-p.DOTEDRESOURCE\Desktop";

                myDocs = myDocs + @"\" + myFile.Name;

                var traceInfo = "Saving file";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("app2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                int size = 10 * 1024;
                using (Stream stream = myFile.OpenBinaryStream())
                {
                    //using (FileStream fs = new FileStream(@"C:\Users\krg\Desktop\xyz.pptx", FileMode.Create, FileAccess.Write))
                    //using (FileStream fs = new FileStream(myDocs, FileMode.Create, FileAccess.Write))

                    try
                    {
                        using (FileStream fs = new FileStream(myDocs, FileMode.CreateNew, FileAccess.Write))
                        {
                            byte[] buffer = new byte[size];
                            int bytesRead;
                            while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                            {
                                fs.Write(buffer, 0, bytesRead);
                            }


                        }
                    
                    }
                    catch (IOException ex)
                    {
                        Label2.Visible = true;
                        Label2.Text = ex.Message;

                        if (ex.Message.Contains("already exists"))
                        {
                            Label1.Text = "Overwrite existing file?";
                            Button1.Visible = false;
                            Button3.Visible = true;
                        }
                        else
                        {
                            Label1.Text = "Click Cancel to close this dialog.";
                            Button1.Visible = false;
                        
                        }

                      
                    }

                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("saveFileToMyDocs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

               
            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string qs_id = "2";
            //qs_id = Page.Request.QueryString["id"];

            string qs_status = "Baseline OTA Submission";
            //qs_status = Page.Request.QueryString["status"];

            string qs_otashort = "AFOTEC";
            //qs_otashort = Page.Request.QueryString["otashort"];



            SPList oLib = SPContext.Current.Web.Lists["CONOPSDev" + qs_otashort];

            SPListItem oLibItem = oLib.GetItemById(Int32.Parse(qs_id));

            SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

            foreach (SPListItemVersion oListItemVersion in collListItemVersions)
            {
                if ((string)oListItemVersion["CONOPSApproval"] == qs_status)
                {
                    var traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("app2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    SPFile myFile = oListItemVersion.ListItem.File;

                    saveFileToMyDocsOverwrite(myFile);

                    break;

                }
            }
        }

        private void saveFileToMyDocsOverwrite(SPFile myFile)
        {
            try
            {


                string myDocs = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                myDocs = myDocs + @"\" + myFile.Name;

                var traceInfo = "Saving file";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("app2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                int size = 10 * 1024;
                using (Stream stream = myFile.OpenBinaryStream())
                {

                    using (FileStream fs = new FileStream(myDocs, FileMode.Create, FileAccess.Write))
                    {
                        byte[] buffer = new byte[size];
                        int bytesRead;
                        while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                        {
                            fs.Write(buffer, 0, bytesRead);
                        }


                    }

                   

                }
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("saveFileToMyDocsOverwrite", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);


            }
        }

    }
}
