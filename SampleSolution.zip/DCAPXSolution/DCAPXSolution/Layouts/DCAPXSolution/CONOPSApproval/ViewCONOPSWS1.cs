﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    class ViewCONOPSWS1
    {

        internal static void viewCONOPSforWS1(Table CONOPSDevWSTableWS1, HtmlGenericControl headerTitleCellDivWS1, string qs_otashort, string qs_ota, string qs_fy)
        {
            var traceInfo = "ViewCONOPSWS1";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            bool wsIsSubmitted = false;
            //Query CONOPSApprovalProgress
            //Query if submitted, then build table else update lable

            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where>" +
                "<And><And>" +
                    "<Eq>" +
                        "<FieldRef Name='OperationalTestAgency'/>" +
                            "<Value Type='Choice'>" + qs_otashort + "</Value>" +
                     "</Eq>" +
                     "<Eq>" +
                        "<FieldRef Name='Submitted'/>" +
                            "<Value Type='Text'>Yes</Value>" +
                        "</Eq>" +
                "</And>" +
                 "<Eq>" +
                        "<FieldRef Name='Title'/>" +
                            "<Value Type='Text'>WS1</Value>" +
                        "</Eq>" +
                "</And>" +
            "</Where>";

            SPListItemCollection collItemsSubmitted = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            if (collItemsSubmitted.Count > 0)
            {

                wsIsSubmitted = true;
            }


            if (wsIsSubmitted)
            {

                TableRowCollection rows = CONOPSDevWSTableWS1.Rows;

                int contractIndex = 17;
                int attachmentIndex = 20;

                int militaryIndex = 4;
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");

                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);
                SPQuery oLibQuery = new SPQuery();



                //Table rows-----------------------------------------------------------------------------------

                
                TableRow headerTitleRow = new TableRow();
                TableRow headerRow = new TableRow();
                TableRow headerDescRow = new TableRow();
                TableRow militaryRow = new TableRow();
                TableRow militaryValsRow = new TableRow();
                TableRow militaryBlankRow = new TableRow();
                TableRow militaryGovRow = new TableRow();
                TableRow militarySubTotalRow = new TableRow();
                TableRow contractorsRow = new TableRow();
                TableRow contractorsDescRow = new TableRow();
                TableRow contractorsValsRow = new TableRow();
                TableRow contractorsBlankRow = new TableRow();
                TableRow additionalItemRow = new TableRow();
                TableRow hoursRow = new TableRow();
                TableRow hoursBlankRow = new TableRow();
                TableRow contractFeeRow = new TableRow();
                TableRow contractorsFYTotalRow = new TableRow();
                TableRow contractorsSubTotalRow = new TableRow();
                TableRow contractorsTotalRow = new TableRow();
                TableRow attachmentsRow = new TableRow();
                TableRow attachmentsValRow = new TableRow();


                headerTitleRow.Style.Add("text-align", "center");
                headerRow.CssClass = "CONOPSDevWSColHeaders";
                headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
                headerDescRow.Style.Add("text-align", "center");
                headerDescRow.ID = "headerDescRow";
                militaryRow.Style.Add("text-align", "center");
                militaryValsRow.Style.Add("text-align", "center");
                militaryGovRow.ID = "militaryGovRow";
                militarySubTotalRow.ID = "militarySubTotalRow";
                contractorsDescRow.ID = "contractorsDescRow";
                contractorsValsRow.Style.Add("text-align", "center");
                contractorsBlankRow.ID = "contractorsBlankRow";
                additionalItemRow.Style.Add("text-align", "center");
                additionalItemRow.ID = "additionalItemRow";
                hoursRow.Style.Add("text-align", "center");
                hoursRow.ID = "hoursRow";
                contractFeeRow.Style.Add("text-align", "center");
                contractorsFYTotalRow.Style.Add("text-align", "center");
                contractorsSubTotalRow.Style.Add("text-align", "center");
                contractorsSubTotalRow.ID = "contractorsSubTotalRow";
                contractorsTotalRow.Style.Add("text-align", "center");
                contractorsTotalRow.ID = "contractorsTotalRow";
                contractorsTotalRow.ToolTip = "contractorsTotalRow";
                attachmentsRow.Style.Add("text-align", "center");
                attachmentsValRow.Style.Add("text-align", "center");

                //Table cells------------------------------------------------------------------------------------------

                TableCell headerTitleCell = new TableCell();
                headerTitleCell.ColumnSpan = 6;

                headerTitleCell.Controls.Add(headerTitleCellDivWS1);

                headerTitleRow.Cells.Add(headerTitleCell);

                CONOPSDevWSTableWS1.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTableWS1

                TableCell wsColCell1 = new TableCell();
                TableCell wsColCell2 = new TableCell();
                TableCell wsColCell3 = new TableCell();
                TableCell wsColCell4 = new TableCell();
                TableCell wsColCell5 = new TableCell();
                TableCell wsColCell6 = new TableCell();

         


                wsColCell1.CssClass = "CONOPSDevWSColCell";
                wsColCell2.CssClass = "CONOPSDevWSColCell";
                wsColCell3.CssClass = "CONOPSDevWSColCell";
                wsColCell4.CssClass = "CONOPSDevWSColCell";
                wsColCell5.CssClass = "CONOPSDevWSColCell";
                wsColCell6.CssClass = "CONOPSDevWSColCell";

            

                wsColCell1.Style.Add("width", "163px");
                wsColCell2.Style.Add("width", "155px");
                wsColCell3.Style.Add("width", "123px");
                wsColCell4.Style.Add("width", "187px");
                wsColCell5.Style.Add("width", "180px");
                wsColCell6.Style.Add("width", "214px");



                wsColCell1.Style.Add("font-weight", "bold");
                wsColCell2.Style.Add("font-weight", "bold");
                wsColCell3.Style.Add("font-weight", "bold");
                wsColCell4.Style.Add("font-weight", "bold");
                wsColCell5.Style.Add("font-weight", "bold");
                wsColCell6.Style.Add("font-weight", "bold");



                wsColCell1.Text = "Name";
                wsColCell2.Text = "Duty Title/Position​";
                wsColCell3.Text = "Status​";
                wsColCell4.Text = "Remarks​";
                wsColCell5.Text = "Contractor Rate or GS Level​";
                wsColCell6.Text = "Funding​";

                headerRow.Cells.Add(wsColCell1);
                headerRow.Cells.Add(wsColCell2);
                headerRow.Cells.Add(wsColCell3);
                headerRow.Cells.Add(wsColCell4);
                headerRow.Cells.Add(wsColCell5);
                headerRow.Cells.Add(wsColCell6);

                CONOPSDevWSTableWS1.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTableWS1

                TableCell headerDescRowCell1 = new TableCell();
                TableCell headerDescRowCell2 = new TableCell();
                TableCell headerDescRowCell3 = new TableCell();
                TableCell headerDescRowCell4 = new TableCell();
                TableCell headerDescRowCell5 = new TableCell();
                TableCell headerDescRowCell6 = new TableCell();

             
                headerDescRowCell1.Style.Add("font-style", "italic");
                headerDescRowCell2.Style.Add("font-style", "italic");
                headerDescRowCell3.Style.Add("font-style", "italic");
                headerDescRowCell4.Style.Add("font-style", "italic");
                headerDescRowCell5.Style.Add("font-style", "italic");
                headerDescRowCell6.Style.Add("font-style", "italic");

              

                headerDescRowCell1.Text = "List the name of each person proposed for funding​";
                headerDescRowCell2.Text = "Provide a duty title/position for each of your core personnel​​";
                headerDescRowCell3.Text = "Identify if the person is full or part time for funding​";
                headerDescRowCell4.Text = "Provide any comments to help clarify your cost estimates​";
                headerDescRowCell5.Text = "Provide the hourly rate for each contractor​";
                headerDescRowCell6.Text = "Provide the requested funding level for each of your core personnel​";

           

                headerDescRow.Cells.Add(headerDescRowCell1);
                headerDescRow.Cells.Add(headerDescRowCell2);
                headerDescRow.Cells.Add(headerDescRowCell3);
                headerDescRow.Cells.Add(headerDescRowCell4);
                headerDescRow.Cells.Add(headerDescRowCell5);
                headerDescRow.Cells.Add(headerDescRowCell6);

                CONOPSDevWSTableWS1.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTableWS1

                TableCell militaryRowCell = new TableCell();

              

                militaryRowCell.ColumnSpan = 6;
                militaryRowCell.Style.Add("font-weight", "bold");
                militaryRowCell.Text = "Military/Government Civilian​​";

                militaryRow.Cells.Add(militaryRowCell);

                CONOPSDevWSTableWS1.Rows.Add(militaryRow); //-----------------militaryRow added to CONOPSDevWSTableWS1

                TableCell militaryValsRowCell1 = new TableCell();
                TableCell militaryValsRowCell2 = new TableCell();
                TableCell militaryValsRowCell3 = new TableCell();
                TableCell militaryValsRowCell4 = new TableCell();
                TableCell militaryValsRowCell5 = new TableCell();
                TableCell militaryValsRowCell6 = new TableCell();

                TableCell militaryValsRowCell7 = new TableCell();
                TableCell militaryValsRowCell8 = new TableCell();

                militaryValsRowCell5.Style.Add("text-align", "right");

                militaryValsRowCell1.Text = "Text";
                militaryValsRowCell2.Text = "Text";
                militaryValsRowCell3.Text = "Text";
                militaryValsRowCell4.Text = "Text";
                militaryValsRowCell5.Text = "GS00";
                militaryValsRowCell6.Text = "0000";

                militaryValsRow.Cells.Add(militaryValsRowCell1);
                militaryValsRow.Cells.Add(militaryValsRowCell2);
                militaryValsRow.Cells.Add(militaryValsRowCell3);
                militaryValsRow.Cells.Add(militaryValsRowCell4);
                militaryValsRow.Cells.Add(militaryValsRowCell5);
                militaryValsRow.Cells.Add(militaryValsRowCell6);

                CONOPSDevWSTableWS1.Rows.Add(militaryValsRow); //-----------------militaryValsRow added to CONOPSDevWSTableWS1

                TableCell militaryBlankRowCell1 = new TableCell();
                TableCell militaryBlankRowCell2 = new TableCell();

           

                militaryBlankRowCell1.ColumnSpan = 5;

                Literal LiteralmilitaryBlankRow = new Literal();
                LiteralmilitaryBlankRow.Text = "&nbsp;";

                militaryBlankRowCell1.Controls.Add(LiteralmilitaryBlankRow);

                militaryBlankRow.Cells.Add(militaryBlankRowCell1);
                militaryBlankRow.Cells.Add(militaryBlankRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(militaryBlankRow); //-----------------militaryBlankRow added to CONOPSDevWSTableWS1

                TableCell militaryGovRowCell1 = new TableCell();
                TableCell militaryGovRowCell2 = new TableCell();

             

                militaryGovRowCell1.ColumnSpan = 5;
                militaryGovRowCell1.Style.Add("text-align", "right");
                militaryGovRowCell1.Text = "Government Labor/month";

                militaryGovRowCell2.Style.Add("text-align", "center");
                militaryGovRowCell2.Text = "000";
                militaryGovRowCell2.ID = "militaryGovRowCell2";

                militaryGovRow.Cells.Add(militaryGovRowCell1);
                militaryGovRow.Cells.Add(militaryGovRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(militaryGovRow); //-----------------militaryGovRow added to CONOPSDevWSTableWS1

                TableCell militarySubTotalRowCell1 = new TableCell();
                TableCell militarySubTotalRowCell2 = new TableCell();
                TableCell militarySubTotalRowCell3 = new TableCell();


                militarySubTotalRowCell1.ColumnSpan = 4;
                militarySubTotalRowCell1.Style.Add("background-color", "#bfbfbf");

                militarySubTotalRowCell2.Style.Add("text-align", "right");
                militarySubTotalRowCell2.Style.Add("font-weight", "bold");
                militarySubTotalRowCell2.Style.Add("background-color", "#d0ffbc");
                militarySubTotalRowCell2.Text = "Sub-Total:​";

                militarySubTotalRowCell3.Style.Add("text-align", "center");
                militarySubTotalRowCell3.Style.Add("background-color", "#d0ffbc");
                militarySubTotalRowCell3.Text = "0000";

                militarySubTotalRow.Cells.Add(militarySubTotalRowCell1);
                militarySubTotalRow.Cells.Add(militarySubTotalRowCell2);
                militarySubTotalRow.Cells.Add(militarySubTotalRowCell3);

                CONOPSDevWSTableWS1.Rows.Add(militarySubTotalRow); //-----------------militarySubTotalRow added to CONOPSDevWSTableWS1

                TableCell contractorsRowCell = new TableCell();

             

                contractorsRowCell.ColumnSpan = 6;

                contractorsRowCell.Style.Add("text-align", "center");
                contractorsRowCell.Style.Add("font-weight", "bold");
                contractorsRowCell.Text = "Contractors";

                contractorsRow.Cells.Add(contractorsRowCell);

                CONOPSDevWSTableWS1.Rows.Add(contractorsRow); //-----------------contractorsRow added to CONOPSDevWSTableWS1

                TableCell contractorsDescRowCell = new TableCell();


                contractorsDescRowCell.ColumnSpan = 6;

                contractorsDescRowCell.Style.Add("text-align", "center");
                contractorsDescRowCell.Style.Add("font-style", "italic");

                Label LabelcontractorsDesc1 = new Label();
                LabelcontractorsDesc1.Text = "Contract Identifier  ";

                Label LabelcontractorsDesc2 = new Label();
                LabelcontractorsDesc2.Text = "Text";
                LabelcontractorsDesc2.Font.Italic = false;

                contractorsDescRowCell.Controls.Add(LabelcontractorsDesc1);
                contractorsDescRowCell.Controls.Add(LabelcontractorsDesc2);

                contractorsDescRow.Cells.Add(contractorsDescRowCell);

                CONOPSDevWSTableWS1.Rows.Add(contractorsDescRow); //-----------------contractorsDescRow added to CONOPSDevWSTableWS1

                TableCell contractorsValsRowCell1 = new TableCell();
                TableCell contractorsValsRowCell2 = new TableCell();
                TableCell contractorsValsRowCell3 = new TableCell();
                TableCell contractorsValsRowCell4 = new TableCell();
                TableCell contractorsValsRowCell5 = new TableCell();
                TableCell contractorsValsRowCell6 = new TableCell();

               

                contractorsValsRowCell5.Style.Add("text-align", "right");

                contractorsValsRowCell1.Text = "Text";
                contractorsValsRowCell2.Text = "Text";
                contractorsValsRowCell3.Text = "Text";
                contractorsValsRowCell4.Text = "Text";
                contractorsValsRowCell5.Text = "000";
                contractorsValsRowCell6.Text = "0000";

                contractorsValsRow.Cells.Add(contractorsValsRowCell1);
                contractorsValsRow.Cells.Add(contractorsValsRowCell2);
                contractorsValsRow.Cells.Add(contractorsValsRowCell3);
                contractorsValsRow.Cells.Add(contractorsValsRowCell4);
                contractorsValsRow.Cells.Add(contractorsValsRowCell5);
                contractorsValsRow.Cells.Add(contractorsValsRowCell6);

                CONOPSDevWSTableWS1.Rows.Add(contractorsValsRow); //-----------------contractorsValsRow added to CONOPSDevWSTableWS1

                TableCell contractorsBlankRowCell1 = new TableCell();
                TableCell contractorsBlankRowCell2 = new TableCell();

             


                contractorsBlankRowCell1.ColumnSpan = 5;

                Literal LiteralcontractorsBlankRow = new Literal();
                LiteralcontractorsBlankRow.Text = "&nbsp;";

                contractorsBlankRowCell1.Controls.Add(LiteralcontractorsBlankRow);

                contractorsBlankRow.Cells.Add(contractorsBlankRowCell1);
                contractorsBlankRow.Cells.Add(contractorsBlankRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(contractorsBlankRow); //-----------------contractorsBlankRow added to CONOPSDevWSTableWS1

                TableCell additionalItemRowCell1 = new TableCell();
                TableCell additionalItemRowCell2 = new TableCell();

               

                additionalItemRowCell1.ColumnSpan = 5;
                additionalItemRowCell1.Style.Add("text-align", "right");

                Label LabeladditionalItemDesc1 = new Label();
                LabeladditionalItemDesc1.Text = "Additional line item (title and amount) ";

                Label LabeladditionalItemDesc2 = new Label();
                LabeladditionalItemDesc2.Text = "Text";
                LabeladditionalItemDesc2.Font.Italic = false;

                additionalItemRowCell1.Controls.Add(LabeladditionalItemDesc1);
                additionalItemRowCell1.Controls.Add(LabeladditionalItemDesc2);
                additionalItemRowCell2.Text = "0000";

                additionalItemRow.Cells.Add(additionalItemRowCell1);
                additionalItemRow.Cells.Add(additionalItemRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(additionalItemRow); //-----------------additionalItemRow added to CONOPSDevWSTableWS1

                TableCell hoursRowCell1 = new TableCell();
                TableCell hoursRowCell2 = new TableCell();


                hoursRowCell1.ColumnSpan = 5;
                hoursRowCell1.Style.Add("text-align", "right");

                Label LabelhoursRow1 = new Label();
                LabelhoursRow1.Text = "Hours per year  ";

                Label LabelhoursRow2 = new Label();
                LabelhoursRow2.Text = "000";

                hoursRowCell1.Controls.Add(LabelhoursRow1);
                hoursRowCell1.Controls.Add(LabelhoursRow2);

                hoursRow.Cells.Add(hoursRowCell1);
                hoursRow.Cells.Add(hoursRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(hoursRow); //-----------------hoursRow added to CONOPSDevWSTableWS1

                TableCell hoursBlankRowCell1 = new TableCell();
                TableCell hoursBlankRowCell2 = new TableCell();


                hoursBlankRowCell1.ColumnSpan = 5;

                Literal LiteralhoursBlankRow = new Literal();
                LiteralhoursBlankRow.Text = "&nbsp;";

                hoursBlankRowCell1.Controls.Add(LiteralhoursBlankRow);

                hoursBlankRow.Cells.Add(hoursBlankRowCell1);
                hoursBlankRow.Cells.Add(hoursBlankRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(hoursBlankRow); //-----------------hoursBlankRow added to CONOPSDevWSTableWS1

                TableCell contractFeeRowCell1 = new TableCell();
                TableCell contractFeeRowCell2 = new TableCell();

             

                contractFeeRowCell1.ColumnSpan = 5;
                contractFeeRowCell1.Style.Add("text-align", "right");

                contractFeeRowCell1.Text = "Contract fee";
                contractFeeRowCell2.Text = "0000";

                contractFeeRow.Cells.Add(contractFeeRowCell1);
                contractFeeRow.Cells.Add(contractFeeRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(contractFeeRow); //-----------------contractFeeRow added to CONOPSDevWSTableWS1

                TableCell contractorFYTotalRowCell1 = new TableCell();
                TableCell contractorFYTotalRowCell2 = new TableCell();


                contractorFYTotalRowCell1.ColumnSpan = 5;
                contractorFYTotalRowCell1.Style.Add("text-align", "right");

                Label LabelcontractorFYTotalVals1 = new Label();
                LabelcontractorFYTotalVals1.Text = "Total for FY ";

                Label LabelcontractorFYTotalVals2 = new Label();
                LabelcontractorFYTotalVals2.Text = "15";

                contractorFYTotalRowCell1.Controls.Add(LabelcontractorFYTotalVals1);
                contractorFYTotalRowCell1.Controls.Add(LabelcontractorFYTotalVals2);
                contractorFYTotalRowCell2.Text = "0000";

                contractorsFYTotalRow.Cells.Add(contractorFYTotalRowCell1);
                contractorsFYTotalRow.Cells.Add(contractorFYTotalRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(contractorsFYTotalRow); //-----------------contractorFYTotalRow added to CONOPSDevWSTableWS1

                TableCell contractorsSubTotalRowCell1 = new TableCell();
                TableCell contractorsSubTotalRowCell2 = new TableCell();
                TableCell contractorsSubTotalRowCell3 = new TableCell();

                

                contractorsSubTotalRowCell1.ColumnSpan = 4;
                contractorsSubTotalRowCell1.Style.Add("background-color", "#bfbfbf");

                contractorsSubTotalRowCell2.Style.Add("text-align", "right");
                contractorsSubTotalRowCell2.Style.Add("font-weight", "bold");
                contractorsSubTotalRowCell2.Style.Add("background-color", "#d0ffbc");
                contractorsSubTotalRowCell2.Text = "Sub-Total:​";

                contractorsSubTotalRowCell3.Style.Add("text-align", "center");
                contractorsSubTotalRowCell3.Style.Add("background-color", "#d0ffbc");
                contractorsSubTotalRowCell3.Text = "0000";

                contractorsSubTotalRow.Cells.Add(contractorsSubTotalRowCell1);
                contractorsSubTotalRow.Cells.Add(contractorsSubTotalRowCell2);
                contractorsSubTotalRow.Cells.Add(contractorsSubTotalRowCell3);

                CONOPSDevWSTableWS1.Rows.Add(contractorsSubTotalRow); //-----------------contractorsSubTotalRow added to CONOPSDevWSTableWS1

                TableCell contractorsTotalRowCell1 = new TableCell();
                TableCell contractorsTotalRowCell2 = new TableCell();


                contractorsTotalRowCell1.ColumnSpan = 5;
                contractorsTotalRowCell1.Style.Add("text-align", "right");
                contractorsTotalRowCell1.Style.Add("font-weight", "bold");
                contractorsTotalRowCell1.Style.Add("background-color", "#d0ffbc");
                contractorsTotalRowCell1.Text = "Total:";

                contractorsTotalRowCell2.Text = "0000";
                contractorsTotalRowCell2.Style.Add("background-color", "#d0ffbc");

                contractorsTotalRow.Cells.Add(contractorsTotalRowCell1);
                contractorsTotalRow.Cells.Add(contractorsTotalRowCell2);

                CONOPSDevWSTableWS1.Rows.Add(contractorsTotalRow); //-----------------contractorsTotalRow added to CONOPSDevWSTableWS1

                TableCell attachmentsRowCell = new TableCell();

               


                attachmentsRowCell.ColumnSpan = 6;
                attachmentsRowCell.Style.Add("font-weight", "bold");
                attachmentsRowCell.Text = "Attachments";

                attachmentsRow.Cells.Add(attachmentsRowCell);

                CONOPSDevWSTableWS1.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTableWS1

                TableCell attachmentsValRowCell = new TableCell();


                attachmentsValRowCell.ColumnSpan = 6;
                attachmentsValRowCell.Text = "attachment1.text";
                attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

                attachmentsValRow.Cells.Add(attachmentsValRowCell);

                CONOPSDevWSTableWS1.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTableWS1



                //================= END OF TABLE TEMPLATE ==================== 






                SPQuery oQuery1 = new SPQuery();
                oQuery1.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy><Where>" +
                   "<And><And><And><And>" +
                       "<Eq>" +
                           "<FieldRef Name='CONOPSApproval'/>" +
                               "<Value Type='Choice'>Deputy Director Approval</Value>" +
                        "</Eq>" +
                        "<Eq>" +
                           "<FieldRef Name='ContentType'/>" +
                               "<Value Type='Computed'>WS1</Value>" +
                           "</Eq>" +
                   "</And>" +
                    "<Eq>" +
                           "<FieldRef Name='FY'/>" +
                               "<Value Type='Text'>" + qs_fy + "</Value>" +
                           "</Eq>" +
                   "</And>" +
                    "<Neq>" +
                           "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                               "<Value Type='Choice'>Not Approved</Value>" +
                           "</Neq>" +
                   "</And>" +
                    "<Neq>" +
                           "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                               "<Value Type='Choice'>Pending</Value>" +
                           "</Neq>" +
                   "</And>" +
               "</Where>";


                SPListItemCollection collListItems1 = oList.GetItems(oQuery1);


                if (collListItems1.Count > 0)
                {
                    oLibQuery.Query = "" +
                      "<OrderBy>" +
                          "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                      "</OrderBy>" +
                      "<Where>" +
                          "<And>" +
                              "<Eq>" +
                                  "<FieldRef Name=\"FY\"/>" +
                                  "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                              "</Eq>" +
                               "<Eq>" +
                                  "<FieldRef Name=\"WS\"/>" +
                                  "<Value Type=\"Text\">WS1</Value>" +
                              "</Eq>" +
                          "</And>" +
                      "</Where>";

                    SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);
                    
                    if (collLibItems.Count > 0)
                    {
                        bool removeAttachmentRow = true;

                        foreach (SPListItem oLibItem in collLibItems)
                        {


                            SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                            foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                            {
                                if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                                {
                                    traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    TableRow attachmentsValRw = new TableRow();

                                    TableCell attachmentsValRwCell = new TableCell();

                                    attachmentsValRwCell.ColumnSpan = 6;
                                    attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                    attachmentsValRwCell.Style.Add("text-align", "center");

                                    string versionUrl = SPContext.Current.Web.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                    traceInfo = versionUrl;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    Literal LiteralattachmentsValRwCell = new Literal();
                                    LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                    attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                    attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                    CONOPSDevWSTableWS1.Rows.AddAt(attachmentIndex, attachmentsValRw);
                                    
                                    removeAttachmentRow = false;

                                    break;

                                }
                            }

                        }

                        if (removeAttachmentRow)
                        {
                            CONOPSDevWSTableWS1.Controls.Remove(attachmentsRow);
                        }

                        CONOPSDevWSTableWS1.Controls.Remove(attachmentsValRow);

                    }
                    else
                    {
                        CONOPSDevWSTableWS1.Controls.Remove(attachmentsRow);
                        CONOPSDevWSTableWS1.Controls.Remove(attachmentsValRow);
                    }


                    foreach (SPListItem oListItem in collListItems1)
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        string GovLaborMonth = "";
                        string MilitarySubTotal = "";



                        if (oListItem[TotalGUID] != null)
                        {
                            try
                            {
                                traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                contractorsTotalRowCell2.Text = oListItem[TotalGUID].ToString();




                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                           

                            contractorsTotalRow.ID = id;
                        }
                        else if (title == "GovLaborMonth")
                        {


                            try
                            {
                                GovLaborMonth += oListItem["GovLaborMonth"].ToString();
                                traceInfo = "GovLaborMonth: " + GovLaborMonth;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            militaryGovRowCell2.Text = GovLaborMonth;


                            militaryGovRow.ID = id;



                        }
                        else if (title == "MilitarySubTotal")
                        {


                            try
                            {
                                MilitarySubTotal += oListItem["MilitarySubTotal"].ToString();
                                traceInfo = "MilitarySubTotal: " + MilitarySubTotal;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            militarySubTotalRowCell3.Text = MilitarySubTotal;



                           


                            militarySubTotalRow.ID = id;



                        }




                    }
                    foreach (SPListItem oListItem in collListItems1) //MilGov
                    {
                        string title = oListItem.Title.ToString();
                        string id = oListItem.ID.ToString();
                        string employer = "";
                        try
                        {
                            employer += oListItem["Employer"].ToString();
                            traceInfo = "employer: " + employer;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        if (employer == "MilitaryOrGovernmentCivilian")
                        {
                            try
                            {
                                TableRow militaryValsRw = new TableRow();

                                TableCell militaryValsRwCell1 = new TableCell();
                                TableCell militaryValsRwCell2 = new TableCell();
                                TableCell militaryValsRwCell3 = new TableCell();
                                TableCell militaryValsRwCell4 = new TableCell();
                                TableCell militaryValsRwCell5 = new TableCell();
                                TableCell militaryValsRwCell6 = new TableCell();

                               

                                militaryValsRwCell1.Style.Add("text-align", "center");
                                militaryValsRwCell2.Style.Add("text-align", "center");
                                militaryValsRwCell3.Style.Add("text-align", "center");
                                militaryValsRwCell4.Style.Add("text-align", "center");
                                militaryValsRwCell5.Style.Add("text-align", "right");
                                militaryValsRwCell6.Style.Add("text-align", "center");

                                string militaryValsRwCell1Text = title;

                                string militaryValsRwCell2Text = "";
                                string militaryValsRwCell3Text = "";
                                string militaryValsRwCell4Text = "";
                                string militaryValsRwCell5Text = "";
                                string militaryValsRwCell6Text = "";

                                try { militaryValsRwCell2Text = oListItem["DutyTitlePosition"].ToString(); }
                                catch { }
                                try { militaryValsRwCell3Text = oListItem["Status"].ToString(); }
                                catch { }
                                try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { militaryValsRwCell4Text = oListItem["Remarks"].ToString(); } }
                                catch { }
                                try { militaryValsRwCell5Text = oListItem["GSLevel"].ToString(); }
                                catch { }
                                try { militaryValsRwCell6Text = oListItem["Funding"].ToString(); }
                                catch { }






                                militaryValsRwCell1.Text = militaryValsRwCell1Text;
                                militaryValsRwCell2.Text = militaryValsRwCell2Text;
                                militaryValsRwCell3.Text = militaryValsRwCell3Text;
                                militaryValsRwCell4.Text = militaryValsRwCell4Text;
                                militaryValsRwCell5.Text = militaryValsRwCell5Text;
                                militaryValsRwCell6.Text = militaryValsRwCell6Text;




                                militaryValsRw.Cells.Add(militaryValsRwCell1);
                                militaryValsRw.Cells.Add(militaryValsRwCell2);
                                militaryValsRw.Cells.Add(militaryValsRwCell3);
                                militaryValsRw.Cells.Add(militaryValsRwCell4);
                                militaryValsRw.Cells.Add(militaryValsRwCell5);
                                militaryValsRw.Cells.Add(militaryValsRwCell6);
                                militaryValsRw.ID = id;

                               
                          

                                traceInfo = "Rows.AddAt militaryIndex: " + militaryIndex;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                CONOPSDevWSTableWS1.Rows.AddAt(militaryIndex, militaryValsRw);
                                contractIndex = contractIndex + 1;
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("milvalsRwCells", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                        CONOPSDevWSTableWS1.Controls.Remove(militaryValsRow);

                    }
                    string contractCheck = "";
                    bool contractItemBlankRowAdded = false;
                    List<string> listOfContracts = new List<string>();

                    foreach (SPListItem oListItem in collListItems1)
                    {
                        string title = "" + oListItem.Title.ToString();
                        traceInfo = "title: " + title;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        string id = oListItem.ID.ToString();

                        string employer = "";
                        string Contract = "";
                        string ContractsSubTotal = "";
                        string FY = "";
                        string ContractTotal = "";
                        string ContractFee = "";
                        string HoursPerYear = "";
                        string AdditionalLineItem = "";
                        string Funding = "";
                        string DutyTitlePosition = "";
                        string Status = "";
                        string Remarks = "";
                        string ContractorRate = "";

                        try
                        {
                            employer += oListItem["Employer"].ToString();
                            traceInfo = "employer: " + employer;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        try
                        {
                            Contract += oListItem["Contract"].ToString();
                            traceInfo = "Contract: " + Contract;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            if (contractCheck != "")
                            {
                                if (contractCheck != Contract)
                                {
                                    contractItemBlankRowAdded = false;
                                }

                            }


                            contractCheck = Contract;



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        if (Contract != "")
                        {



                            TableRow rw = new TableRow();

                            rw.ID = Contract;


                            //=============== Conditions =================

                            if (title == "ContractsSubTotal")
                            {
                                try
                                {
                                    ContractsSubTotal += oListItem["ContractsSubTotal"].ToString();
                                    traceInfo = "ContractsSubTotal: " + ContractsSubTotal;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }

                                rw.ID = "ContractsSubTotal";

                                TableCell contractorsSubTotalRwCell1 = new TableCell();
                                TableCell contractorsSubTotalRwCell2 = new TableCell();
                                TableCell contractorsSubTotalRwCell3 = new TableCell();

                                TableCell contractorsSubTotalRwCell4 = new TableCell();
                                TableCell contractorsSubTotalRwCell5 = new TableCell();

                                contractorsSubTotalRwCell1.ColumnSpan = 4;
                                contractorsSubTotalRwCell1.Style.Add("background-color", "#bfbfbf");

                                contractorsSubTotalRwCell2.Style.Add("text-align", "right");
                                contractorsSubTotalRwCell2.Style.Add("font-weight", "bold");
                                contractorsSubTotalRwCell2.Style.Add("background-color", "#d0ffbc");
                                contractorsSubTotalRwCell2.Text = "Sub-Total:​";

                                contractorsSubTotalRwCell3.Style.Add("text-align", "center");
                                contractorsSubTotalRwCell3.Style.Add("background-color", "#d0ffbc");

                                contractorsSubTotalRwCell3.Text = ContractsSubTotal;


                                rw.Cells.Add(contractorsSubTotalRwCell1);
                                rw.Cells.Add(contractorsSubTotalRwCell2);
                                rw.Cells.Add(contractorsSubTotalRwCell3);

                             
                            }


                            //CONDITIONS 

                            if (title == "ContractTotal")
                            {
                                try
                                {
                                    FY += oListItem["FY"].ToString();
                                    traceInfo = "ContractFY: " + FY;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    ContractTotal += oListItem["ContractTotal"].ToString();
                                    traceInfo = "ContractFYTotal: " + ContractTotal;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                TableCell contractorFYTotalRwCell1 = new TableCell();
                                TableCell contractorFYTotalRwCell2 = new TableCell();

                                TableCell contractorFYTotalRwCell3 = new TableCell();
                                TableCell contractorFYTotalRwCell4 = new TableCell();


                                contractorFYTotalRwCell1.ColumnSpan = 5;
                                contractorFYTotalRwCell1.Style.Add("text-align", "right");
                                contractorFYTotalRwCell2.Style.Add("text-align", "center");

                                Label LabelcontractorFYTotalVals1b = new Label();
                                LabelcontractorFYTotalVals1b.Text = "Total for FY ";

                                Label LabelcontractorFYTotalVals2b = new Label();
                                LabelcontractorFYTotalVals2b.Text = FY;

                                contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals1b);
                                contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals2b);


                                contractorFYTotalRwCell2.Text = ContractTotal;


                                rw.Cells.Add(contractorFYTotalRwCell1);
                                rw.Cells.Add(contractorFYTotalRwCell2);

                            }

                            if (title == "ContractFee")
                            {
                                try
                                {
                                    ContractFee += oListItem["ContractFee"].ToString();
                                    traceInfo = "ContractFee: " + ContractFee;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }

                                TableCell contractFeeRwCell1 = new TableCell();
                                TableCell contractFeeRwCell2 = new TableCell();

                            

                                contractFeeRwCell1.ColumnSpan = 5;
                                contractFeeRwCell1.Style.Add("text-align", "right");
                                contractFeeRwCell2.Style.Add("text-align", "center");

                                contractFeeRwCell1.Text = "Contract fee";


                                contractFeeRwCell2.Text = ContractFee;


                                rw.Cells.Add(contractFeeRwCell1);
                                rw.Cells.Add(contractFeeRwCell2);

                                rw.ID = id;
                            }
                            if (title == "HoursPerYear")
                            {
                                try
                                {
                                    HoursPerYear += oListItem["HoursPerYear"].ToString();
                                    traceInfo = "HoursPerYear: " + HoursPerYear;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                TableRow hoursBlankRw = new TableRow();

                                TableCell hoursBlankRwCell1 = new TableCell();
                                TableCell hoursBlankRwCell2 = new TableCell();

                               

                                hoursBlankRwCell1.ColumnSpan = 5;

                                Literal LiteralhoursBlankRowb = new Literal();
                                LiteralhoursBlankRowb.Text = "&nbsp;";

                                hoursBlankRwCell1.Controls.Add(LiteralhoursBlankRowb);

                                hoursBlankRw.Cells.Add(hoursBlankRwCell1);
                                hoursBlankRw.Cells.Add(hoursBlankRwCell2);

                            

                                hoursBlankRw.ToolTip = Contract;
                                hoursBlankRw.ID = "BlankHoursRow";

                                CONOPSDevWSTableWS1.Rows.AddAt(contractIndex, hoursBlankRw);


                                TableCell hoursRwCell1 = new TableCell();
                                TableCell hoursRwCell2 = new TableCell();


                                hoursRwCell1.ColumnSpan = 5;
                                hoursRwCell1.Style.Add("text-align", "right");
                                hoursRwCell2.Style.Add("text-align", "center");

                                Label LabelhoursRow1b = new Label();
                                LabelhoursRow1b.Text = "Hours per year  " + HoursPerYear;

                                LabelhoursRow1b.ToolTip = Contract;
                                LabelhoursRow1b.ID = "HoursPerYear";


                                hoursRwCell1.Controls.Add(LabelhoursRow1b);


                                rw.Cells.Add(hoursRwCell1);
                                rw.Cells.Add(hoursRwCell2);

                                rw.ID = id;
                            }


                            try
                            {
                                AdditionalLineItem += oListItem["AdditionalLineItem"].ToString();
                                traceInfo = "AdditionalLineItem: " + AdditionalLineItem;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            if (AdditionalLineItem != "")
                            {


                                TableCell additionalItemRwCell1 = new TableCell();
                                TableCell additionalItemRwCell2 = new TableCell();


                                additionalItemRwCell1.ColumnSpan = 5;
                                additionalItemRwCell1.Style.Add("text-align", "right");
                                additionalItemRwCell2.Style.Add("text-align", "center");

                                Label LabeladditionalItemDesc1b = new Label();
                                LabeladditionalItemDesc1b.Text = "Additional line item (title and amount) ";

                                Label LabeladditionalItemDesc2bTextBox = new Label();
                                LabeladditionalItemDesc2bTextBox.Text = title;
                                LabeladditionalItemDesc2bTextBox.Font.Italic = false;

                                additionalItemRwCell1.Controls.Add(LabeladditionalItemDesc1b);
                                additionalItemRwCell1.Controls.Add(LabeladditionalItemDesc2bTextBox);


                                additionalItemRwCell2.Text = AdditionalLineItem;



                                rw.Cells.Add(additionalItemRwCell1);
                                rw.Cells.Add(additionalItemRwCell2);

                                

                                rw.ID = id;
                                string dds1 = oListItem["DateDraftSaved"].ToString();


                                if (oListItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                                {

                                    rw.ToolTip = "NewLineItem_" + Contract;


                                }


                                AdditionalLineItem = "";





                            }



                            try
                            {
                                Funding += oListItem["Funding"].ToString();
                                traceInfo = "Funding: " + Funding;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            if (Funding != "")
                            {




                                try
                                {
                                    DutyTitlePosition += oListItem["DutyTitlePosition"].ToString();
                                    traceInfo = "DutyTitlePosition: " + DutyTitlePosition;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                try
                                {
                                    Status += oListItem["Status"].ToString();
                                    traceInfo = "Status: " + Status;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                try
                                {
                                    if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); }
                                    traceInfo = "Remarks: " + Remarks;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                                try
                                {
                                    ContractorRate += oListItem["ContractorRate"].ToString();
                                    traceInfo = "ContractorRate: " + ContractorRate;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }

                                TableCell contractorsValsRwCell1 = new TableCell();
                                TableCell contractorsValsRwCell2 = new TableCell();
                                TableCell contractorsValsRwCell3 = new TableCell();
                                TableCell contractorsValsRwCell4 = new TableCell();
                                TableCell contractorsValsRwCell5 = new TableCell();
                                TableCell contractorsValsRwCell6 = new TableCell();


                                contractorsValsRwCell1.Style.Add("text-align", "center");
                                contractorsValsRwCell2.Style.Add("text-align", "center");
                                contractorsValsRwCell3.Style.Add("text-align", "center");
                                contractorsValsRwCell4.Style.Add("text-align", "center");
                                contractorsValsRwCell5.Style.Add("text-align", "right");
                                contractorsValsRwCell6.Style.Add("text-align", "center");



                                contractorsValsRwCell1.Text = title;
                                contractorsValsRwCell2.Text = DutyTitlePosition;
                                contractorsValsRwCell3.Text = Status;
                                contractorsValsRwCell4.Text = Remarks;
                                contractorsValsRwCell5.Text = ContractorRate;
                                contractorsValsRwCell6.Text = Funding;



                                rw.Cells.Add(contractorsValsRwCell1);
                                rw.Cells.Add(contractorsValsRwCell2);
                                rw.Cells.Add(contractorsValsRwCell3);
                                rw.Cells.Add(contractorsValsRwCell4);
                                rw.Cells.Add(contractorsValsRwCell5);
                                rw.Cells.Add(contractorsValsRwCell6);


                                rw.ID = id;
                                bool contractSectionExists = false;
                                string dds = oListItem["DateDraftSaved"].ToString();


                                if (oListItem["OTASubmissionID"] == null && !dds.Contains(":"))
                                {

                                    rw.ToolTip = "NewItem_" + Contract; //oListItem["Contract"].ToString()


                                }
                                else { contractSectionExists = true; }


                                Funding = "";

                                //----------


                                if (!contractItemBlankRowAdded && contractSectionExists)
                                {
                                    TableRow contractorsBlankRw = new TableRow();

                                    TableCell contractorsBlankRwCell1 = new TableCell();
                                    TableCell contractorsBlankRwCell2 = new TableCell();


                                    contractorsBlankRwCell1.ColumnSpan = 5;

                                    Literal LiteralcontractorsBlankRw = new Literal();
                                    LiteralcontractorsBlankRw.Text = "&nbsp;";

                                    contractorsBlankRwCell1.Controls.Add(LiteralcontractorsBlankRw);

                                    contractorsBlankRw.Cells.Add(contractorsBlankRwCell1);
                                    contractorsBlankRw.Cells.Add(contractorsBlankRwCell2);

                                    contractorsBlankRw.ID = "contractorsBlankRow";
                                    contractorsBlankRw.ToolTip = Contract;

                                    CONOPSDevWSTableWS1.Rows.AddAt(contractIndex, contractorsBlankRw);

                                    contractItemBlankRowAdded = true;
                                }


                            }
                            if (title == "Contract")
                            {

                                TableCell contractorsDescRwCell = new TableCell();

                               

                                contractorsDescRwCell.ColumnSpan = 6;

                                contractorsDescRwCell.Style.Add("text-align", "center");
                                contractorsDescRwCell.Style.Add("font-style", "italic");

                                Label LabelcontractorsDesc1b = new Label();
                                LabelcontractorsDesc1b.Text = "Contract Identifier  ";

                                Label LabelcontractorsDesc2bTextBox = new Label();
                                LabelcontractorsDesc2bTextBox.Text = Contract;
                                LabelcontractorsDesc2bTextBox.Font.Italic = false;
                                LabelcontractorsDesc2bTextBox.ID = "rowId" + id + "Contract";
                                LabelcontractorsDesc2bTextBox.CssClass = "ContractIdentifyer";

                                contractorsDescRwCell.Controls.Add(LabelcontractorsDesc1b);
                                contractorsDescRwCell.Controls.Add(LabelcontractorsDesc2bTextBox);

                                rw.Cells.Add(contractorsDescRwCell);


                                rw.ToolTip = "Contract";

                            }


                            //==================
                            rw.ID = id;
                            //rw.CssClass = "WSGroupStartRow";

                            CONOPSDevWSTableWS1.Rows.AddAt(contractIndex, rw);
                        }

                    }




                }
                //end collListItems1.Count > 0



                try
                {
                    //Remove template rows
                    CONOPSDevWSTableWS1.Controls.Remove(contractorsDescRow);
                    CONOPSDevWSTableWS1.Controls.Remove(contractorsValsRow);
                    CONOPSDevWSTableWS1.Controls.Remove(contractorsBlankRow);
                    CONOPSDevWSTableWS1.Controls.Remove(additionalItemRow);
                    CONOPSDevWSTableWS1.Controls.Remove(hoursRow);
                    CONOPSDevWSTableWS1.Controls.Remove(hoursBlankRow);
                    CONOPSDevWSTableWS1.Controls.Remove(contractFeeRow);
                    CONOPSDevWSTableWS1.Controls.Remove(contractorsFYTotalRow);
                    CONOPSDevWSTableWS1.Controls.Remove(contractorsSubTotalRow);
                    CONOPSDevWSTableWS1.Controls.Remove(attachmentsValRow);

                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
            }
            else
            {
                TableRow headerTitleRow = new TableRow();
                TableRow msgRow = new TableRow();
                TableCell msgCell = new TableCell();
                TableCell headerTitleCell = new TableCell();

                headerTitleRow.Style.Add("text-align", "center");
                msgCell.Text = "Worksheet Pending Approval";
                msgCell.CssClass = "msgCell";
                msgCell.Style.Add("font-size","14px");
               
                headerTitleCell.Controls.Add(headerTitleCellDivWS1);
                headerTitleRow.Cells.Add(headerTitleCell);
                msgRow.Cells.Add(msgCell);

                CONOPSDevWSTableWS1.Rows.Add(headerTitleRow); 
                CONOPSDevWSTableWS1.Rows.Add(msgRow);

            }
        }

     







    }
}
