﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    class WS1makeViewOrFormForOTASubmission
    {
        internal static void makeViewOrFormForOTASubmission(TableRow militaryGovRow, TableRow militarySubTotalRow, TableRow contractorsTotalRow, TableRow contractorsDescRow, TableRow contractorsValsRow, TableRow contractorsBlankRow, TableRow additionalItemRow, TableRow hoursRow, TableRow hoursBlankRow, TableRow contractFeeRow, TableRow contractorsFYTotalRow, TableRow contractorsSubTotalRow, TableRow attachmentsRow, TableRow attachmentsValRow, TableCell contractorsTotalRowCell2, TableCell militaryGovRowCell2, TableCell militarySubTotalRowCell3, TableRow militaryValsRow, TableCell militaryGovRowCell3, TableCell militaryGovRowCell4, TableCell militarySubTotalRowCell4, TableCell militarySubTotalRowCell5, TableCell contractorsTotalRowCell3, TableCell contractorsTotalRowCell4, Table CONOPSDevWSTable, string qs_submitted, string qs_ota, string qs_otashort, string qs_fy, string qs_tab, string qs_ws, HiddenField DisablePMReview, HiddenField DisableDeputyDirectorReviewandApproval)
        {
            try
            {
            

                TableRowCollection rows = CONOPSDevWSTable.Rows;


                int contractIndex = 17;
                int attachmentIndex = 20;
                var traceInfo = "";
                int militaryIndex = 4;

                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);


                //oLib            
                traceInfo = "oLib for attachments";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPQuery oLibQuery = new SPQuery();

                
                //oLibQuery.Query = "" +
                //     "<OrderBy>" +
                //         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                //     "</OrderBy>" +
                //     "<Where>" +
                //         "<And>" +
                //             "<Eq>" +
                //                 "<FieldRef Name=\"FY\"/>" +
                //                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                //             "</Eq>" +
                //              "<Eq>" +
                //                 "<FieldRef Name=\"WS\"/>" +
                //                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                //             "</Eq>" +
                //         "</And>" +
                //     "</Where>";
                oLibQuery.Query = "" +
                   "<OrderBy>" +
                       "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                   "</OrderBy>" +
                   "<Where>" +
                       "<Or>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                "</Eq>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"WS\"/>" +
                                    "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +

                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                "</Eq>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Title\"/>" +
                                    "<Value Type=\"Text\">Approval Memo</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Or>" +
                    "</Where>";
                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;
                    string approvalMemoStr = "";

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Baseline OTA Submission" && oListItemVersion.VersionLabel != "1.0")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (oListItemVersion["Title"] != null)
                                {
                                    if ((string)oListItemVersion["Title"] == "Approval Memo")
                                    {
                                        approvalMemoStr = "Approval Memo: ";
                                    }
                                }


                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();

                                attachmentsValRwCell.ColumnSpan = 6;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + approvalMemoStr + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                           
                        }

                    }

                    if(removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }
                
                //oList
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">Baseline OTA Submission</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);


                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");


                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();
                    string GovLaborMonth = "";
                    string MilitarySubTotal = "";
                    string Employer = "";
                    try
                    {
                        Employer += oListItem["Employer"].ToString();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            contractorsTotalRowCell2.Text = oListItem[TotalGUID].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }

                    else if (title == "GovLaborMonth")
                    {

                        try
                        {
                            GovLaborMonth += oListItem["GovLaborMonth"].ToString();
                            militaryGovRowCell2.Text = GovLaborMonth;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                    else if (title == "MilitarySubTotal")
                    {

                        try
                        {
                            MilitarySubTotal += oListItem["MilitarySubTotal"].ToString();
                            militarySubTotalRowCell3.Text = MilitarySubTotal;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }

                    else if (Employer == "MilitaryOrGovernmentCivilian")
                    {
                        TableRow militaryValsRw = new TableRow();

                        TableCell militaryValsRwCell1 = new TableCell();
                        TableCell militaryValsRwCell2 = new TableCell();
                        TableCell militaryValsRwCell3 = new TableCell();
                        TableCell militaryValsRwCell4 = new TableCell();
                        TableCell militaryValsRwCell5 = new TableCell();
                        TableCell militaryValsRwCell6 = new TableCell();

                        militaryValsRwCell1.Style.Add("text-align", "center");
                        militaryValsRwCell2.Style.Add("text-align", "center");
                        militaryValsRwCell3.Style.Add("text-align", "center");
                        militaryValsRwCell4.Style.Add("text-align", "center");
                        militaryValsRwCell5.Style.Add("text-align", "right");
                        militaryValsRwCell6.Style.Add("text-align", "center");

                        string militaryValsRwCell1Text = title;

                        string militaryValsRwCell2Text = "";
                        string militaryValsRwCell3Text = "";
                        string militaryValsRwCell4Text = "";
                        string militaryValsRwCell5Text = "";
                        string militaryValsRwCell6Text = "";

                        try { militaryValsRwCell2Text = oListItem["DutyTitlePosition"].ToString(); }
                        catch { }
                        try { militaryValsRwCell3Text = oListItem["Status"].ToString(); }
                        catch { }
                        try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { militaryValsRwCell4Text = oListItem["Remarks"].ToString(); } }
                        catch { }
                        try { militaryValsRwCell5Text = oListItem["GSLevel"].ToString(); }
                        catch { }
                        try { militaryValsRwCell6Text = oListItem["Funding"].ToString(); }
                        catch { }

                        militaryValsRwCell1.Text = militaryValsRwCell1Text;
                        militaryValsRwCell2.Text = militaryValsRwCell2Text;
                        militaryValsRwCell3.Text = militaryValsRwCell3Text;
                        militaryValsRwCell4.Text = militaryValsRwCell4Text;
                        militaryValsRwCell5.Text = militaryValsRwCell5Text;
                        militaryValsRwCell6.Text = militaryValsRwCell6Text;

                        militaryValsRw.Cells.Add(militaryValsRwCell1);
                        militaryValsRw.Cells.Add(militaryValsRwCell2);
                        militaryValsRw.Cells.Add(militaryValsRwCell3);
                        militaryValsRw.Cells.Add(militaryValsRwCell4);
                        militaryValsRw.Cells.Add(militaryValsRwCell5);
                        militaryValsRw.Cells.Add(militaryValsRwCell6);

                        CONOPSDevWSTable.Rows.AddAt(militaryIndex, militaryValsRw);

                        contractIndex = contractIndex + 1;
                    }

                    try
                    {
                        CONOPSDevWSTable.Controls.Remove(militaryValsRow);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }




                string contractCheck = "";
                bool contractItemBlankRowAdded = false;

                foreach (SPListItem oListItem in collListItems)
                {

                    string title = "" + oListItem.Title.ToString();
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    string id = oListItem.ID.ToString();

                    string employer = "";
                    string Contract = "";
                    string ContractsSubTotal = "";
                    string FY = "";
                    string ContractTotal = "";
                    string ContractFee = "";
                    string HoursPerYear = "";
                    string AdditionalLineItem = "";
                    string Funding = "";
                    string DutyTitlePosition = "";
                    string Status = "";
                    string Remarks = "";
                    string ContractorRate = "";

                    try
                    {
                        employer += oListItem["Employer"].ToString();
                        traceInfo = "employer: " + employer;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                    try
                    {
                        Contract += oListItem["Contract"].ToString();
                        traceInfo = "Contract: " + Contract;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (contractCheck != "")
                        {
                            if (contractCheck != Contract)
                            {
                                contractItemBlankRowAdded = false;
                            }

                        }


                        contractCheck = Contract;



                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    if (Contract != "")
                    {



                        TableRow rw = new TableRow();

                        rw.ID = Contract;


                        //=============== Conditions =================

                        if (title == "ContractsSubTotal")
                        {
                            try
                            {
                                ContractsSubTotal += oListItem["ContractsSubTotal"].ToString();
                                traceInfo = "ContractsSubTotal: " + ContractsSubTotal;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            rw.ID = "ContractsSubTotal";

                            TableCell contractorsSubTotalRwCell1 = new TableCell();
                            TableCell contractorsSubTotalRwCell2 = new TableCell();
                            TableCell contractorsSubTotalRwCell3 = new TableCell();


                            contractorsSubTotalRwCell1.ColumnSpan = 4;
                            contractorsSubTotalRwCell1.Style.Add("background-color", "#bfbfbf");

                            contractorsSubTotalRwCell2.Style.Add("text-align", "right");
                            contractorsSubTotalRwCell2.Style.Add("font-weight", "bold");
                            contractorsSubTotalRwCell2.Style.Add("background-color", "#d0ffbc");
                            contractorsSubTotalRwCell2.Text = "Sub-Total:​";

                            contractorsSubTotalRwCell3.Style.Add("text-align", "center");
                            contractorsSubTotalRwCell3.Style.Add("background-color", "#d0ffbc");

                            contractorsSubTotalRwCell3.Text = ContractsSubTotal;


                            rw.Cells.Add(contractorsSubTotalRwCell1);
                            rw.Cells.Add(contractorsSubTotalRwCell2);
                            rw.Cells.Add(contractorsSubTotalRwCell3);


                            rw.ID = id;
                        }


                        //CONDITIONS 

                        if (title == "ContractTotal")
                        {
                            try
                            {
                                FY += oListItem["FY"].ToString();
                                traceInfo = "ContractFY: " + FY;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                ContractTotal += oListItem["ContractTotal"].ToString();
                                traceInfo = "ContractFYTotal: " + ContractTotal;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            TableCell contractorFYTotalRwCell1 = new TableCell();
                            TableCell contractorFYTotalRwCell2 = new TableCell();

                            contractorFYTotalRwCell1.ColumnSpan = 5;
                            contractorFYTotalRwCell1.Style.Add("text-align", "right");
                            contractorFYTotalRwCell2.Style.Add("text-align", "center");

                            Label LabelcontractorFYTotalVals1b = new Label();
                            LabelcontractorFYTotalVals1b.Text = "Total for FY ";

                            Label LabelcontractorFYTotalVals2b = new Label();
                            LabelcontractorFYTotalVals2b.Text = FY;

                            contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals1b);
                            contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals2b);


                            contractorFYTotalRwCell2.Text = ContractTotal;


                            rw.Cells.Add(contractorFYTotalRwCell1);
                            rw.Cells.Add(contractorFYTotalRwCell2);

                        }

                        if (title == "ContractFee")
                        {
                            try
                            {
                                ContractFee += oListItem["ContractFee"].ToString();
                                traceInfo = "ContractFee: " + ContractFee;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            TableCell contractFeeRwCell1 = new TableCell();
                            TableCell contractFeeRwCell2 = new TableCell();


                            contractFeeRwCell1.ColumnSpan = 5;
                            contractFeeRwCell1.Style.Add("text-align", "right");
                            contractFeeRwCell2.Style.Add("text-align", "center");

                            contractFeeRwCell1.Text = "Contract fee";

                            contractFeeRwCell2.Text = ContractFee;


                            rw.Cells.Add(contractFeeRwCell1);
                            rw.Cells.Add(contractFeeRwCell2);

                            rw.ID = id;
                        }
                        if (title == "HoursPerYear")
                        {
                            try
                            {
                                HoursPerYear += oListItem["HoursPerYear"].ToString();
                                traceInfo = "HoursPerYear: " + HoursPerYear;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            TableRow hoursBlankRw = new TableRow();

                            TableCell hoursBlankRwCell1 = new TableCell();
                            TableCell hoursBlankRwCell2 = new TableCell();


                            hoursBlankRwCell1.ColumnSpan = 5;

                            Literal LiteralhoursBlankRowb = new Literal();
                            LiteralhoursBlankRowb.Text = "&nbsp;";

                            hoursBlankRwCell1.Controls.Add(LiteralhoursBlankRowb);

                            hoursBlankRw.Cells.Add(hoursBlankRwCell1);
                            hoursBlankRw.Cells.Add(hoursBlankRwCell2);



                            CONOPSDevWSTable.Rows.AddAt(contractIndex, hoursBlankRw);


                            TableCell hoursRwCell1 = new TableCell();
                            TableCell hoursRwCell2 = new TableCell();




                            hoursRwCell1.ColumnSpan = 5;
                            hoursRwCell1.Style.Add("text-align", "right");
                            hoursRwCell2.Style.Add("text-align", "center");

                            Label LabelhoursRow1b = new Label();
                            LabelhoursRow1b.Text = "Hours per year  " + HoursPerYear;

                            hoursRwCell1.Controls.Add(LabelhoursRow1b);


                            rw.Cells.Add(hoursRwCell1);
                            rw.Cells.Add(hoursRwCell2);


                            rw.ID = id;
                        }


                        try
                        {
                            AdditionalLineItem += oListItem["AdditionalLineItem"].ToString();
                            traceInfo = "AdditionalLineItem: " + AdditionalLineItem;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        if (AdditionalLineItem != "")
                        {


                            TableCell additionalItemRwCell1 = new TableCell();
                            TableCell additionalItemRwCell2 = new TableCell();


                            additionalItemRwCell1.ColumnSpan = 5;
                            additionalItemRwCell1.Style.Add("text-align", "right");
                            additionalItemRwCell2.Style.Add("text-align", "center");

                            Label LabeladditionalItemDesc1b = new Label();
                            LabeladditionalItemDesc1b.Text = "Additional line item (title and amount) " + title;

                            additionalItemRwCell1.Controls.Add(LabeladditionalItemDesc1b);

                            additionalItemRwCell2.Text = AdditionalLineItem;


                            rw.Cells.Add(additionalItemRwCell1);
                            rw.Cells.Add(additionalItemRwCell2);


                            rw.ID = id;

                            AdditionalLineItem = "";





                        }



                        try
                        {
                            Funding += oListItem["Funding"].ToString();
                            traceInfo = "Funding: " + Funding;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        if (Funding != "")
                        {




                            try
                            {
                                DutyTitlePosition += oListItem["DutyTitlePosition"].ToString();
                                traceInfo = "DutyTitlePosition: " + DutyTitlePosition;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                Status += oListItem["Status"].ToString();
                                traceInfo = "Status: " + Status;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); }
                                traceInfo = "Remarks: " + Remarks;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                ContractorRate += oListItem["ContractorRate"].ToString();
                                traceInfo = "ContractorRate: " + ContractorRate;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            TableCell contractorsValsRwCell1 = new TableCell();
                            TableCell contractorsValsRwCell2 = new TableCell();
                            TableCell contractorsValsRwCell3 = new TableCell();
                            TableCell contractorsValsRwCell4 = new TableCell();
                            TableCell contractorsValsRwCell5 = new TableCell();
                            TableCell contractorsValsRwCell6 = new TableCell();


                            contractorsValsRwCell1.Style.Add("text-align", "center");
                            contractorsValsRwCell2.Style.Add("text-align", "center");
                            contractorsValsRwCell3.Style.Add("text-align", "center");
                            contractorsValsRwCell4.Style.Add("text-align", "center");
                            contractorsValsRwCell5.Style.Add("text-align", "right");
                            contractorsValsRwCell6.Style.Add("text-align", "center");


                            contractorsValsRwCell1.Text = title;
                            contractorsValsRwCell2.Text = DutyTitlePosition;
                            contractorsValsRwCell3.Text = Status;
                            contractorsValsRwCell4.Text = Remarks;
                            contractorsValsRwCell5.Text = ContractorRate;
                            contractorsValsRwCell6.Text = Funding;


                            rw.Cells.Add(contractorsValsRwCell1);
                            rw.Cells.Add(contractorsValsRwCell2);
                            rw.Cells.Add(contractorsValsRwCell3);
                            rw.Cells.Add(contractorsValsRwCell4);
                            rw.Cells.Add(contractorsValsRwCell5);
                            rw.Cells.Add(contractorsValsRwCell6);


                            rw.ID = id;

                            Funding = "";

                            //----------


                            if (!contractItemBlankRowAdded)
                            {
                                TableRow contractorsBlankRw = new TableRow();

                                TableCell contractorsBlankRwCell1 = new TableCell();
                                TableCell contractorsBlankRwCell2 = new TableCell();


                                contractorsBlankRwCell1.ColumnSpan = 5;

                                Literal LiteralcontractorsBlankRw = new Literal();
                                LiteralcontractorsBlankRw.Text = "&nbsp;";

                                contractorsBlankRwCell1.Controls.Add(LiteralcontractorsBlankRw);

                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell1);
                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell2);


                                CONOPSDevWSTable.Rows.AddAt(contractIndex, contractorsBlankRw);

                                contractItemBlankRowAdded = true;
                            }


                        }
                        if (title == "Contract")
                        {

                            TableCell contractorsDescRwCell = new TableCell();


                            contractorsDescRwCell.ColumnSpan = 6;

                            contractorsDescRwCell.Style.Add("text-align", "center");
                            contractorsDescRwCell.Style.Add("font-style", "italic");

                            Label LabelcontractorsDesc1b = new Label();
                            LabelcontractorsDesc1b.Text = "Contract Identifier  ";

                            Label LabelcontractorsDesc2b = new Label();
                            LabelcontractorsDesc2b.Text = Contract;
                            LabelcontractorsDesc2b.Font.Italic = false;


                            contractorsDescRwCell.Controls.Add(LabelcontractorsDesc1b);
                            contractorsDescRwCell.Controls.Add(LabelcontractorsDesc2b);

                            rw.Cells.Add(contractorsDescRwCell);


                        }


                        rw.ID = id;

                        CONOPSDevWSTable.Rows.AddAt(contractIndex, rw);
                    }

                }



            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }

            try
            {
                //Remove template rows
                CONOPSDevWSTable.Controls.Remove(contractorsDescRow);
                CONOPSDevWSTable.Controls.Remove(contractorsValsRow);
                CONOPSDevWSTable.Controls.Remove(contractorsBlankRow);
                CONOPSDevWSTable.Controls.Remove(additionalItemRow);
                CONOPSDevWSTable.Controls.Remove(hoursRow);
                CONOPSDevWSTable.Controls.Remove(hoursBlankRow);
                CONOPSDevWSTable.Controls.Remove(contractFeeRow);
                CONOPSDevWSTable.Controls.Remove(contractorsFYTotalRow);
                CONOPSDevWSTable.Controls.Remove(contractorsSubTotalRow);
                CONOPSDevWSTable.Controls.Remove(attachmentsValRow); 
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }


      
    }
}
