﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using Microsoft.SharePoint.Utilities; 

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    public partial class WS1 : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack )
            {
                var traceInfo = "template WS1";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                
                enableTabs();

                //FilterSelected-----
                
                //end FilterSelected------


                //----------LinkButtonAdddocument-----

                //string uName = Page.User.Identity.Name;

                //QueryStrings requiring Page object reference
                string qs_submitted = Page.Request.QueryString["submitted"];
                string qs_ota = Page.Request.QueryString["ota"];
                string qs_otashort = Page.Request.QueryString["otashort"];
                string qs_fy = Page.Request.QueryString["fy"];
                string qs_tab = Page.Request.QueryString["tab"];
                string qs_ws = Page.Request.QueryString["ws"];

                string urlFirstPart = Page.Request.RawUrl;
                urlFirstPart = urlFirstPart.Substring(0, urlFirstPart.IndexOf("/_layouts"));

                traceInfo = "urlFirstPart: " + urlFirstPart;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPList oLibb = SPContext.Current.Web.Lists["CONOPSDev" + qs_otashort];
                string oLibbID = oLibb.ID.ToString();

                traceInfo = "oLibbID: " + oLibbID;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
             
                LinkButtonAdddocument.OnClientClick = "javascript:NewItem2(event, \'" + urlFirstPart + "/_layouts/Upload.aspx?List={" + oLibbID + "}&tab=" + qs_tab + "&fy=" + qs_fy + "&otashort=" + qs_otashort + "&ws=" + qs_ws + "&module=CONOPSApproval&RootFolder=\');javascript:return false;";
                
                //--end LinkButtonAdddocument--------------




                LabelOTA.Text = qs_ota;
                LabelWSFY.Text = qs_fy;

                //Table rows-----------------------------------------------------------------------------------

                TableRow headerTitleRow = new TableRow();
                TableRow headerRow = new TableRow();
                TableRow headerDescRow = new TableRow();
                TableRow militaryRow = new TableRow();
                TableRow militaryValsRow = new TableRow();
                TableRow militaryBlankRow = new TableRow();
                TableRow militaryGovRow = new TableRow();
                TableRow militarySubTotalRow = new TableRow();
                TableRow contractorsRow = new TableRow();
                TableRow contractorsDescRow = new TableRow();
                TableRow contractorsValsRow = new TableRow();
                TableRow contractorsBlankRow = new TableRow();
                TableRow additionalItemRow = new TableRow();
                TableRow hoursRow = new TableRow();
                TableRow hoursBlankRow = new TableRow();
                TableRow contractFeeRow = new TableRow();
                TableRow contractorsFYTotalRow = new TableRow();
                TableRow contractorsSubTotalRow = new TableRow();
                TableRow contractorsTotalRow = new TableRow();
                TableRow attachmentsRow = new TableRow();
                TableRow attachmentsValRow = new TableRow();
                TableRow attachDocRow = new TableRow();


                headerTitleRow.Style.Add("text-align", "center");
                headerRow.CssClass = "CONOPSDevWSColHeaders";
                headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
                headerDescRow.Style.Add("text-align", "center");
                headerDescRow.ID = "headerDescRow";
                militaryRow.Style.Add("text-align", "center");
                militaryValsRow.Style.Add("text-align", "center");
                militaryGovRow.ID = "militaryGovRow";
                militarySubTotalRow.ID = "militarySubTotalRow";
                contractorsDescRow.ID = "contractorsDescRow";
                contractorsValsRow.Style.Add("text-align", "center");
                contractorsBlankRow.ID = "contractorsBlankRow";
                additionalItemRow.Style.Add("text-align", "center");
                additionalItemRow.ID = "additionalItemRow";
                hoursRow.Style.Add("text-align", "center");
                hoursRow.ID = "hoursRow";
                contractFeeRow.Style.Add("text-align", "center");
                contractorsFYTotalRow.Style.Add("text-align", "center");
                contractorsSubTotalRow.Style.Add("text-align", "center");
                contractorsSubTotalRow.ID = "contractorsSubTotalRow";
                contractorsTotalRow.Style.Add("text-align", "center");
                contractorsTotalRow.ID = "contractorsTotalRow";
                contractorsTotalRow.ToolTip = "contractorsTotalRow";
                attachmentsRow.Style.Add("text-align", "center");
                attachmentsValRow.Style.Add("text-align", "center");
                

                //Table cells------------------------------------------------------------------------------------------

                TableCell headerTitleCell = new TableCell();
                headerTitleCell.ColumnSpan = 6;

                headerTitleCell.Controls.Add(headerTitleCellDiv);

                headerTitleRow.Cells.Add(headerTitleCell);

                CONOPSDevWSTable.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTable

                TableCell wsColCell1 = new TableCell();
                TableCell wsColCell2 = new TableCell();
                TableCell wsColCell3 = new TableCell();
                TableCell wsColCell4 = new TableCell();
                TableCell wsColCell5 = new TableCell();
                TableCell wsColCell6 = new TableCell();

                TableCell wsColCell7 = new TableCell();
                TableCell wsColCell8 = new TableCell();


                wsColCell1.CssClass = "CONOPSDevWSColCell";
                wsColCell2.CssClass = "CONOPSDevWSColCell";
                wsColCell3.CssClass = "CONOPSDevWSColCell";
                wsColCell4.CssClass = "CONOPSDevWSColCell";
                wsColCell5.CssClass = "CONOPSDevWSColCell";
                wsColCell6.CssClass = "CONOPSDevWSColCell";

                wsColCell7.CssClass = "CONOPSApprovalColCell";
                wsColCell8.CssClass = "CONOPSApprovalColCell";
                wsColCell7.Style.Add("width", "163px");
                wsColCell8.Style.Add("width", "163px");
                wsColCell7.Style.Add("font-weight", "bold");
                wsColCell8.Style.Add("font-weight", "bold");

            

                wsColCell1.Style.Add("width", "163px");
                wsColCell2.Style.Add("width", "155px");
                wsColCell3.Style.Add("width", "123px");
                wsColCell4.Style.Add("width", "187px");
                wsColCell5.Style.Add("width", "180px");
                wsColCell6.Style.Add("width", "214px");



                wsColCell1.Style.Add("font-weight", "bold");
                wsColCell2.Style.Add("font-weight", "bold");
                wsColCell3.Style.Add("font-weight", "bold");
                wsColCell4.Style.Add("font-weight", "bold");
                wsColCell5.Style.Add("font-weight", "bold");
                wsColCell6.Style.Add("font-weight", "bold");



                wsColCell1.Text = "Name";
                wsColCell2.Text = "Duty Title/Position​";
                wsColCell3.Text = "Status​";
                wsColCell4.Text = "Remarks​";
                wsColCell5.Text = "Contractor Rate or GS Level​";
                wsColCell6.Text = "Funding​";

                headerRow.Cells.Add(wsColCell1);
                headerRow.Cells.Add(wsColCell2);
                headerRow.Cells.Add(wsColCell3);
                headerRow.Cells.Add(wsColCell4);
                headerRow.Cells.Add(wsColCell5);
                headerRow.Cells.Add(wsColCell6);

                CONOPSDevWSTable.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTable

                TableCell headerDescRowCell1 = new TableCell();
                TableCell headerDescRowCell2 = new TableCell();
                TableCell headerDescRowCell3 = new TableCell();
                TableCell headerDescRowCell4 = new TableCell();
                TableCell headerDescRowCell5 = new TableCell();
                TableCell headerDescRowCell6 = new TableCell();

                TableCell headerDescRowCell7 = new TableCell();
                TableCell headerDescRowCell8 = new TableCell();

                headerDescRowCell1.Style.Add("font-style", "italic");
                headerDescRowCell2.Style.Add("font-style", "italic");
                headerDescRowCell3.Style.Add("font-style", "italic");
                headerDescRowCell4.Style.Add("font-style", "italic");
                headerDescRowCell5.Style.Add("font-style", "italic");
                headerDescRowCell6.Style.Add("font-style", "italic");

                headerDescRowCell7.Style.Add("font-style", "italic");
                headerDescRowCell8.Style.Add("font-style", "italic");
                //headerDescRowCell7.Style.Add("background-color", "Cornsilk");
                //headerDescRowCell8.Style.Add("background-color", "Cornsilk");


                headerDescRowCell1.Text = "List the name of each person proposed for funding​";
                headerDescRowCell2.Text = "Provide a duty title/position for each of your core personnel​​";
                headerDescRowCell3.Text = "Identify if the person is full or part time for funding​";
                headerDescRowCell4.Text = "Provide any comments to help clarify your cost estimates​";
                headerDescRowCell5.Text = "Provide the hourly rate for each contractor​";
                headerDescRowCell6.Text = "Provide the requested funding level for each of your core personnel​";

                headerDescRowCell7.Text = "Reviewer approval";
                headerDescRowCell8.Text = "Reviewer comments";

                headerDescRow.Cells.Add(headerDescRowCell1);
                headerDescRow.Cells.Add(headerDescRowCell2);
                headerDescRow.Cells.Add(headerDescRowCell3);
                headerDescRow.Cells.Add(headerDescRowCell4);
                headerDescRow.Cells.Add(headerDescRowCell5);
                headerDescRow.Cells.Add(headerDescRowCell6);

                CONOPSDevWSTable.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTable

                TableCell militaryRowCell = new TableCell();

                TableCell militaryRowCell2 = new TableCell();
                TableCell militaryRowCell3 = new TableCell();

                //militaryRowCell2.Style.Add("background-color", "Cornsilk");
                //militaryRowCell3.Style.Add("background-color", "Cornsilk");

                militaryRowCell.ColumnSpan = 6;
                militaryRowCell.Style.Add("font-weight", "bold");
                militaryRowCell.Text = "Military/Government Civilian​​";

                militaryRow.Cells.Add(militaryRowCell);

                CONOPSDevWSTable.Rows.Add(militaryRow); //-----------------militaryRow added to CONOPSDevWSTable

                TableCell militaryValsRowCell1 = new TableCell();
                TableCell militaryValsRowCell2 = new TableCell();
                TableCell militaryValsRowCell3 = new TableCell();
                TableCell militaryValsRowCell4 = new TableCell();
                TableCell militaryValsRowCell5 = new TableCell();
                TableCell militaryValsRowCell6 = new TableCell();

                TableCell militaryValsRowCell7 = new TableCell();
                TableCell militaryValsRowCell8 = new TableCell();

                militaryValsRowCell5.Style.Add("text-align", "right");

                militaryValsRowCell1.Text = "Text";
                militaryValsRowCell2.Text = "Text";
                militaryValsRowCell3.Text = "Text";
                militaryValsRowCell4.Text = "Text";
                militaryValsRowCell5.Text = "GS00";
                militaryValsRowCell6.Text = "0000";

                militaryValsRow.Cells.Add(militaryValsRowCell1);
                militaryValsRow.Cells.Add(militaryValsRowCell2);
                militaryValsRow.Cells.Add(militaryValsRowCell3);
                militaryValsRow.Cells.Add(militaryValsRowCell4);
                militaryValsRow.Cells.Add(militaryValsRowCell5);
                militaryValsRow.Cells.Add(militaryValsRowCell6);

                CONOPSDevWSTable.Rows.Add(militaryValsRow); //-----------------militaryValsRow added to CONOPSDevWSTable

                TableCell militaryBlankRowCell1 = new TableCell();
                TableCell militaryBlankRowCell2 = new TableCell();

                TableCell militaryBlankRowCell3 = new TableCell();
                TableCell militaryBlankRowCell4 = new TableCell();

                //militaryBlankRowCell3.Style.Add("background-color", "Cornsilk");
                //militaryBlankRowCell4.Style.Add("background-color", "Cornsilk");

                militaryBlankRowCell1.ColumnSpan = 5;

                Literal LiteralmilitaryBlankRow = new Literal();
                LiteralmilitaryBlankRow.Text = "&nbsp;";

                militaryBlankRowCell1.Controls.Add(LiteralmilitaryBlankRow);

                militaryBlankRow.Cells.Add(militaryBlankRowCell1);
                militaryBlankRow.Cells.Add(militaryBlankRowCell2);

                CONOPSDevWSTable.Rows.Add(militaryBlankRow); //-----------------militaryBlankRow added to CONOPSDevWSTable

                TableCell militaryGovRowCell1 = new TableCell();
                TableCell militaryGovRowCell2 = new TableCell();

                TableCell militaryGovRowCell3 = new TableCell();
                TableCell militaryGovRowCell4 = new TableCell();

                militaryGovRowCell1.ColumnSpan = 5;
                militaryGovRowCell1.Style.Add("text-align", "right");
                militaryGovRowCell1.Text = "Government Labor/month";

                militaryGovRowCell2.Style.Add("text-align", "center");
                militaryGovRowCell2.Text = "000";
                militaryGovRowCell2.ID = "militaryGovRowCell2";

                militaryGovRow.Cells.Add(militaryGovRowCell1);
                militaryGovRow.Cells.Add(militaryGovRowCell2);

                CONOPSDevWSTable.Rows.Add(militaryGovRow); //-----------------militaryGovRow added to CONOPSDevWSTable

                TableCell militarySubTotalRowCell1 = new TableCell();
                TableCell militarySubTotalRowCell2 = new TableCell();
                TableCell militarySubTotalRowCell3 = new TableCell();

                TableCell militarySubTotalRowCell4 = new TableCell();
                TableCell militarySubTotalRowCell5 = new TableCell();

                militarySubTotalRowCell1.ColumnSpan = 4;
                militarySubTotalRowCell1.Style.Add("background-color", "#bfbfbf");

                //----------------------AddMilGovBtn------------
                AddMilGovBtn.Text = "Add Military/Government Civilian";
                AddMilGovBtn.ToolTip = "Add Military/Government Civilian";
                AddMilGovBtn.CssClass = "CONOPSApprovalAddMilGovButton";
                militarySubTotalRowCell1.Controls.Add(AddMilGovBtn);
                //-----------------------------------------------------

                militarySubTotalRowCell2.Style.Add("text-align", "right");
                militarySubTotalRowCell2.Style.Add("font-weight", "bold");
                militarySubTotalRowCell2.Style.Add("background-color", "#d0ffbc");
                militarySubTotalRowCell2.Text = "Sub-Total:​";

                militarySubTotalRowCell3.Style.Add("text-align", "center");
                militarySubTotalRowCell3.Style.Add("background-color", "#d0ffbc");
                militarySubTotalRowCell3.Text = "0000";

                militarySubTotalRow.Cells.Add(militarySubTotalRowCell1);
                militarySubTotalRow.Cells.Add(militarySubTotalRowCell2);
                militarySubTotalRow.Cells.Add(militarySubTotalRowCell3);

                CONOPSDevWSTable.Rows.Add(militarySubTotalRow); //-----------------militarySubTotalRow added to CONOPSDevWSTable

                TableCell contractorsRowCell = new TableCell();

                TableCell contractorsRowCell2 = new TableCell();
                TableCell contractorsRowCell3 = new TableCell();

                //contractorsRowCell2.Style.Add("background-color", "Cornsilk");
                //contractorsRowCell3.Style.Add("background-color", "Cornsilk");

                contractorsRowCell.ColumnSpan = 6;

                contractorsRowCell.Style.Add("text-align", "center");
                contractorsRowCell.Style.Add("font-weight", "bold");
                contractorsRowCell.Text = "Contractors";

                contractorsRow.Cells.Add(contractorsRowCell);

                CONOPSDevWSTable.Rows.Add(contractorsRow); //-----------------contractorsRow added to CONOPSDevWSTable

                TableCell contractorsDescRowCell = new TableCell();

                TableCell contractorsDescRowCell2 = new TableCell();
                TableCell contractorsDescRowCell3 = new TableCell();

                contractorsDescRowCell.ColumnSpan = 6;

                contractorsDescRowCell.Style.Add("text-align", "center");
                contractorsDescRowCell.Style.Add("font-style", "italic");

                Label LabelcontractorsDesc1 = new Label();
                LabelcontractorsDesc1.Text = "Contract Identifier  ";

                Label LabelcontractorsDesc2 = new Label();
                LabelcontractorsDesc2.Text = "Text";
                LabelcontractorsDesc2.Font.Italic = false;

                contractorsDescRowCell.Controls.Add(LabelcontractorsDesc1);
                contractorsDescRowCell.Controls.Add(LabelcontractorsDesc2);

                contractorsDescRow.Cells.Add(contractorsDescRowCell);

                CONOPSDevWSTable.Rows.Add(contractorsDescRow); //-----------------contractorsDescRow added to CONOPSDevWSTable

                TableCell contractorsValsRowCell1 = new TableCell();
                TableCell contractorsValsRowCell2 = new TableCell();
                TableCell contractorsValsRowCell3 = new TableCell();
                TableCell contractorsValsRowCell4 = new TableCell();
                TableCell contractorsValsRowCell5 = new TableCell();
                TableCell contractorsValsRowCell6 = new TableCell();

                TableCell contractorsValsRowCell7 = new TableCell();
                TableCell contractorsValsRowCell8 = new TableCell();

                contractorsValsRowCell5.Style.Add("text-align", "right");

                contractorsValsRowCell1.Text = "Text";
                contractorsValsRowCell2.Text = "Text";
                contractorsValsRowCell3.Text = "Text";
                contractorsValsRowCell4.Text = "Text";
                contractorsValsRowCell5.Text = "000";
                contractorsValsRowCell6.Text = "0000";

                contractorsValsRow.Cells.Add(contractorsValsRowCell1);
                contractorsValsRow.Cells.Add(contractorsValsRowCell2);
                contractorsValsRow.Cells.Add(contractorsValsRowCell3);
                contractorsValsRow.Cells.Add(contractorsValsRowCell4);
                contractorsValsRow.Cells.Add(contractorsValsRowCell5);
                contractorsValsRow.Cells.Add(contractorsValsRowCell6);

                CONOPSDevWSTable.Rows.Add(contractorsValsRow); //-----------------contractorsValsRow added to CONOPSDevWSTable

                TableCell contractorsBlankRowCell1 = new TableCell();
                TableCell contractorsBlankRowCell2 = new TableCell();

                TableCell contractorsBlankRowCell3 = new TableCell();
                TableCell contractorsBlankRowCell4 = new TableCell();

                //contractorsBlankRowCell3.Style.Add("background-color", "Cornsilk");
                //contractorsBlankRowCell4.Style.Add("background-color", "Cornsilk");


                contractorsBlankRowCell1.ColumnSpan = 5;

                Literal LiteralcontractorsBlankRow = new Literal();
                LiteralcontractorsBlankRow.Text = "&nbsp;";

                contractorsBlankRowCell1.Controls.Add(LiteralcontractorsBlankRow);

                contractorsBlankRow.Cells.Add(contractorsBlankRowCell1);
                contractorsBlankRow.Cells.Add(contractorsBlankRowCell2);

                CONOPSDevWSTable.Rows.Add(contractorsBlankRow); //-----------------contractorsBlankRow added to CONOPSDevWSTable

                TableCell additionalItemRowCell1 = new TableCell();
                TableCell additionalItemRowCell2 = new TableCell();

                TableCell additionalItemRowCell3 = new TableCell();
                TableCell additionalItemRowCell4 = new TableCell();

                additionalItemRowCell1.ColumnSpan = 5;
                additionalItemRowCell1.Style.Add("text-align", "right");

                Label LabeladditionalItemDesc1 = new Label();
                LabeladditionalItemDesc1.Text = "Additional line item (title and amount) ";

                Label LabeladditionalItemDesc2 = new Label();
                LabeladditionalItemDesc2.Text = "Text";
                LabeladditionalItemDesc2.Font.Italic = false;

                additionalItemRowCell1.Controls.Add(LabeladditionalItemDesc1);
                additionalItemRowCell1.Controls.Add(LabeladditionalItemDesc2);
                additionalItemRowCell2.Text = "0000";

                additionalItemRow.Cells.Add(additionalItemRowCell1);
                additionalItemRow.Cells.Add(additionalItemRowCell2);

                CONOPSDevWSTable.Rows.Add(additionalItemRow); //-----------------additionalItemRow added to CONOPSDevWSTable

                TableCell hoursRowCell1 = new TableCell();
                TableCell hoursRowCell2 = new TableCell();

                TableCell hoursRowCell3 = new TableCell();
                TableCell hoursRowCell4 = new TableCell();

                hoursRowCell1.ColumnSpan = 5;
                hoursRowCell1.Style.Add("text-align", "right");

                Label LabelhoursRow1 = new Label();
                LabelhoursRow1.Text = "Hours per year  ";

                Label LabelhoursRow2 = new Label();
                LabelhoursRow2.Text = "000";

                hoursRowCell1.Controls.Add(LabelhoursRow1);
                hoursRowCell1.Controls.Add(LabelhoursRow2);

                hoursRow.Cells.Add(hoursRowCell1);
                hoursRow.Cells.Add(hoursRowCell2);

                CONOPSDevWSTable.Rows.Add(hoursRow); //-----------------hoursRow added to CONOPSDevWSTable

                TableCell hoursBlankRowCell1 = new TableCell();
                TableCell hoursBlankRowCell2 = new TableCell();

                TableCell hoursBlankRowCell3 = new TableCell();
                TableCell hoursBlankRowCell4 = new TableCell();

                //hoursBlankRowCell3.Style.Add("background-color", "Cornsilk");
                //hoursBlankRowCell4.Style.Add("background-color", "Cornsilk");

                hoursBlankRowCell1.ColumnSpan = 5;

                Literal LiteralhoursBlankRow = new Literal();
                LiteralhoursBlankRow.Text = "&nbsp;";

                hoursBlankRowCell1.Controls.Add(LiteralhoursBlankRow);

                hoursBlankRow.Cells.Add(hoursBlankRowCell1);
                hoursBlankRow.Cells.Add(hoursBlankRowCell2);

                CONOPSDevWSTable.Rows.Add(hoursBlankRow); //-----------------hoursBlankRow added to CONOPSDevWSTable

                TableCell contractFeeRowCell1 = new TableCell();
                TableCell contractFeeRowCell2 = new TableCell();

                TableCell contractFeeRowCell3 = new TableCell();
                TableCell contractFeeRowCell4 = new TableCell();

                contractFeeRowCell1.ColumnSpan = 5;
                contractFeeRowCell1.Style.Add("text-align", "right");

                contractFeeRowCell1.Text = "Contract fee";
                contractFeeRowCell2.Text = "0000";

                contractFeeRow.Cells.Add(contractFeeRowCell1);
                contractFeeRow.Cells.Add(contractFeeRowCell2);

                CONOPSDevWSTable.Rows.Add(contractFeeRow); //-----------------contractFeeRow added to CONOPSDevWSTable

                TableCell contractorFYTotalRowCell1 = new TableCell();
                TableCell contractorFYTotalRowCell2 = new TableCell();

                TableCell contractorFYTotalRowCell3 = new TableCell();
                TableCell contractorFYTotalRowCell4 = new TableCell();

                contractorFYTotalRowCell1.ColumnSpan = 5;
                contractorFYTotalRowCell1.Style.Add("text-align", "right");

                Label LabelcontractorFYTotalVals1 = new Label();
                LabelcontractorFYTotalVals1.Text = "Total for FY ";

                Label LabelcontractorFYTotalVals2 = new Label();
                LabelcontractorFYTotalVals2.Text = "15";

                contractorFYTotalRowCell1.Controls.Add(LabelcontractorFYTotalVals1);
                contractorFYTotalRowCell1.Controls.Add(LabelcontractorFYTotalVals2);
                contractorFYTotalRowCell2.Text = "0000";

                contractorsFYTotalRow.Cells.Add(contractorFYTotalRowCell1);
                contractorsFYTotalRow.Cells.Add(contractorFYTotalRowCell2);

                CONOPSDevWSTable.Rows.Add(contractorsFYTotalRow); //-----------------contractorFYTotalRow added to CONOPSDevWSTable

                TableCell contractorsSubTotalRowCell1 = new TableCell();
                TableCell contractorsSubTotalRowCell2 = new TableCell();
                TableCell contractorsSubTotalRowCell3 = new TableCell();

                TableCell contractorsSubTotalRowCell4 = new TableCell();
                TableCell contractorsSubTotalRowCell5 = new TableCell();

                contractorsSubTotalRowCell1.ColumnSpan = 4;
                contractorsSubTotalRowCell1.Style.Add("background-color", "#bfbfbf");

                contractorsSubTotalRowCell2.Style.Add("text-align", "right");
                contractorsSubTotalRowCell2.Style.Add("font-weight", "bold");
                contractorsSubTotalRowCell2.Style.Add("background-color", "#d0ffbc");
                contractorsSubTotalRowCell2.Text = "Sub-Total:​";


                contractorsSubTotalRowCell3.Style.Add("text-align", "center");
                contractorsSubTotalRowCell3.Style.Add("background-color", "#d0ffbc");
                contractorsSubTotalRowCell3.Text = "0000";

                contractorsSubTotalRow.Cells.Add(contractorsSubTotalRowCell1);
                contractorsSubTotalRow.Cells.Add(contractorsSubTotalRowCell2);
                contractorsSubTotalRow.Cells.Add(contractorsSubTotalRowCell3);

                CONOPSDevWSTable.Rows.Add(contractorsSubTotalRow); //-----------------contractorsSubTotalRow added to CONOPSDevWSTable

                TableCell contractorsTotalRowCell1 = new TableCell();
                TableCell contractorsTotalRowCell2 = new TableCell();

                TableCell contractorsTotalRowCell3 = new TableCell();
                TableCell contractorsTotalRowCell4 = new TableCell();

                contractorsTotalRowCell1.ColumnSpan = 5;
                contractorsTotalRowCell1.Style.Add("text-align", "right");
                contractorsTotalRowCell1.Style.Add("font-weight", "bold");
                contractorsTotalRowCell1.Style.Add("background-color", "#d0ffbc");


                //------------------------------------Add Contract button --------
                AddContractBtn.Text = "Add Contract";
                AddContractBtn.Style.Add("float", "left");
                AddContractBtn.Style.Add("clear", "right");
                AddContractBtn.CssClass = "CONOPSApprovalAddContractButton";
                AddContractBtn.ToolTip = "Add Contract";
                AddContractBtn.UseSubmitBehavior = false;
                AddContractBtn.OnClientClick = "return false";
                contractorsTotalRowCell1.Controls.Add(AddContractBtn);

                Label LabelTotal = new Label();
                LabelTotal.Text = "Total:";
                contractorsTotalRowCell1.Controls.Add(LabelTotal);
                //-------------------------------------------------------------



                contractorsTotalRowCell2.Text = "0000";
                contractorsTotalRowCell2.Style.Add("background-color", "#d0ffbc");

                contractorsTotalRow.Cells.Add(contractorsTotalRowCell1);
                contractorsTotalRow.Cells.Add(contractorsTotalRowCell2);

                CONOPSDevWSTable.Rows.Add(contractorsTotalRow); //-----------------contractorsTotalRow added to CONOPSDevWSTable

                TableCell attachmentsRowCell = new TableCell();               

                TableCell attachmentsRowCell2 = new TableCell();
                TableCell attachmentsRowCell3 = new TableCell();

                

                //attachmentsRowCell2.Style.Add("background-color", "Cornsilk");
                //attachmentsRowCell3.Style.Add("background-color", "Cornsilk");


                attachmentsRowCell.ColumnSpan = 6;
                attachmentsRowCell.Style.Add("font-weight", "bold");
                attachmentsRowCell.Text = "Attachments";

                attachmentsRow.Cells.Add(attachmentsRowCell);

                CONOPSDevWSTable.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTable

                TableCell attachmentsValRowCell = new TableCell();

                TableCell attachmentsValRowCell2 = new TableCell();
                TableCell attachmentsValRowCell3 = new TableCell();

                attachmentsValRowCell2.CssClass = "CONOPSApprovalCell";
                attachmentsValRowCell3.CssClass = "CONOPSApprovalCell";

                //attachmentsValRowCell2.Style.Add("background-color", "Cornsilk");
                //attachmentsValRowCell3.Style.Add("background-color", "Cornsilk");

                attachmentsValRowCell.ColumnSpan = 6;
                attachmentsValRowCell.Text = "attachment1.text";
                attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

                attachmentsValRow.Cells.Add(attachmentsValRowCell);

                CONOPSDevWSTable.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTable

                TableCell attachDocRowCell = new TableCell();

                TableCell attachDocRowCell2 = new TableCell();
                TableCell attachDocRowCell3 = new TableCell();           

                attachDocRowCell.ColumnSpan = 6;
                attachDocRowCell.Controls.Add(LiteralAdddocument);
                attachDocRowCell.Controls.Add(LinkButtonAdddocument);
                attachDocRowCell.Style.Add("padding-left", "10px");


                attachDocRow.Cells.Add(attachDocRowCell);


                CONOPSDevWSTable.Rows.Add(attachDocRow); //-----------------attachDocRow added to CONOPSDevWSTable
                
              


                //================= END OF TABLE TEMPLATE ====================

            

                if (qs_tab == "OTASubmission")
                {


                    contractorsTotalRowCell1.Controls.Remove(AddContractBtn);
                    militarySubTotalRowCell1.Controls.Remove(AddMilGovBtn);



                    CONOPSDevWSTable.Controls.Remove(attachDocRow);

                    DCAPXSolution.CONOPSApproval.WS1makeViewOrFormForOTASubmission.makeViewOrFormForOTASubmission(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval);
                
                }
                if (qs_tab == "AOReview")
                {
                    headerTitleCell.ColumnSpan = 8;

                    wsColCell7.Text = "AO Approval​";
                    wsColCell8.Text = "AO Comments​";

                    headerRow.Cells.Add(wsColCell7);
                    headerRow.Cells.Add(wsColCell8);

                    headerDescRow.Cells.Add(headerDescRowCell7);
                    headerDescRow.Cells.Add(headerDescRowCell8);

                    militaryRow.Cells.Add(militaryRowCell2);
                    militaryRow.Cells.Add(militaryRowCell3);

                    militaryBlankRow.Cells.Add(militaryBlankRowCell3);
                    militaryBlankRow.Cells.Add(militaryBlankRowCell4);

                    militaryGovRow.Cells.Add(militaryGovRowCell3);
                    militaryGovRow.Cells.Add(militaryGovRowCell4);

                    militarySubTotalRow.Cells.Add(militarySubTotalRowCell4);
                    militarySubTotalRow.Cells.Add(militarySubTotalRowCell5);

                    contractorsRow.Cells.Add(contractorsRowCell2);
                    contractorsRow.Cells.Add(contractorsRowCell3);

                    contractorsTotalRow.Cells.Add(contractorsTotalRowCell3);
                    contractorsTotalRow.Cells.Add(contractorsTotalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);
                    //DCAPXSolution.CONOPSApproval.WS1makeViewOrFormForAOReview.makeViewOrFormForAOReview(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval, itemIDFirstHidden, itemIDLastHidden, CONOPSApprovalSaveButton, CONOPSApprovalSaveButton1, CheckBox1, CheckBox2, SaveDiv1, SaveDiv2, LiteralAdddocument, LinkButtonAdddocument, attachDocRow, contractorsTotalRowCell1, AddContractBtn, militarySubTotalRowCell1, AddMilGovBtn);

                    DCAPXSolution.CONOPSApproval.WS1makeFormForAOReview.makeFormAOReview(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval, itemIDFirstHidden, itemIDLastHidden, CONOPSApprovalSaveButton, CONOPSApprovalSaveButton1, CheckBox1, CheckBox2, SaveDiv1, SaveDiv2, LiteralAdddocument, LinkButtonAdddocument, attachDocRow, contractorsTotalRowCell1, militarySubTotalRowCell1, AddMilGovBtn, contractorsSubTotalRowCell1, AddContractBtn);

                }
                if (qs_tab == "PMReview")
                {
                    headerTitleCell.ColumnSpan = 8;

                    wsColCell7.Text = "PM Approval​";
                    wsColCell8.Text = "PM Comments​";

                    headerRow.Cells.Add(wsColCell7);
                    headerRow.Cells.Add(wsColCell8);

                    headerDescRow.Cells.Add(headerDescRowCell7);
                    headerDescRow.Cells.Add(headerDescRowCell8);

                    militaryRow.Cells.Add(militaryRowCell2);
                    militaryRow.Cells.Add(militaryRowCell3);

                    militaryBlankRow.Cells.Add(militaryBlankRowCell3);
                    militaryBlankRow.Cells.Add(militaryBlankRowCell4);

                    militaryGovRow.Cells.Add(militaryGovRowCell3);
                    militaryGovRow.Cells.Add(militaryGovRowCell4);

                    militarySubTotalRow.Cells.Add(militarySubTotalRowCell4);
                    militarySubTotalRow.Cells.Add(militarySubTotalRowCell5);

                    contractorsRow.Cells.Add(contractorsRowCell2);
                    contractorsRow.Cells.Add(contractorsRowCell3);

                    contractorsTotalRow.Cells.Add(contractorsTotalRowCell3);
                    contractorsTotalRow.Cells.Add(contractorsTotalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);

                    //DCAPXSolution.CONOPSApproval.WS1makeViewOrFormForPMReview.makeViewOrFormForPMReview(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval, itemIDFirstHidden, itemIDLastHidden, CONOPSApprovalSaveButton, CONOPSApprovalSaveButton1, CheckBox1, CheckBox2, SaveDiv1, SaveDiv2, LiteralAdddocument, LinkButtonAdddocument, attachDocRow, contractorsTotalRowCell1, AddContractBtn, militarySubTotalRowCell1, AddMilGovBtn);
                    DCAPXSolution.CONOPSApproval.WS1makeFormForPMReview.makeFormPMReview(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval, itemIDFirstHidden, itemIDLastHidden, CONOPSApprovalSaveButton, CONOPSApprovalSaveButton1, CheckBox1, CheckBox2, SaveDiv1, SaveDiv2, LiteralAdddocument, LinkButtonAdddocument, attachDocRow, contractorsTotalRowCell1, militarySubTotalRowCell1, AddMilGovBtn, contractorsSubTotalRowCell1, AddContractBtn);


                }
                if (qs_tab == "DeputyDirectorReviewandApproval")
                {
                    headerTitleCell.ColumnSpan = 8;

                    wsColCell7.Text = "DD Approval​";
                    wsColCell8.Text = "DD Comments​";

                    headerRow.Cells.Add(wsColCell7);
                    headerRow.Cells.Add(wsColCell8);

                    headerDescRow.Cells.Add(headerDescRowCell7);
                    headerDescRow.Cells.Add(headerDescRowCell8);

                    militaryRow.Cells.Add(militaryRowCell2);
                    militaryRow.Cells.Add(militaryRowCell3);

                    militaryBlankRow.Cells.Add(militaryBlankRowCell3);
                    militaryBlankRow.Cells.Add(militaryBlankRowCell4);

                    militaryGovRow.Cells.Add(militaryGovRowCell3);
                    militaryGovRow.Cells.Add(militaryGovRowCell4);

                    militarySubTotalRow.Cells.Add(militarySubTotalRowCell4);
                    militarySubTotalRow.Cells.Add(militarySubTotalRowCell5);

                    contractorsRow.Cells.Add(contractorsRowCell2);
                    contractorsRow.Cells.Add(contractorsRowCell3);

                    contractorsTotalRow.Cells.Add(contractorsTotalRowCell3);
                    contractorsTotalRow.Cells.Add(contractorsTotalRowCell4);

                    attachmentsRow.Cells.Add(attachmentsRowCell2);
                    attachmentsRow.Cells.Add(attachmentsRowCell3);

                    attachDocRow.Cells.Add(attachDocRowCell2);
                    attachDocRow.Cells.Add(attachDocRowCell3);

                    //DCAPXSolution.CONOPSApproval.WS1makeViewOrFormForDeputyDirectorReviewandApproval.makeViewOrFormForDeputyDirectorReviewandApproval(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval, itemIDFirstHidden, itemIDLastHidden, CONOPSApprovalSaveButton, CONOPSApprovalSaveButton1, CheckBox1, CheckBox2, SaveDiv1, SaveDiv2, LiteralAdddocument, LinkButtonAdddocument, attachDocRow, contractorsTotalRowCell1, AddContractBtn, militarySubTotalRowCell1, AddMilGovBtn, contractorsSubTotalRowCell1, AddContractorBtn, AddLineItemBtn);
                    //DCAPXSolution.CONOPSApproval.WS1makeViewOrFormForDeputyDirectorReviewandApproval.makeViewOrFormForDeputyDirectorReviewandApproval(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval, itemIDFirstHidden, itemIDLastHidden, CONOPSApprovalSaveButton, CONOPSApprovalSaveButton1, CheckBox1, CheckBox2, SaveDiv1, SaveDiv2, LiteralAdddocument, LinkButtonAdddocument, attachDocRow, contractorsTotalRowCell1, AddContractBtn, militarySubTotalRowCell1, AddMilGovBtn, contractorsSubTotalRowCell1, AddContractorBtn, AddContractorBtn_Click, AddLineItemBtn, ContractName);
                    DCAPXSolution.CONOPSApproval.WS1makeFormForDDReview.makeFormForDDReview(militaryGovRow, militarySubTotalRow, contractorsTotalRow, contractorsDescRow, contractorsValsRow, contractorsBlankRow, additionalItemRow, hoursRow, hoursBlankRow, contractFeeRow, contractorsFYTotalRow, contractorsSubTotalRow, attachmentsRow, attachmentsValRow, contractorsTotalRowCell2, militaryGovRowCell2, militarySubTotalRowCell3, militaryValsRow, militaryGovRowCell3, militaryGovRowCell4, militarySubTotalRowCell4, militarySubTotalRowCell5, contractorsTotalRowCell3, contractorsTotalRowCell4, CONOPSDevWSTable, qs_submitted, qs_ota, qs_otashort, qs_fy, qs_tab, qs_ws, DisablePMReview, DisableDeputyDirectorReviewandApproval, itemIDFirstHidden, itemIDLastHidden, CONOPSApprovalSaveButton, CONOPSApprovalSaveButton1, CheckBox1, CheckBox2, SaveDiv1, SaveDiv2, LiteralAdddocument, LinkButtonAdddocument, attachDocRow, contractorsTotalRowCell1, militarySubTotalRowCell1, AddMilGovBtn, contractorsSubTotalRowCell1, AddContractBtn);
                }
            }
            if (Page.IsPostBack)
            {

                string rawUrl = "1";
                if (Page.Request.RawUrl.ToString().Length > 0)
                {
                    rawUrl = Page.Request.RawUrl.ToString();
                }

                var traceInfo = "IsPostBack is true: " + Page.IsPostBack + " So closeDialog. url is: " + Page.Request.RawUrl.ToString();
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalPostback", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose('OK', '" + rawUrl + "');</script>");

               

            }

           
        }





        private void enableTabs()
        {
            var traceInfo = "enableTabs";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("enableTabs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_ws = Page.Request.QueryString["ws"];

            SPWeb oWeb = SPContext.Current.Web;

            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";
            SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            foreach (SPListItem oListItem in collListItemsCONOPSApprovalProgress)
            {
                string Yes = "Yes";
                string PMPreapproval = "PM Preapproval";
                string DeputyDirectorApproval = "Deputy Director Approval";

                try
                {
                    if (oListItem["CONOPSApproval"].ToString() == PMPreapproval)
                    {
                        DisablePMReview.Value = "No";
                    }
                    if (oListItem["CONOPSApproval"].ToString() == DeputyDirectorApproval)
                    {
                        DisablePMReview.Value = "No";
                        DisableDeputyDirectorReviewandApproval.Value = "No";
                    } 
                    if (oListItem["Submitted"].ToString() == Yes)
                    {
                        AllTabsChecked.Value = "Yes";

                    }
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("enableTabs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

               

            }
        }





        protected void CONOPSApprovalSaveButton_Click(object sender, EventArgs e)
        {
            var traceInfo = "CONOPSApprovalSaveButton_Click " + Page.Request.QueryString["otashort"];
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_ws = Page.Request.QueryString["ws"];
            string qs_tab = Page.Request.QueryString["tab"];


            if (Page.Request.QueryString["tab"] == "AOReview")
            {
                qs_tab = "AO Recommendation";
            }
            if (Page.Request.QueryString["tab"] == "PMReview")
            {
                qs_tab = "PM Preapproval";
            }
            if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
            {
                qs_tab = "Deputy Director Approval";
            }  
            
            SPWeb oWeb = SPContext.Current.Web;
            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);
            
            traceInfo = "oWeb: " + oWeb.Title + " oList: " + oList.Title;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


           

            if (HttpContext.Current != null)
            {
                if (Page.Response != null)
                {

                    var response = Page.Response;
                    var request = HttpContext.Current.Request;
                    NameValueCollection coll;
                    coll = request.Form;

                    traceInfo = "got coll.Count: " + coll.Count;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                    
                    string pattern = @"\D";
                    Regex rgx = new Regex(pattern);
                    string pattern2 = @"\d";
                    Regex rgx2 = new Regex(pattern2);

                    foreach (String s in coll.AllKeys)
                    {

                        traceInfo = "s: " + s + " coll[s] " + coll[s];
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if(s.Contains("rowId"))
                        {

                            string rowId = s.Substring(s.IndexOf("rowId") + 5);

                            string fieldName = rgx2.Replace(rowId, "");
                            
                            rowId = rgx.Replace(rowId, "");

                            string fieldValue = coll[s];

                            traceInfo = "rowId: " + rowId + " fieldName: " + fieldName  +" fieldValue: " + fieldValue;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSaveButton", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        }
                        //attachments must update oLib not oList
                        if (s.Contains("attId"))
                        {
                            string attId = s.Substring(s.IndexOf("attId") + 5);

                            string attfieldName = rgx2.Replace(attId, "");

                            attId = rgx.Replace(attId, "");

                            string attfieldValue = coll[s];

                            updateoLibItem(attId, attfieldName, attfieldValue);

                        }

                    }


                  


                    SPQuery oQuery2 = new SPQuery();
                    oQuery2.Query = "" +
                                "<OrderBy>" +
                                    "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                "</OrderBy>" +
                                "<Where>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"OTA\"/>" +
                                                    "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                "</Eq>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"FY\"/>" +
                                                    "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                "<Value Type=\"Text\">" + qs_tab + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Neq>" +
                                            "<FieldRef Name=\"Submitted\"/>" +
                                            "<Value Type=\"Text\">Yes</Value>" +
                                        "</Neq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ContentType\"/>" +
                                        "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                    "</Eq>" +
                                "</And>" +
                            "</Where>";

                    SPListItemCollection collListItems2 = oList.GetItems(oQuery2);

                    foreach (SPListItem oListItem in collListItems2)
                    {

                        string id = oListItem.ID.ToString();
                        string rrowId = "rowId" + id;

                        Dictionary<string, string> worksheetFieldsDictionary = new Dictionary<string, string>();

                        foreach (String s in coll.AllKeys)
                        {

                            if (s.Contains(rrowId))
                            {

                                string fieldNameValue = s.Substring(s.IndexOf("rowId") + 5);

                                string fieldName = rgx2.Replace(fieldNameValue, "");
                                string fieldValue = coll[s];

                                worksheetFieldsDictionary.Add(fieldName, fieldValue);
                               

                            }

                        }

                        updateoListItem(id, worksheetFieldsDictionary);

                    }
         
                }
            }


            
        }

        private void updateoLibItem(string attId, string attfieldName, string attfieldValue)
        {
            try
            {
                int iid = Int32.Parse(attId);

                SPWeb oWeb = SPContext.Current.Web;
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + Page.Request.QueryString["otashort"]);

                SPListItem oLibItem = oLib.GetItemById(iid);

                oLibItem[attfieldName] = attfieldValue;
                oWeb.AllowUnsafeUpdates = true;
                oLibItem.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoLibItem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

        private void updateoListItem(string id, Dictionary<string, string> worksheetFieldsDictionary)
        {
            var traceInfo = "updateoListItem";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoListItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            try
            {
                int iid = Int32.Parse(id);

                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + Page.Request.QueryString["otashort"]);

                SPListItem oListItem = oList.GetItemById(iid);

                foreach (KeyValuePair<string, string> kvp in worksheetFieldsDictionary)
                {
                    traceInfo = "kvp.Key: " + kvp.Key + " kvp.Value: " + kvp.Value;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoListItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    oListItem[kvp.Key] = kvp.Value;
                }
                oWeb.AllowUnsafeUpdates = true;
                oListItem.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateoListItem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            CheckBox submitCheckBox = sender as CheckBox;
            var traceInfo = "submitCheckBox.Checked: " + submitCheckBox.Checked;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string qs_otashort = Page.Request.QueryString["otashort"];
            string qs_fy = Page.Request.QueryString["fy"];
            string qs_ws = Page.Request.QueryString["ws"];

            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16

            SPUser user;

            DateTime DateDraftSaved = DateTime.Now;

         

            if(submitCheckBox.Checked)
            {
                
                SPWeb oWeb = SPContext.Current.Web;
                SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);

                traceInfo = "oWeb: " + oWeb.Title + " oList: " + oList.Title;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                HasNoPendingItems.Value = "true";


                if (HttpContext.Current != null)
                {
                    if (Page.Response != null)
                    {

                        var response = Page.Response;
                        var request = HttpContext.Current.Request;
                        NameValueCollection coll;
                        coll = request.Form;

                        traceInfo = "got coll.Count: " + coll.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string pattern = @"\D";
                        Regex rgx = new Regex(pattern);
                        string pattern2 = @"\d";
                        Regex rgx2 = new Regex(pattern2);

                        foreach (String s in coll.AllKeys)
                        {

                            traceInfo = "s: " + s + " coll[s] " + coll[s];
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            if (coll[s] == "Pending")
                            {
                                traceInfo = "s: " + s + " coll[s] " + coll[s];
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                HasNoPendingItems.Value = "false";

                              
                            }

                          

                        }


                    }

                    if (HasNoPendingItems.Value == "true")
                    {
                        //do ops

                        user = oWeb.CurrentUser;

                        string tab = "";
                        string nexttab = "";
                        string AORecommendation = "AO Recommendation";
                        string PMPreapproval = "PM Preapproval";
                        string DRApproval = "Deputy Director Approval";

                        if (Page.Request.QueryString["tab"] == "AOReview")
                        {
                            tab = AORecommendation; nexttab = PMPreapproval;
                        }
                        if (Page.Request.QueryString["tab"] == "PMReview")
                        {
                            tab = PMPreapproval; nexttab = DRApproval;
                        }
                        if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
                        {
                            tab = DRApproval;
                        }




                        try
                        {

                            //------------- lib -----------------
                            //return the docs, not the versions, in this case
                            SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);

                            SPQuery oLibQuery = new SPQuery();

                            oLibQuery.Query = "" +
                                 "<OrderBy>" +
                                     "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                 "</OrderBy>" +
                                 "<Where>" +

                                 "<And><And>" +
                                         "<Eq>" +
                                             "<FieldRef Name=\"FY\"/>" +
                                             "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                         "</Eq>" +
                                          "<Eq>" +
                                             "<FieldRef Name=\"WS\"/>" +
                                             "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                                         "</Eq>" +
                                     "</And>" +
                                       "<Neq>" +
                                             "<FieldRef Name=\"Submitted\"/>" +
                                             "<Value Type=\"Text\">Yes</Value>" +
                                         "</Neq>" +
                                     "</And>" +
                                 "</Where>";

                            SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                            List<string> itemsForSecondPass = new List<string>();

                            foreach (SPListItem oListItem in collLibItems)
                            {
                                itemsForSecondPass.Add(oListItem.ID.ToString());

                                oListItem["Submitted"] = "Yes";
                                oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                string SubmittedBy = user.ID + ";#" + user.LoginName;
                                oListItem["SubmittedBy"] = SubmittedBy;
                                oListItem["SubmittedOn"] = DateDraftSaved;
                                oListItem["CONOPSApproval"] = tab;

                                oWeb.AllowUnsafeUpdates = true;

                                oListItem.Update();
                            }
                            //=====UPDATE METADATA AGAIN ====
                            if (Page.Request.QueryString["tab"] != "DeputyDirectorReviewandApproval") //DeputyDirectorReviewandApproval
                            {
                                foreach (string itemForSecondPass in itemsForSecondPass)
                                {
                                    SPListItem oitemForSecondPass = oLib.GetItemById(Int32.Parse(itemForSecondPass));

                                    oitemForSecondPass["Submitted"] = "";
                                    oitemForSecondPass["SubmittedFY"] = "";
                                    oitemForSecondPass["SubmittedBy"] = "";
                                    oitemForSecondPass["SubmittedOn"] = "";
                                    oitemForSecondPass["CONOPSApproval"] = nexttab;

                                    oWeb.AllowUnsafeUpdates = true;

                                    oitemForSecondPass.Update();
                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("submitAttachments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }












                        //List
                        SPQuery oQuery = new SPQuery();
                        oQuery.Query = "" +
                                    "<OrderBy>" +
                                        "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                    "</OrderBy>" +
                                    "<Where>" +
                                    "<And>" +
                                        "<And>" +
                                            "<And>" +
                                                "<And>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"OTA\"/>" +
                                                        "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                    "</Eq>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"FY\"/>" +
                                                        "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                    "</Eq>" +
                                                "</And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                    "<Value Type=\"Text\">" + tab + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                            "<Neq>" +
                                                "<FieldRef Name=\"Submitted\"/>" +
                                                "<Value Type=\"Text\">Yes</Value>" +
                                            "</Neq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"ContentType\"/>" +
                                            "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                "</Where>";

                        SPListItemCollection collListItems = oList.GetItems(oQuery);

                        foreach (SPListItem oListItem in collListItems)
                        {
                           
                            try
                            {
                                traceInfo = "Item ID being marked Submitted is Yes: " + oListItem.ID;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                              

                                oListItem["Submitted"] = "Yes";
                                oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                string SubmittedBy = user.ID + ";#" + user.LoginName;
                                oListItem["SubmittedBy"] = SubmittedBy;
                                oListItem["SubmittedOn"] = DateDraftSaved;

                                ////--If item is added during CONOPS Approval--
                                //if (Page.Request.QueryString["tab"] == "AOReview")
                                //{
                                //    if (oListItem["OTASubmissionID"] == null && oListItem["AOReviewID"] == null)
                                //    {
                                //        oListItem["AOReviewID"] = oListItem.ID.ToString();
                                //    }
                                //}
                                //if (Page.Request.QueryString["tab"] == "PMReview")
                                //{
                                //    if (oListItem["OTASubmissionID"] == null && oListItem["AOReviewID"] == null && oListItem["PMReviewID"] == null)
                                //    {
                                //        oListItem["PMReviewID"] = oListItem.ID.ToString();
                                //    }
                                //}
                                ////--end--
                                


                                oWeb.AllowUnsafeUpdates = true;

                                oListItem.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                        if (Page.Request.QueryString["tab"] != "DeputyDirectorReviewandApproval") //DeputyDirectorReviewandApproval
                        {

                            traceInfo = "CONOPSDevDuplicate";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            try
                            {



                                //SPQuery oQuery2 = new SPQuery();

                                //oQuery2.Query = "" +
                                //            "<OrderBy>" +
                                //                "<FieldRef Name=\"ID\" Ascending=\"TRUE\"/>" +
                                //            "</OrderBy>" +
                                //            "<Where>" +
                                //                "<And>" +
                                //                    "<Geq>" +
                                //                        "<FieldRef Name=\"ID\"/>" +
                                //                        "<Value Type=\"Integer\">" + firstIDToDuplicate + "</Value>" +
                                //                    "</Geq>" +
                                //                     "<Leq>" +
                                //                        "<FieldRef Name=\"ID\"/>" +
                                //                        "<Value Type=\"Integer\">" + lastIDToDuplicate + "</Value>" +
                                //                    "</Leq>" +
                                //                "</And>" +
                                //            "</Where>";

                                //SPListItemCollection collListItems2 = oList.GetItems(oQuery2);

                                SPQuery oQuery2 = new SPQuery();
                                oQuery2.Query = "" +
                                            "<OrderBy>" +
                                                "<FieldRef Name=\"ID\" Ascending=\"TRUE\"/>" +
                                            "</OrderBy>" +
                                            "<Where>" +
                                            "<And>" +
                                                "<And>" +
                                                    "<And>" +
                                                        "<And>" +
                                                            "<Eq>" +
                                                                "<FieldRef Name=\"OTA\"/>" +
                                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                                            "</Eq>" +
                                                            "<Eq>" +
                                                                "<FieldRef Name=\"FY\"/>" +
                                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                                            "</Eq>" +
                                                        "</And>" +
                                                        "<Eq>" +
                                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                                            "<Value Type=\"Text\">" + tab + "</Value>" +
                                                        "</Eq>" +
                                                    "</And>" +
                                                    "<Eq>" +
                                                        "<FieldRef Name=\"Submitted\"/>" +
                                                        "<Value Type=\"Text\">Yes</Value>" +
                                                    "</Eq>" +
                                                "</And>" +
                                                "<Eq>" +
                                                    "<FieldRef Name=\"ContentType\"/>" +
                                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                                "</Eq>" +
                                            "</And>" +
                                        "</Where>";
                                
                                SPListItemCollection collListItems2 = oList.GetItems(oQuery2);
                                
                                foreach (SPListItem oListItem in collListItems2)
                                {

                                    SPListItem newListItem = oList.Items.Add();
                                    newListItem["ContentTypeId"] = oListItem.ContentTypeId;
                                    newListItem["Title"] = oListItem["Title"].ToString();
                                    newListItem["CONOPSApproval"] = nexttab;


                                    if (oListItem["DutyTitlePosition"] != null) { newListItem["DutyTitlePosition"] = oListItem["DutyTitlePosition"].ToString(); }
                                    if (oListItem["Status"] != null) { newListItem["Status"] = oListItem["Status"].ToString(); }
                                    if (oListItem["Remarks"] != null) { newListItem["Remarks"] = oListItem["Remarks"].ToString(); }
                                    if (oListItem["ContractorRate"] != null) { newListItem["ContractorRate"] = oListItem["ContractorRate"].ToString(); }
                                    if (oListItem["GSLevel"] != null) { newListItem["GSLevel"] = oListItem["GSLevel"].ToString(); }
                                    if (oListItem["Funding"] != null) { newListItem["Funding"] = oListItem["Funding"].ToString(); }
                                    if (oListItem["GovLaborMonth"] != null) { newListItem["GovLaborMonth"] = oListItem["GovLaborMonth"].ToString(); }
                                    if (oListItem["Employer"] != null) { newListItem["Employer"] = oListItem["Employer"].ToString(); }
                                    if (oListItem["Contract"] != null) { newListItem["Contract"] = oListItem["Contract"].ToString(); }
                                    if (oListItem["ContractFee"] != null) { newListItem["ContractFee"] = oListItem["ContractFee"].ToString(); }
                                    if (oListItem["ContractTotal"] != null) { newListItem["ContractTotal"] = oListItem["ContractTotal"].ToString(); }
                                    if (oListItem["AdditionalLineItem"] != null) { newListItem["AdditionalLineItem"] = oListItem["AdditionalLineItem"].ToString(); }
                                    if (oListItem["MilitarySubTotal"] != null) { newListItem["MilitarySubTotal"] = oListItem["MilitarySubTotal"].ToString(); }
                                    if (oListItem["Total"] != null) { newListItem["Total"] = oListItem["Total"].ToString(); }
                                    if (oListItem["ContractsSubTotal"] != null) { newListItem["ContractsSubTotal"] = oListItem["ContractsSubTotal"].ToString(); }
                                    if (oListItem["HoursPerYear"] != null) { newListItem["HoursPerYear"] = oListItem["HoursPerYear"].ToString(); }
                                    if (oListItem["OTA"] != null) { newListItem["OTA"] = oListItem["OTA"].ToString(); }
                                    if (oListItem["FY"] != null) { newListItem["FY"] = oListItem["FY"].ToString(); }

                                    if (oListItem["DateDraftSaved"] != null) { newListItem["DateDraftSaved"] = oListItem["DateDraftSaved"]; }
                                    if (oListItem["TimeDraftSaved"] != null) { newListItem["TimeDraftSaved"] = oListItem["TimeDraftSaved"]; }
                                    if (oListItem["DraftSavedBy"] != null) { newListItem["DraftSavedBy"] = oListItem["DraftSavedBy"]; }



                                    if (oListItem["OTASubmissionID"] != null) { newListItem["OTASubmissionID"] = oListItem["OTASubmissionID"].ToString(); }
                                    if (oListItem["AOReviewID"] != null) { newListItem["AOReviewID"] = oListItem["AOReviewID"].ToString(); }
                                    if (oListItem["PMReviewID"] != null) { newListItem["PMReviewID"] = oListItem["PMReviewID"].ToString(); }


                                    ////Set Approvals to selected value
                                    //if (Page.Request.QueryString["tab"] == "AOReview")
                                    //{
                                    //    newListItem["AOReviewID"] = oListItem.ID.ToString();
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalPMReview"] = oListItem["CONOPSApprovalAOReview"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AOReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalPMComments"] = oListItem["CONOPSApprovalAOComments"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AOReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //}
                                    //if (Page.Request.QueryString["tab"] == "PMReview")
                                    //{
                                    //    newListItem["PMReviewID"] = oListItem.ID.ToString();
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalDRReview"] = oListItem["CONOPSApprovalPMReview"].ToString();

                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("PMReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //    try
                                    //    {
                                    //        newListItem["CONOPSApprovalDRComments"] = oListItem["CONOPSApprovalPMComments"].ToString();
                                    //    }
                                    //    catch (Exception ex)
                                    //    {
                                    //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("PMReviewSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    //    }
                                    //}

                                    traceInfo = "CONOPSDevDuplicating Now";
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    oWeb.AllowUnsafeUpdates = true;

                                    newListItem.Update();

                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //----- CONOPSAPPROVALPROGRESS update -----

                            SPList CONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];

                            traceInfo = "got CONOPSApprovalProgress: " + CONOPSApprovalProgress.Title;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
                                oQueryCONOPSApprovalProgress.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

                                foreach (SPListItem oListItem in collListItemsCONOPSApprovalProgress)
                                {
                                    oListItem["CONOPSApproval"] = nexttab;

                                    traceInfo = "Update CONOPSApprovalProgress list for OTA: " + qs_otashort + " and WS: " + oListItem.Title;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    oWeb.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                        }
                        else //tab is DeputyDirectorReviewandApproval
                        {
                            //update CONOPSApprovalProgress to show submitted

                            SPList oListCONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];
                            try
                            {
                                SPQuery oQueryCONOPSApprovalProgressGeneral = new SPQuery();
                                oQueryCONOPSApprovalProgressGeneral.Query = "<Where><And><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + qs_otashort + "</Value></Eq><Eq><FieldRef Name='Title'/><Value Type='Text'>WS" + qs_ws + "</Value></Eq></And></Where>";

                                SPListItemCollection collItemsSubmittedGeneral = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgressGeneral);

                                foreach (SPListItem oListItem in collItemsSubmittedGeneral)
                                {


                                    traceInfo = "Update to Submitted CONOPSApprovalProgress list for OTA: " + qs_otashort + " and WS: " + oListItem.Title;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oWeb.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalSubmitDDtab", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }




                    }

                }








            
            }
        }

        protected void AddMilGovBtn_Click(object sender, EventArgs e)
        {

            //Button AddMilGovBtnButton = (Button)sender;

            //try
            //{
            //    if (AddMilGovBtnButton.Attributes["alt"].ToString() == "disabled")
            //    {
            //        Page.ClientScript.RegisterStartupScript(typeof(Page), "disabledmssg", "<script type=\"text/javascript\">alert('Please save your recent changes first.'); return false;</script>");
            //    }

            //}
            //catch (Exception ex)
            //{
            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddMilGovBtnClickDisabled", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            //}

            try
            {
               

                var traceInfo = "otashort: " + Page.Request.QueryString["otashort"] + " fy: " + Page.Request.QueryString["fy"] + " tab: " + Page.Request.QueryString["tab"];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddMilGovBtnClick", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                string tab = "";
                if (Page.Request.QueryString["tab"] == "AOReview")
                {
                    tab = "AO Recommendation";
                }
                if (Page.Request.QueryString["tab"] == "PMReview")
                {
                    tab = "PM Preapproval";
                }
                if (Page.Request.QueryString["tab"] == "DeputyDirectorReviewandApproval")
                {
                    tab = "Deputy Director Approval";
                }

                DateTime DateDraftSaved = DateTime.Now;

                DateTime twentyFifteen = new DateTime(2015, 1, 1);
                long elapsedTicks = DateDraftSaved.Ticks - twentyFifteen.Ticks;

                // get snapshot of time                           
                var DateDraftSavedSnapShot = DateDraftSaved;
                var TimeDraftSavedSnapShot = elapsedTicks;

                SPWeb oWeb = SPContext.Current.Web;

                SPFieldUserValue currentUser = new SPFieldUserValue(oWeb, oWeb.CurrentUser.ID, oWeb.CurrentUser.Name);

                SPList oList = oWeb.Lists["CONOPSDevWS" + Page.Request.QueryString["otashort"]];
                SPListItem oListItem = oList.AddItem();

                oListItem["Title"] = "Enter Name";
                oListItem["Funding"] = "0";
                oListItem["GSLevel"] = "0";
                oListItem["Remarks"] = "None";
                oListItem["Status"] = "None"; 
                oListItem["DutyTitlePosition"] = "None";
                oListItem["Employer"] = "MilitaryOrGovernmentCivilian";
                oListItem["OTA"] = Page.Request.QueryString["otashort"];
                oListItem["FY"] = Page.Request.QueryString["fy"];
                oListItem["CONOPSApproval"] = tab;
                oListItem["ContentTypeId"] = "0x0100E0E45C6EA5EF4D07B7760A569CBEEAAA";
                oListItem["DateDraftSaved"] = DateDraftSavedSnapShot;
                oListItem["TimeDraftSaved"] = TimeDraftSavedSnapShot;
                oListItem["DraftSavedBy"] = currentUser;

                oWeb.AllowUnsafeUpdates = true;
                oListItem.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddMilGovBtnClick", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
        }

    }
}
