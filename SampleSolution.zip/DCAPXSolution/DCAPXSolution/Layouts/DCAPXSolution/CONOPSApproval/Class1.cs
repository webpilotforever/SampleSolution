﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    class Class1
     {//from conoopsdev
function updateTotals(){
	// set totals in worksheet
	if(worksheetPageName.indexOf("WS1")>-1){
		// ws1 top
		var MilitarySubTotal = 0;
		$("input#Funding").each(function(i){
			
			var fundingVal = $(this).val();
	    	if(fundingVal.indexOf("$")>-1){
	    		fundingVal = fundingVal.substr(fundingVal.indexOf("$")+1); 
	    		$(this).val(fundingVal);
	    	}
	    	if($.isNumeric(fundingVal)){
	    	    //var nn = Math.round(fundingVal);
	    	    var nn = fundingVal;
	    		$(this).val(nn);
				if($(this).closest('tr').index() < $("input#MilitarySubTotal").closest('tr').index()){
					MilitarySubTotal +=  parseInt($(this).val());
				
				}    	
	    	}
		});
		
		var GovLaborMonthRound = Math.round(MilitarySubTotal/12);
		$("input#GovLaborMonth").val(GovLaborMonthRound ); 
		$("input#MilitarySubTotal").val(MilitarySubTotal);
		// ws1 contractors
		
		var ContractsSubTotal = 0;
		
		var contractSliceStart;
		var contractSliceEnd;
		var contractSliced; 
		
		$("tr.WSGroupStartRow").each(function(i){
			contractSliceStart = $(this).index();
			contractSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
			contractSliced = $(this).parent().children().slice(contractSliceStart, contractSliceEnd);
			var ContractTotal = 0;
			contractSliced.find("input#Funding").each(function(){
				if($.isNumeric($(this).val())){
					ContractTotal += parseInt($(this).val());
				}	
			}); 
			
			contractSliced.find("input#AdditionalLineItem").each(function(){
				if($.isNumeric($(this).val())){
					ContractTotal += parseInt($(this).val());
				}				
			}); 			
			 
					 
			if($.isNumeric(contractSliced.find("input#ContractFee").val())){
				ContractTotal += parseInt(contractSliced.find("#ContractFee").val());
			}
			
			contractSliced.find("input#ContractTotal").val(ContractTotal);
			ContractsSubTotal += ContractTotal;
			contractSliced.find("input#ContractsSubTotal").val(ContractsSubTotal);
		});
		$("input#Total").val(MilitarySubTotal + ContractsSubTotal);
		
	}
	if(worksheetPageName.indexOf("WS2")>-1){
		
		var venueSliceStart;
		var venueSliceEnd;
		var venueSliced; 
		
		var Total = 0;
		
		$("tr.WSGroupStartRow").each(function(i){
			var VenueSubTotal = 0;
			venueSliceStart = $(this).index();
			venueSliceEnd = $("tr.WSGroupEndRow").eq(i).next().index();
			venueSliced = $(this).parent().children().slice(venueSliceStart, venueSliceEnd);
			
			venueSliced.find("input#Funding").each(function(){
				
				var venueVal = $(this).val();
		    	if(venueVal.indexOf("$")>-1){
		    		venueVal = venueVal.substr(venueVal.indexOf("$")+1); 
		    		$(this).val(venueVal);
		    	}
		    	if($.isNumeric(venueVal)){
		    	    //var nn = Math.round(venueVal);
		    	    var nn = venueVal;
		    		$(this).val(nn);
		    		VenueSubTotal += parseInt($(this).val());					
				}	
				
			});
						
			venueSliced.find("input#VenueSubTotal").val(VenueSubTotal.toFixed(2));
			
			Total += VenueSubTotal;
			
		});
		$("input#Total").val(Total.toFixed(2));

	}
	if(worksheetPageName.indexOf("WS3")>-1 || worksheetPageName.indexOf("WS4")>-1){
		var Total = 0;
		$("input#Funding").each(function(){
			if($.isNumeric($(this).val())){
				Total += parseInt($(this).val());
			}	
		});
		$("input#Total").val(Total);
	}
	

}


            }
}
