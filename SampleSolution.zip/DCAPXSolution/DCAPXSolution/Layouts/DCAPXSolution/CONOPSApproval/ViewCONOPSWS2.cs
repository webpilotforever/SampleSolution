﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Specialized;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Web;
using System.Text.RegularExpressions;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    class ViewCONOPSWS2
    {

        internal static void viewCONOPSforWS2(Table CONOPSDevWSTableWS2, HtmlGenericControl headerTitleCellDivWS2, string qs_otashort, string qs_ota, string qs_fy, HiddenField itemIDFirstHidden, HiddenField itemIDLastHidden)
        {
            var traceInfo = "ViewCONOPSWS2";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            bool wsIsSubmitted = false;
            //Query CONOPSApprovalProgress
            //Query if submitted, then build table else update lable

            SPList oListCONOPSApprovalProgress = SPContext.Current.Web.Lists["CONOPSApprovalProgress"];
            SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
            oQueryCONOPSApprovalProgress.Query = "<Where>" +
                "<And><And>" +
                    "<Eq>" +
                        "<FieldRef Name='OperationalTestAgency'/>" +
                            "<Value Type='Choice'>" + qs_otashort + "</Value>" +
                     "</Eq>" +
                     "<Eq>" +
                        "<FieldRef Name='Submitted'/>" +
                            "<Value Type='Text'>Yes</Value>" +
                        "</Eq>" +
                "</And>" +
                 "<Eq>" +
                        "<FieldRef Name='Title'/>" +
                            "<Value Type='Text'>WS2</Value>" +
                        "</Eq>" +
                "</And>" +
            "</Where>";

            SPListItemCollection collItemsSubmitted = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

            if (collItemsSubmitted.Count > 0)
            {

                wsIsSubmitted = true;
            }


            if (wsIsSubmitted)
            {
                int venueSubTotalRowIndex = 5;
                int attachmentIndex = 7;
                Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");
                SPWeb oWeb = SPContext.Current.Web;
                //SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);
                SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);
                SPQuery oLibQuery = new SPQuery();
                TableRowCollection rows = CONOPSDevWSTableWS2.Rows;

                //Table rows-----------------------------------------------------------------------------------

                TableRow headerTitleRow = new TableRow();
                TableRow headerRow = new TableRow();
                TableRow headerDescRow = new TableRow();
                TableRow venueRow = new TableRow();
                TableRow venueSubTotalRow = new TableRow();
                TableRow totalRow = new TableRow();
                TableRow attachmentsRow = new TableRow();
                TableRow attachmentsValRow = new TableRow();

                headerTitleRow.Style.Add("text-align", "center");
                headerRow.CssClass = "CONOPSDevWSColHeaders";
                headerDescRow.CssClass = "CONOPSDevWSColHeaderDesc";
                headerDescRow.Style.Add("text-align", "center");
                headerDescRow.ID = "headerDescRow";
                venueRow.Style.Add("text-align", "center");
                venueRow.CssClass = "WSGroupStartRow";
                venueSubTotalRow.Style.Add("text-align", "center");
                totalRow.Style.Add("text-align", "center");
                totalRow.ToolTip = "Total";
                totalRow.ID = "totalRow";
                attachmentsRow.Style.Add("text-align", "center");
                attachmentsValRow.Style.Add("text-align", "center");
                attachmentsValRow.ID = "attachmentsValRow";

                //Table cells------------------------------------------------------------------------------------------

                TableCell headerTitleCell = new TableCell();
                headerTitleCell.ColumnSpan = 8;

                headerTitleCell.Controls.Add(headerTitleCellDivWS2);

                headerTitleRow.Cells.Add(headerTitleCell);

                CONOPSDevWSTableWS2.Rows.Add(headerTitleRow); //-----------------headerTitleRow added to CONOPSDevWSTableWS2

                TableCell wsColCell1 = new TableCell();
                TableCell wsColCell2 = new TableCell();
                TableCell wsColCell3 = new TableCell();
                TableCell wsColCell4 = new TableCell();
                TableCell wsColCell5 = new TableCell();
                TableCell wsColCell6 = new TableCell();
                TableCell wsColCell7 = new TableCell();
                TableCell wsColCell8 = new TableCell();



                wsColCell1.CssClass = "CONOPSDevWSColCell";
                wsColCell2.CssClass = "CONOPSDevWSColCell";
                wsColCell3.CssClass = "CONOPSDevWSColCell";
                wsColCell4.CssClass = "CONOPSDevWSColCell";
                wsColCell5.CssClass = "CONOPSDevWSColCell";
                wsColCell6.CssClass = "CONOPSDevWSColCell";
                wsColCell7.CssClass = "CONOPSDevWSColCell";
                wsColCell8.CssClass = "CONOPSDevWSColCell";

                wsColCell1.Style.Add("width", "200px");
                wsColCell2.Style.Add("width", "155px");
                wsColCell3.Style.Add("width", "155px");
                wsColCell4.Style.Add("width", "155px");
                wsColCell5.Style.Add("width", "155px");
                wsColCell6.Style.Add("width", "155px");
                wsColCell7.Style.Add("width", "155px");
                wsColCell8.Style.Add("width", "155px");

                wsColCell1.Style.Add("font-weight", "bold");
                wsColCell2.Style.Add("font-weight", "bold");
                wsColCell3.Style.Add("font-weight", "bold");
                wsColCell4.Style.Add("font-weight", "bold");
                wsColCell5.Style.Add("font-weight", "bold");
                wsColCell6.Style.Add("font-weight", "bold");
                wsColCell7.Style.Add("font-weight", "bold");
                wsColCell8.Style.Add("font-weight", "bold");

                wsColCell1.Text = "Venue​";
                wsColCell2.Text = "Activity/Event​​";
                wsColCell3.Text = "Dates​";
                wsColCell4.Text = "People​";
                wsColCell5.Text = "Location";
                wsColCell6.Text = "Estimated Travel Costs";
                wsColCell7.Text = "Estimated Labor Overtime Costs";
                wsColCell8.Text = "Funding​";

                headerRow.Cells.Add(wsColCell1);
                headerRow.Cells.Add(wsColCell2);
                headerRow.Cells.Add(wsColCell3);
                headerRow.Cells.Add(wsColCell4);
                headerRow.Cells.Add(wsColCell5);
                headerRow.Cells.Add(wsColCell6);
                headerRow.Cells.Add(wsColCell7);
                headerRow.Cells.Add(wsColCell8);

                CONOPSDevWSTableWS2.Rows.Add(headerRow); //-----------------headerRow added to CONOPSDevWSTableWS2

                TableCell headerDescRowCell1 = new TableCell();
                TableCell headerDescRowCell2 = new TableCell();
                TableCell headerDescRowCell3 = new TableCell();
                TableCell headerDescRowCell4 = new TableCell();
                TableCell headerDescRowCell5 = new TableCell();
                TableCell headerDescRowCell6 = new TableCell();
                TableCell headerDescRowCell7 = new TableCell();
                TableCell headerDescRowCell8 = new TableCell();

                //TableCell headerDescRowCell9 = new TableCell();
                //TableCell headerDescRowCell10 = new TableCell();

                headerDescRowCell1.Style.Add("font-style", "italic");
                headerDescRowCell2.Style.Add("font-style", "italic");
                headerDescRowCell3.Style.Add("font-style", "italic");
                headerDescRowCell4.Style.Add("font-style", "italic");
                headerDescRowCell5.Style.Add("font-style", "italic");
                headerDescRowCell6.Style.Add("font-style", "italic");
                headerDescRowCell7.Style.Add("font-style", "italic");
                headerDescRowCell8.Style.Add("font-style", "italic");

                //headerDescRowCell9.Style.Add("font-style", "italic");
                //headerDescRowCell10.Style.Add("font-style", "italic");

                headerDescRowCell1.Text = "List the proposed assessment value​";
                headerDescRowCell2.Text = "List every activity/event associated with the proposed assessment​";
                headerDescRowCell3.Text = "List the dates for each activity/event​";
                headerDescRowCell4.Text = "List the number of people attending each activity/event​";
                headerDescRowCell5.Text = "Identify the location for each activity/event (List location by military base, not by the city)";
                headerDescRowCell6.Text = "Estimated travel cost for each activity/event​";
                headerDescRowCell7.Text = "Estimated labor overtime cost for each activity/event";
                headerDescRowCell8.Text = "Total proposed funding level for each activity/event";

                //headerDescRowCell9.Text = "Reviewer approval";
                //headerDescRowCell10.Text = "Reviewer comments";

                headerDescRow.Cells.Add(headerDescRowCell1);
                headerDescRow.Cells.Add(headerDescRowCell2);
                headerDescRow.Cells.Add(headerDescRowCell3);
                headerDescRow.Cells.Add(headerDescRowCell4);
                headerDescRow.Cells.Add(headerDescRowCell5);
                headerDescRow.Cells.Add(headerDescRowCell6);
                headerDescRow.Cells.Add(headerDescRowCell7);
                headerDescRow.Cells.Add(headerDescRowCell8);

                CONOPSDevWSTableWS2.Rows.Add(headerDescRow); //-----------------headerDescRow added to CONOPSDevWSTableWS2

                TableCell venueValCell1 = new TableCell();
                TableCell venueValCell2 = new TableCell();
                TableCell venueValCell3 = new TableCell();
                TableCell venueValCell4 = new TableCell();
                TableCell venueValCell5 = new TableCell();
                TableCell venueValCell6 = new TableCell();
                TableCell venueValCell7 = new TableCell();
                TableCell venueValCell8 = new TableCell();

                //TableCell venueValCell9 = new TableCell();
                //TableCell venueValCell10 = new TableCell();

                venueValCell1.RowSpan = 2;
                venueValCell1.Style.Add("vertical-align", "middle");
                venueValCell1.Style.Add("text-align", "center");
                venueValCell2.Style.Add("text-align", "center");
                venueValCell3.Style.Add("text-align", "center");
                venueValCell4.Style.Add("text-align", "center");
                venueValCell5.Style.Add("text-align", "center");
                venueValCell6.Style.Add("text-align", "center");
                venueValCell7.Style.Add("text-align", "center");
                venueValCell8.Style.Add("text-align", "center");


                venueValCell1.Text = "Text";
                venueValCell2.Text = "Text";
                venueValCell3.Text = "Text";
                venueValCell4.Text = "00";
                venueValCell5.Text = "Text";
                venueValCell6.Text = "0";
                venueValCell7.Text = "0";
                venueValCell8.Text = "0000";


                venueRow.Cells.Add(venueValCell1);
                venueRow.Cells.Add(venueValCell2);
                venueRow.Cells.Add(venueValCell3);
                venueRow.Cells.Add(venueValCell4);
                venueRow.Cells.Add(venueValCell5);
                venueRow.Cells.Add(venueValCell6);
                venueRow.Cells.Add(venueValCell7);
                venueRow.Cells.Add(venueValCell8);

                CONOPSDevWSTableWS2.Rows.Add(venueRow); //-----------------venueRow added to CONOPSDevWSTableWS2

                TableCell venueSubTotalCell1 = new TableCell();
                TableCell venueSubTotalCell2 = new TableCell();
                TableCell venueSubTotalCell3 = new TableCell();

                //TableCell venueSubTotalCell4 = new TableCell();
                //TableCell venueSubTotalCell5 = new TableCell();

                venueSubTotalCell1.ColumnSpan = 5;
                venueSubTotalCell1.Style.Add("background-color", "#bfbfbf");

                venueSubTotalCell2.Style.Add("text-align", "right");
                venueSubTotalCell2.Style.Add("font-weight", "bold");
                venueSubTotalCell2.Style.Add("background-color", "#d0ffbc");
                venueSubTotalCell2.Text = "Sub-Total:​";

                venueSubTotalCell3.Style.Add("background-color", "#d0ffbc");
                venueSubTotalCell3.Text = "0000";

                venueSubTotalRow.Cells.Add(venueSubTotalCell1);
                venueSubTotalRow.Cells.Add(venueSubTotalCell2);
                venueSubTotalRow.Cells.Add(venueSubTotalCell3);

                CONOPSDevWSTableWS2.Rows.Add(venueSubTotalRow); //-----------------venueSubTotalRow added to CONOPSDevWSTableWS2

                TableCell totalRowCell1 = new TableCell();
                TableCell totalRowCell2 = new TableCell();

                //TableCell totalRowCell3 = new TableCell();
                //TableCell totalRowCell4 = new TableCell();

                totalRowCell1.ColumnSpan = 7;
                totalRowCell1.Style.Add("text-align", "right");
                totalRowCell1.Style.Add("font-weight", "bold");
                totalRowCell1.Style.Add("background-color", "#d0ffbc");
                totalRowCell1.Text = "Total:";


                totalRowCell2.Text = "0000";
                totalRowCell2.Style.Add("background-color", "#d0ffbc");

                totalRow.Cells.Add(totalRowCell1);
                totalRow.Cells.Add(totalRowCell2);

                CONOPSDevWSTableWS2.Rows.Add(totalRow); //-----------------totalRow added to CONOPSDevWSTableWS2

                TableCell attachmentsRowCell = new TableCell();

                //TableCell attachmentsRowCell2 = new TableCell();
                //TableCell attachmentsRowCell3 = new TableCell();

                attachmentsRowCell.ColumnSpan = 8;
                attachmentsRowCell.Style.Add("font-weight", "bold");
                attachmentsRowCell.Text = "Attachments";

                attachmentsRow.Cells.Add(attachmentsRowCell);

                CONOPSDevWSTableWS2.Rows.Add(attachmentsRow); //-----------------attachmentsRow added to CONOPSDevWSTableWS2

                TableCell attachmentsValRowCell = new TableCell();

                //TableCell attachmentsValRowCell2 = new TableCell();
                //TableCell attachmentsValRowCell3 = new TableCell();

                attachmentsValRowCell.ColumnSpan = 8;
                attachmentsValRowCell.Text = "attachment1.text";
                attachmentsValRowCell.CssClass = "CONOPSDevWSAttachment";

                attachmentsValRow.Cells.Add(attachmentsValRowCell);

                CONOPSDevWSTableWS2.Rows.Add(attachmentsValRow); //-----------------attachmentsValRow added to CONOPSDevWSTableWS2


                //================= END OF TABLE TEMPLATE ====================      


                oLibQuery.Query = "" +
                    "<OrderBy>" +
                        "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                    "</OrderBy>" +
                    "<Where>" +
                        "<And>" +
                            "<Eq>" +
                                "<FieldRef Name=\"FY\"/>" +
                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                            "</Eq>" +
                             "<Eq>" +
                                "<FieldRef Name=\"WS\"/>" +
                                "<Value Type=\"Text\">WS2</Value>" +
                            "</Eq>" +
                        "</And>" +
                    "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "Deputy Director Approval")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();

                                attachmentsValRwCell.ColumnSpan = 8;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                CONOPSDevWSTableWS2.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTableWS2.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTableWS2.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTableWS2.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTableWS2.Controls.Remove(attachmentsValRow);
                }

                SPList oList = SPContext.Current.Web.Lists["CONOPSDevWS" + qs_otashort];

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy><Where>" +
                    "<And><And><And><And>" +
                        "<Eq>" +
                            "<FieldRef Name='CONOPSApproval'/>" +
                                "<Value Type='Choice'>Deputy Director Approval</Value>" +
                         "</Eq>" +
                         "<Eq>" +
                            "<FieldRef Name='ContentType'/>" +
                                "<Value Type='Computed'>WS2</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Eq>" +
                            "<FieldRef Name='FY'/>" +
                                "<Value Type='Text'>" + qs_fy + "</Value>" +
                            "</Eq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Not Approved</Value>" +
                            "</Neq>" +
                    "</And>" +
                     "<Neq>" +
                            "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                "<Value Type='Choice'>Pending</Value>" +
                            "</Neq>" +
                    "</And>" +
                "</Where>";
                traceInfo = "collListItems next...";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPListItemCollection collListItems = oList.GetItems(oQuery);



                if (collListItems.Count > 0)
                {

                    foreach (SPListItem oListItem in collListItems)
                    {
                        string title = oListItem.Title.ToString();

                        //Only one Total
                        string id = oListItem.ID.ToString();
                        if (oListItem[TotalGUID] != null)
                        {
                            try
                            {
                                traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                totalRowCell2.Text = oListItem[TotalGUID].ToString();

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }
                    }

                    //end Total------------

                    //VenueSubTotal-------------this will get all Venue sections---------
                    foreach (SPListItem oListItem in collListItems)
                    {
                        string title = "" + oListItem.Title.ToString();

                        traceInfo = "title: " + title;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string id = oListItem.ID.ToString();

                        TableRow rw = new TableRow();

                        if (oListItem.Title == "VenueSubTotal")
                        {
                            TableCell venueSubTotalCell1b = new TableCell();
                            TableCell venueSubTotalCell2b = new TableCell();
                            TableCell venueSubTotalCell3b = new TableCell();

                            
                            venueSubTotalCell1b.ColumnSpan = 5;
                            venueSubTotalCell1b.Style.Add("background-color", "#bfbfbf");

                            venueSubTotalCell2b.Style.Add("text-align", "right");
                            venueSubTotalCell2b.Style.Add("font-weight", "bold");
                            venueSubTotalCell2b.Style.Add("background-color", "#d0ffbc");
                            venueSubTotalCell2b.Text = "Sub-Total:​";

                            venueSubTotalCell3b.Style.Add("background-color", "#d0ffbc");
                            venueSubTotalCell3b.Style.Add("text-align", "center");


                            string VenueSubTotal = "";
                            try { VenueSubTotal += oListItem["VenueSubTotal"].ToString(); }
                            catch { }


                            venueSubTotalCell3b.Text = VenueSubTotal;

                            rw.Cells.Add(venueSubTotalCell1b);
                            rw.Cells.Add(venueSubTotalCell2b);
                            rw.Cells.Add(venueSubTotalCell3b);


                            rw.ID = "rowId" + id + "VenueSubTotal";

                            rw.ToolTip = oListItem["Venue"].ToString();

                            CONOPSDevWSTableWS2.Rows.AddAt(venueSubTotalRowIndex, rw);
                        }

                    }

                    traceInfo = "endVenueSubTotal";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("endVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    //end VenueSubTotal-----------


                    //iterate through VenueSubTotals-----
                    foreach (SPListItem oListItem in collListItems)
                    {
                        traceInfo = "oListItem.Title: " + oListItem.Title;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("iterVenueSubTotal", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (oListItem.Title == "VenueSubTotal")
                        {
                            string Venue = oListItem["Venue"].ToString();
                            int VenueRowIndexForThisCounter = 0;
                            int VenueRowIndexForThis = 0;

                            traceInfo = "VenueTableRows next";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRows", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                foreach (TableRow VenueSubTotalRow in rows)
                                {
                                    try
                                    {
                                        if (VenueSubTotalRow.ID.Contains("VenueSubTotal"))
                                        {
                                            try
                                            {
                                                if (VenueSubTotalRow.ToolTip == Venue)
                                                {
                                                    VenueRowIndexForThis = VenueRowIndexForThisCounter;
                                                    //break;
                                                }
                                            }
                                            catch (Exception ex)
                                            {
                                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ToolTipVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                            }
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IDVenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                    VenueRowIndexForThisCounter = VenueRowIndexForThisCounter + 1;
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueTableRowsloop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            traceInfo = "VenueRowIndexForThis " + VenueRowIndexForThis;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThisq", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPQuery VenueItemQuery = new SPQuery();

                            VenueItemQuery.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy><Where>" +
                                "<And><And><And><And><And><And>" +
                                       "<Eq>" +
                                           "<FieldRef Name='CONOPSApproval'/>" +
                                               "<Value Type='Choice'>Deputy Director Approval</Value>" +
                                        "</Eq>" +
                                        "<Eq>" +
                                           "<FieldRef Name='ContentType'/>" +
                                               "<Value Type='Computed'>WS2</Value>" +
                                           "</Eq>" +
                                       "</And>" +
                                        "<Eq>" +
                                               "<FieldRef Name='FY'/>" +
                                                   "<Value Type='Text'>" + qs_fy + "</Value>" +
                                               "</Eq>" +
                                       "</And>" +
                                        "<Neq>" +
                                               "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                                   "<Value Type='Choice'>Not Approved</Value>" +
                                               "</Neq>" +
                                       "</And>" +
                                        "<Neq>" +
                                               "<FieldRef Name='CONOPSApprovalDRReview'/>" +
                                                   "<Value Type='Choice'>Pending</Value>" +
                                               "</Neq>" +
                                       "</And>" +
                                        "<Neq>" +
                                            "<FieldRef Name=\"Title\"/>" +
                                            "<Value Type=\"Text\">VenueSubTotal</Value>" +
                                        "</Neq>" +
                                        "</And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"Venue\"/>" +
                                                "<Value Type=\"Text\">" + Venue + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                    "</Where>";
                            SPListItemCollection collListItemsVenueItems = oList.GetItems(VenueItemQuery);

                            traceInfo = "collListItemsVenueItems.Count: " + collListItemsVenueItems.Count;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CountcollListItemsVenueItems", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            foreach (SPListItem oListItemVenueItem in collListItemsVenueItems)
                            {
                                //This will get the venue items as a group and render them as rows at the venue row index
                                //traceInfo = "oListItemVenueItem Venue" + oListItemVenueItem["Venue"] + " oListItemVenueItem.Title: " + oListItemVenueItem.Title;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("oListItemVenueItemVenueItem", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow rw = new TableRow();

                                string iid = oListItemVenueItem.ID.ToString();

                                TableCell VenueCell = new TableCell();
                                TableCell TitleCell = new TableCell();
                                TableCell DatesCell = new TableCell();
                                TableCell PeopleCell = new TableCell();
                                TableCell EventLocationCell = new TableCell();
                                TableCell EstTravelCell = new TableCell();
                                TableCell EstLaborOvertimeCell = new TableCell();
                                TableCell FundingCell = new TableCell();

                                TableCell ApprovalCell = new TableCell();
                                TableCell CommentsCell = new TableCell();

                                VenueCell.Style.Add("vertical-align", "middle");
                                VenueCell.Style.Add("text-align", "center");
                                TitleCell.Style.Add("text-align", "center");
                                DatesCell.Style.Add("text-align", "center");
                                PeopleCell.Style.Add("text-align", "center");
                                EventLocationCell.Style.Add("text-align", "center");
                                EstTravelCell.Style.Add("text-align", "center");
                                EstLaborOvertimeCell.Style.Add("text-align", "center");
                                FundingCell.Style.Add("text-align", "center");

                                //string Venue = "";
                                string Title = "";
                                string Dates = "";
                                string People = "";
                                string EventLocation = "";
                                string EstTravel = "";
                                string EstLaborOvertime = "";
                                string Funding = "";


                                //try { Venue += oListItemVenueItem["Venue"].ToString(); }
                                //catch { }
                                Title += oListItemVenueItem.Title;
                                try { Dates += oListItemVenueItem["Dates"].ToString(); }
                                catch { }
                                try { People += oListItemVenueItem["People"].ToString(); }
                                catch { }
                                try { EventLocation += oListItemVenueItem["EventLocation"].ToString(); }
                                catch { }
                                try { EstTravel += oListItemVenueItem["EstTravel"].ToString(); }
                                catch { }
                                try { EstLaborOvertime += oListItemVenueItem["EstLaborOvertime"].ToString(); }
                                catch { }
                                try { Funding += oListItemVenueItem["Funding"].ToString(); }
                                catch { }
                                VenueCell.Text = Venue;
                                TitleCell.Text = Title;
                                DatesCell.Text = Dates;
                                PeopleCell.Text = People;
                                EventLocationCell.Text = EventLocation;
                                EstTravelCell.Text = EstTravel;
                                EstLaborOvertimeCell.Text = EstLaborOvertime;
                                FundingCell.Text = Funding;

                                rw.Cells.Add(VenueCell);
                                rw.Cells.Add(TitleCell);
                                rw.Cells.Add(DatesCell);
                                rw.Cells.Add(PeopleCell);
                                rw.Cells.Add(EventLocationCell);
                                rw.Cells.Add(EstTravelCell);
                                rw.Cells.Add(EstLaborOvertimeCell);
                                rw.Cells.Add(FundingCell);




                                rw.ToolTip = "Item";


                                traceInfo = "Adding row at VenueRowIndexForThis: " + VenueRowIndexForThis;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("VenueRowIndexForThis", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                CONOPSDevWSTableWS2.Rows.AddAt(VenueRowIndexForThis, rw);
                            }

                        }
                    }
                    //end iterate through VenueSubTotals----
                    try
                    {
                        CONOPSDevWSTableWS2.Controls.Remove(attachmentsValRow);
                        CONOPSDevWSTableWS2.Controls.Remove(venueRow);
                        CONOPSDevWSTableWS2.Controls.Remove(venueSubTotalRow);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    int itemCount = 0;
                    TableRow itemRowToUpdate = null;
                    int rspan = 2;
                    try
                    {
                        foreach (TableRow row in rows)
                        {

                            traceInfo = "row.ToolTip: " + row.ToolTip + " itemCount: " + itemCount;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("itemRowToUpdate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                if (row.ToolTip == "Item")
                                {

                                    if (itemRowToUpdate == null && itemCount < 1)
                                    {

                                        itemRowToUpdate = row;
                                        itemRowToUpdate.Cells[0].RowSpan = rspan;
                                        itemRowToUpdate.Cells[0].ToolTip = "Venue";
                                    }
                                    if (itemRowToUpdate != null && itemCount > 0)
                                    {
                                        rspan = rspan + 1;
                                        itemRowToUpdate.Cells[0].RowSpan = rspan;
                                        itemRowToUpdate.Cells[0].ToolTip = "Venue";

                                        row.Cells.RemoveAt(0);
                                    }


                                    itemCount = itemCount + 1;

                                }
                                else
                                {
                                    itemRowToUpdate = null;
                                    itemCount = 0;
                                    rspan = 2;
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpansItems", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("RowSpans", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
                //end collListItems.Count > 0










            }
            else
            {
                TableRow headerTitleRow = new TableRow();
                TableRow msgRow = new TableRow();
                TableCell msgCell = new TableCell();
                TableCell headerTitleCell = new TableCell();

                headerTitleRow.Style.Add("text-align", "center");
                msgCell.Text = "Worksheet Pending Approval";
                msgCell.CssClass = "msgCell";
                msgCell.Style.Add("font-size", "14px");

                headerTitleCell.Controls.Add(headerTitleCellDivWS2);
                headerTitleRow.Cells.Add(headerTitleCell);
                msgRow.Cells.Add(msgCell);

                CONOPSDevWSTableWS2.Rows.Add(headerTitleRow);
                CONOPSDevWSTableWS2.Rows.Add(msgRow);
            }
        }

     
    }
}
