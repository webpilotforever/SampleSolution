﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace DCAPXSolution.Layouts.DCAPXSolution.CONOPSApproval
{
    class WS1makeFormForAOReview
    {
        private static string getBdrcolor(string fieldName, string fieldValue, SPList oList, string qs_fy, string qs_ws, string qs_tab, string OTASubmissionID, string AOReviewID, string PMReviewID)
        {
            var traceInfo = "call to getBdrcolor fieldName: " + fieldName + " fieldValue: " + fieldValue + " AOReviewID:" + AOReviewID;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("getBdrcolor", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string colorHex = "";
            if (qs_tab == "PMReview")
            {
                colorHex = "#b5a2c6See PM Review"; //PM Review blue
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                    "<Where>" +
                    "<Eq><FieldRef Name='ID'/><Value Type='Text'>" + AOReviewID + "</Value></Eq>" +
                    "</Where>";
                SPListItemCollection collistitems = oList.GetItems(oQuery);
                foreach (SPListItem oListItem in collistitems)
                {
                    if (oListItem[fieldName].ToString() == fieldValue)
                    {
                        colorHex = "#ffdf73See AO Review"; // yellow AOReview 
                        traceInfo = "yep";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("getBdrcolor", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                }

            }


            if (qs_tab == "DeputyDirectorReviewandApproval")
            {
                colorHex = "#94cb5aSee Deputy Director Review and Approval"; //DeputyDirectorReviewandApproval green               
                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                    "<Where>" +
                    "<Eq><FieldRef Name='ID'/><Value Type='Text'>" + PMReviewID + "</Value></Eq>" +
                    "</Where>";
                SPListItemCollection collistitems = oList.GetItems(oQuery);
                foreach (SPListItem oListItem in collistitems)
                {
                    if (oListItem[fieldName].ToString() == fieldValue)
                    {
                        colorHex = "#b5a2c6See PM Review"; //PM Review blue                    
                    }
                }

            }


            return colorHex;
        }


        private static bool IsDiff(string fieldName, string fieldValue, SPList oList, string qs_fy, string qs_ws, string srcItemID)
        {




            // since this is called from PM Review as well if PM returns value back to OTASubmission there will be no border
            bool IsDiff = false;

            var traceInfo = "start IsDiff: " + IsDiff + " fieldName: " + fieldName + " fieldValue: " + fieldValue;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            if (srcItemID != "0")
            {

                try
                {

                    SPQuery oQuery = new SPQuery();

                    if (fieldValue.Length > 0)
                    {
                        oQuery.Query = "" +
                            "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ID\"/>" +
                                        "<Value Type=\"Text\">" + srcItemID + "</Value>" +
                                    "</Eq>" +
                                     "<Eq>" +
                                        "<FieldRef Name=\"" + fieldName + "\"/>" +
                                        "<Value Type=\"Text\">" + fieldValue + "</Value>" +
                                      "</Eq>" +
                                "</And>" +
                            "</Where>";
                    }
                    else
                    {
                        oQuery.Query = "" +
                            "<Where>" +
                                "<And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"ID\"/>" +
                                        "<Value Type=\"Text\">" + srcItemID + "</Value>" +
                                    "</Eq>" +
                                     "<IsNull>" +
                                        "<FieldRef Name=\"" + fieldName + "\"/>" +
                                      "</IsNull>" +
                                "</And>" +
                            "</Where>";
                    }



                    SPListItemCollection collListItems = oList.GetItems(oQuery);

                    if (collListItems.Count > 0)
                    {
                        IsDiff = false;
                    }
                    else { IsDiff = true; }


                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }


            }
            else
            {
                IsDiff = true;
            }
            traceInfo = "end IsDiff: " + IsDiff;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            return IsDiff;
        }




        internal static void makeFormAOReview(TableRow militaryGovRow, TableRow militarySubTotalRow, TableRow contractorsTotalRow, TableRow contractorsDescRow, TableRow contractorsValsRow, TableRow contractorsBlankRow, TableRow additionalItemRow, TableRow hoursRow, TableRow hoursBlankRow, TableRow contractFeeRow, TableRow contractorsFYTotalRow, TableRow contractorsSubTotalRow, TableRow attachmentsRow, TableRow attachmentsValRow, TableCell contractorsTotalRowCell2, TableCell militaryGovRowCell2, TableCell militarySubTotalRowCell3, TableRow militaryValsRow, TableCell militaryGovRowCell3, TableCell militaryGovRowCell4, TableCell militarySubTotalRowCell4, TableCell militarySubTotalRowCell5, TableCell contractorsTotalRowCell3, TableCell contractorsTotalRowCell4, Table CONOPSDevWSTable, string qs_submitted, string qs_ota, string qs_otashort, string qs_fy, string qs_tab, string qs_ws, HiddenField DisablePMReview, HiddenField DisableDeputyDirectorReviewandApproval, HiddenField itemIDFirstHidden, HiddenField itemIDLastHidden, Button CONOPSApprovalSaveButton, Button CONOPSApprovalSaveButton1, CheckBox CheckBox1, CheckBox CheckBox2, System.Web.UI.HtmlControls.HtmlGenericControl SaveDiv1, System.Web.UI.HtmlControls.HtmlGenericControl SaveDiv2, Literal LiteralAdddocument, LinkButton LinkButtonAdddocument, TableRow attachDocRow, TableCell contractorsTotalRowCell1, TableCell militarySubTotalRowCell1, Button AddMilGovBtn, TableCell contractorsSubTotalRowCell1, Button AddContractBtn)
        {
            
            var traceInfo = "";
            TableRowCollection rows = CONOPSDevWSTable.Rows;

            int contractIndex = 17;
            int attachmentIndex = 20;

            int militaryIndex = 4;
            Guid TotalGUID = new Guid("efe5a4c0-550b-4d4d-9dff-76ce5db9e9ec");


            SPWeb oWeb = SPContext.Current.Web;
            SPList oList = oWeb.GetList(oWeb.ServerRelativeUrl + "/Lists/CONOPSDevWS" + qs_otashort);
            SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);
            SPQuery oLibQuery = new SPQuery();


            SPQuery oQuery1 = new SPQuery();
            oQuery1.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                        //"<And>" +
                        "<And>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"OTA\"/>" +
                                            "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                        "</Eq>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"FY\"/>" +
                                            "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"CONOPSApproval\"/>" +
                                        "<Value Type=\"Text\">AO Recommendation</Value>" +
                                    "</Eq>" +
                                "</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Eq>" +
                            "</And>" +
                             //"<IsNotNull>" +
                             //           "<FieldRef Name=\"OTASubmissionID\"/>" +
                             //       "</IsNotNull>" +
                             //   "</And>" +
                            "<Eq>" +
                                "<FieldRef Name=\"ContentType\"/>" +
                                "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                            "</Eq>" +
                        "</And>" +
                    "</Where>";

            SPListItemCollection collListItems1 = oList.GetItems(oQuery1);

            SPQuery oQuery1MilGovb = new SPQuery();
            oQuery1MilGovb.Query = "" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                        "</OrderBy>" +
                        "<Where>" +

                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">AO Recommendation</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Eq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Eq>" +
                                "</And>" +

                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

            SPListItemCollection collListItems1MilGovb = oList.GetItems(oQuery1MilGovb);


            if (collListItems1.Count > 0)
            {
                traceInfo = "static view";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




                CONOPSApprovalSaveButton.Visible = false;
                CheckBox1.Visible = false;
                CONOPSApprovalSaveButton1.Visible = false;
                CheckBox2.Visible = false;
                SaveDiv1.Visible = false;
                SaveDiv2.Visible = false;




                //------------- lib -----------------
                //SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);


                //SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "AO Recommendation")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();

                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 6;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);

                                string id = oLibItem.ID.ToString();

                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalAOReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalAOComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                attachmentsValRwCell2.Text = attachmentsValRwCell2Text;
                                attachmentsValRwCell3.Text = attachmentsValRwCell3Text;

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }










                foreach (SPListItem oListItem in collListItems1)
                {
                    string title = oListItem.Title.ToString();
                    string id = oListItem.ID.ToString();
                    string GovLaborMonth = "";
                    string MilitarySubTotal = "";



                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                            contractorsTotalRowCell2.Text = oListItem[TotalGUID].ToString();
                            militarySubTotalRowCell1.Controls.Remove(AddMilGovBtn);
                            contractorsTotalRowCell1.Controls.Remove(AddContractBtn);


                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", contractorsTotalRowCell2.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", contractorsTotalRowCell2.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        contractorsTotalRowCell2.Style.Add("border-bottom", "solid"); contractorsTotalRowCell2.Style.Add("border-top", "solid"); contractorsTotalRowCell2.Style.Add("border-left", "solid"); contractorsTotalRowCell2.Style.Add("border-right", "solid"); contractorsTotalRowCell2.Style.Add("border-color", "#ffdf73"); contractorsTotalRowCell2.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}





                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        //Approval

                        string contractorsTotalRowCell3Text = "";
                        string contractorsTotalRowCell4Text = "";
                        try
                        {
                            contractorsTotalRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            contractorsTotalRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }



                        contractorsTotalRowCell3.Text = contractorsTotalRowCell3Text;
                        contractorsTotalRowCell4.Text = contractorsTotalRowCell4Text;


                        contractorsTotalRowCell3.CssClass = "CONOPSApprovalCell";
                        contractorsTotalRowCell4.CssClass = "CONOPSApprovalCell";

                        //---------------

                        contractorsTotalRow.ID = id;
                        

                    }
                    else if (title == "GovLaborMonth")
                    {


                        try
                        {
                            GovLaborMonth += oListItem["GovLaborMonth"].ToString();
                            traceInfo = "GovLaborMonth: " + GovLaborMonth;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        militaryGovRowCell2.Text = GovLaborMonth;



                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("GovLaborMonth", GovLaborMonth, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("GovLaborMonth", GovLaborMonth, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        militaryGovRowCell2.Style.Add("border-bottom", "solid"); militaryGovRowCell2.Style.Add("border-top", "solid"); militaryGovRowCell2.Style.Add("border-left", "solid"); militaryGovRowCell2.Style.Add("border-right", "solid"); militaryGovRowCell2.Style.Add("border-color", "#ffdf73"); militaryGovRowCell2.ToolTip = "See AO Review";
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}


                        //Approval

                        string militaryGovRowCell3Text = "";
                        string militaryGovRowCell4Text = "";
                        try
                        {
                            militaryGovRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            militaryGovRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        militaryGovRowCell3.Text = militaryGovRowCell3Text;
                        militaryGovRowCell4.Text = militaryGovRowCell4Text;



                        militaryGovRowCell3.CssClass = "CONOPSApprovalCell";
                        militaryGovRowCell4.CssClass = "CONOPSApprovalCell";

                        //---------------

                        militaryGovRow.ID = id;



                    }
                    else if (title == "MilitarySubTotal")
                    {


                        try
                        {
                            MilitarySubTotal += oListItem["MilitarySubTotal"].ToString();
                            traceInfo = "MilitarySubTotal: " + MilitarySubTotal;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        militarySubTotalRowCell3.Text = MilitarySubTotal;



                        

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("MilitarySubTotal", MilitarySubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("MilitarySubTotal", MilitarySubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        militarySubTotalRowCell3.Style.Add("border-bottom", "solid"); militarySubTotalRowCell3.Style.Add("border-top", "solid"); militarySubTotalRowCell3.Style.Add("border-left", "solid"); militarySubTotalRowCell3.Style.Add("border-right", "solid"); militarySubTotalRowCell3.Style.Add("border-color", "#ffdf73"); militarySubTotalRowCell3.ToolTip = "See AO Review";
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}

                        //Approval

                        string militarySubTotalRowCell4Text = "";
                        string militarySubTotalRowCell5Text = "";
                        try
                        {
                            militarySubTotalRowCell4Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            militarySubTotalRowCell5Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }



                        militarySubTotalRowCell4.Text = militarySubTotalRowCell4Text;
                        militarySubTotalRowCell5.Text = militarySubTotalRowCell5Text;


                        militarySubTotalRowCell4.CssClass = "CONOPSApprovalCell";
                        militarySubTotalRowCell5.CssClass = "CONOPSApprovalCell";


                        //---------------


                        militarySubTotalRow.ID = id;



                    }




                }
                foreach (SPListItem oListItem in collListItems1MilGovb)
                {
                    string title = oListItem.Title.ToString();
                    string id = oListItem.ID.ToString();
                    string employer = "";
                    try
                    {
                        employer += oListItem["Employer"].ToString();
                        traceInfo = "employer: " + employer;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    if (employer == "MilitaryOrGovernmentCivilian")
                    {
                        try
                        {
                            TableRow militaryValsRw = new TableRow();

                            TableCell militaryValsRwCell1 = new TableCell();
                            TableCell militaryValsRwCell2 = new TableCell();
                            TableCell militaryValsRwCell3 = new TableCell();
                            TableCell militaryValsRwCell4 = new TableCell();
                            TableCell militaryValsRwCell5 = new TableCell();
                            TableCell militaryValsRwCell6 = new TableCell();

                            TableCell militaryValsRwCell7 = new TableCell();
                            TableCell militaryValsRwCell8 = new TableCell();

                            militaryValsRwCell1.Style.Add("text-align", "center");
                            militaryValsRwCell2.Style.Add("text-align", "center");
                            militaryValsRwCell3.Style.Add("text-align", "center");
                            militaryValsRwCell4.Style.Add("text-align", "center");
                            militaryValsRwCell5.Style.Add("text-align", "right");
                            militaryValsRwCell6.Style.Add("text-align", "center");

                            string militaryValsRwCell1Text = title;

                            string militaryValsRwCell2Text = "";
                            string militaryValsRwCell3Text = "";
                            string militaryValsRwCell4Text = "";
                            string militaryValsRwCell5Text = "";
                            string militaryValsRwCell6Text = "";

                            try { militaryValsRwCell2Text = oListItem["DutyTitlePosition"].ToString(); }
                            catch { }
                            try { militaryValsRwCell3Text = oListItem["Status"].ToString(); }
                            catch { }
                            try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { militaryValsRwCell4Text = oListItem["Remarks"].ToString(); } }
                            catch { }
                            try { militaryValsRwCell5Text = oListItem["GSLevel"].ToString(); }
                            catch { }
                            try { militaryValsRwCell6Text = oListItem["Funding"].ToString(); }
                            catch { }






                            militaryValsRwCell1.Text = militaryValsRwCell1Text;
                            militaryValsRwCell2.Text = militaryValsRwCell2Text;
                            militaryValsRwCell3.Text = militaryValsRwCell3Text;
                            militaryValsRwCell4.Text = militaryValsRwCell4Text;
                            militaryValsRwCell5.Text = militaryValsRwCell5Text;
                            militaryValsRwCell6.Text = militaryValsRwCell6Text;




                            militaryValsRw.Cells.Add(militaryValsRwCell1);
                            militaryValsRw.Cells.Add(militaryValsRwCell2);
                            militaryValsRw.Cells.Add(militaryValsRwCell3);
                            militaryValsRw.Cells.Add(militaryValsRwCell4);
                            militaryValsRw.Cells.Add(militaryValsRwCell5);
                            militaryValsRw.Cells.Add(militaryValsRwCell6);
                            militaryValsRw.ID = id;

                           
                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Title", title, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Title", title, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell1.Style.Add("border-bottom", "solid"); militaryValsRwCell1.Style.Add("border-top", "solid"); militaryValsRwCell1.Style.Add("border-left", "solid"); militaryValsRwCell1.Style.Add("border-right", "solid"); militaryValsRwCell1.Style.Add("border-color", "#ffdf73"); militaryValsRwCell1.ToolTip = "See AO Review";
                                }
                                if (IsDiff("DutyTitlePosition", militaryValsRwCell2Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell2.Style.Add("border-bottom", "solid"); militaryValsRwCell2.Style.Add("border-top", "solid"); militaryValsRwCell2.Style.Add("border-left", "solid"); militaryValsRwCell2.Style.Add("border-right", "solid"); militaryValsRwCell2.Style.Add("border-color", "#ffdf73"); militaryValsRwCell2.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Status", militaryValsRwCell3Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell3.Style.Add("border-bottom", "solid"); militaryValsRwCell3.Style.Add("border-top", "solid"); militaryValsRwCell3.Style.Add("border-left", "solid"); militaryValsRwCell3.Style.Add("border-right", "solid"); militaryValsRwCell3.Style.Add("border-color", "#ffdf73"); militaryValsRwCell3.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Remarks", militaryValsRwCell4Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell4.Style.Add("border-bottom", "solid"); militaryValsRwCell4.Style.Add("border-top", "solid"); militaryValsRwCell4.Style.Add("border-left", "solid"); militaryValsRwCell4.Style.Add("border-right", "solid"); militaryValsRwCell4.Style.Add("border-color", "#ffdf73"); militaryValsRwCell4.ToolTip = "See AO Review";
                                }
                                if (IsDiff("GSLevel", militaryValsRwCell5Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell5.Style.Add("border-bottom", "solid"); militaryValsRwCell5.Style.Add("border-top", "solid"); militaryValsRwCell5.Style.Add("border-left", "solid"); militaryValsRwCell5.Style.Add("border-right", "solid"); militaryValsRwCell5.Style.Add("border-color", "#ffdf73"); militaryValsRwCell5.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Funding", militaryValsRwCell6Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell6.Style.Add("border-bottom", "solid"); militaryValsRwCell6.Style.Add("border-top", "solid"); militaryValsRwCell6.Style.Add("border-left", "solid"); militaryValsRwCell6.Style.Add("border-right", "solid"); militaryValsRwCell6.Style.Add("border-color", "#ffdf73"); militaryValsRwCell6.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string militaryValsRwCell7Text = "";
                            string militaryValsRwCell8Text = "";
                            try
                            {
                                militaryValsRwCell7Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                militaryValsRwCell8Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            militaryValsRwCell7.Text = militaryValsRwCell7Text;
                            militaryValsRwCell8.Text = militaryValsRwCell8Text;


                            militaryValsRwCell7.CssClass = "CONOPSApprovalCell";
                            militaryValsRwCell8.CssClass = "CONOPSApprovalCell";



                            //---------------

                            militaryValsRw.Cells.Add(militaryValsRwCell7);
                            militaryValsRw.Cells.Add(militaryValsRwCell8);
                            militaryValsRw.ID = id;

                            traceInfo = "Rows.AddAt militaryIndex: " + militaryIndex;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            CONOPSDevWSTable.Rows.AddAt(militaryIndex, militaryValsRw);
                            contractIndex = contractIndex + 1;
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("milvalsRwCells", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }

                    CONOPSDevWSTable.Controls.Remove(militaryValsRow);

                }


                string contractCheck = "";
                bool contractItemBlankRowAdded = false;

                List<string> listOfContracts = new List<string>();

                foreach (SPListItem oListItem in collListItems1)
                {
                    string title = "" + oListItem.Title.ToString();
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    string id = oListItem.ID.ToString();

                    string employer = "";
                    string Contract = "";
                    string ContractsSubTotal = "";
                    string FY = "";
                    string ContractTotal = "";
                    string ContractFee = "";
                    string HoursPerYear = "";
                    string AdditionalLineItem = "";
                    string Funding = "";
                    string DutyTitlePosition = "";
                    string Status = "";
                    string Remarks = "";
                    string ContractorRate = "";

                    try
                    {
                        employer += oListItem["Employer"].ToString();
                        traceInfo = "employer: " + employer;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                    try
                    {
                        Contract += oListItem["Contract"].ToString();
                        traceInfo = "Contract: " + Contract;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (contractCheck != "")
                        {
                            if (contractCheck != Contract)
                            {
                                contractItemBlankRowAdded = false;
                            }

                        }


                        contractCheck = Contract;



                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    if (Contract != "")
                    {



                        TableRow rw = new TableRow();

                        rw.ID = Contract;


                        //=============== Conditions =================

                        if (title == "ContractsSubTotal")
                        {
                            try
                            {
                                ContractsSubTotal += oListItem["ContractsSubTotal"].ToString();
                                traceInfo = "ContractsSubTotal: " + ContractsSubTotal;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            rw.ID = "ContractsSubTotal";

                            TableCell contractorsSubTotalRwCell1 = new TableCell();
                            TableCell contractorsSubTotalRwCell2 = new TableCell();
                            TableCell contractorsSubTotalRwCell3 = new TableCell();

                            TableCell contractorsSubTotalRwCell4 = new TableCell();
                            TableCell contractorsSubTotalRwCell5 = new TableCell();

                            contractorsSubTotalRwCell1.ColumnSpan = 4;
                            contractorsSubTotalRwCell1.Style.Add("background-color", "#bfbfbf");

                            contractorsSubTotalRwCell2.Style.Add("text-align", "right");
                            contractorsSubTotalRwCell2.Style.Add("font-weight", "bold");
                            contractorsSubTotalRwCell2.Style.Add("background-color", "#d0ffbc");
                            contractorsSubTotalRwCell2.Text = "Sub-Total:​";

                            contractorsSubTotalRwCell3.Style.Add("text-align", "center");
                            contractorsSubTotalRwCell3.Style.Add("background-color", "#d0ffbc");

                            contractorsSubTotalRwCell3.Text = ContractsSubTotal;


                            rw.Cells.Add(contractorsSubTotalRwCell1);
                            rw.Cells.Add(contractorsSubTotalRwCell2);
                            rw.Cells.Add(contractorsSubTotalRwCell3);


                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("ContractsSubTotal", ContractsSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("ContractsSubTotal", ContractsSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        contractorsSubTotalRwCell3.Style.Add("border-bottom", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-top", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-left", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-right", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-color", "#ffdf73");
                            //        contractorsSubTotalRwCell3.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}


                            //Approval

                            string contractorsSubTotalRwCell4Text = "";
                            string contractorsSubTotalRwCell5Text = "";
                            try
                            {
                                contractorsSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorsSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            contractorsSubTotalRwCell4.Text = contractorsSubTotalRwCell4Text;
                            contractorsSubTotalRwCell5.Text = contractorsSubTotalRwCell5Text;


                            contractorsSubTotalRwCell4.CssClass = "CONOPSApprovalCell";
                            contractorsSubTotalRwCell5.CssClass = "CONOPSApprovalCell";

                            //---------------

                            rw.Cells.Add(contractorsSubTotalRwCell4);
                            rw.Cells.Add(contractorsSubTotalRwCell5);
                            rw.ID = id;
                        }


                        //CONDITIONS 

                        if (title == "ContractTotal")
                        {
                            try
                            {
                                FY += oListItem["FY"].ToString();
                                traceInfo = "ContractFY: " + FY;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                ContractTotal += oListItem["ContractTotal"].ToString();
                                traceInfo = "ContractFYTotal: " + ContractTotal;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            TableCell contractorFYTotalRwCell1 = new TableCell();
                            TableCell contractorFYTotalRwCell2 = new TableCell();

                            TableCell contractorFYTotalRwCell3 = new TableCell();
                            TableCell contractorFYTotalRwCell4 = new TableCell();


                            contractorFYTotalRwCell1.ColumnSpan = 5;
                            contractorFYTotalRwCell1.Style.Add("text-align", "right");
                            contractorFYTotalRwCell2.Style.Add("text-align", "center");

                            Label LabelcontractorFYTotalVals1b = new Label();
                            LabelcontractorFYTotalVals1b.Text = "Total for FY ";

                            Label LabelcontractorFYTotalVals2b = new Label();
                            LabelcontractorFYTotalVals2b.Text = FY;

                            contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals1b);
                            contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals2b);


                            contractorFYTotalRwCell2.Text = ContractTotal;


                            rw.Cells.Add(contractorFYTotalRwCell1);
                            rw.Cells.Add(contractorFYTotalRwCell2);

                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("ContractTotal", ContractTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("ContractTotal", ContractTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        contractorFYTotalRwCell2.Style.Add("border-bottom", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-top", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-left", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-right", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-color", "#ffdf73");
                            //        contractorFYTotalRwCell2.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}

                            //Approval

                            string contractorFYTotalRwCell3Text = "";
                            string contractorFYTotalRwCell4Text = "";
                            try
                            {
                                contractorFYTotalRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorFYTotalRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            contractorFYTotalRwCell3.Text = contractorFYTotalRwCell3Text;
                            contractorFYTotalRwCell4.Text = contractorFYTotalRwCell4Text;



                            contractorFYTotalRwCell3.CssClass = "CONOPSApprovalCell";
                            contractorFYTotalRwCell4.CssClass = "CONOPSApprovalCell";


                            //---------------
                            rw.Cells.Add(contractorFYTotalRwCell3);
                            rw.Cells.Add(contractorFYTotalRwCell4);
                        }

                        if (title == "ContractFee")
                        {
                            try
                            {
                                ContractFee += oListItem["ContractFee"].ToString();
                                traceInfo = "ContractFee: " + ContractFee;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            TableCell contractFeeRwCell1 = new TableCell();
                            TableCell contractFeeRwCell2 = new TableCell();

                            TableCell contractFeeRwCell3 = new TableCell();
                            TableCell contractFeeRwCell4 = new TableCell();

                            contractFeeRwCell1.ColumnSpan = 5;
                            contractFeeRwCell1.Style.Add("text-align", "right");
                            contractFeeRwCell2.Style.Add("text-align", "center");

                            contractFeeRwCell1.Text = "Contract fee";


                            contractFeeRwCell2.Text = ContractFee;


                            rw.Cells.Add(contractFeeRwCell1);
                            rw.Cells.Add(contractFeeRwCell2);

                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("ContractFee", ContractFee, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("ContractFee", ContractFee, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractFeeRwCell2.Style.Add("border-bottom", "solid");
                                    contractFeeRwCell2.Style.Add("border-top", "solid");
                                    contractFeeRwCell2.Style.Add("border-left", "solid");
                                    contractFeeRwCell2.Style.Add("border-right", "solid");
                                    contractFeeRwCell2.Style.Add("border-color", "#ffdf73");
                                    contractFeeRwCell2.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string contractFeeRwCell3Text = "";
                            string contractFeeRwCell4Text = "";
                            try
                            {
                                contractFeeRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractFeeRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            contractFeeRwCell3.Text = contractFeeRwCell3Text;
                            contractFeeRwCell4.Text = contractFeeRwCell4Text;


                            contractFeeRwCell3.CssClass = "CONOPSApprovalCell";
                            contractFeeRwCell4.CssClass = "CONOPSApprovalCell";


                            //---------------

                            rw.Cells.Add(contractFeeRwCell3);
                            rw.Cells.Add(contractFeeRwCell4);
                            rw.ID = id;
                        }
                        if (title == "HoursPerYear")
                        {
                            try
                            {
                                HoursPerYear += oListItem["HoursPerYear"].ToString();
                                traceInfo = "HoursPerYear: " + HoursPerYear;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            TableRow hoursBlankRw = new TableRow();

                            TableCell hoursBlankRwCell1 = new TableCell();
                            TableCell hoursBlankRwCell2 = new TableCell();

                            TableCell hoursBlankRwCell3 = new TableCell();
                            TableCell hoursBlankRwCell4 = new TableCell();

                            hoursBlankRwCell1.ColumnSpan = 5;

                            Literal LiteralhoursBlankRowb = new Literal();
                            LiteralhoursBlankRowb.Text = "&nbsp;";

                            hoursBlankRwCell1.Controls.Add(LiteralhoursBlankRowb);

                            hoursBlankRw.Cells.Add(hoursBlankRwCell1);
                            hoursBlankRw.Cells.Add(hoursBlankRwCell2);

                            hoursBlankRw.Cells.Add(hoursBlankRwCell3);
                            hoursBlankRw.Cells.Add(hoursBlankRwCell4);

                            hoursBlankRw.ToolTip = Contract;
                            hoursBlankRw.ID = "BlankHoursRow";

                            CONOPSDevWSTable.Rows.AddAt(contractIndex, hoursBlankRw);


                            TableCell hoursRwCell1 = new TableCell();
                            TableCell hoursRwCell2 = new TableCell();

                            TableCell hoursRwCell3 = new TableCell();
                            TableCell hoursRwCell4 = new TableCell();

                            hoursRwCell3.CssClass = "CONOPSApprovalCell";
                            hoursRwCell4.CssClass = "CONOPSApprovalCell";

                            //hoursRwCell3.Style.Add("background-color", "Cornsilk");
                            //hoursRwCell4.Style.Add("background-color", "Cornsilk");

                         

                            hoursRwCell1.ColumnSpan = 5;
                            hoursRwCell1.Style.Add("text-align", "right");
                            hoursRwCell2.Style.Add("text-align", "center");

                            Label LabelhoursRow1b = new Label();
                            LabelhoursRow1b.Text = "Hours per year  " + HoursPerYear;
                            LabelhoursRow1b.ToolTip = Contract;
                            LabelhoursRow1b.ID = "HoursPerYear";
                            


                            hoursRwCell1.Controls.Add(LabelhoursRow1b);


                            rw.Cells.Add(hoursRwCell1);
                            rw.Cells.Add(hoursRwCell2);

                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("HoursPerYear", HoursPerYear, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("HoursPerYear", HoursPerYear, oList, qs_fy, qs_ws, srcID))
                                {
                                    hoursRwCell1.Style.Add("border-bottom", "solid");
                                    hoursRwCell1.Style.Add("border-top", "solid");
                                    hoursRwCell1.Style.Add("border-left", "solid");
                                    hoursRwCell1.Style.Add("border-right", "solid");
                                    hoursRwCell1.Style.Add("border-color", "#ffdf73");
                                    hoursRwCell1.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string hoursRwCell3Text = "";
                            string hoursRwCell4Text = "";
                            try
                            {
                                hoursRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                hoursRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            hoursRwCell3.Text = hoursRwCell3Text;
                            hoursRwCell4.Text = hoursRwCell4Text;

                            hoursRwCell3.CssClass = "CONOPSApprovalCell";
                            hoursRwCell4.CssClass = "CONOPSApprovalCell";






                            //---------------

                            rw.Cells.Add(hoursRwCell3);
                            rw.Cells.Add(hoursRwCell4);
                            rw.ID = id;
                        }


                        try
                        {
                            AdditionalLineItem += oListItem["AdditionalLineItem"].ToString();
                            traceInfo = "AdditionalLineItem: " + AdditionalLineItem;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        if (AdditionalLineItem != "")
                        {


                            TableCell additionalItemRwCell1 = new TableCell();
                            TableCell additionalItemRwCell2 = new TableCell();

                            TableCell additionalItemRwCell3 = new TableCell();
                            TableCell additionalItemRwCell4 = new TableCell();

                            additionalItemRwCell1.ColumnSpan = 5;
                            additionalItemRwCell1.Style.Add("text-align", "right");
                            additionalItemRwCell2.Style.Add("text-align", "center");

                            Label LabeladditionalItemDesc1b = new Label();
                            LabeladditionalItemDesc1b.Text = "Additional line item (title and amount) ";

                            Label LabeladditionalItemDesc2bTextBox = new Label();
                            LabeladditionalItemDesc2bTextBox.Text = title;
                            LabeladditionalItemDesc2bTextBox.Font.Italic = false;

                            additionalItemRwCell1.Controls.Add(LabeladditionalItemDesc1b);
                            additionalItemRwCell1.Controls.Add(LabeladditionalItemDesc2bTextBox);


                            additionalItemRwCell2.Text = AdditionalLineItem;



                            rw.Cells.Add(additionalItemRwCell1);
                            rw.Cells.Add(additionalItemRwCell2);

                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("AdditionalLineItem", AdditionalLineItem, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Title", title, oList, qs_fy, qs_ws, srcID))
                                {
                                    additionalItemRwCell1.Style.Add("border-bottom", "solid");
                                    additionalItemRwCell1.Style.Add("border-top", "solid");
                                    additionalItemRwCell1.Style.Add("border-left", "solid");
                                    additionalItemRwCell1.Style.Add("border-right", "solid");
                                    additionalItemRwCell1.Style.Add("border-color", "#ffdf73");
                                    additionalItemRwCell1.ToolTip = "See AO Review";
                                }
                                if (IsDiff("AdditionalLineItem", AdditionalLineItem, oList, qs_fy, qs_ws, srcID))
                                {
                                    additionalItemRwCell2.Style.Add("border-bottom", "solid");
                                    additionalItemRwCell2.Style.Add("border-top", "solid");
                                    additionalItemRwCell2.Style.Add("border-left", "solid");
                                    additionalItemRwCell2.Style.Add("border-right", "solid");
                                    additionalItemRwCell2.Style.Add("border-color", "#ffdf73");
                                    additionalItemRwCell2.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string additionalItemRwCell3Text = "";
                            string additionalItemRwCell4Text = "";
                            try
                            {
                                additionalItemRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                additionalItemRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            additionalItemRwCell3.Text = additionalItemRwCell3Text;
                            additionalItemRwCell4.Text = additionalItemRwCell4Text;


                            additionalItemRwCell3.CssClass = "CONOPSApprovalCell";
                            additionalItemRwCell4.CssClass = "CONOPSApprovalCell";

                            //---------------

                            rw.Cells.Add(additionalItemRwCell3);
                            rw.Cells.Add(additionalItemRwCell4);

                            rw.ID = id;

                            string dds1 = oListItem["DateDraftSaved"].ToString();


                            if (oListItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            {

                                rw.ToolTip = "NewLineItem_" + Contract;


                            }

                            AdditionalLineItem = "";





                        }



                        try
                        {
                            Funding += oListItem["Funding"].ToString();
                            traceInfo = "Funding: " + Funding;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        if (Funding != "")
                        {




                            try
                            {
                                DutyTitlePosition += oListItem["DutyTitlePosition"].ToString();
                                traceInfo = "DutyTitlePosition: " + DutyTitlePosition;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                Status += oListItem["Status"].ToString();
                                traceInfo = "Status: " + Status;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); }
                                traceInfo = "Remarks: " + Remarks;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                ContractorRate += oListItem["ContractorRate"].ToString();
                                traceInfo = "ContractorRate: " + ContractorRate;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            TableCell contractorsValsRwCell1 = new TableCell();
                            TableCell contractorsValsRwCell2 = new TableCell();
                            TableCell contractorsValsRwCell3 = new TableCell();
                            TableCell contractorsValsRwCell4 = new TableCell();
                            TableCell contractorsValsRwCell5 = new TableCell();
                            TableCell contractorsValsRwCell6 = new TableCell();

                            TableCell contractorsValsRwCell7 = new TableCell();
                            TableCell contractorsValsRwCell8 = new TableCell();

                            contractorsValsRwCell1.Style.Add("text-align", "center");
                            contractorsValsRwCell2.Style.Add("text-align", "center");
                            contractorsValsRwCell3.Style.Add("text-align", "center");
                            contractorsValsRwCell4.Style.Add("text-align", "center");
                            contractorsValsRwCell5.Style.Add("text-align", "right");
                            contractorsValsRwCell6.Style.Add("text-align", "center");



                            contractorsValsRwCell1.Text = title;
                            contractorsValsRwCell2.Text = DutyTitlePosition;
                            contractorsValsRwCell3.Text = Status;
                            contractorsValsRwCell4.Text = Remarks;
                            contractorsValsRwCell5.Text = ContractorRate;
                            contractorsValsRwCell6.Text = Funding;



                            rw.Cells.Add(contractorsValsRwCell1);
                            rw.Cells.Add(contractorsValsRwCell2);
                            rw.Cells.Add(contractorsValsRwCell3);
                            rw.Cells.Add(contractorsValsRwCell4);
                            rw.Cells.Add(contractorsValsRwCell5);
                            rw.Cells.Add(contractorsValsRwCell6);

                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Title", title, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Title", title, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell1.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell1.Style.Add("border-top", "solid");
                                    contractorsValsRwCell1.Style.Add("border-left", "solid");
                                    contractorsValsRwCell1.Style.Add("border-right", "solid");
                                    contractorsValsRwCell1.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell1.ToolTip = "See AO Review";

                                }
                                if (IsDiff("DutyTitlePosition", DutyTitlePosition, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell2.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell2.Style.Add("border-top", "solid");
                                    contractorsValsRwCell2.Style.Add("border-left", "solid");
                                    contractorsValsRwCell2.Style.Add("border-right", "solid");
                                    contractorsValsRwCell2.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell2.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Status", Status, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell3.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell3.Style.Add("border-top", "solid");
                                    contractorsValsRwCell3.Style.Add("border-left", "solid");
                                    contractorsValsRwCell3.Style.Add("border-right", "solid");
                                    contractorsValsRwCell3.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell3.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell4.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell4.Style.Add("border-top", "solid");
                                    contractorsValsRwCell4.Style.Add("border-left", "solid");
                                    contractorsValsRwCell4.Style.Add("border-right", "solid");
                                    contractorsValsRwCell4.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell4.ToolTip = "See AO Review";
                                }
                                if (IsDiff("ContractorRate", ContractorRate, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell5.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell5.Style.Add("border-top", "solid");
                                    contractorsValsRwCell5.Style.Add("border-left", "solid");
                                    contractorsValsRwCell5.Style.Add("border-right", "solid");
                                    contractorsValsRwCell5.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell5.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell6.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell6.Style.Add("border-top", "solid");
                                    contractorsValsRwCell6.Style.Add("border-left", "solid");
                                    contractorsValsRwCell6.Style.Add("border-right", "solid");
                                    contractorsValsRwCell6.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell6.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string contractorsValsRwCell7Text = "";
                            string contractorsValsRwCell8Text = "";
                            try
                            {
                                contractorsValsRwCell7Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorsValsRwCell8Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            contractorsValsRwCell7.Text = contractorsValsRwCell7Text;
                            contractorsValsRwCell8.Text = contractorsValsRwCell8Text;


                            contractorsValsRwCell7.CssClass = "CONOPSApprovalCell";
                            contractorsValsRwCell8.CssClass = "CONOPSApprovalCell";

                            //---------------

                            rw.Cells.Add(contractorsValsRwCell7);
                            rw.Cells.Add(contractorsValsRwCell8);

                            rw.ID = id;

                            bool contractSectionExists = false;
                            string dds = oListItem["DateDraftSaved"].ToString();


                            if (oListItem["OTASubmissionID"] == null && !dds.Contains(":"))
                            {

                                rw.ToolTip = "NewItem_" + Contract; //oListItem["Contract"].ToString()


                            }
                            else { contractSectionExists = true; }

                            Funding = "";

                            //----------


                            if (!contractItemBlankRowAdded && contractSectionExists)
                            {
                                TableRow contractorsBlankRw = new TableRow();

                                TableCell contractorsBlankRwCell1 = new TableCell();
                                TableCell contractorsBlankRwCell2 = new TableCell();

                                TableCell contractorsBlankRwCell3 = new TableCell();
                                TableCell contractorsBlankRwCell4 = new TableCell();

                                contractorsBlankRwCell1.ColumnSpan = 5;

                                Literal LiteralcontractorsBlankRw = new Literal();
                                LiteralcontractorsBlankRw.Text = "&nbsp;";

                                contractorsBlankRwCell1.Controls.Add(LiteralcontractorsBlankRw);

                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell1);
                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell2);

                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell3);
                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell4);

                                contractorsBlankRw.ID = "contractorsBlankRow";
                                contractorsBlankRw.ToolTip = Contract;

                                CONOPSDevWSTable.Rows.AddAt(contractIndex, contractorsBlankRw);

                                contractItemBlankRowAdded = true;
                            }


                        }
                        if (title == "Contract")
                        {

                            TableCell contractorsDescRwCell = new TableCell();

                            TableCell contractorsDescRwCell2 = new TableCell();
                            TableCell contractorsDescRwCell3 = new TableCell();

                            contractorsDescRwCell.ColumnSpan = 6;

                            contractorsDescRwCell.Style.Add("text-align", "center");
                            contractorsDescRwCell.Style.Add("font-style", "italic");

                            Label LabelcontractorsDesc1b = new Label();
                            LabelcontractorsDesc1b.Text = "Contract Identifier  ";

                            Label LabelcontractorsDesc2bTextBox = new Label();
                            LabelcontractorsDesc2bTextBox.Text = Contract;
                            LabelcontractorsDesc2bTextBox.Font.Italic = false;
                            LabelcontractorsDesc2bTextBox.ID = "rowId" + id + "Contract";
                            LabelcontractorsDesc2bTextBox.CssClass = "ContractIdentifyer";

                            contractorsDescRwCell.Controls.Add(LabelcontractorsDesc1b);
                            contractorsDescRwCell.Controls.Add(LabelcontractorsDesc2bTextBox);

                            rw.Cells.Add(contractorsDescRwCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Contract", Contract, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Contract", Contract, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsDescRwCell.Style.Add("border-bottom", "solid");
                                    contractorsDescRwCell.Style.Add("border-top", "solid");
                                    contractorsDescRwCell.Style.Add("border-left", "solid");
                                    contractorsDescRwCell.Style.Add("border-right", "solid");
                                    contractorsDescRwCell.Style.Add("border-color", "#ffdf73");
                                    contractorsDescRwCell.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string contractorsDescRwCell2Text = "";
                            string contractorsDescRwCell3Text = "";
                            try
                            {
                                contractorsDescRwCell2Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorsDescRwCell3Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                            contractorsDescRwCell2.Text = contractorsDescRwCell2Text;
                            contractorsDescRwCell3.Text = contractorsDescRwCell3Text;


                            contractorsDescRwCell2.CssClass = "CONOPSApprovalCell";
                            contractorsDescRwCell3.CssClass = "CONOPSApprovalCell";


                            //---------------

                            rw.Cells.Add(contractorsDescRwCell2);
                            rw.Cells.Add(contractorsDescRwCell3);
                            rw.ToolTip = "Contract";
                        }


                        //==================
                        rw.ID = id;
                        //rw.CssClass = "WSGroupStartRow";

                        CONOPSDevWSTable.Rows.AddAt(contractIndex, rw);
                    }

                }




                try
                {
                    //Remove template rows
                    CONOPSDevWSTable.Controls.Remove(contractorsDescRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsValsRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsBlankRow);
                    CONOPSDevWSTable.Controls.Remove(additionalItemRow);
                    CONOPSDevWSTable.Controls.Remove(hoursRow);
                    CONOPSDevWSTable.Controls.Remove(hoursBlankRow);
                    CONOPSDevWSTable.Controls.Remove(contractFeeRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsFYTotalRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsSubTotalRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                    CONOPSDevWSTable.Controls.Remove(attachDocRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }



            }
            else
            {

                //------------- lib -----------------
                //SPList oLib = oWeb.GetList(oWeb.ServerRelativeUrl + "/CONOPSDev" + qs_otashort);



                //SPQuery oLibQuery = new SPQuery();


                oLibQuery.Query = "" +
                     "<OrderBy>" +
                         "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                     "</OrderBy>" +
                     "<Where>" +
                         "<And>" +
                             "<Eq>" +
                                 "<FieldRef Name=\"FY\"/>" +
                                 "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                             "</Eq>" +
                              "<Eq>" +
                                 "<FieldRef Name=\"WS\"/>" +
                                 "<Value Type=\"Text\">WS" + qs_ws + "</Value>" +
                             "</Eq>" +
                         "</And>" +
                     "</Where>";

                SPListItemCollection collLibItems = oLib.GetItems(oLibQuery);

                if (collLibItems.Count > 0)
                {
                    bool removeAttachmentRow = true;

                    foreach (SPListItem oLibItem in collLibItems)
                    {


                        SPListItemVersionCollection collListItemVersions = oLibItem.Versions;

                        foreach (SPListItemVersion oListItemVersion in collListItemVersions)
                        {
                            if ((string)oListItemVersion["CONOPSApproval"] == "AO Recommendation")
                            {
                                traceInfo = (string)oListItemVersion["CONOPSApproval"] + " | " + oListItemVersion.VersionLabel;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("linktoversion", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                TableRow attachmentsValRw = new TableRow();

                                TableCell attachmentsValRwCell = new TableCell();
                                TableCell attachmentsValRwCell2 = new TableCell();
                                TableCell attachmentsValRwCell3 = new TableCell();

                                attachmentsValRwCell2.CssClass = "CONOPSApprovalCell";
                                attachmentsValRwCell3.CssClass = "CONOPSApprovalCell";

                                attachmentsValRwCell.ColumnSpan = 6;
                                attachmentsValRwCell.CssClass = "CONOPSDevWSAttachment";
                                attachmentsValRwCell.Style.Add("text-align", "center");

                                string versionUrl = oWeb.ServerRelativeUrl + "/" + oListItemVersion.Url; //_vti_history/2048/CONOPSDevAFOTEC/testOfUploadAttachedDocs.txt                            

                                traceInfo = versionUrl;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("versionUrl", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                Literal LiteralattachmentsValRwCell = new Literal();
                                LiteralattachmentsValRwCell.Text = "<A onfocus=OnLink(this) onmousedown='return VerifyHref(this,event,\"1\", \"SharePoint.OpenDocuments\", \"\"); ' onclick='DispDocItemExWithServerRedirect(this,event,\"FALSE\",\"FALSE\",\"FALSE\",\"SharePoint.OpenDocuments\",\"1\",\"\"); return false;' href=\"" + versionUrl + "\">" + oListItemVersion.ListItem.File.Name + "</A>";

                                attachmentsValRwCell.Controls.Add(LiteralattachmentsValRwCell);

                                attachmentsValRw.Cells.Add(attachmentsValRwCell);



                                string id = oLibItem.ID.ToString();



                                //Approval

                                string attachmentsValRwCell2Text = "";
                                string attachmentsValRwCell3Text = "";
                                try
                                {
                                    attachmentsValRwCell2Text = "" + (string)oListItemVersion["CONOPSApprovalAOReview"];
                                    attachmentsValRwCell3Text = "" + (string)oListItemVersion["CONOPSApprovalAOComments"];
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                                ListItem attachmentsValRwCell2ListItem1 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem2 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem3 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem4 = new ListItem();
                                ListItem attachmentsValRwCell2ListItem5 = new ListItem();

                                attachmentsValRwCell2ListItem1.Value = "Pending";
                                attachmentsValRwCell2ListItem1.Text = "Pending";
                                attachmentsValRwCell2ListItem1.Selected = true;

                                attachmentsValRwCell2ListItem2.Value = "Approved";
                                attachmentsValRwCell2ListItem2.Text = "Approved";

                                attachmentsValRwCell2ListItem3.Value = "Approved With Comments";
                                attachmentsValRwCell2ListItem3.Text = "Approved With Comments";

                                attachmentsValRwCell2ListItem4.Value = "Approved With Revisions";
                                attachmentsValRwCell2ListItem4.Text = "Approved With Revisions";

                                attachmentsValRwCell2ListItem5.Value = "Not Approved";
                                attachmentsValRwCell2ListItem5.Text = "Not Approved";


                                DropDownList attachmentsValRwCell2DropDownList = new DropDownList();
                                attachmentsValRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                                attachmentsValRwCell2DropDownList.ID = "attId" + id + "CONOPSApprovalAOReview";

                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem1);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem2);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem3);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem4);
                                attachmentsValRwCell2DropDownList.Items.Add(attachmentsValRwCell2ListItem5);


                                TextBox attachmentsValRwCell3TextBox = new TextBox();
                                attachmentsValRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                                attachmentsValRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";

                                attachmentsValRwCell2DropDownList.SelectedValue = attachmentsValRwCell2Text;
                                attachmentsValRwCell3TextBox.Text = attachmentsValRwCell3Text;
                                attachmentsValRwCell3TextBox.ID = "attId" + id + "CONOPSApprovalAOComments";

                                attachmentsValRwCell2.Controls.Add(attachmentsValRwCell2DropDownList);
                                attachmentsValRwCell3.Controls.Add(attachmentsValRwCell3TextBox);

                                //---------------

                                attachmentsValRw.Cells.Add(attachmentsValRwCell2);
                                attachmentsValRw.Cells.Add(attachmentsValRwCell3);
                                attachmentsValRw.ID = id;

                                CONOPSDevWSTable.Rows.AddAt(attachmentIndex, attachmentsValRw);

                                removeAttachmentRow = false;

                                break;

                            }
                        }

                    }

                    if (removeAttachmentRow)
                    {
                        CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    }

                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);

                }
                else
                {
                    CONOPSDevWSTable.Controls.Remove(attachmentsRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                            //"<And>" +
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">AO Recommendation</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" + 
                                //"<IsNotNull>" +
                                //        "<FieldRef Name=\"OTASubmissionID\"/>" +
                                //    "</IsNotNull>" +
                                //"</And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItems = oList.GetItems(oQuery);
               
                
                SPQuery oQueryMilGov = new SPQuery();
                oQueryMilGov.Query = "" +
                            "<OrderBy>" +
                                "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                            "</OrderBy>" +
                            "<Where>" +
                         
                            "<And>" +
                                "<And>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"OTA\"/>" +
                                                "<Value Type=\"Text\">" + qs_otashort + "</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                                "<FieldRef Name=\"FY\"/>" +
                                                "<Value Type=\"Text\">" + qs_fy + "</Value>" +
                                            "</Eq>" +
                                        "</And>" +
                                        "<Eq>" +
                                            "<FieldRef Name=\"CONOPSApproval\"/>" +
                                            "<Value Type=\"Text\">AO Recommendation</Value>" +
                                        "</Eq>" +
                                    "</And>" +
                                    "<Neq>" +
                                        "<FieldRef Name=\"Submitted\"/>" +
                                        "<Value Type=\"Text\">Yes</Value>" +
                                    "</Neq>" +
                                "</And>" +
                                
                                "<Eq>" +
                                    "<FieldRef Name=\"ContentType\"/>" +
                                    "<Value Type=\"Computed\">WS" + qs_ws + "</Value>" +
                                "</Eq>" +
                            "</And>" +
                        "</Where>";

                SPListItemCollection collListItemsMilGov = oList.GetItems(oQueryMilGov);

                

                foreach (SPListItem oListItem in collListItems)
                {
                    string title = oListItem.Title.ToString();
                    string id = oListItem.ID.ToString();
                    string GovLaborMonth = "";
                    string MilitarySubTotal = "";



                    if (oListItem[TotalGUID] != null)
                    {
                        try
                        {
                            traceInfo = "oListItem[TotalGUID].ToString(): " + oListItem[TotalGUID].ToString();
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                            contractorsTotalRowCell2.Text = "";



                            TextBox totalTextBox = new TextBox();
                            totalTextBox.Width = 80;
                            totalTextBox.Text = oListItem[TotalGUID].ToString();
                            totalTextBox.ID = "rowId" + id + "Total";


                            contractorsTotalRowCell2.Controls.Add(totalTextBox);


                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("Total", totalTextBox.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("Total", totalTextBox.Text, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        contractorsTotalRowCell2.Style.Add("border-bottom", "solid"); contractorsTotalRowCell2.Style.Add("border-top", "solid"); contractorsTotalRowCell2.Style.Add("border-left", "solid"); contractorsTotalRowCell2.Style.Add("border-right", "solid"); contractorsTotalRowCell2.Style.Add("border-color", "#ffdf73"); contractorsTotalRowCell2.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}




                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        //Approval

                        string contractorsTotalRowCell3Text = "";
                        string contractorsTotalRowCell4Text = "";
                        try
                        {
                            contractorsTotalRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            contractorsTotalRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        ListItem contractorsTotalRowCell3ListItem1 = new ListItem();
                        ListItem contractorsTotalRowCell3ListItem2 = new ListItem();
                        ListItem contractorsTotalRowCell3ListItem3 = new ListItem();
                        ListItem contractorsTotalRowCell3ListItem4 = new ListItem();
                        ListItem contractorsTotalRowCell3ListItem5 = new ListItem();

                        contractorsTotalRowCell3ListItem1.Value = "Pending";
                        contractorsTotalRowCell3ListItem1.Text = "Pending";
                        contractorsTotalRowCell3ListItem1.Selected = true;

                        contractorsTotalRowCell3ListItem2.Value = "Approved";
                        contractorsTotalRowCell3ListItem2.Text = "Approved";

                        contractorsTotalRowCell3ListItem3.Value = "Approved With Comments";
                        contractorsTotalRowCell3ListItem3.Text = "Approved With Comments";

                        contractorsTotalRowCell3ListItem4.Value = "Approved With Revisions";
                        contractorsTotalRowCell3ListItem4.Text = "Approved With Revisions";

                        contractorsTotalRowCell3ListItem5.Value = "Not Approved";
                        contractorsTotalRowCell3ListItem5.Text = "Not Approved";



                        DropDownList contractorsTotalRowCell3DropDownList = new DropDownList();
                        contractorsTotalRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                        contractorsTotalRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                        contractorsTotalRowCell3DropDownList.Items.Add(contractorsTotalRowCell3ListItem1);
                        contractorsTotalRowCell3DropDownList.Items.Add(contractorsTotalRowCell3ListItem2);
                        contractorsTotalRowCell3DropDownList.Items.Add(contractorsTotalRowCell3ListItem3);
                        contractorsTotalRowCell3DropDownList.Items.Add(contractorsTotalRowCell3ListItem4);
                        contractorsTotalRowCell3DropDownList.Items.Add(contractorsTotalRowCell3ListItem5);


                        TextBox contractorsTotalRowCell4TextBox = new TextBox();
                        contractorsTotalRowCell4TextBox.TextMode = TextBoxMode.MultiLine;
                        contractorsTotalRowCell4TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                        contractorsTotalRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                        contractorsTotalRowCell3DropDownList.SelectedValue = contractorsTotalRowCell3Text;
                        contractorsTotalRowCell4TextBox.Text = contractorsTotalRowCell4Text;

                        contractorsTotalRowCell3.Controls.Add(contractorsTotalRowCell3DropDownList);
                        contractorsTotalRowCell4.Controls.Add(contractorsTotalRowCell4TextBox);

                        contractorsTotalRowCell3.CssClass = "CONOPSApprovalCell";
                        contractorsTotalRowCell4.CssClass = "CONOPSApprovalCell";

                        //contractorsTotalRowCell3.Style.Add("background-color", "Cornsilk");
                        //contractorsTotalRowCell4.Style.Add("background-color", "Cornsilk");
                        //---------------

                        contractorsTotalRow.ID = id;
                    }
                    else if (title == "GovLaborMonth")
                    {


                        try
                        {
                            GovLaborMonth += oListItem["GovLaborMonth"].ToString();
                            traceInfo = "GovLaborMonth: " + GovLaborMonth;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        militaryGovRowCell2.Text = "";

                        TextBox militaryGovRowCell2TextBox = new TextBox();
                        militaryGovRowCell2TextBox.Width = 80;
                        militaryGovRowCell2TextBox.Text = GovLaborMonth;
                        militaryGovRowCell2TextBox.ID = "rowId" + id + "GovLaborMonth";

                        militaryGovRowCell2.Controls.Add(militaryGovRowCell2TextBox);
                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("GovLaborMonth", GovLaborMonth, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("GovLaborMonth", GovLaborMonth, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        militaryGovRowCell2.Style.Add("border-bottom", "solid"); militaryGovRowCell2.Style.Add("border-top", "solid"); militaryGovRowCell2.Style.Add("border-left", "solid"); militaryGovRowCell2.Style.Add("border-right", "solid"); militaryGovRowCell2.Style.Add("border-color", "#ffdf73"); militaryGovRowCell2.ToolTip = "See AO Review";
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}


                        //Approval

                        string militaryGovRowCell3Text = "";
                        string militaryGovRowCell4Text = "";
                        try
                        {
                            militaryGovRowCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            militaryGovRowCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        ListItem militaryGovRowCell3ListItem1 = new ListItem();
                        ListItem militaryGovRowCell3ListItem2 = new ListItem();
                        ListItem militaryGovRowCell3ListItem3 = new ListItem();
                        ListItem militaryGovRowCell3ListItem4 = new ListItem();
                        ListItem militaryGovRowCell3ListItem5 = new ListItem();

                        militaryGovRowCell3ListItem1.Value = "Pending";
                        militaryGovRowCell3ListItem1.Text = "Pending";
                        militaryGovRowCell3ListItem1.Selected = true;

                        militaryGovRowCell3ListItem2.Value = "Approved";
                        militaryGovRowCell3ListItem2.Text = "Approved";

                        militaryGovRowCell3ListItem3.Value = "Approved With Comments";
                        militaryGovRowCell3ListItem3.Text = "Approved With Comments";

                        militaryGovRowCell3ListItem4.Value = "Approved With Revisions";
                        militaryGovRowCell3ListItem4.Text = "Approved With Revisions";

                        militaryGovRowCell3ListItem5.Value = "Not Approved";
                        militaryGovRowCell3ListItem5.Text = "Not Approved";



                        DropDownList militaryGovRowCell3DropDownList = new DropDownList();
                        militaryGovRowCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                        militaryGovRowCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                        militaryGovRowCell3DropDownList.Items.Add(militaryGovRowCell3ListItem1);
                        militaryGovRowCell3DropDownList.Items.Add(militaryGovRowCell3ListItem2);
                        militaryGovRowCell3DropDownList.Items.Add(militaryGovRowCell3ListItem3);
                        militaryGovRowCell3DropDownList.Items.Add(militaryGovRowCell3ListItem4);
                        militaryGovRowCell3DropDownList.Items.Add(militaryGovRowCell3ListItem5);


                        TextBox militaryGovRowCell4TextBox = new TextBox();
                        militaryGovRowCell4TextBox.TextMode = TextBoxMode.MultiLine;
                        militaryGovRowCell4TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                        militaryGovRowCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                        militaryGovRowCell3DropDownList.SelectedValue = militaryGovRowCell3Text;
                        militaryGovRowCell4TextBox.Text = militaryGovRowCell4Text;

                        militaryGovRowCell3.Controls.Add(militaryGovRowCell3DropDownList);
                        militaryGovRowCell4.Controls.Add(militaryGovRowCell4TextBox);

                        militaryGovRowCell3.CssClass = "CONOPSApprovalCell";
                        militaryGovRowCell4.CssClass = "CONOPSApprovalCell";

                        //militaryGovRowCell3.Style.Add("background-color", "Cornsilk");
                        //militaryGovRowCell4.Style.Add("background-color", "Cornsilk");
                        //---------------

                        militaryGovRow.ID = id;



                    }
                    else if (title == "MilitarySubTotal")
                    {


                        try
                        {
                            MilitarySubTotal += oListItem["MilitarySubTotal"].ToString();
                            traceInfo = "MilitarySubTotal: " + MilitarySubTotal;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        militarySubTotalRowCell3.Text = "";

                        TextBox militarySubTotalRowCell3TextBox = new TextBox();
                        militarySubTotalRowCell3TextBox.Width = 80;
                        militarySubTotalRowCell3TextBox.Text = MilitarySubTotal;
                        militarySubTotalRowCell3TextBox.ID = "rowId" + id + "MilitarySubTotal";

                        militarySubTotalRowCell3.Controls.Add(militarySubTotalRowCell3TextBox);

                        //try
                        //{
                        //    traceInfo = "call to IsDiff: " + IsDiff("MilitarySubTotal", MilitarySubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    if (IsDiff("MilitarySubTotal", MilitarySubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                        //    {
                        //        militarySubTotalRowCell3.Style.Add("border-bottom", "solid"); militarySubTotalRowCell3.Style.Add("border-top", "solid"); militarySubTotalRowCell3.Style.Add("border-left", "solid"); militarySubTotalRowCell3.Style.Add("border-right", "solid"); militarySubTotalRowCell3.Style.Add("border-color", "#ffdf73"); militarySubTotalRowCell3.ToolTip = "See AO Review";
                        //    }
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        //}


                        //Approval

                        string militarySubTotalRowCell4Text = "";
                        string militarySubTotalRowCell5Text = "";
                        try
                        {
                            militarySubTotalRowCell4Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                            militarySubTotalRowCell5Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        ListItem militarySubTotalRowCell4ListItem1 = new ListItem();
                        ListItem militarySubTotalRowCell4ListItem2 = new ListItem();
                        ListItem militarySubTotalRowCell4ListItem3 = new ListItem();
                        ListItem militarySubTotalRowCell4ListItem4 = new ListItem();
                        ListItem militarySubTotalRowCell4ListItem5 = new ListItem();

                        militarySubTotalRowCell4ListItem1.Value = "Pending";
                        militarySubTotalRowCell4ListItem1.Text = "Pending";
                        militarySubTotalRowCell4ListItem1.Selected = true;

                        militarySubTotalRowCell4ListItem2.Value = "Approved";
                        militarySubTotalRowCell4ListItem2.Text = "Approved";

                        militarySubTotalRowCell4ListItem3.Value = "Approved With Comments";
                        militarySubTotalRowCell4ListItem3.Text = "Approved With Comments";

                        militarySubTotalRowCell4ListItem4.Value = "Approved With Revisions";
                        militarySubTotalRowCell4ListItem4.Text = "Approved With Revisions";

                        militarySubTotalRowCell4ListItem5.Value = "Not Approved";
                        militarySubTotalRowCell4ListItem5.Text = "Not Approved";



                        DropDownList militarySubTotalRowCell4DropDownList = new DropDownList();
                        militarySubTotalRowCell4DropDownList.CssClass = "CONOPSApprovalSelect";
                        militarySubTotalRowCell4DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                        militarySubTotalRowCell4DropDownList.Items.Add(militarySubTotalRowCell4ListItem1);
                        militarySubTotalRowCell4DropDownList.Items.Add(militarySubTotalRowCell4ListItem2);
                        militarySubTotalRowCell4DropDownList.Items.Add(militarySubTotalRowCell4ListItem3);
                        militarySubTotalRowCell4DropDownList.Items.Add(militarySubTotalRowCell4ListItem4);
                        militarySubTotalRowCell4DropDownList.Items.Add(militarySubTotalRowCell4ListItem5);


                        TextBox militarySubTotalRowCell5TextBox = new TextBox();
                        militarySubTotalRowCell5TextBox.TextMode = TextBoxMode.MultiLine;
                        militarySubTotalRowCell5TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                        militarySubTotalRowCell4DropDownList.SelectedValue = militarySubTotalRowCell4Text;
                        militarySubTotalRowCell5TextBox.Text = militarySubTotalRowCell5Text;

                        militarySubTotalRowCell4.Controls.Add(militarySubTotalRowCell4DropDownList);
                        militarySubTotalRowCell5.Controls.Add(militarySubTotalRowCell5TextBox);

                        militarySubTotalRowCell4.CssClass = "CONOPSApprovalCell";
                        militarySubTotalRowCell5.CssClass = "CONOPSApprovalCell";

                        //militarySubTotalRowCell4.Style.Add("background-color", "Cornsilk");
                        //militarySubTotalRowCell5.Style.Add("background-color", "Cornsilk");

                        //---------------


                        militarySubTotalRow.ID = id;



                    }




                }
                
                foreach (SPListItem oListItem in collListItemsMilGov)
                {
                    string title = oListItem.Title.ToString();
                    string id = oListItem.ID.ToString();
                    string employer = "";
                    try
                    {
                        employer += oListItem["Employer"].ToString();
                        traceInfo = "employer: " + employer;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    if (employer == "MilitaryOrGovernmentCivilian")
                    {
                        try
                        {



                            TableRow militaryValsRw = new TableRow();

                            TableCell militaryValsRwCell1 = new TableCell();
                            TableCell militaryValsRwCell2 = new TableCell();
                            TableCell militaryValsRwCell3 = new TableCell();
                            TableCell militaryValsRwCell4 = new TableCell();
                            TableCell militaryValsRwCell5 = new TableCell();
                            TableCell militaryValsRwCell6 = new TableCell();

                            TableCell militaryValsRwCell7 = new TableCell();
                            TableCell militaryValsRwCell8 = new TableCell();

                            militaryValsRwCell1.Style.Add("text-align", "center");
                            militaryValsRwCell2.Style.Add("text-align", "center");
                            militaryValsRwCell3.Style.Add("text-align", "center");
                            militaryValsRwCell4.Style.Add("text-align", "center");
                            militaryValsRwCell5.Style.Add("text-align", "right");
                            militaryValsRwCell6.Style.Add("text-align", "center");

                            string militaryValsRwCell1Text = title;

                            string militaryValsRwCell2Text = "";
                            string militaryValsRwCell3Text = "";
                            string militaryValsRwCell4Text = "";
                            string militaryValsRwCell5Text = "";
                            string militaryValsRwCell6Text = "";

                            try { militaryValsRwCell2Text = oListItem["DutyTitlePosition"].ToString(); }
                            catch { }
                            try { militaryValsRwCell3Text = oListItem["Status"].ToString(); }
                            catch { }
                            try { if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { militaryValsRwCell4Text = oListItem["Remarks"].ToString(); } }
                            catch { }
                            try { militaryValsRwCell5Text = oListItem["GSLevel"].ToString(); }
                            catch { }
                            try { militaryValsRwCell6Text = oListItem["Funding"].ToString(); }
                            catch { }







                            TextBox militaryValsRwCell1TextBox = new TextBox();
                            TextBox militaryValsRwCell2TextBox = new TextBox();
                            TextBox militaryValsRwCell3TextBox = new TextBox();
                            TextBox militaryValsRwCell4TextBox = new TextBox();
                            TextBox militaryValsRwCell5TextBox = new TextBox();
                            TextBox militaryValsRwCell6TextBox = new TextBox();




                            militaryValsRwCell1TextBox.Width = 80;
                            militaryValsRwCell2TextBox.Width = 80;
                            militaryValsRwCell3TextBox.Width = 80;
                            militaryValsRwCell4TextBox.Width = 80;
                            militaryValsRwCell5TextBox.Width = 80;
                            militaryValsRwCell6TextBox.Width = 80;




                            militaryValsRwCell1TextBox.Text = militaryValsRwCell1Text;
                            militaryValsRwCell2TextBox.Text = militaryValsRwCell2Text;
                            militaryValsRwCell3TextBox.Text = militaryValsRwCell3Text;
                            militaryValsRwCell4TextBox.Text = militaryValsRwCell4Text;
                            militaryValsRwCell5TextBox.Text = militaryValsRwCell5Text;
                            militaryValsRwCell6TextBox.Text = militaryValsRwCell6Text;

                            militaryValsRwCell1TextBox.ID = "rowId" + id + "Title";
                            militaryValsRwCell2TextBox.ID = "rowId" + id + "DutyTitlePosition";
                            militaryValsRwCell3TextBox.ID = "rowId" + id + "Status";
                            militaryValsRwCell4TextBox.ID = "rowId" + id + "Remarks";
                            militaryValsRwCell5TextBox.ID = "rowId" + id + "GSLevel";
                            militaryValsRwCell6TextBox.ID = "rowId" + id + "Funding";

                            militaryValsRwCell1.Controls.Add(militaryValsRwCell1TextBox);
                            militaryValsRwCell2.Controls.Add(militaryValsRwCell2TextBox);
                            militaryValsRwCell3.Controls.Add(militaryValsRwCell3TextBox);
                            militaryValsRwCell4.Controls.Add(militaryValsRwCell4TextBox);
                            militaryValsRwCell5.Controls.Add(militaryValsRwCell5TextBox);
                            militaryValsRwCell6.Controls.Add(militaryValsRwCell6TextBox);



                            militaryValsRw.Cells.Add(militaryValsRwCell1);
                            militaryValsRw.Cells.Add(militaryValsRwCell2);
                            militaryValsRw.Cells.Add(militaryValsRwCell3);
                            militaryValsRw.Cells.Add(militaryValsRwCell4);
                            militaryValsRw.Cells.Add(militaryValsRwCell5);
                            militaryValsRw.Cells.Add(militaryValsRwCell6);
                            militaryValsRw.ID = id;

                          
                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Title", title, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Title", title, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell1.Style.Add("border-bottom", "solid"); militaryValsRwCell1.Style.Add("border-top", "solid"); militaryValsRwCell1.Style.Add("border-left", "solid"); militaryValsRwCell1.Style.Add("border-right", "solid"); militaryValsRwCell1.Style.Add("border-color", "#ffdf73"); militaryValsRwCell1.ToolTip = "See AO Review";
                                }
                                if (IsDiff("DutyTitlePosition", militaryValsRwCell2Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell2.Style.Add("border-bottom", "solid"); militaryValsRwCell2.Style.Add("border-top", "solid"); militaryValsRwCell2.Style.Add("border-left", "solid"); militaryValsRwCell2.Style.Add("border-right", "solid"); militaryValsRwCell2.Style.Add("border-color", "#ffdf73"); militaryValsRwCell2.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Status", militaryValsRwCell3Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell3.Style.Add("border-bottom", "solid"); militaryValsRwCell3.Style.Add("border-top", "solid"); militaryValsRwCell3.Style.Add("border-left", "solid"); militaryValsRwCell3.Style.Add("border-right", "solid"); militaryValsRwCell3.Style.Add("border-color", "#ffdf73"); militaryValsRwCell3.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Remarks", militaryValsRwCell4Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell4.Style.Add("border-bottom", "solid"); militaryValsRwCell4.Style.Add("border-top", "solid"); militaryValsRwCell4.Style.Add("border-left", "solid"); militaryValsRwCell4.Style.Add("border-right", "solid"); militaryValsRwCell4.Style.Add("border-color", "#ffdf73"); militaryValsRwCell4.ToolTip = "See AO Review";
                                }
                                if (IsDiff("GSLevel", militaryValsRwCell5Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell5.Style.Add("border-bottom", "solid"); militaryValsRwCell5.Style.Add("border-top", "solid"); militaryValsRwCell5.Style.Add("border-left", "solid"); militaryValsRwCell5.Style.Add("border-right", "solid"); militaryValsRwCell5.Style.Add("border-color", "#ffdf73"); militaryValsRwCell5.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Funding", militaryValsRwCell6Text, oList, qs_fy, qs_ws, srcID))
                                {
                                    militaryValsRwCell6.Style.Add("border-bottom", "solid"); militaryValsRwCell6.Style.Add("border-top", "solid"); militaryValsRwCell6.Style.Add("border-left", "solid"); militaryValsRwCell6.Style.Add("border-right", "solid"); militaryValsRwCell6.Style.Add("border-color", "#ffdf73"); militaryValsRwCell6.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string militaryValsRwCell7Text = "";
                            string militaryValsRwCell8Text = "";
                            try
                            {
                                militaryValsRwCell7Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                militaryValsRwCell8Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem militaryValsRwCell7ListItem1 = new ListItem();
                            ListItem militaryValsRwCell7ListItem2 = new ListItem();
                            ListItem militaryValsRwCell7ListItem3 = new ListItem();
                            ListItem militaryValsRwCell7ListItem4 = new ListItem();
                            ListItem militaryValsRwCell7ListItem5 = new ListItem();

                            militaryValsRwCell7ListItem1.Value = "Pending";
                            militaryValsRwCell7ListItem1.Text = "Pending";
                            militaryValsRwCell7ListItem1.Selected = true;

                            militaryValsRwCell7ListItem2.Value = "Approved";
                            militaryValsRwCell7ListItem2.Text = "Approved";

                            militaryValsRwCell7ListItem3.Value = "Approved With Comments";
                            militaryValsRwCell7ListItem3.Text = "Approved With Comments";

                            militaryValsRwCell7ListItem4.Value = "Approved With Revisions";
                            militaryValsRwCell7ListItem4.Text = "Approved With Revisions";

                            militaryValsRwCell7ListItem5.Value = "Not Approved";
                            militaryValsRwCell7ListItem5.Text = "Not Approved";



                            DropDownList militaryValsRwCell7DropDownList = new DropDownList();
                            militaryValsRwCell7DropDownList.CssClass = "CONOPSApprovalSelect";
                            militaryValsRwCell7DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            militaryValsRwCell7DropDownList.Items.Add(militaryValsRwCell7ListItem1);
                            militaryValsRwCell7DropDownList.Items.Add(militaryValsRwCell7ListItem2);
                            militaryValsRwCell7DropDownList.Items.Add(militaryValsRwCell7ListItem3);
                            militaryValsRwCell7DropDownList.Items.Add(militaryValsRwCell7ListItem4);
                            militaryValsRwCell7DropDownList.Items.Add(militaryValsRwCell7ListItem5);


                            TextBox militaryValsRwCell8TextBox = new TextBox();
                            militaryValsRwCell8TextBox.TextMode = TextBoxMode.MultiLine;
                            militaryValsRwCell8TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            militaryValsRwCell8TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            militaryValsRwCell7DropDownList.SelectedValue = militaryValsRwCell7Text;
                            militaryValsRwCell8TextBox.Text = militaryValsRwCell8Text;

                            militaryValsRwCell7.Controls.Add(militaryValsRwCell7DropDownList);
                            militaryValsRwCell8.Controls.Add(militaryValsRwCell8TextBox);

                            militaryValsRwCell7.CssClass = "CONOPSApprovalCell";
                            militaryValsRwCell8.CssClass = "CONOPSApprovalCell";

                            //militaryValsRwCell7.Style.Add("background-color", "Cornsilk");
                            //militaryValsRwCell8.Style.Add("background-color", "Cornsilk");


                            //---------------

                            militaryValsRw.Cells.Add(militaryValsRwCell7);
                            militaryValsRw.Cells.Add(militaryValsRwCell8);
                            militaryValsRw.ID = id;

                            traceInfo = "Rows.AddAt militaryIndex: " + militaryIndex;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            CONOPSDevWSTable.Rows.AddAt(militaryIndex, militaryValsRw);
                            contractIndex = contractIndex + 1;
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("milgovRwCellsVals", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }

                    CONOPSDevWSTable.Controls.Remove(militaryValsRow);

                }

                string contractCheck = "";
                bool contractItemBlankRowAdded = false;




                List<string> listOfContracts = new List<string>();



                //Build Contract section minus Contractors (will be added at index later)
                foreach (SPListItem oListItem in collListItems)
                {
                    string title = "" + oListItem.Title.ToString();
                    traceInfo = "title: " + title;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    string id = oListItem.ID.ToString();

                    string employer = "";
                    string Contract = "";
                    string ContractsSubTotal = "";
                    string FY = "";
                    string ContractTotal = "";
                    string ContractFee = "";
                    string HoursPerYear = "";
                    string AdditionalLineItem = "";
                    string Funding = "";
                    string DutyTitlePosition = "";
                    string Status = "";
                    string Remarks = "";
                    string ContractorRate = "";

                    try
                    {
                        employer += oListItem["Employer"].ToString();
                        traceInfo = "employer: " + employer;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                    try
                    {
                        Contract += oListItem["Contract"].ToString();
                        traceInfo = "Contract: " + Contract;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (contractCheck != "")
                        {
                            if (contractCheck != Contract)
                            {
                                contractItemBlankRowAdded = false;
                            }

                        }


                        contractCheck = Contract;



                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                    if (Contract != "")
                    {



                        TableRow rw = new TableRow();

                        rw.ID = Contract;


                        //=============== Conditions =================

                        if (title == "ContractsSubTotal")
                        {
                            try
                            {
                                ContractsSubTotal += oListItem["ContractsSubTotal"].ToString();
                                traceInfo = "ContractsSubTotal: " + ContractsSubTotal;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            rw.ID = "ContractsSubTotal";

                            TableCell contractorsSubTotalRwCell1 = new TableCell();
                            TableCell contractorsSubTotalRwCell2 = new TableCell();
                            TableCell contractorsSubTotalRwCell3 = new TableCell();

                            TableCell contractorsSubTotalRwCell4 = new TableCell();
                            TableCell contractorsSubTotalRwCell5 = new TableCell();

                            contractorsSubTotalRwCell1.ColumnSpan = 4;
                            contractorsSubTotalRwCell1.Style.Add("background-color", "#bfbfbf");

                            //----------------------AddContractorBtn------------
                            Button AddContractorBtn2 = new Button();
                            AddContractorBtn2.Text = "Add Contractor";
                            AddContractorBtn2.CssClass = "CONOPSApprovalAddContractorButton";
                            AddContractorBtn2.OnClientClick = "return false";
                            AddContractorBtn2.UseSubmitBehavior = false;
                            AddContractorBtn2.ToolTip = oListItem["Contract"].ToString();
                            HiddenField ContractName2 = new HiddenField();
                            ContractName2.ID = "ContractName";
                            ContractName2.Value = oListItem["Contract"].ToString();
                            contractorsSubTotalRwCell1.Controls.Add(ContractName2);
                            contractorsSubTotalRwCell1.Controls.Add(AddContractorBtn2);
                            //-----------------------------------------------------

                            //----------------------AddLineItemBtn------------
                            Button AddLineItemBtn2 = new Button();
                            AddLineItemBtn2.Text = "Add Line Item";
                            AddLineItemBtn2.ToolTip = oListItem["Contract"].ToString();
                            AddLineItemBtn2.CssClass = "CONOPSApprovalAddLineItemButton";
                            AddLineItemBtn2.OnClientClick = "return false";
                            AddLineItemBtn2.UseSubmitBehavior = false;
                            contractorsSubTotalRwCell1.Controls.Add(AddLineItemBtn2);
                            //-----------------------------------------------------

                            contractorsSubTotalRwCell2.Style.Add("text-align", "right");
                            contractorsSubTotalRwCell2.Style.Add("font-weight", "bold");
                            contractorsSubTotalRwCell2.Style.Add("background-color", "#d0ffbc");
                            contractorsSubTotalRwCell2.Text = "Sub-Total:​";

                            contractorsSubTotalRwCell3.Style.Add("text-align", "center");
                            contractorsSubTotalRwCell3.Style.Add("background-color", "#d0ffbc");

                            TextBox contractorsSubTotalRwCell3TextBox = new TextBox();
                            contractorsSubTotalRwCell3TextBox.Width = 80;
                            contractorsSubTotalRwCell3TextBox.Text = ContractsSubTotal;
                            contractorsSubTotalRwCell3TextBox.ID = "rowId" + id + "ContractsSubTotal";

                            contractorsSubTotalRwCell3.Controls.Add(contractorsSubTotalRwCell3TextBox);

                            rw.Cells.Add(contractorsSubTotalRwCell1);
                            rw.Cells.Add(contractorsSubTotalRwCell2);
                            rw.Cells.Add(contractorsSubTotalRwCell3);


                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("ContractsSubTotal", ContractsSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("ContractsSubTotal", ContractsSubTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        contractorsSubTotalRwCell3.Style.Add("border-bottom", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-top", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-left", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-right", "solid");
                            //        contractorsSubTotalRwCell3.Style.Add("border-color", "#ffdf73");
                            //        contractorsSubTotalRwCell3.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}



                            //Approval

                            string contractorsSubTotalRwCell4Text = "";
                            string contractorsSubTotalRwCell5Text = "";
                            try
                            {
                                contractorsSubTotalRwCell4Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorsSubTotalRwCell5Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem contractorsSubTotalRwCell4ListItem1 = new ListItem();
                            ListItem contractorsSubTotalRwCell4ListItem2 = new ListItem();
                            ListItem contractorsSubTotalRwCell4ListItem3 = new ListItem();
                            ListItem contractorsSubTotalRwCell4ListItem4 = new ListItem();
                            ListItem contractorsSubTotalRwCell4ListItem5 = new ListItem();

                            contractorsSubTotalRwCell4ListItem1.Value = "Pending";
                            contractorsSubTotalRwCell4ListItem1.Text = "Pending";
                            contractorsSubTotalRwCell4ListItem1.Selected = true;

                            contractorsSubTotalRwCell4ListItem2.Value = "Approved";
                            contractorsSubTotalRwCell4ListItem2.Text = "Approved";

                            contractorsSubTotalRwCell4ListItem3.Value = "Approved With Comments";
                            contractorsSubTotalRwCell4ListItem3.Text = "Approved With Comments";

                            contractorsSubTotalRwCell4ListItem4.Value = "Approved With Revisions";
                            contractorsSubTotalRwCell4ListItem4.Text = "Approved With Revisions";

                            contractorsSubTotalRwCell4ListItem5.Value = "Not Approved";
                            contractorsSubTotalRwCell4ListItem5.Text = "Not Approved";



                            DropDownList contractorsSubTotalRwCell4DropDownList = new DropDownList();
                            contractorsSubTotalRwCell4DropDownList.CssClass = "CONOPSApprovalSelect";
                            contractorsSubTotalRwCell4DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            contractorsSubTotalRwCell4DropDownList.Items.Add(contractorsSubTotalRwCell4ListItem1);
                            contractorsSubTotalRwCell4DropDownList.Items.Add(contractorsSubTotalRwCell4ListItem2);
                            contractorsSubTotalRwCell4DropDownList.Items.Add(contractorsSubTotalRwCell4ListItem3);
                            contractorsSubTotalRwCell4DropDownList.Items.Add(contractorsSubTotalRwCell4ListItem4);
                            contractorsSubTotalRwCell4DropDownList.Items.Add(contractorsSubTotalRwCell4ListItem5);


                            TextBox contractorsSubTotalRwCell5TextBox = new TextBox();
                            contractorsSubTotalRwCell5TextBox.TextMode = TextBoxMode.MultiLine;
                            contractorsSubTotalRwCell5TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            contractorsSubTotalRwCell5TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            contractorsSubTotalRwCell4DropDownList.SelectedValue = contractorsSubTotalRwCell4Text;
                            contractorsSubTotalRwCell5TextBox.Text = contractorsSubTotalRwCell5Text;

                            contractorsSubTotalRwCell4.Controls.Add(contractorsSubTotalRwCell4DropDownList);
                            contractorsSubTotalRwCell5.Controls.Add(contractorsSubTotalRwCell5TextBox);

                            contractorsSubTotalRwCell4.CssClass = "CONOPSApprovalCell";
                            contractorsSubTotalRwCell5.CssClass = "CONOPSApprovalCell";

                            //contractorsSubTotalRwCell4.Style.Add("background-color", "Cornsilk");
                            //contractorsSubTotalRwCell5.Style.Add("background-color", "Cornsilk");

                            //---------------

                            rw.Cells.Add(contractorsSubTotalRwCell4);
                            rw.Cells.Add(contractorsSubTotalRwCell5);
                            rw.ID = id;
                        }


                        //CONDITIONS 

                        if (title == "ContractTotal")
                        {
                            try
                            {
                                FY += oListItem["FY"].ToString();
                                traceInfo = "ContractFY: " + FY;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                ContractTotal += oListItem["ContractTotal"].ToString();
                                traceInfo = "ContractFYTotal: " + ContractTotal;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            TableCell contractorFYTotalRwCell1 = new TableCell();
                            TableCell contractorFYTotalRwCell2 = new TableCell();

                            TableCell contractorFYTotalRwCell3 = new TableCell();
                            TableCell contractorFYTotalRwCell4 = new TableCell();


                            contractorFYTotalRwCell1.ColumnSpan = 5;
                            contractorFYTotalRwCell1.Style.Add("text-align", "right");
                            contractorFYTotalRwCell2.Style.Add("text-align", "center");

                            Label LabelcontractorFYTotalVals1b = new Label();
                            LabelcontractorFYTotalVals1b.Text = "Total for FY ";

                            Label LabelcontractorFYTotalVals2b = new Label();
                            LabelcontractorFYTotalVals2b.Text = FY;

                            contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals1b);
                            contractorFYTotalRwCell1.Controls.Add(LabelcontractorFYTotalVals2b);

                            TextBox contractorFYTotalRwCell2TextBox = new TextBox();
                            contractorFYTotalRwCell2TextBox.Width = 80;
                            contractorFYTotalRwCell2TextBox.Text = ContractTotal;
                            contractorFYTotalRwCell2TextBox.ID = "rowId" + id + "ContractTotal";

                            contractorFYTotalRwCell2.Controls.Add(contractorFYTotalRwCell2TextBox);

                            rw.Cells.Add(contractorFYTotalRwCell1);
                            rw.Cells.Add(contractorFYTotalRwCell2);

                            //try
                            //{
                            //    traceInfo = "call to IsDiff: " + IsDiff("ContractTotal", ContractTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    if (IsDiff("ContractTotal", ContractTotal, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString()))
                            //    {
                            //        contractorFYTotalRwCell2.Style.Add("border-bottom", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-top", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-left", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-right", "solid");
                            //        contractorFYTotalRwCell2.Style.Add("border-color", "#ffdf73");
                            //        contractorFYTotalRwCell2.ToolTip = "See AO Review";
                            //    }
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}

                            //Approval

                            string contractorFYTotalRwCell3Text = "";
                            string contractorFYTotalRwCell4Text = "";
                            try
                            {
                                contractorFYTotalRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorFYTotalRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem contractorFYTotalRwCell3ListItem1 = new ListItem();
                            ListItem contractorFYTotalRwCell3ListItem2 = new ListItem();
                            ListItem contractorFYTotalRwCell3ListItem3 = new ListItem();
                            ListItem contractorFYTotalRwCell3ListItem4 = new ListItem();
                            ListItem contractorFYTotalRwCell3ListItem5 = new ListItem();

                            contractorFYTotalRwCell3ListItem1.Value = "Pending";
                            contractorFYTotalRwCell3ListItem1.Text = "Pending";
                            contractorFYTotalRwCell3ListItem1.Selected = true;

                            contractorFYTotalRwCell3ListItem2.Value = "Approved";
                            contractorFYTotalRwCell3ListItem2.Text = "Approved";

                            contractorFYTotalRwCell3ListItem3.Value = "Approved With Comments";
                            contractorFYTotalRwCell3ListItem3.Text = "Approved With Comments";

                            contractorFYTotalRwCell3ListItem4.Value = "Approved With Revisions";
                            contractorFYTotalRwCell3ListItem4.Text = "Approved With Revisions";

                            contractorFYTotalRwCell3ListItem5.Value = "Not Approved";
                            contractorFYTotalRwCell3ListItem5.Text = "Not Approved";



                            DropDownList contractorFYTotalRwCell3DropDownList = new DropDownList();
                            contractorFYTotalRwCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                            contractorFYTotalRwCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            contractorFYTotalRwCell3DropDownList.Items.Add(contractorFYTotalRwCell3ListItem1);
                            contractorFYTotalRwCell3DropDownList.Items.Add(contractorFYTotalRwCell3ListItem2);
                            contractorFYTotalRwCell3DropDownList.Items.Add(contractorFYTotalRwCell3ListItem3);
                            contractorFYTotalRwCell3DropDownList.Items.Add(contractorFYTotalRwCell3ListItem4);
                            contractorFYTotalRwCell3DropDownList.Items.Add(contractorFYTotalRwCell3ListItem5);


                            TextBox contractorFYTotalRwCell4TextBox = new TextBox();
                            contractorFYTotalRwCell4TextBox.TextMode = TextBoxMode.MultiLine;
                            contractorFYTotalRwCell4TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            contractorFYTotalRwCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            contractorFYTotalRwCell3DropDownList.SelectedValue = contractorFYTotalRwCell3Text;
                            contractorFYTotalRwCell4TextBox.Text = contractorFYTotalRwCell4Text;

                            contractorFYTotalRwCell3.Controls.Add(contractorFYTotalRwCell3DropDownList);
                            contractorFYTotalRwCell4.Controls.Add(contractorFYTotalRwCell4TextBox);

                            contractorFYTotalRwCell3.CssClass = "CONOPSApprovalCell";
                            contractorFYTotalRwCell4.CssClass = "CONOPSApprovalCell";

                            //contractorFYTotalRwCell3.Style.Add("background-color", "Cornsilk");
                            //contractorFYTotalRwCell4.Style.Add("background-color", "Cornsilk");


                            //---------------
                            rw.Cells.Add(contractorFYTotalRwCell3);
                            rw.Cells.Add(contractorFYTotalRwCell4);
                        }

                        if (title == "ContractFee")
                        {
                            try
                            {
                                ContractFee += oListItem["ContractFee"].ToString();
                                traceInfo = "ContractFee: " + ContractFee;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            TableCell contractFeeRwCell1 = new TableCell();
                            TableCell contractFeeRwCell2 = new TableCell();

                            TableCell contractFeeRwCell3 = new TableCell();
                            TableCell contractFeeRwCell4 = new TableCell();

                            contractFeeRwCell1.ColumnSpan = 5;
                            contractFeeRwCell1.Style.Add("text-align", "right");
                            contractFeeRwCell2.Style.Add("text-align", "center");

                            contractFeeRwCell1.Text = "Contract fee";

                            TextBox contractFeeRwCell2TextBox = new TextBox();
                            contractFeeRwCell2TextBox.Width = 80;
                            contractFeeRwCell2TextBox.Text = ContractFee;
                            contractFeeRwCell2TextBox.ID = "rowId" + id + "ContractFee";

                            contractFeeRwCell2.Controls.Add(contractFeeRwCell2TextBox);

                            rw.Cells.Add(contractFeeRwCell1);
                            rw.Cells.Add(contractFeeRwCell2);

                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("ContractFee", ContractFee, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("ContractFee", ContractFee, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractFeeRwCell2.Style.Add("border-bottom", "solid");
                                    contractFeeRwCell2.Style.Add("border-top", "solid");
                                    contractFeeRwCell2.Style.Add("border-left", "solid");
                                    contractFeeRwCell2.Style.Add("border-right", "solid");
                                    contractFeeRwCell2.Style.Add("border-color", "#ffdf73");
                                    contractFeeRwCell2.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string contractFeeRwCell3Text = "";
                            string contractFeeRwCell4Text = "";
                            try
                            {
                                contractFeeRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractFeeRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem contractFeeRwCell3ListItem1 = new ListItem();
                            ListItem contractFeeRwCell3ListItem2 = new ListItem();
                            ListItem contractFeeRwCell3ListItem3 = new ListItem();
                            ListItem contractFeeRwCell3ListItem4 = new ListItem();
                            ListItem contractFeeRwCell3ListItem5 = new ListItem();

                            contractFeeRwCell3ListItem1.Value = "Pending";
                            contractFeeRwCell3ListItem1.Text = "Pending";
                            contractFeeRwCell3ListItem1.Selected = true;

                            contractFeeRwCell3ListItem2.Value = "Approved";
                            contractFeeRwCell3ListItem2.Text = "Approved";

                            contractFeeRwCell3ListItem3.Value = "Approved With Comments";
                            contractFeeRwCell3ListItem3.Text = "Approved With Comments";

                            contractFeeRwCell3ListItem4.Value = "Approved With Revisions";
                            contractFeeRwCell3ListItem4.Text = "Approved With Revisions";

                            contractFeeRwCell3ListItem5.Value = "Not Approved";
                            contractFeeRwCell3ListItem5.Text = "Not Approved";



                            DropDownList contractFeeRwCell3DropDownList = new DropDownList();
                            contractFeeRwCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                            contractFeeRwCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            contractFeeRwCell3DropDownList.Items.Add(contractFeeRwCell3ListItem1);
                            contractFeeRwCell3DropDownList.Items.Add(contractFeeRwCell3ListItem2);
                            contractFeeRwCell3DropDownList.Items.Add(contractFeeRwCell3ListItem3);
                            contractFeeRwCell3DropDownList.Items.Add(contractFeeRwCell3ListItem4);
                            contractFeeRwCell3DropDownList.Items.Add(contractFeeRwCell3ListItem5);


                            TextBox contractFeeRwCell4TextBox = new TextBox();
                            contractFeeRwCell4TextBox.TextMode = TextBoxMode.MultiLine;
                            contractFeeRwCell4TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            contractFeeRwCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            contractFeeRwCell3DropDownList.SelectedValue = contractFeeRwCell3Text;
                            contractFeeRwCell4TextBox.Text = contractFeeRwCell4Text;

                            contractFeeRwCell3.Controls.Add(contractFeeRwCell3DropDownList);
                            contractFeeRwCell4.Controls.Add(contractFeeRwCell4TextBox);

                            contractFeeRwCell3.CssClass = "CONOPSApprovalCell";
                            contractFeeRwCell4.CssClass = "CONOPSApprovalCell";

                            //contractFeeRwCell3.Style.Add("background-color", "Cornsilk");
                            //contractFeeRwCell4.Style.Add("background-color", "Cornsilk");

                            //---------------

                            rw.Cells.Add(contractFeeRwCell3);
                            rw.Cells.Add(contractFeeRwCell4);
                            rw.ID = id;
                        }
                        if (title == "HoursPerYear")
                        {
                            try
                            {
                                HoursPerYear += oListItem["HoursPerYear"].ToString();
                                traceInfo = "HoursPerYear: " + HoursPerYear;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            TableRow hoursBlankRw = new TableRow();

                            TableCell hoursBlankRwCell1 = new TableCell();
                            TableCell hoursBlankRwCell2 = new TableCell();

                            TableCell hoursBlankRwCell3 = new TableCell();
                            TableCell hoursBlankRwCell4 = new TableCell();

                            hoursBlankRwCell1.ColumnSpan = 5;

                            Literal LiteralhoursBlankRowb = new Literal();
                            LiteralhoursBlankRowb.Text = "&nbsp;";

                            hoursBlankRwCell1.Controls.Add(LiteralhoursBlankRowb);

                            hoursBlankRw.Cells.Add(hoursBlankRwCell1);
                            hoursBlankRw.Cells.Add(hoursBlankRwCell2);

                            hoursBlankRw.Cells.Add(hoursBlankRwCell3);
                            hoursBlankRw.Cells.Add(hoursBlankRwCell4);

                            hoursBlankRw.ToolTip = Contract;
                            hoursBlankRw.ID = "BlankHoursRow";

                            CONOPSDevWSTable.Rows.AddAt(contractIndex, hoursBlankRw);


                            TableCell hoursRwCell1 = new TableCell();
                            TableCell hoursRwCell2 = new TableCell();

                            TableCell hoursRwCell3 = new TableCell();
                            TableCell hoursRwCell4 = new TableCell();

                            hoursRwCell3.CssClass = "CONOPSApprovalCell";
                            hoursRwCell4.CssClass = "CONOPSApprovalCell";

                            //hoursRwCell3.Style.Add("background-color", "Cornsilk");
                            //hoursRwCell4.Style.Add("background-color", "Cornsilk");


                            hoursRwCell1.ColumnSpan = 5;
                            hoursRwCell1.Style.Add("text-align", "right");
                            hoursRwCell2.Style.Add("text-align", "center");

                            Label LabelhoursRow1b = new Label();
                            LabelhoursRow1b.Text = "Hours per year  ";

                            TextBox LabelhoursRow2bTextBox = new TextBox();
                            LabelhoursRow2bTextBox.Width = 80;
                            LabelhoursRow2bTextBox.Text = HoursPerYear;
                            LabelhoursRow2bTextBox.ID = "rowId" + id + "HoursPerYear";
                            LabelhoursRow2bTextBox.ToolTip = Contract;

                            hoursRwCell1.Controls.Add(LabelhoursRow1b);
                            hoursRwCell1.Controls.Add(LabelhoursRow2bTextBox);

                            rw.Cells.Add(hoursRwCell1);
                            rw.Cells.Add(hoursRwCell2);

                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("HoursPerYear", HoursPerYear, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("HoursPerYear", HoursPerYear, oList, qs_fy, qs_ws, srcID))
                                {
                                    hoursRwCell1.Style.Add("border-bottom", "solid");
                                    hoursRwCell1.Style.Add("border-top", "solid");
                                    hoursRwCell1.Style.Add("border-left", "solid");
                                    hoursRwCell1.Style.Add("border-right", "solid");
                                    hoursRwCell1.Style.Add("border-color", "#ffdf73");
                                    hoursRwCell1.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string hoursRwCell3Text = "";
                            string hoursRwCell4Text = "";
                            try
                            {
                                hoursRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                hoursRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem hoursRwCell3ListItem1 = new ListItem();
                            ListItem hoursRwCell3ListItem2 = new ListItem();
                            ListItem hoursRwCell3ListItem3 = new ListItem();
                            ListItem hoursRwCell3ListItem4 = new ListItem();
                            ListItem hoursRwCell3ListItem5 = new ListItem();

                            hoursRwCell3ListItem1.Value = "Pending";
                            hoursRwCell3ListItem1.Text = "Pending";
                            hoursRwCell3ListItem1.Selected = true;

                            hoursRwCell3ListItem2.Value = "Approved";
                            hoursRwCell3ListItem2.Text = "Approved";

                            hoursRwCell3ListItem3.Value = "Approved With Comments";
                            hoursRwCell3ListItem3.Text = "Approved With Comments";

                            hoursRwCell3ListItem4.Value = "Approved With Revisions";
                            hoursRwCell3ListItem4.Text = "Approved With Revisions";

                            hoursRwCell3ListItem5.Value = "Not Approved";
                            hoursRwCell3ListItem5.Text = "Not Approved";



                            DropDownList hoursRwCell3DropDownList = new DropDownList();
                            hoursRwCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                            hoursRwCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            hoursRwCell3DropDownList.Items.Add(hoursRwCell3ListItem1);
                            hoursRwCell3DropDownList.Items.Add(hoursRwCell3ListItem2);
                            hoursRwCell3DropDownList.Items.Add(hoursRwCell3ListItem3);
                            hoursRwCell3DropDownList.Items.Add(hoursRwCell3ListItem4);
                            hoursRwCell3DropDownList.Items.Add(hoursRwCell3ListItem5);


                            TextBox hoursRwCell4TextBox = new TextBox();
                            hoursRwCell4TextBox.TextMode = TextBoxMode.MultiLine;
                            hoursRwCell4TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            hoursRwCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            hoursRwCell3DropDownList.SelectedValue = hoursRwCell3Text;
                            hoursRwCell4TextBox.Text = hoursRwCell4Text;

                            hoursRwCell3.CssClass = "CONOPSApprovalCell";
                            hoursRwCell4.CssClass = "CONOPSApprovalCell";

                            //hoursRwCell3.Style.Add("background-color", "Cornsilk");
                            //hoursRwCell4.Style.Add("background-color", "Cornsilk");

                            hoursRwCell3.Controls.Add(hoursRwCell3DropDownList);
                            hoursRwCell4.Controls.Add(hoursRwCell4TextBox);




                            //---------------

                            rw.Cells.Add(hoursRwCell3);
                            rw.Cells.Add(hoursRwCell4);
                            rw.ID = id;
                        }


                        try
                        {
                            AdditionalLineItem += oListItem["AdditionalLineItem"].ToString();
                            traceInfo = "AdditionalLineItem: " + AdditionalLineItem;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                        if (AdditionalLineItem != "")
                        {


                            TableCell additionalItemRwCell1 = new TableCell();
                            TableCell additionalItemRwCell2 = new TableCell();

                            TableCell additionalItemRwCell3 = new TableCell();
                            TableCell additionalItemRwCell4 = new TableCell();

                            additionalItemRwCell1.ColumnSpan = 5;
                            additionalItemRwCell1.Style.Add("text-align", "right");
                            additionalItemRwCell2.Style.Add("text-align", "center");

                            Label LabeladditionalItemDesc1b = new Label();
                            LabeladditionalItemDesc1b.Text = "Additional line item (title and amount) ";

                            TextBox LabeladditionalItemDesc2bTextBox = new TextBox();
                            LabeladditionalItemDesc2bTextBox.Width = 80;
                            LabeladditionalItemDesc2bTextBox.Text = title;
                            LabeladditionalItemDesc2bTextBox.Font.Italic = false;
                            LabeladditionalItemDesc2bTextBox.ID = "rowId" + id + "Title";

                            additionalItemRwCell1.Controls.Add(LabeladditionalItemDesc1b);
                            additionalItemRwCell1.Controls.Add(LabeladditionalItemDesc2bTextBox);

                            TextBox additionalItemRwCell2TextBox = new TextBox();
                            additionalItemRwCell2TextBox.Width = 80;
                            additionalItemRwCell2TextBox.Text = AdditionalLineItem;
                            additionalItemRwCell2TextBox.ID = "rowId" + id + "AdditionalLineItem";

                            additionalItemRwCell2.Controls.Add(additionalItemRwCell2TextBox);

                            rw.Cells.Add(additionalItemRwCell1);
                            rw.Cells.Add(additionalItemRwCell2);

                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("AdditionalLineItem", AdditionalLineItem, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Title", title, oList, qs_fy, qs_ws, srcID))
                                {
                                    additionalItemRwCell1.Style.Add("border-bottom", "solid");
                                    additionalItemRwCell1.Style.Add("border-top", "solid");
                                    additionalItemRwCell1.Style.Add("border-left", "solid");
                                    additionalItemRwCell1.Style.Add("border-right", "solid");
                                    additionalItemRwCell1.Style.Add("border-color", "#ffdf73");
                                    additionalItemRwCell1.ToolTip = "See AO Review";
                                }
                                if (IsDiff("AdditionalLineItem", AdditionalLineItem, oList, qs_fy, qs_ws, srcID))
                                {
                                    additionalItemRwCell2.Style.Add("border-bottom", "solid");
                                    additionalItemRwCell2.Style.Add("border-top", "solid");
                                    additionalItemRwCell2.Style.Add("border-left", "solid");
                                    additionalItemRwCell2.Style.Add("border-right", "solid");
                                    additionalItemRwCell2.Style.Add("border-color", "#ffdf73");
                                    additionalItemRwCell2.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string additionalItemRwCell3Text = "";
                            string additionalItemRwCell4Text = "";
                            try
                            {
                                additionalItemRwCell3Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                additionalItemRwCell4Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem additionalItemRwCell3ListItem1 = new ListItem();
                            ListItem additionalItemRwCell3ListItem2 = new ListItem();
                            ListItem additionalItemRwCell3ListItem3 = new ListItem();
                            ListItem additionalItemRwCell3ListItem4 = new ListItem();
                            ListItem additionalItemRwCell3ListItem5 = new ListItem();

                            additionalItemRwCell3ListItem1.Value = "Pending";
                            additionalItemRwCell3ListItem1.Text = "Pending";
                            additionalItemRwCell3ListItem1.Selected = true;

                            additionalItemRwCell3ListItem2.Value = "Approved";
                            additionalItemRwCell3ListItem2.Text = "Approved";

                            additionalItemRwCell3ListItem3.Value = "Approved With Comments";
                            additionalItemRwCell3ListItem3.Text = "Approved With Comments";

                            additionalItemRwCell3ListItem4.Value = "Approved With Revisions";
                            additionalItemRwCell3ListItem4.Text = "Approved With Revisions";

                            additionalItemRwCell3ListItem5.Value = "Not Approved";
                            additionalItemRwCell3ListItem5.Text = "Not Approved";



                            DropDownList additionalItemRwCell3DropDownList = new DropDownList();
                            additionalItemRwCell3DropDownList.CssClass = "CONOPSApprovalSelect";
                            additionalItemRwCell3DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            additionalItemRwCell3DropDownList.Items.Add(additionalItemRwCell3ListItem1);
                            additionalItemRwCell3DropDownList.Items.Add(additionalItemRwCell3ListItem2);
                            additionalItemRwCell3DropDownList.Items.Add(additionalItemRwCell3ListItem3);
                            additionalItemRwCell3DropDownList.Items.Add(additionalItemRwCell3ListItem4);
                            additionalItemRwCell3DropDownList.Items.Add(additionalItemRwCell3ListItem5);


                            TextBox additionalItemRwCell4TextBox = new TextBox();
                            additionalItemRwCell4TextBox.TextMode = TextBoxMode.MultiLine;
                            additionalItemRwCell4TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            additionalItemRwCell4TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            additionalItemRwCell3DropDownList.SelectedValue = additionalItemRwCell3Text;
                            additionalItemRwCell4TextBox.Text = additionalItemRwCell4Text;

                            additionalItemRwCell3.Controls.Add(additionalItemRwCell3DropDownList);
                            additionalItemRwCell4.Controls.Add(additionalItemRwCell4TextBox);

                            additionalItemRwCell3.CssClass = "CONOPSApprovalCell";
                            additionalItemRwCell4.CssClass = "CONOPSApprovalCell";

                            //additionalItemRwCell3.Style.Add("background-color", "Cornsilk");
                            //additionalItemRwCell4.Style.Add("background-color", "Cornsilk");

                            //---------------

                            rw.Cells.Add(additionalItemRwCell3);
                            rw.Cells.Add(additionalItemRwCell4);

                            rw.ID = id;

                            string dds1 = oListItem["DateDraftSaved"].ToString();


                            if (oListItem["OTASubmissionID"] == null && !dds1.Contains(":"))
                            {

                                rw.ToolTip = "NewLineItem_" + Contract; 


                            }

                            AdditionalLineItem = "";





                        }



                        try
                        {
                            Funding += oListItem["Funding"].ToString();
                            traceInfo = "Funding: " + Funding;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        //-------------

                        if (Funding != "")
                        {




                            try
                            {
                                DutyTitlePosition += oListItem["DutyTitlePosition"].ToString();
                                traceInfo = "DutyTitlePosition: " + DutyTitlePosition;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                Status += oListItem["Status"].ToString();
                                traceInfo = "Status: " + Status;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                if (oListItem["Remarks"] != null && oListItem["Remarks"].ToString() != "") { Remarks += oListItem["Remarks"].ToString(); }
                                traceInfo = "Remarks: " + Remarks;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                ContractorRate += oListItem["ContractorRate"].ToString();
                                traceInfo = "ContractorRate: " + ContractorRate;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWS1", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            TableCell contractorsValsRwCell1 = new TableCell();
                            TableCell contractorsValsRwCell2 = new TableCell();
                            TableCell contractorsValsRwCell3 = new TableCell();
                            TableCell contractorsValsRwCell4 = new TableCell();
                            TableCell contractorsValsRwCell5 = new TableCell();
                            TableCell contractorsValsRwCell6 = new TableCell();

                            TableCell contractorsValsRwCell7 = new TableCell();
                            TableCell contractorsValsRwCell8 = new TableCell();

                            contractorsValsRwCell1.Style.Add("text-align", "center");
                            contractorsValsRwCell2.Style.Add("text-align", "center");
                            contractorsValsRwCell3.Style.Add("text-align", "center");
                            contractorsValsRwCell4.Style.Add("text-align", "center");
                            contractorsValsRwCell5.Style.Add("text-align", "right");
                            contractorsValsRwCell6.Style.Add("text-align", "center");

                            TextBox contractorsValsRwCell1TextBox = new TextBox();
                            TextBox contractorsValsRwCell2TextBox = new TextBox();
                            TextBox contractorsValsRwCell3TextBox = new TextBox();
                            TextBox contractorsValsRwCell4TextBox = new TextBox();
                            TextBox contractorsValsRwCell5TextBox = new TextBox();
                            TextBox contractorsValsRwCell6TextBox = new TextBox();

                            contractorsValsRwCell1TextBox.Width = 80;
                            contractorsValsRwCell2TextBox.Width = 80;
                            contractorsValsRwCell3TextBox.Width = 80;
                            contractorsValsRwCell4TextBox.Width = 80;
                            contractorsValsRwCell5TextBox.Width = 80;
                            contractorsValsRwCell6TextBox.Width = 80;

                            contractorsValsRwCell1TextBox.Text = title;
                            contractorsValsRwCell2TextBox.Text = DutyTitlePosition;
                            contractorsValsRwCell3TextBox.Text = Status;
                            contractorsValsRwCell4TextBox.Text = Remarks;
                            contractorsValsRwCell5TextBox.Text = ContractorRate;
                            contractorsValsRwCell6TextBox.Text = Funding;

                            contractorsValsRwCell1TextBox.ID = "rowId" + id + "Title";
                            contractorsValsRwCell2TextBox.ID = "rowId" + id + "DutyTitlePosition";
                            contractorsValsRwCell3TextBox.ID = "rowId" + id + "Status";
                            contractorsValsRwCell4TextBox.ID = "rowId" + id + "Remarks";
                            contractorsValsRwCell5TextBox.ID = "rowId" + id + "ContractorRate";
                            contractorsValsRwCell6TextBox.ID = "rowId" + id + "Funding";

                            contractorsValsRwCell1.Controls.Add(contractorsValsRwCell1TextBox);
                            contractorsValsRwCell2.Controls.Add(contractorsValsRwCell2TextBox);
                            contractorsValsRwCell3.Controls.Add(contractorsValsRwCell3TextBox);
                            contractorsValsRwCell4.Controls.Add(contractorsValsRwCell4TextBox);
                            contractorsValsRwCell5.Controls.Add(contractorsValsRwCell5TextBox);
                            contractorsValsRwCell6.Controls.Add(contractorsValsRwCell6TextBox);

                            rw.Cells.Add(contractorsValsRwCell1);
                            rw.Cells.Add(contractorsValsRwCell2);
                            rw.Cells.Add(contractorsValsRwCell3);
                            rw.Cells.Add(contractorsValsRwCell4);
                            rw.Cells.Add(contractorsValsRwCell5);
                            rw.Cells.Add(contractorsValsRwCell6);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Title", title, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Title", title, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell1.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell1.Style.Add("border-top", "solid");
                                    contractorsValsRwCell1.Style.Add("border-left", "solid");
                                    contractorsValsRwCell1.Style.Add("border-right", "solid");
                                    contractorsValsRwCell1.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell1.ToolTip = "See AO Review";
                                }
                                if (IsDiff("DutyTitlePosition", DutyTitlePosition, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell2.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell2.Style.Add("border-top", "solid");
                                    contractorsValsRwCell2.Style.Add("border-left", "solid");
                                    contractorsValsRwCell2.Style.Add("border-right", "solid");
                                    contractorsValsRwCell2.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell2.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Status", Status, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell3.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell3.Style.Add("border-top", "solid");
                                    contractorsValsRwCell3.Style.Add("border-left", "solid");
                                    contractorsValsRwCell3.Style.Add("border-right", "solid");
                                    contractorsValsRwCell3.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell3.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Remarks", Remarks, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell4.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell4.Style.Add("border-top", "solid");
                                    contractorsValsRwCell4.Style.Add("border-left", "solid");
                                    contractorsValsRwCell4.Style.Add("border-right", "solid");
                                    contractorsValsRwCell4.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell4.ToolTip = "See AO Review";
                                }
                                if (IsDiff("ContractorRate", ContractorRate, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell5.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell5.Style.Add("border-top", "solid");
                                    contractorsValsRwCell5.Style.Add("border-left", "solid");
                                    contractorsValsRwCell5.Style.Add("border-right", "solid");
                                    contractorsValsRwCell5.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell5.ToolTip = "See AO Review";
                                }
                                if (IsDiff("Funding", Funding, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsValsRwCell6.Style.Add("border-bottom", "solid");
                                    contractorsValsRwCell6.Style.Add("border-top", "solid");
                                    contractorsValsRwCell6.Style.Add("border-left", "solid");
                                    contractorsValsRwCell6.Style.Add("border-right", "solid");
                                    contractorsValsRwCell6.Style.Add("border-color", "#ffdf73");
                                    contractorsValsRwCell6.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            //Approval

                            string contractorsValsRwCell7Text = "";
                            string contractorsValsRwCell8Text = "";
                            try
                            {
                                contractorsValsRwCell7Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorsValsRwCell8Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem contractorsValsRwCell7ListItem1 = new ListItem();
                            ListItem contractorsValsRwCell7ListItem2 = new ListItem();
                            ListItem contractorsValsRwCell7ListItem3 = new ListItem();
                            ListItem contractorsValsRwCell7ListItem4 = new ListItem();
                            ListItem contractorsValsRwCell7ListItem5 = new ListItem();

                            contractorsValsRwCell7ListItem1.Value = "Pending";
                            contractorsValsRwCell7ListItem1.Text = "Pending";
                            contractorsValsRwCell7ListItem1.Selected = true;

                            contractorsValsRwCell7ListItem2.Value = "Approved";
                            contractorsValsRwCell7ListItem2.Text = "Approved";

                            contractorsValsRwCell7ListItem3.Value = "Approved With Comments";
                            contractorsValsRwCell7ListItem3.Text = "Approved With Comments";

                            contractorsValsRwCell7ListItem4.Value = "Approved With Revisions";
                            contractorsValsRwCell7ListItem4.Text = "Approved With Revisions";

                            contractorsValsRwCell7ListItem5.Value = "Not Approved";
                            contractorsValsRwCell7ListItem5.Text = "Not Approved";



                            DropDownList contractorsValsRwCell7DropDownList = new DropDownList();
                            contractorsValsRwCell7DropDownList.CssClass = "CONOPSApprovalSelect";
                            contractorsValsRwCell7DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            contractorsValsRwCell7DropDownList.Items.Add(contractorsValsRwCell7ListItem1);
                            contractorsValsRwCell7DropDownList.Items.Add(contractorsValsRwCell7ListItem2);
                            contractorsValsRwCell7DropDownList.Items.Add(contractorsValsRwCell7ListItem3);
                            contractorsValsRwCell7DropDownList.Items.Add(contractorsValsRwCell7ListItem4);
                            contractorsValsRwCell7DropDownList.Items.Add(contractorsValsRwCell7ListItem5);


                            TextBox contractorsValsRwCell8TextBox = new TextBox();
                            contractorsValsRwCell8TextBox.TextMode = TextBoxMode.MultiLine;
                            contractorsValsRwCell8TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            contractorsValsRwCell8TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            contractorsValsRwCell7DropDownList.SelectedValue = contractorsValsRwCell7Text;
                            contractorsValsRwCell8TextBox.Text = contractorsValsRwCell8Text;

                            contractorsValsRwCell7.Controls.Add(contractorsValsRwCell7DropDownList);
                            contractorsValsRwCell8.Controls.Add(contractorsValsRwCell8TextBox);

                            contractorsValsRwCell7.CssClass = "CONOPSApprovalCell";
                            contractorsValsRwCell8.CssClass = "CONOPSApprovalCell";

                            //contractorsValsRwCell7.Style.Add("background-color", "Cornsilk");
                            //contractorsValsRwCell8.Style.Add("background-color", "Cornsilk");

                            //---------------

                            rw.Cells.Add(contractorsValsRwCell7);
                            rw.Cells.Add(contractorsValsRwCell8);

                            rw.ID = id;

                            bool contractSectionExists = false;
                            string dds = oListItem["DateDraftSaved"].ToString();


                            if (oListItem["OTASubmissionID"] == null && !dds.Contains(":"))
                            {
                               
                                    rw.ToolTip = "NewItem_" + Contract; //oListItem["Contract"].ToString()

                                
                            }
                            else { contractSectionExists = true; }
                            

                            Funding = "";

                            

                            if (!contractItemBlankRowAdded && contractSectionExists)
                            {
                                TableRow contractorsBlankRw = new TableRow();

                                TableCell contractorsBlankRwCell1 = new TableCell();
                                TableCell contractorsBlankRwCell2 = new TableCell();

                                TableCell contractorsBlankRwCell3 = new TableCell();
                                TableCell contractorsBlankRwCell4 = new TableCell();

                                contractorsBlankRwCell1.ColumnSpan = 5;

                                Literal LiteralcontractorsBlankRw = new Literal();
                                LiteralcontractorsBlankRw.Text = "&nbsp;";

                                contractorsBlankRwCell1.Controls.Add(LiteralcontractorsBlankRw);

                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell1);
                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell2);

                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell3);
                                contractorsBlankRw.Cells.Add(contractorsBlankRwCell4);

                                contractorsBlankRw.ID = "contractorsBlankRow";
                                contractorsBlankRw.ToolTip = Contract;

                                CONOPSDevWSTable.Rows.AddAt(contractIndex, contractorsBlankRw);

                                contractItemBlankRowAdded = true;
                            }


                        }
                        //-----------------

                        if (title == "Contract")
                        {


                            TableCell contractorsDescRwCell = new TableCell();

                            TableCell contractorsDescRwCell2 = new TableCell();
                            TableCell contractorsDescRwCell3 = new TableCell();

                            contractorsDescRwCell.ColumnSpan = 6;

                            contractorsDescRwCell.Style.Add("text-align", "center");
                            contractorsDescRwCell.Style.Add("font-style", "italic");

                            Label LabelcontractorsDesc1b = new Label();
                            LabelcontractorsDesc1b.Text = "Contract Identifier  ";

                            TextBox LabelcontractorsDesc2bTextBox = new TextBox();
                            LabelcontractorsDesc2bTextBox.Width = 80;
                            LabelcontractorsDesc2bTextBox.Text = Contract;
                            LabelcontractorsDesc2bTextBox.Font.Italic = false;
                            LabelcontractorsDesc2bTextBox.ID = "rowId" + id + "Contract";
                            LabelcontractorsDesc2bTextBox.CssClass = "ContractIdentifyer";

                            contractorsDescRwCell.Controls.Add(LabelcontractorsDesc1b);
                            contractorsDescRwCell.Controls.Add(LabelcontractorsDesc2bTextBox);

                            rw.Cells.Add(contractorsDescRwCell);


                            try
                            {
                                //traceInfo = "call to IsDiff: " + IsDiff("Contract", Contract, oList, qs_fy, qs_ws, oListItem["OTASubmissionID"].ToString());
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string srcID = "0";
                                if (oListItem["OTASubmissionID"] != null) { srcID = oListItem["OTASubmissionID"].ToString(); }

                                if (IsDiff("Contract", Contract, oList, qs_fy, qs_ws, srcID))
                                {
                                    contractorsDescRwCell.Style.Add("border-bottom", "solid");
                                    contractorsDescRwCell.Style.Add("border-top", "solid");
                                    contractorsDescRwCell.Style.Add("border-left", "solid");
                                    contractorsDescRwCell.Style.Add("border-right", "solid");
                                    contractorsDescRwCell.Style.Add("border-color", "#ffdf73");
                                    contractorsDescRwCell.ToolTip = "See AO Review";
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalIsDiff", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            //Approval

                            string contractorsDescRwCell2Text = "";
                            string contractorsDescRwCell3Text = "";
                            try
                            {
                                contractorsDescRwCell2Text = "" + oListItem["CONOPSApprovalAOReview"].ToString();
                                contractorsDescRwCell3Text = "" + oListItem["CONOPSApprovalAOComments"].ToString();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            ListItem contractorsDescRwCell2ListItem1 = new ListItem();
                            ListItem contractorsDescRwCell2ListItem2 = new ListItem();
                            ListItem contractorsDescRwCell2ListItem3 = new ListItem();
                            ListItem contractorsDescRwCell2ListItem4 = new ListItem();
                            ListItem contractorsDescRwCell2ListItem5 = new ListItem();

                            contractorsDescRwCell2ListItem1.Value = "Pending";
                            contractorsDescRwCell2ListItem1.Text = "Pending";
                            contractorsDescRwCell2ListItem1.Selected = true;

                            contractorsDescRwCell2ListItem2.Value = "Approved";
                            contractorsDescRwCell2ListItem2.Text = "Approved";

                            contractorsDescRwCell2ListItem3.Value = "Approved With Comments";
                            contractorsDescRwCell2ListItem3.Text = "Approved With Comments";

                            contractorsDescRwCell2ListItem4.Value = "Approved With Revisions";
                            contractorsDescRwCell2ListItem4.Text = "Approved With Revisions";

                            contractorsDescRwCell2ListItem5.Value = "Not Approved";
                            contractorsDescRwCell2ListItem5.Text = "Not Approved";



                            DropDownList contractorsDescRwCell2DropDownList = new DropDownList();
                            contractorsDescRwCell2DropDownList.CssClass = "CONOPSApprovalSelect";
                            contractorsDescRwCell2DropDownList.ID = "rowId" + id + "CONOPSApprovalAOReview";

                            contractorsDescRwCell2DropDownList.Items.Add(contractorsDescRwCell2ListItem1);
                            contractorsDescRwCell2DropDownList.Items.Add(contractorsDescRwCell2ListItem2);
                            contractorsDescRwCell2DropDownList.Items.Add(contractorsDescRwCell2ListItem3);
                            contractorsDescRwCell2DropDownList.Items.Add(contractorsDescRwCell2ListItem4);
                            contractorsDescRwCell2DropDownList.Items.Add(contractorsDescRwCell2ListItem5);


                            TextBox contractorsDescRwCell3TextBox = new TextBox();
                            contractorsDescRwCell3TextBox.TextMode = TextBoxMode.MultiLine;
                            contractorsDescRwCell3TextBox.CssClass = "CONOPSApprovalTextBoxMultiLine";
                            contractorsDescRwCell3TextBox.ID = "rowId" + id + "CONOPSApprovalAOComments";

                            contractorsDescRwCell2DropDownList.SelectedValue = contractorsDescRwCell2Text;
                            contractorsDescRwCell3TextBox.Text = contractorsDescRwCell3Text;

                            contractorsDescRwCell2.Controls.Add(contractorsDescRwCell2DropDownList);
                            contractorsDescRwCell3.Controls.Add(contractorsDescRwCell3TextBox);

                            contractorsDescRwCell2.CssClass = "CONOPSApprovalCell";
                            contractorsDescRwCell3.CssClass = "CONOPSApprovalCell";

                            //contractorsDescRwCell2.Style.Add("background-color", "Cornsilk");
                            //contractorsDescRwCell3.Style.Add("background-color", "Cornsilk");

                            //---------------

                            rw.Cells.Add(contractorsDescRwCell2);
                            rw.Cells.Add(contractorsDescRwCell3);
                            rw.ToolTip = "Contract";
                        }


                        //==================
                        rw.ID = id;

                        //rw.CssClass = "ContractSection";

                        CONOPSDevWSTable.Rows.AddAt(contractIndex, rw);
                    }

                } //end loop for Contract section minus Contractors

                try
                {
                    //Remove template rows
                    CONOPSDevWSTable.Controls.Remove(contractorsDescRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsValsRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsBlankRow);
                    CONOPSDevWSTable.Controls.Remove(additionalItemRow);
                    CONOPSDevWSTable.Controls.Remove(hoursRow);
                    CONOPSDevWSTable.Controls.Remove(hoursBlankRow);
                    CONOPSDevWSTable.Controls.Remove(contractFeeRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsFYTotalRow);
                    CONOPSDevWSTable.Controls.Remove(contractorsSubTotalRow);
                    CONOPSDevWSTable.Controls.Remove(attachmentsValRow);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSApprovalEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }


            }

        }

    }
}
