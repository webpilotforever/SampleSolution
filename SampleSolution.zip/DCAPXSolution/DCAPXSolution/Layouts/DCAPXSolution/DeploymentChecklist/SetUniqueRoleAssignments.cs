﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class SetUniqueRoleAssignmentsClass
    {
        internal static string SetUniqueRoleAssignments(string oSiteUrl, string traceInfo)
        {
            string tr = "false";

            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;
                    SPList listCONOPSDevProgress = null;
                    SPList listCONOPSApprovalProgress = null;
                    SPList listDCAPXPOCs = null;
                    SPList listFeedback = null;
                    SPList listProgramContacts = null;
                    SPList listMasterCalendar = null;

                    SPGroup DCAPXOwners = null;
                    SPGroup DCAPXVisitors = null;
                    SPGroup DCAPXAO = null;
                    SPGroup DCAPXOTA = null;
                    SPGroup CONOPSApproval = null;
                    SPGroup CONOPSDevReadersAFOTEC = null;
                    SPGroup CONOPSDevReadersATEC = null;
                    SPGroup CONOPSDevReadersCOTF = null;
                    SPGroup CONOPSDevReadersJITC = null;
                    SPGroup CONOPSDevReadersMCOTEA = null;
                    SPGroup CONOPSDevSubmittersAFOTEC = null;
                    SPGroup CONOPSDevSubmittersATEC = null;
                    SPGroup CONOPSDevSubmittersCOTF = null;
                    SPGroup CONOPSDevSubmittersJITC = null;
                    SPGroup CONOPSDevSubmittersMCOTEA = null;

                    SPGroupCollection collGroups = oWeb.SiteGroups;

                    foreach (SPGroup oGroup in collGroups)
                    {
                        if (oGroup.Name == "DCAPXOwners")
                        {
                            DCAPXOwners = oGroup;
                        }
                        if (oGroup.Name == "DCAPXVisitors")
                        {
                            DCAPXVisitors = oGroup;
                        }
                        if (oGroup.Name == "DCAPXAO")
                        {
                            DCAPXAO = oGroup;
                        }
                        if (oGroup.Name == "DCAPXOTA")
                        {
                            DCAPXOTA = oGroup;
                        }
                        if (oGroup.Name == "CONOPSApproval")
                        {
                            CONOPSApproval = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevReadersAFOTEC")
                        {
                            CONOPSDevReadersAFOTEC = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevReadersATEC")
                        {
                            CONOPSDevReadersATEC = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevReadersCOTF")
                        {
                            CONOPSDevReadersCOTF = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevReadersJITC")
                        {
                            CONOPSDevReadersJITC = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevReadersMCOTEA")
                        {
                            CONOPSDevReadersMCOTEA = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevSubmittersAFOTEC")
                        {
                            CONOPSDevSubmittersAFOTEC = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevSubmittersATEC")
                        {
                            CONOPSDevSubmittersATEC = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevSubmittersCOTF")
                        {
                            CONOPSDevSubmittersCOTF = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevSubmittersJITC")
                        {
                            CONOPSDevSubmittersJITC = oGroup;
                        }
                        if (oGroup.Name == "CONOPSDevSubmittersMCOTEA")
                        {
                            CONOPSDevSubmittersMCOTEA = oGroup;
                        }
                    }

                    SPListCollection oWebLists = oWeb.Lists;

                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }
                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                        if (oList.Title == "CONOPSDevProgress")
                        {
                            listCONOPSDevProgress = oList;
                        }
                        if (oList.Title == "CONOPSApprovalProgress")
                        {
                            listCONOPSApprovalProgress = oList;
                        }
                        if (oList.Title == "DCAPXPOCs")
                        {
                            listDCAPXPOCs = oList;
                        }
                        if (oList.Title == "Feedback")
                        {
                            listFeedback = oList;
                        }
                        if (oList.Title == "ProgramContacts")
                        {
                            listProgramContacts = oList;
                        }
                        if (oList.Title == "MasterCalendar")
                        {
                            listMasterCalendar = oList;
                        }
                    }




                    try
                    {

                        if (libCONOPSDevAFOTEC.HasUniqueRoleAssignments)
                        {
                            try
                            {

                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevAFOTEC.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersAFOTEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersAFOTEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }



                        if (listCONOPSDevWSAFOTEC.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSAFOTEC.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersAFOTEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersAFOTEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSAFOTEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        if (libCONOPSDevATEC.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevATEC.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersATEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersATEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                        if (libCONOPSDevCOTF.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevCOTF.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersCOTF);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersCOTF);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        if (libCONOPSDevJITC.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevJITC.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersJITC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersJITC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                        if (libCONOPSDevMCOTEA.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevMCOTEA.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersMCOTEA);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersMCOTEA);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                libCONOPSDevMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                        if (listCONOPSDevWSATEC.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSATEC.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersATEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersATEC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSATEC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                        if (listCONOPSDevWSCOTF.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSCOTF.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersCOTF);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersCOTF);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSCOTF.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                        if (listCONOPSDevWSJITC.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSJITC.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersJITC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersJITC);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSJITC.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                        if (listCONOPSDevWSMCOTEA.HasUniqueRoleAssignments)
                        {
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Administrator);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXOwners);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSMCOTEA.RoleAssignments.Add(roleAssignment);

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXVisitors);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(DCAPXAO);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Contributor);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSApproval);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevReadersMCOTEA);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                oWeb.AllowUnsafeUpdates = true; SPRoleDefinition roleDefinition = oWeb.RoleDefinitions.GetByType(SPRoleType.Reader);
                                SPRoleAssignment roleAssignment = new SPRoleAssignment(CONOPSDevSubmittersMCOTEA);
                                roleAssignment.RoleDefinitionBindings.Add(roleDefinition);
                                listCONOPSDevWSMCOTEA.RoleAssignments.Add(roleAssignment);
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEARoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }



                        traceInfo = "Update() lists";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsSetUniqueRoleAssignments", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        tr = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsSetUniqueRoleAssignments", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }
            }
            return tr;

        }

    }
}
