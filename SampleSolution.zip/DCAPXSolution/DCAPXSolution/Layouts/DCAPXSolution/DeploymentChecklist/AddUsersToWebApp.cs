﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class AddUsersToWebAppClass
    {
        internal static void AddUsersToWebApp(string pageUrl, string traceInfo, string ThisNetworkValue)
        {

            using (SPSite oSite = new SPSite(pageUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    if (ThisNetworkValue == "SIPR Net")
                    {
                        try
                        {
                            traceInfo = "addUsersToWebApp SHAREPOINT\\system";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("SHAREPOINT\\system");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcesystem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {

                            traceInfo = "addUsersToWebApp resource\\danielnw";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("resource\\danielnw");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcedanielnw", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {

                            traceInfo = "addUsersToWebApp resource\\aoberg";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("resource\\aoberg");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceaoberg", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {


                            traceInfo = "addUsersToWebApp resource\\clarkrm";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("resource\\clarkrm");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceclarkrm", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {

                            traceInfo = "addUsersToWebApp resource\\clarkr-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("resource\\clarkr-p");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceclarkr-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }



                    }
                    else
                    {
                        try
                        {
                            traceInfo = "addUsersToWebApp SHAREPOINT\\system";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("SHAREPOINT\\system");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcesystem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToWebApp dotedresource\\danielnw-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("dotedresource\\danielnw-p");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcedanielnw-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToWebApp dotedresource\\clarkrm-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("dotedresource\\clarkrm-p");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceclarkrm-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToWebApp dotedresource\\oberga-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\oberga-p");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceoberga-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {
                            traceInfo = "addUsersToWebApp dotedresource\\sp-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToWebApp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\sp-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcesp-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {
                            traceInfo = "addUsersToWebApp dotedresource\\oberga-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWebAppoberga-test", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\oberga-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWebAppoberga-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {
                            traceInfo = "addUsersToWebApp dotedresource\\clarkrm-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWebAppclarkrm-test", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\clarkrm-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWebAppclarkrm-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {
                            traceInfo = "addUsersToWebApp dotedresource\\danielnw-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWebAppdanielnw-test", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\danielnw-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXWebAppdanielnw-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }


                    }

                }
            }
        }

    }
}
