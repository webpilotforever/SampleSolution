﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class AllowContentTypesClass
    {
        internal static string AllowContentTypes(string oSiteUrl, string traceInfo)
        {
            string tr = "false";


            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;
                    SPList listCONOPSDevProgress = null;
                    SPList listCONOPSApprovalProgress = null;
                    SPList listDCAPXPOCs = null;
                    SPList listFeedback = null;
                    SPList listProgramContacts = null;
                    SPList listMasterCalendar = null;

                    SPListCollection oWebLists = oWeb.Lists;

                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }
                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                        if (oList.Title == "CONOPSDevProgress")
                        {
                            listCONOPSDevProgress = oList;
                        }
                        if (oList.Title == "CONOPSApprovalProgress")
                        {
                            listCONOPSApprovalProgress = oList;
                        }
                        if (oList.Title == "DCAPXPOCs")
                        {
                            listDCAPXPOCs = oList;
                        }
                        if (oList.Title == "Feedback")
                        {
                            listFeedback = oList;
                        }
                        if (oList.Title == "ProgramContacts")
                        {
                            listProgramContacts = oList;
                        }
                        if (oList.Title == "MasterCalendar")
                        {
                            listMasterCalendar = oList;
                        }
                    }

                    if (!listCONOPSDevWSAFOTEC.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listCONOPSDevWSAFOTEC.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTEC", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSAFOTEC.ContentTypesEnabled = true;


                    }
                    if (!listCONOPSDevWSATEC.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listCONOPSDevWSATEC.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATEC", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSATEC.ContentTypesEnabled = true;


                    }
                    if (!listCONOPSDevWSCOTF.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listCONOPSDevWSCOTF.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTF", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSCOTF.ContentTypesEnabled = true;


                    }
                    if (!listCONOPSDevWSJITC.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listCONOPSDevWSJITC.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITC", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSJITC.ContentTypesEnabled = true;


                    }
                    if (!listCONOPSDevWSMCOTEA.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listCONOPSDevWSMCOTEA.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEA", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevWSMCOTEA.ContentTypesEnabled = true;


                    }

                    if (!listCONOPSDevProgress.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listCONOPSDevProgress.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSDevProgress.ContentTypesEnabled = true;


                    }
                    if (!listCONOPSApprovalProgress.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listCONOPSApprovalProgress.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listCONOPSApprovalProgress.ContentTypesEnabled = true;


                    }
                    if (!listDCAPXPOCs.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listDCAPXPOCs.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistDCAPXPOCs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listDCAPXPOCs.ContentTypesEnabled = true;


                    }
                    if (!listFeedback.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listFeedback.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistFeedback", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listFeedback.ContentTypesEnabled = true;


                    }
                    if (!listProgramContacts.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listProgramContacts.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listProgramContacts.ContentTypesEnabled = true;
                        oWeb.AllowUnsafeUpdates = true;
                        //listProgramContacts.Update();

                    }

                    if (!listMasterCalendar.ContentTypesEnabled)
                    {
                        traceInfo = "Enabling Content Types on the " + listMasterCalendar.Title + " list";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistMasterCalendar", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        listMasterCalendar.ContentTypesEnabled = true;


                    }
                    try
                    {
                        traceInfo = "Update() lists";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAllowedContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSMCOTEA.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevProgress.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSApprovalProgress.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listProgramContacts.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listFeedback.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listDCAPXPOCs.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listMasterCalendar.Update();

                        tr = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAllowedContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }

            return tr;
        }

    }
}
