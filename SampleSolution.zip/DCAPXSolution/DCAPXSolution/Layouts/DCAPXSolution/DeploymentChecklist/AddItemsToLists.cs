﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SharePoint.Navigation;
using System.Collections.Generic;
using System.Reflection;
using System.Collections.Specialized;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class AddItemsToListsClass
    {
       


            internal static string AddItemsToLists(string oSiteUrl, string traceInfo, string ThisNetworkValue)
            {
                string tr = "false";

                using (SPSite oSite = new SPSite(oSiteUrl))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        SPList listCONOPSDevProgress = null;
                        SPList listCONOPSApprovalProgress = null;
                        SPList listDCAPXPOCs = null;
                        SPList listProgramContacts = null;



                        SPListCollection oWebLists = oWeb.Lists;

                        foreach (SPList oList in oWebLists)
                        {

                            if (oList.Title == "CONOPSDevProgress")
                            {
                                listCONOPSDevProgress = oList;
                            }
                            if (oList.Title == "CONOPSApprovalProgress")
                            {
                                listCONOPSApprovalProgress = oList;
                            }
                            if (oList.Title == "DCAPXPOCs")
                            {
                                listDCAPXPOCs = oList;
                            }

                            if (oList.Title == "ProgramContacts")
                            {
                                listProgramContacts = oList;
                            }

                        }

                        SPListItemCollection listItemsCONOPSDevProgress = listCONOPSDevProgress.Items;
                        SPListItemCollection listItemsCONOPSApprovalProgress = listCONOPSApprovalProgress.Items;
                        SPListItemCollection listItemsDCAPXPOCs = listDCAPXPOCs.Items;
                        SPListItemCollection listItemsProgramContacts = listProgramContacts.Items;

                        SPListItem listItemCONOPSDevProgress1 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress2 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress3 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress4 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress5 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress6 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress7 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress8 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress9 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress10 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress11 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress12 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress13 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress14 = listItemsCONOPSDevProgress.Add();
                        SPListItem listItemCONOPSDevProgress15 = listItemsCONOPSDevProgress.Add();

                        SPListItem listItemCONOPSApprovalProgress1 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress2 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress3 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress4 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress5 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress6 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress7 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress8 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress9 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress10 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress11 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress12 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress13 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress14 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress15 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress16 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress17 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress18 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress19 = listItemsCONOPSApprovalProgress.Add();
                        SPListItem listItemCONOPSApprovalProgress20 = listItemsCONOPSApprovalProgress.Add();

                        SPListItem listItemDCAPXPOCs1 = listItemsDCAPXPOCs.Add();
                        SPListItem listItemDCAPXPOCs2 = listItemsDCAPXPOCs.Add();
                        //SPListItem listItemDCAPXPOCs3 = listItemsDCAPXPOCs.Add();
                        SPListItem listItemProgramContacts1 = listItemsProgramContacts.Add();
                        SPListItem listItemProgramContacts2 = listItemsProgramContacts.Add();
                        SPListItem listItemProgramContacts3 = listItemsProgramContacts.Add();
                        SPListItem listItemProgramContacts4 = listItemsProgramContacts.Add();
                        SPListItem listItemProgramContacts5 = listItemsProgramContacts.Add();
                        SPListItem listItemProgramContacts6 = listItemsProgramContacts.Add();
                        SPListItem listItemProgramContacts7 = listItemsProgramContacts.Add();
                        SPListItem listItemProgramContacts8 = listItemsProgramContacts.Add();

                        if (listCONOPSDevProgress.ItemCount < 1)
                        {

                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress1["Title"] = "Current FY";
                                listItemCONOPSDevProgress1["OperationalTestAgency"] = "AFOTEC";
                                listItemCONOPSDevProgress1["WS1Progress"] = "In Progress";
                                listItemCONOPSDevProgress1["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress1["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress1["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress1["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress1["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress2["Title"] = "Next FY";
                                listItemCONOPSDevProgress2["OperationalTestAgency"] = "AFOTEC";
                                listItemCONOPSDevProgress2["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress2["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress2["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress2["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress2["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress2["ForFY"] = "Next";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress3["Title"] = "Future FY";
                                listItemCONOPSDevProgress3["OperationalTestAgency"] = "AFOTEC";
                                listItemCONOPSDevProgress3["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress3["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress3["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress3["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress3["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress3["ForFY"] = "Future";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress4["Title"] = "Current FY";
                                listItemCONOPSDevProgress4["OperationalTestAgency"] = "ATEC";
                                listItemCONOPSDevProgress4["WS1Progress"] = "In Progress";
                                listItemCONOPSDevProgress4["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress4["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress4["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress4["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress4["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress5["Title"] = "Next FY";
                                listItemCONOPSDevProgress5["OperationalTestAgency"] = "ATEC";
                                listItemCONOPSDevProgress5["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress5["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress5["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress5["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress5["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress5["ForFY"] = "Next";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress6["Title"] = "Future FY";
                                listItemCONOPSDevProgress6["OperationalTestAgency"] = "ATEC";
                                listItemCONOPSDevProgress6["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress6["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress6["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress6["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress6["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress6["ForFY"] = "Future";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress7["Title"] = "Current FY";
                                listItemCONOPSDevProgress7["OperationalTestAgency"] = "COTF";
                                listItemCONOPSDevProgress7["WS1Progress"] = "In Progress";
                                listItemCONOPSDevProgress7["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress7["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress7["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress7["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress7["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress8["Title"] = "Next FY";
                                listItemCONOPSDevProgress8["OperationalTestAgency"] = "COTF";
                                listItemCONOPSDevProgress8["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress8["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress8["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress8["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress8["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress8["ForFY"] = "Next";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress9["Title"] = "Future FY";
                                listItemCONOPSDevProgress9["OperationalTestAgency"] = "COTF";
                                listItemCONOPSDevProgress9["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress9["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress9["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress9["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress9["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress9["ForFY"] = "Future";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress10["Title"] = "Current FY";
                                listItemCONOPSDevProgress10["OperationalTestAgency"] = "JITC";
                                listItemCONOPSDevProgress10["WS1Progress"] = "In Progress";
                                listItemCONOPSDevProgress10["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress10["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress10["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress10["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress10["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress11["Title"] = "Next FY";
                                listItemCONOPSDevProgress11["OperationalTestAgency"] = "JITC";
                                listItemCONOPSDevProgress11["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress11["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress11["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress11["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress11["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress11["ForFY"] = "Next";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress12["Title"] = "Future FY";
                                listItemCONOPSDevProgress12["OperationalTestAgency"] = "JITC";
                                listItemCONOPSDevProgress12["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress12["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress12["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress12["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress12["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress12["ForFY"] = "Future";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress13["Title"] = "Current FY";
                                listItemCONOPSDevProgress13["OperationalTestAgency"] = "MCOTEA";
                                listItemCONOPSDevProgress13["WS1Progress"] = "In Progress";
                                listItemCONOPSDevProgress13["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress13["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress13["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress13["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress13["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress14["Title"] = "Next FY";
                                listItemCONOPSDevProgress14["OperationalTestAgency"] = "MCOTEA";
                                listItemCONOPSDevProgress14["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress14["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress14["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress14["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress14["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress14["ForFY"] = "Next";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSDevProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSDevProgress15["Title"] = "Future FY";
                                listItemCONOPSDevProgress15["OperationalTestAgency"] = "MCOTEA";
                                listItemCONOPSDevProgress15["WS1Progress"] = "Not Started";
                                listItemCONOPSDevProgress15["WS2Progress"] = "Not Started";
                                listItemCONOPSDevProgress15["WS3Progress"] = "Not Started";
                                listItemCONOPSDevProgress15["WS4Progress"] = "Not Started";
                                listItemCONOPSDevProgress15["WSReview"] = "Not Started";
                                listItemCONOPSDevProgress15["ForFY"] = "Future";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


















                        if (listCONOPSApprovalProgress.ItemCount < 1)
                        {

                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress1["Title"] = "WS1";
                                listItemCONOPSApprovalProgress1["OperationalTestAgency"] = "AFOTEC";
                                listItemCONOPSApprovalProgress1["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress1["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress2["Title"] = "WS2";
                                listItemCONOPSApprovalProgress2["OperationalTestAgency"] = "AFOTEC";
                                listItemCONOPSApprovalProgress2["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress2["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemCONOPSApprovalProgress3["Title"] = "WS3";
                                listItemCONOPSApprovalProgress3["OperationalTestAgency"] = "AFOTEC";
                                listItemCONOPSApprovalProgress3["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress3["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress4["Title"] = "WS4";
                                listItemCONOPSApprovalProgress4["OperationalTestAgency"] = "AFOTEC";
                                listItemCONOPSApprovalProgress4["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress4["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress5["Title"] = "WS1";
                                listItemCONOPSApprovalProgress5["OperationalTestAgency"] = "ATEC";
                                listItemCONOPSApprovalProgress5["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress5["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress6["Title"] = "WS2";
                                listItemCONOPSApprovalProgress6["OperationalTestAgency"] = "ATEC";
                                listItemCONOPSApprovalProgress6["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress6["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress7["Title"] = "WS3";
                                listItemCONOPSApprovalProgress7["OperationalTestAgency"] = "ATEC";
                                listItemCONOPSApprovalProgress7["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress7["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress8["Title"] = "WS4";
                                listItemCONOPSApprovalProgress8["OperationalTestAgency"] = "ATEC";
                                listItemCONOPSApprovalProgress8["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress8["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress9["Title"] = "WS1";
                                listItemCONOPSApprovalProgress9["OperationalTestAgency"] = "COTF";
                                listItemCONOPSApprovalProgress9["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress9["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress10["Title"] = "WS2";
                                listItemCONOPSApprovalProgress10["OperationalTestAgency"] = "COTF";
                                listItemCONOPSApprovalProgress10["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress10["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress11["Title"] = "WS3";
                                listItemCONOPSApprovalProgress11["OperationalTestAgency"] = "COTF";
                                listItemCONOPSApprovalProgress11["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress11["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress12["Title"] = "WS4";
                                listItemCONOPSApprovalProgress12["OperationalTestAgency"] = "COTF";
                                listItemCONOPSApprovalProgress12["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress12["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress13["Title"] = "WS1";
                                listItemCONOPSApprovalProgress13["OperationalTestAgency"] = "JITC";
                                listItemCONOPSApprovalProgress13["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress13["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress14["Title"] = "WS2";
                                listItemCONOPSApprovalProgress14["OperationalTestAgency"] = "JITC";
                                listItemCONOPSApprovalProgress14["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress14["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress15["Title"] = "WS3";
                                listItemCONOPSApprovalProgress15["OperationalTestAgency"] = "JITC";
                                listItemCONOPSApprovalProgress15["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress15["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress16["Title"] = "WS4";
                                listItemCONOPSApprovalProgress16["OperationalTestAgency"] = "JITC";
                                listItemCONOPSApprovalProgress16["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress16["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress17["Title"] = "WS1";
                                listItemCONOPSApprovalProgress17["OperationalTestAgency"] = "MCOTEA";
                                listItemCONOPSApprovalProgress17["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress17["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress18["Title"] = "WS2";
                                listItemCONOPSApprovalProgress18["OperationalTestAgency"] = "MCOTEA";
                                listItemCONOPSApprovalProgress18["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress18["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress19["Title"] = "WS3";
                                listItemCONOPSApprovalProgress19["OperationalTestAgency"] = "MCOTEA";
                                listItemCONOPSApprovalProgress19["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress19["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to CONOPSApprovalProgress list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listItemCONOPSApprovalProgress20["Title"] = "WS4";
                                listItemCONOPSApprovalProgress20["OperationalTestAgency"] = "MCOTEA";
                                listItemCONOPSApprovalProgress20["CONOPSApproval"] = "Baseline OTA Submission";
                                listItemCONOPSApprovalProgress20["ForFY"] = "Current";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }




                        if (listDCAPXPOCs.ItemCount < 1)
                        {

                            //try
                            //{
                            //    traceInfo = "AddItems to DCAPXPOCs list";
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsDCAPXPOCs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                            //    listItemDCAPXPOCs1["ContentTypeId"] = "0x010085F0FF6431F64EA0A7E778E83BBBFD60"; // id of the content type
                            //    listItemDCAPXPOCs1["Title"] = "Clifford Lang";
                            //    listItemDCAPXPOCs1["EMail"] = "clifford.e.lang.civ@mail.smil.mil";
                            //    listItemDCAPXPOCs1["WorkPhone"] = "571-372-3887";

                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsDCAPXPOCs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}
                            try
                            {
                                traceInfo = "AddItems to DCAPXPOCs list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsDCAPXPOCs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemDCAPXPOCs1["ContentTypeId"] = "0x010085F0FF6431F64EA0A7E778E83BBBFD60"; // id of the content type
                                listItemDCAPXPOCs1["Title"] = "DOT&E CAP Team";
                                listItemDCAPXPOCs1["EMail"] = "osd.pentagon.dote.list.cap@mail.smil.mil";
                                listItemDCAPXPOCs1["WorkPhone"] = "571-372-3893";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsDCAPXPOCs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                traceInfo = "AddItems to DCAPXPOCs list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsDCAPXPOCs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                                listItemDCAPXPOCs2["ContentTypeId"] = "0x010085F0FF6431F64EA0A7E778E83BBBFD60"; // id of the content type
                                listItemDCAPXPOCs2["Title"] = "DOT&E Webmaster";
                                listItemDCAPXPOCs2["EMail"] = "osd.pentagon.dote.list.it-support@mail.smil.mil";
                                listItemDCAPXPOCs2["WorkPhone"] = "571-372-3893";

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsDCAPXPOCs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                        if (listProgramContacts.ItemCount < 1)
                        {

                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts1["Title"] = "Neal Daniel";

                                SPUser user = null;

                                if (ThisNetworkValue == "SIPR Net")
                                {
                                    user = oWeb.AllUsers["resource\\danielnw"];
                                }
                                else
                                {
                                    user = oWeb.AllUsers["dotedresource\\danielnw-p"];
                                }
                                if (user != null)
                                {
                                    listItemProgramContacts1["Account"] = user;
                                }


                                listItemProgramContacts1["OperationalTestAgency"] = "ATEC";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts1["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }



                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts2["Title"] = "Allison Oberg";

                                SPUser user = null;

                                if (ThisNetworkValue == "SIPR Net")
                                {
                                    user = oWeb.AllUsers["resource\\aoberg"];
                                }
                                else
                                {
                                    user = oWeb.AllUsers["dotedresource\\oberga-p"];
                                }
                                if (user != null)
                                {
                                    listItemProgramContacts2["Account"] = user;
                                }


                                listItemProgramContacts2["OperationalTestAgency"] = "AFOTEC";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts2["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts3["Title"] = "Robert Clark";

                                SPUser user = null;

                                if (ThisNetworkValue == "SIPR Net")
                                {
                                    user = oWeb.AllUsers["resource\\clarkrm"];
                                }
                                else
                                {
                                    user = oWeb.AllUsers["dotedresource\\clarkrm-p"];
                                }
                                if (user != null)
                                {
                                    listItemProgramContacts3["Account"] = user;
                                }


                                listItemProgramContacts3["OperationalTestAgency"] = "COTF";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts3["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts4["Title"] = "Robert Clark-p";

                                SPUser user = null;

                                if (ThisNetworkValue == "SIPR Net")
                                {
                                    user = oWeb.AllUsers["resource\\clarkr-p"];
                                }

                                if (user != null)
                                {
                                    listItemProgramContacts4["Account"] = user;
                                }


                                listItemProgramContacts4["OperationalTestAgency"] = "COTF";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts4["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts5["Title"] = "SP-Test";

                                SPUser user = null;

                                if (ThisNetworkValue == "NIPR Net")
                                {
                                    user = oWeb.AllUsers["dotedresource\\sp-test"];
                                }

                                if (user != null)
                                {
                                    listItemProgramContacts5["Account"] = user;
                                }


                                listItemProgramContacts5["OperationalTestAgency"] = "MCOTEA";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts5["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            //Allison Test
                            //DOTEDRESOURCE\oberga-test 
                            //Bob Test
                            //DOTEDRESOURCE\clarkrm-test 
                            //Neal Test
                            //DOTEDRESOURCE\danielnw-test 
                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts6["Title"] = "Allison Test";

                                SPUser user = null;

                                if (ThisNetworkValue == "NIPR Net")
                                {
                                    user = oWeb.AllUsers["dotedresource\\oberga-test"];
                                }

                                if (user != null)
                                {
                                    listItemProgramContacts6["Account"] = user;
                                }


                                listItemProgramContacts6["OperationalTestAgency"] = "AFOTEC";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                //choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts6["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts7["Title"] = "Bob Test";

                                SPUser user = null;

                                if (ThisNetworkValue == "NIPR Net")
                                {
                                    user = oWeb.AllUsers["dotedresource\\clarkrm-test"];
                                }

                                if (user != null)
                                {
                                    listItemProgramContacts7["Account"] = user;
                                }


                                listItemProgramContacts7["OperationalTestAgency"] = "COTF";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                //choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts7["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "AddItems to ProgramContacts list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                listItemProgramContacts8["Title"] = "Neal Test";

                                SPUser user = null;

                                if (ThisNetworkValue == "NIPR Net")
                                {
                                    user = oWeb.AllUsers["dotedresource\\danielnw-test"];
                                }

                                if (user != null)
                                {
                                    listItemProgramContacts8["Account"] = user;
                                }


                                listItemProgramContacts8["OperationalTestAgency"] = "ATEC";

                                StringCollection choices = new StringCollection();
                                choices.Add("CONOPS Development Module Readers (Gov Only)");
                                //choices.Add("CONOPS Development Module Submitters (Gov Only)");
                                SPFieldMultiChoiceValue values = new SPFieldMultiChoiceValue();
                                foreach (string choice in choices)
                                {
                                    values.Add(choice);
                                }
                                listItemProgramContacts8["ModuleAccess"] = values;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddItemsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                        }
                        try
                        {
                            traceInfo = "Update() lists";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddedItemsToLists", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            if (listCONOPSDevProgress.ItemCount < 1)
                            {
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress1.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress2.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress3.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress4.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress5.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress6.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress7.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress8.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress9.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress10.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress11.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress12.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress13.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress14.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSDevProgress15.Update();
                            }
                            if (listCONOPSApprovalProgress.ItemCount < 1)
                            {
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress1.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress2.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress3.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress4.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress5.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress6.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress7.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress8.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress9.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress10.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress11.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress12.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress13.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress14.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress15.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress16.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress17.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress18.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress19.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemCONOPSApprovalProgress20.Update();
                            }
                            if (listDCAPXPOCs.ItemCount < 1)
                            {
                                oWeb.AllowUnsafeUpdates = true;
                                listItemDCAPXPOCs1.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemDCAPXPOCs2.Update();
                                //oWeb.AllowUnsafeUpdates = true;
                                //listItemDCAPXPOCs3.Update();
                            }
                            if (listProgramContacts.ItemCount < 1)
                            {
                                oWeb.AllowUnsafeUpdates = true;
                                listItemProgramContacts1.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemProgramContacts2.Update();
                                oWeb.AllowUnsafeUpdates = true;
                                listItemProgramContacts3.Update();
                                if (ThisNetworkValue == "SIPR Net")
                                {
                                    oWeb.AllowUnsafeUpdates = true;
                                    listItemProgramContacts4.Update();
                                }
                                if (ThisNetworkValue == "NIPR Net")
                                {
                                    oWeb.AllowUnsafeUpdates = true;
                                    listItemProgramContacts5.Update();
                                    listItemProgramContacts6.Update();
                                    listItemProgramContacts7.Update();
                                    listItemProgramContacts8.Update();

                                }
                            }





                            tr = "true";


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddedItemsToLists", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }


                    }
                }

                return tr;
            }
        

    }
}
