﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class SetDefaultViewClass
    {
        internal static string SetDefaultView(string oSiteUrl, string traceInfo)
        {
            string tr = "false";

            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;
                    SPList listCONOPSDevProgress = null;
                    SPList listCONOPSApprovalProgress = null;
                    SPList listDCAPXPOCs = null;
                    SPList listFeedback = null;
                    SPList listProgramContacts = null;
                    SPList listMasterCalendar = null;

                    SPListCollection oWebLists = oWeb.Lists;


                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }
                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                        if (oList.Title == "CONOPSDevProgress")
                        {
                            listCONOPSDevProgress = oList;
                        }
                        if (oList.Title == "CONOPSApprovalProgress")
                        {
                            listCONOPSApprovalProgress = oList;
                        }
                        if (oList.Title == "DCAPXPOCs")
                        {
                            listDCAPXPOCs = oList;
                        }
                        if (oList.Title == "Feedback")
                        {
                            listFeedback = oList;
                        }
                        if (oList.Title == "ProgramContacts")
                        {
                            listProgramContacts = oList;
                        }
                        if (oList.Title == "MasterCalendar")
                        {
                            listMasterCalendar = oList;
                        }
                    }

                    SPView viewlibCONOPSDevAFOTEC = libCONOPSDevAFOTEC.DefaultView;
                    SPView viewlibCONOPSDevATEC = libCONOPSDevATEC.DefaultView;
                    SPView viewlibCONOPSDevCOTF = libCONOPSDevCOTF.DefaultView;
                    SPView viewlibCONOPSDevJITC = libCONOPSDevJITC.DefaultView;
                    SPView viewlibCONOPSDevMCOTEA = libCONOPSDevMCOTEA.DefaultView;
                    SPView viewlistCONOPSDevWSAFOTEC = listCONOPSDevWSAFOTEC.DefaultView;
                    SPView viewlistCONOPSDevWSATEC = listCONOPSDevWSATEC.DefaultView;
                    SPView viewlistCONOPSDevWSCOTF = listCONOPSDevWSCOTF.DefaultView;
                    SPView viewlistCONOPSDevWSJITC = listCONOPSDevWSJITC.DefaultView;
                    SPView viewlistCONOPSDevWSMCOTEA = listCONOPSDevWSMCOTEA.DefaultView;
                    SPView viewlistCONOPSDevProgress = listCONOPSDevProgress.DefaultView;
                    SPView viewlistCONOPSApprovalProgress = listCONOPSApprovalProgress.DefaultView;
                    SPView viewlistProgramContacts = listProgramContacts.DefaultView;
                    SPView viewlistFeedback = listFeedback.DefaultView;
                    SPView viewlistDCAPXPOCs = listDCAPXPOCs.DefaultView;
                    SPView viewlistMasterCalendar = listMasterCalendar.DefaultView;


                    //libCONOPSDevAFOTEC------------------
                    if (!libCONOPSDevAFOTEC.DefaultView.ViewFields.Exists("CONOPSApproval"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevAFOTEC list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlibCONOPSDevAFOTEC.ViewFields.Add("WS");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("OTA");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("FY");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("Submitted");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("DateDraftSaved");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("SubmittedFY");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("SubmittedBy");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("SubmittedOn");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("TimeDraftSaved");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("DraftSavedBy");
                            viewlibCONOPSDevAFOTEC.ViewFields.Add("CONOPSApproval");

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                    //libCONOPSDevATEC------------------
                    if (!libCONOPSDevATEC.DefaultView.ViewFields.Exists("CONOPSApproval"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevATEC list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlibCONOPSDevATEC.ViewFields.Add("WS");
                            viewlibCONOPSDevATEC.ViewFields.Add("OTA");
                            viewlibCONOPSDevATEC.ViewFields.Add("FY");
                            viewlibCONOPSDevATEC.ViewFields.Add("Submitted");
                            viewlibCONOPSDevATEC.ViewFields.Add("DateDraftSaved");
                            viewlibCONOPSDevATEC.ViewFields.Add("SubmittedFY");
                            viewlibCONOPSDevATEC.ViewFields.Add("SubmittedBy");
                            viewlibCONOPSDevATEC.ViewFields.Add("SubmittedOn");
                            viewlibCONOPSDevATEC.ViewFields.Add("TimeDraftSaved");
                            viewlibCONOPSDevATEC.ViewFields.Add("DraftSavedBy");
                            viewlibCONOPSDevATEC.ViewFields.Add("CONOPSApproval");



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                    //libCONOPSDevCOTF------------------
                    if (!libCONOPSDevCOTF.DefaultView.ViewFields.Exists("CONOPSApproval"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevCOTF list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlibCONOPSDevCOTF.ViewFields.Add("WS");
                            viewlibCONOPSDevCOTF.ViewFields.Add("OTA");
                            viewlibCONOPSDevCOTF.ViewFields.Add("FY");
                            viewlibCONOPSDevCOTF.ViewFields.Add("Submitted");
                            viewlibCONOPSDevCOTF.ViewFields.Add("DateDraftSaved");
                            viewlibCONOPSDevCOTF.ViewFields.Add("SubmittedFY");
                            viewlibCONOPSDevCOTF.ViewFields.Add("SubmittedBy");
                            viewlibCONOPSDevCOTF.ViewFields.Add("SubmittedOn");
                            viewlibCONOPSDevCOTF.ViewFields.Add("TimeDraftSaved");
                            viewlibCONOPSDevCOTF.ViewFields.Add("DraftSavedBy");
                            viewlibCONOPSDevCOTF.ViewFields.Add("CONOPSApproval");



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                    //libCONOPSDevJITC------------------
                    if (!libCONOPSDevJITC.DefaultView.ViewFields.Exists("CONOPSApproval"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevJITC list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlibCONOPSDevJITC.ViewFields.Add("WS");
                            viewlibCONOPSDevJITC.ViewFields.Add("OTA");
                            viewlibCONOPSDevJITC.ViewFields.Add("FY");
                            viewlibCONOPSDevJITC.ViewFields.Add("Submitted");
                            viewlibCONOPSDevJITC.ViewFields.Add("DateDraftSaved");
                            viewlibCONOPSDevJITC.ViewFields.Add("SubmittedFY");
                            viewlibCONOPSDevJITC.ViewFields.Add("SubmittedBy");
                            viewlibCONOPSDevJITC.ViewFields.Add("SubmittedOn");
                            viewlibCONOPSDevJITC.ViewFields.Add("TimeDraftSaved");
                            viewlibCONOPSDevJITC.ViewFields.Add("DraftSavedBy");
                            viewlibCONOPSDevJITC.ViewFields.Add("CONOPSApproval");



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                    //libCONOPSDevMCOTEA------------------
                    if (!libCONOPSDevMCOTEA.DefaultView.ViewFields.Exists("CONOPSApproval"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevMCOTEA list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEADefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlibCONOPSDevMCOTEA.ViewFields.Add("WS");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("OTA");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("FY");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("Submitted");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("DateDraftSaved");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("SubmittedFY");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("SubmittedBy");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("SubmittedOn");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("TimeDraftSaved");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("DraftSavedBy");
                            viewlibCONOPSDevMCOTEA.ViewFields.Add("CONOPSApproval");



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEADefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }


                    //listCONOPSDevWSAFOTEC------------------
                    if (!listCONOPSDevWSAFOTEC.DefaultView.ViewFields.Exists("ContentType"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevWSAFOTEC list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("ID");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("ContentType");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("LinkTitle");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("CONOPSApproval");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("DateDraftSaved");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("TimeDraftSaved");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("DraftSavedBy");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("FY");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Submitted");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("SubmittedBy");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("SubmittedFY");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("SubmittedOn");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("CONOPSApprovalAOReview");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("CONOPSApprovalPMReview");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("CONOPSApprovalDRReview");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("CONOPSApprovalAOComments");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("CONOPSApprovalPMComments");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("CONOPSApprovalDRComments");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Created");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Author");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Modified");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Editor");

                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("AdditionalLineItem");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Contract");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("ContractFee");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("ContractorRate");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("ContractsSubTotal");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("ContractTotal");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Dates");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("DutyTitlePosition");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Employer");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("EstLaborOvertime");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("EstTravel");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("EventLocation");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Funding");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("GovLaborMonth");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("GSLevel");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("HoursPerYear");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("MilitarySubTotal");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Number");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("OTA");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("People");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Remarks");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Status");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Total");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("Venue");
                            viewlistCONOPSDevWSAFOTEC.ViewFields.Add("VenueSubTotal");


                            string viewQuery = "<OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>";


                            viewlistCONOPSDevWSAFOTEC.Query = viewQuery;
                            viewlistCONOPSDevWSAFOTEC.RowLimit = 300;
                            viewlistCONOPSDevWSAFOTEC.Paged = true;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }


                    //listCONOPSDevWSATEC------------------

                    if (!listCONOPSDevWSATEC.DefaultView.ViewFields.Exists("ContentType"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevWSATEC list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlistCONOPSDevWSATEC.ViewFields.Add("ID");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("ContentType");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("LinkTitle");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("CONOPSApproval");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("DateDraftSaved");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("TimeDraftSaved");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("DraftSavedBy");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("FY");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Submitted");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("SubmittedBy");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("SubmittedFY");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("SubmittedOn");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("CONOPSApprovalAOReview");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("CONOPSApprovalPMReview");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("CONOPSApprovalDRReview");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("CONOPSApprovalAOComments");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("CONOPSApprovalPMComments");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("CONOPSApprovalDRComments");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Created");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Author");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Modified");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Editor");

                            viewlistCONOPSDevWSATEC.ViewFields.Add("AdditionalLineItem");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Contract");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("ContractFee");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("ContractorRate");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("ContractsSubTotal");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("ContractTotal");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Dates");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("DutyTitlePosition");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Employer");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("EstLaborOvertime");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("EstTravel");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("EventLocation");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Funding");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("GovLaborMonth");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("GSLevel");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("HoursPerYear");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("MilitarySubTotal");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Number");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("OTA");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("People");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Remarks");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Status");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Total");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("Venue");
                            viewlistCONOPSDevWSATEC.ViewFields.Add("VenueSubTotal");

                            string viewQuery = "<OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>";

                            viewlistCONOPSDevWSATEC.Query = viewQuery;
                            viewlistCONOPSDevWSATEC.RowLimit = 300;
                            viewlistCONOPSDevWSATEC.Paged = true;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }


                    //listCONOPSDevWSCOTF------------------

                    if (!listCONOPSDevWSCOTF.DefaultView.ViewFields.Exists("ContentType"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevWSCOTF list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlistCONOPSDevWSCOTF.ViewFields.Add("ID");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("ContentType");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("LinkTitle");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("CONOPSApproval");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("DateDraftSaved");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("TimeDraftSaved");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("DraftSavedBy");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("FY");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Submitted");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("SubmittedBy");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("SubmittedFY");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("SubmittedOn");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("CONOPSApprovalAOReview");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("CONOPSApprovalPMReview");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("CONOPSApprovalDRReview");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("CONOPSApprovalAOComments");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("CONOPSApprovalPMComments");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("CONOPSApprovalDRComments");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Created");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Author");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Modified");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Editor");

                            viewlistCONOPSDevWSCOTF.ViewFields.Add("AdditionalLineItem");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Contract");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("ContractFee");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("ContractorRate");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("ContractsSubTotal");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("ContractTotal");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Dates");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("DutyTitlePosition");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Employer");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("EstLaborOvertime");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("EstTravel");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("EventLocation");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Funding");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("GovLaborMonth");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("GSLevel");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("HoursPerYear");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("MilitarySubTotal");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Number");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("OTA");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("People");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Remarks");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Status");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Total");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("Venue");
                            viewlistCONOPSDevWSCOTF.ViewFields.Add("VenueSubTotal");
                            string viewQuery = "<OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>";
                            viewlistCONOPSDevWSCOTF.Query = viewQuery;
                            viewlistCONOPSDevWSCOTF.RowLimit = 300;
                            viewlistCONOPSDevWSCOTF.Paged = true;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }

                    //listCONOPSDevWSJITC------------------

                    if (!listCONOPSDevWSJITC.DefaultView.ViewFields.Exists("ContentType"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevWSJITC list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlistCONOPSDevWSJITC.ViewFields.Add("ID");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("ContentType");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("LinkTitle");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("CONOPSApproval");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("DateDraftSaved");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("TimeDraftSaved");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("DraftSavedBy");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("FY");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Submitted");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("SubmittedBy");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("SubmittedFY");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("SubmittedOn");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("CONOPSApprovalAOReview");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("CONOPSApprovalPMReview");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("CONOPSApprovalDRReview");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("CONOPSApprovalAOComments");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("CONOPSApprovalPMComments");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("CONOPSApprovalDRComments");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Created");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Author");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Modified");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Editor");

                            viewlistCONOPSDevWSJITC.ViewFields.Add("AdditionalLineItem");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Contract");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("ContractFee");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("ContractorRate");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("ContractsSubTotal");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("ContractTotal");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Dates");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("DutyTitlePosition");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Employer");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("EstLaborOvertime");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("EstTravel");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("EventLocation");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Funding");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("GovLaborMonth");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("GSLevel");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("HoursPerYear");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("MilitarySubTotal");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Number");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("OTA");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("People");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Remarks");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Status");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Total");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("Venue");
                            viewlistCONOPSDevWSJITC.ViewFields.Add("VenueSubTotal");
                            string viewQuery = "<OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>";
                            viewlistCONOPSDevWSJITC.Query = viewQuery;
                            viewlistCONOPSDevWSJITC.RowLimit = 300;
                            viewlistCONOPSDevWSJITC.Paged = true;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }



                    //listCONOPSDevWSMCOTEA------------------

                    if (!listCONOPSDevWSMCOTEA.DefaultView.ViewFields.Exists("ContentType"))
                    {
                        try
                        {
                            traceInfo = "CONOPSDevWSMCOTEA list default view";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEADefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("ID");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("ContentType");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("LinkTitle");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("CONOPSApproval");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("DateDraftSaved");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("TimeDraftSaved");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("DraftSavedBy");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("FY");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Submitted");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("SubmittedBy");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("SubmittedFY");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("SubmittedOn");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("CONOPSApprovalAOReview");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("CONOPSApprovalPMReview");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("CONOPSApprovalDRReview");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("CONOPSApprovalAOComments");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("CONOPSApprovalPMComments");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("CONOPSApprovalDRComments");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Created");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Author");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Modified");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Editor");

                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("AdditionalLineItem");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Contract");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("ContractFee");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("ContractorRate");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("ContractsSubTotal");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("ContractTotal");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Dates");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("DutyTitlePosition");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Employer");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("EstLaborOvertime");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("EstTravel");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("EventLocation");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Funding");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("GovLaborMonth");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("GSLevel");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("HoursPerYear");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("MilitarySubTotal");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Number");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("OTA");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("People");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Remarks");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Status");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Total");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("Venue");
                            viewlistCONOPSDevWSMCOTEA.ViewFields.Add("VenueSubTotal");
                            string viewQuery = "<OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>";
                            viewlistCONOPSDevWSMCOTEA.Query = viewQuery;
                            viewlistCONOPSDevWSMCOTEA.RowLimit = 300;
                            viewlistCONOPSDevWSMCOTEA.Paged = true;

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEADefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }


                    if (!listCONOPSDevProgress.DefaultView.ViewFields.Exists("OperationalTestAgency"))
                    {
                        try
                        {
                            traceInfo = "AddFields to CONOPSDevProgress list";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";



                            viewlistCONOPSDevProgress.ViewFields.Add("OperationalTestAgency");
                            viewlistCONOPSDevProgress.ViewFields.Add("WS1Progress");
                            viewlistCONOPSDevProgress.ViewFields.Add("WS2Progress");
                            viewlistCONOPSDevProgress.ViewFields.Add("WS3Progress");
                            viewlistCONOPSDevProgress.ViewFields.Add("WS4Progress");
                            viewlistCONOPSDevProgress.ViewFields.Add("WSReview");
                            viewlistCONOPSDevProgress.ViewFields.Add("ForFY");
                            viewlistCONOPSDevProgress.ViewFields.Add("SubmittedFY");
                            viewlistCONOPSDevProgress.ViewFields.Add("SubmittedBy");
                            viewlistCONOPSDevProgress.ViewFields.Add("SubmittedOn");
                            string viewQuery = "<GroupBy Collapse='FALSE'><FieldRef Name='OperationalTestAgency'/></GroupBy>";
                            viewlistCONOPSDevProgress.Query = viewQuery;


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }


                    }
                    if (!listCONOPSApprovalProgress.DefaultView.ViewFields.Exists("OperationalTestAgency"))
                    {
                        try
                        {
                            traceInfo = "AddFields to CONOPSApprovalProgress list";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";



                            viewlistCONOPSApprovalProgress.ViewFields.Add("OperationalTestAgency");
                            viewlistCONOPSApprovalProgress.ViewFields.Add("CONOPSApproval");
                            viewlistCONOPSApprovalProgress.ViewFields.Add("ForFY");
                            string viewQuery = "<GroupBy Collapse='FALSE'><FieldRef Name='OperationalTestAgency'/></GroupBy>";
                            viewlistCONOPSApprovalProgress.Query = viewQuery;


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }


                    }
                    if (!listProgramContacts.DefaultView.ViewFields.Exists("Account"))
                    {

                        try
                        {
                            traceInfo = "AddFields to ProgramContacts list";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";



                            viewlistProgramContacts.ViewFields.Add("Account");
                            viewlistProgramContacts.ViewFields.Add("OperationalTestAgency");
                            viewlistProgramContacts.ViewFields.Add("ModuleAccess");


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }


                    }
                    if (!listFeedback.DefaultView.ViewFields.Exists("Comments"))
                    {

                        try
                        {
                            traceInfo = "AddFields to Feedback list";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";



                            viewlistFeedback.ViewFields.Add("Comments");


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }


                    }
                    if (!listDCAPXPOCs.DefaultView.ViewFields.Exists("EMail"))
                    {

                        try
                        {
                            traceInfo = "AddFields to DCAPXPOCs list";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";



                            viewlistDCAPXPOCs.ViewFields.Add("EMail");
                            viewlistDCAPXPOCs.ViewFields.Add("WorkPhone");


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }


                    }
                    if (!listMasterCalendar.DefaultView.ViewFields.Exists("OperationalTestAgency"))
                    {


                        try
                        {
                            traceInfo = "AddFields to MasterCalendar list";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";



                            viewlistMasterCalendar.ViewFields.Add("OperationalTestAgency");


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                    }

                    try
                    {
                        traceInfo = "Update() views";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsSetDefaultView", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        oWeb.AllowUnsafeUpdates = true;
                        viewlibCONOPSDevAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlibCONOPSDevATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlibCONOPSDevCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlibCONOPSDevJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlibCONOPSDevMCOTEA.Update();

                        oWeb.AllowUnsafeUpdates = true;
                        viewlistCONOPSDevWSAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistCONOPSDevWSATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistCONOPSDevWSCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistCONOPSDevWSJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistCONOPSDevWSMCOTEA.Update();

                        oWeb.AllowUnsafeUpdates = true;
                        viewlistCONOPSDevProgress.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistCONOPSApprovalProgress.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistProgramContacts.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistFeedback.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistDCAPXPOCs.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        viewlistMasterCalendar.Update();

                        tr = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsSetDefaultView", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }
            }
            return tr;
        }

    }
}
