﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class QuickLaunchOnDCAPXClass
    {
        internal static string QuickLaunchOnDCAPX(string oSiteUrl, string traceInfo, string TextBox1Text)
        {
            string tr = "false";

            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {

                    try
                    {
                        //bool clearQL = false;
                        //try
                        //{
                        //    SPNavigationNodeCollection nodesSitesDCAPX = oWeb.Navigation.QuickLaunch;

                        //    //bool IsInQuickLaunchCONOPSApproval = false; int conopsapprovalqlcount = 0; 
                        //    //bool IsInQuickLaunchCONOPSDevelopment = false; int conopsdevqlcount = 0;
                        //    bool IsInQuickLaunchCONOPS = false; int conopsqlcount = 0;


                        //    bool IsInQuickLaunchMASR = false; int maserqlcount = 0;
                        //    bool IsInQuickLaunchMasterCalendar = false; int mastercalqlcount = 0;
                        //    bool IsInQuickLaunchProgramContacts = false; int progcontqlcount = 0;
                        //    bool IsInQuickLaunchDECRE = false; int decreeqlcount = 0;
                        //    bool IsInQuickLaunchFeedback = false; int feedbackqlcount = 0;
                        //    int tcount = 0;

                        //    foreach (SPNavigationNode nodeInSitesDCAPX in nodesSitesDCAPX)
                        //    {
                        //        //if (nodeInSitesDCAPX.Title == "CONOPS Approval")
                        //        //{
                        //        //    IsInQuickLaunchCONOPSApproval = true;
                        //        //    conopsapprovalqlcount = conopsapprovalqlcount + 1;
                        //        //}
                        //        //if (nodeInSitesDCAPX.Title == "CONOPS Development")
                        //        //{
                        //        //    IsInQuickLaunchCONOPSDevelopment = true;
                        //        //    conopsdevqlcount = conopsdevqlcount + 1;
                        //        //}
                        //        if (nodeInSitesDCAPX.Title == "CONOPS")
                        //        {
                        //            IsInQuickLaunchCONOPS = true;
                        //            conopsqlcount = conopsqlcount + 1;
                        //        }
                        //        if (nodeInSitesDCAPX.Title == "MASR")
                        //        {
                        //            IsInQuickLaunchMASR = true;
                        //            maserqlcount = maserqlcount + 1;
                        //        }
                        //        if (nodeInSitesDCAPX.Title == "Master Calendar")
                        //        {
                        //            IsInQuickLaunchMasterCalendar = true;
                        //            mastercalqlcount = mastercalqlcount + 1;
                        //        }
                        //        if (nodeInSitesDCAPX.Title == "Program Contacts")
                        //        {
                        //            IsInQuickLaunchProgramContacts = true;
                        //            progcontqlcount = progcontqlcount + 1;
                        //        }
                        //        if (nodeInSitesDCAPX.Title == "DECRE")
                        //        {
                        //            IsInQuickLaunchDECRE = true;
                        //            decreeqlcount = decreeqlcount + 1;
                        //        }
                        //        if (nodeInSitesDCAPX.Title == "Feedback and Comments")
                        //        {
                        //            IsInQuickLaunchFeedback = true;
                        //            feedbackqlcount = feedbackqlcount + 1;
                        //        }
                        //        tcount = conopsqlcount + maserqlcount + mastercalqlcount + progcontqlcount + decreeqlcount + feedbackqlcount;

                        //    }
                        //    if (tcount != 6 || !IsInQuickLaunchCONOPS && !IsInQuickLaunchMASR && !IsInQuickLaunchMasterCalendar && !IsInQuickLaunchProgramContacts && !IsInQuickLaunchDECRE && !IsInQuickLaunchFeedback)
                        //    {
                        //        clearQL = true;
                        //    }

                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        //}
                        //actually -- just clear it anyway

                        traceInfo = "QLaunchCountStart: " + oWeb.Navigation.QuickLaunch.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("QLaunchCountStart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            
                        SPNavigationNode[] oldNodes = new SPNavigationNode[oWeb.Navigation.QuickLaunch.Count];
                        if (oldNodes.Length > 0)
                        {
                            oWeb.Navigation.QuickLaunch.CopyTo(oldNodes, 0);
                        }
                      
                       
                            


                            //traceInfo = "Clear Quick Launch menu on " + TextBox1Text;
                            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //try
                            //{
                            //    oWeb.AllowUnsafeUpdates = true;
                            //    oWeb.QuickLaunchEnabled = true;

                            //    SPNavigationNodeCollection nodes = oWeb.Navigation.QuickLaunch;
                            //    for (int i = nodes.Count - 1; i >= 0; i--)
                            //    {
                            //        nodes[i].Delete();
                            //    }
                            //    oWeb.Update();
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedClearQL", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}
                            

                            traceInfo = "Add links to Quick Launch menu on " + TextBox1Text;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                           
                            try
                            {
                                SPNavigationNode nodeCONOPS = new SPNavigationNode("CONOPS", TextBox1Text + "/_layouts/DCAPXSolution/CONOPS.aspx", true);
                               
                                traceInfo = "create CONOPS link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeCONOPS);
                                nodeCONOPS.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddCONOPSlink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            try
                            {
                                traceInfo = "create MASR link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("MASR", TextBox1Text + "/masr", true);
                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                nodeSitesDCAPX.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddMASRlink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                         
                            try
                            {
                                traceInfo = "create Master Calendar link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("Master Calendar", TextBox1Text + "/Lists/MasterCalendar", true);
                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                nodeSitesDCAPX.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddMasterCalendarlink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                           
                            try
                            {
                                traceInfo = "create Program Contacts link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string pcLink = "javascript:OpenPopUpPage('" + TextBox1Text + "/_layouts/DCAPXSolution/ProgramContacts/ProgramContacts.aspx')";
                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("Program Contacts", pcLink, true);
                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                nodeSitesDCAPX.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddProgramContactslink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                          
                            try
                            {
                                traceInfo = "create DECRE link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("DECRE", TextBox1Text + "/decre", true);
                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                nodeSitesDCAPX.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddDECRElink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                          
                            try
                            {
                                traceInfo = "create Feedback link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string fLink = "javascript:OpenPopUpPage('" + TextBox1Text + "/_layouts/DCAPXSolution/Feedback.aspx')";
                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("Feedback and Comments", fLink, true);

                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                nodeSitesDCAPX.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddFeedbacklink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            oWeb.AllowUnsafeUpdates = true;

                            oWeb.Update();


                            //try
                            //{
                            //    SPNavigationNode nodeCONOPSDevelopment = new SPNavigationNode("Development", TextBox1Text + "/SitePages/CONOPSDevelopment.aspx");

                            //    traceInfo = "create CONOPS Development link";
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    oWeb.AllowUnsafeUpdates = true;
                            //    oWeb.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSDevelopment);
                            //    oWeb.Update();
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddDevelopmentlink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}

                            //try
                            //{
                            //    SPNavigationNode nodeCONOPSApproval = new SPNavigationNode("Approval", TextBox1Text + "/_layouts/DCAPXSolution/CONOPSApproval/CONOPSApproval.aspx");

                            //    traceInfo = "create CONOPS Approval link";
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    oWeb.AllowUnsafeUpdates = true;
                            //    oWeb.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSApproval);
                            //    oWeb.Update();
                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddApprovallink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}
                            //Moving above to updatedDCAPXHomePage.cs to be created on feature activation






                            //QL audiences

                            //try
                            //{

                            //    SPNavigationNode nodeCONOPSApproval = oWeb.Navigation.QuickLaunch[0].Children[1];
                            //    string nodeT = nodeCONOPSApproval.Title;
                            //    string TargetGroups = ";;;;CONOPSApproval,DCAPXAO,DCAPXOwners";

                            //    traceInfo = "Setting Audience for Approval link";
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            //    if (nodeT == "Approval")
                            //    {
                            //        if (nodeCONOPSApproval.Properties.Contains("Audience"))
                            //        {

                            //            traceInfo = "nodeCONOPSApproval.Properties['Audience']: " + nodeCONOPSApproval.Properties["Audience"].ToString();
                            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addAudienceApproval", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            //            nodeCONOPSApproval.Properties["Audience"] = TargetGroups;
                            //        }
                            //        else
                            //        {
                            //            nodeCONOPSApproval.Properties.Add("Audience", TargetGroups);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        traceInfo = "this node, nodeT is not set to Approval: " + nodeT;
                            //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    }
                            //    oWeb.AllowUnsafeUpdates = true;
                            //    nodeCONOPSApproval.Update();
                            //    oWeb.Update();

                            //}
                            //catch (Exception ex)
                            //{
                            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddAudienceApproval", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //}
                          
                            // Above moved to updateDCAPXHomePage.cs on Feature2 activation because it fails here
                            //Cannot complete this action error.


                            //SPNavigationNodeCollection quickLaunchMenuNodes = oWeb.Navigation.QuickLaunch;

                            //foreach (SPNavigationNode node in quickLaunchMenuNodes)
                            //{

                            //    string nodeT = node.Title;
                            //    string TargetGroups = "";

                            //    //TRY TO INTEGRATE INTO THIS LOOP
                            //    //if nodeT == "CONOPS"...update audience cor approval
                            //    if(nodeT=="CONOPS")
                            //    {
                            //        try
                            //        {
                            //            traceInfo = "DevelopmentLinkTitle: " + node.Children[0].Title + " ApprovalLinkTitle: " + node.Children[1].Title;
                            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("foundCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            //        }
                            //        catch (Exception ex)
                            //        {
                            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("trytogetconopschildren", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //        }
                            //    }

                            //    if (nodeT == "MASR")
                            //    {

                            //        try
                            //        {
                            //            TargetGroups = ";;;;DCAPXOwners";

                            //            if (node.Properties.Contains("Audience"))
                            //            {

                            //                traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                            //                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            //                node.Properties["Audience"] = TargetGroups;
                            //            }
                            //            else
                            //            {
                            //                node.Properties.Add("Audience", TargetGroups);
                            //            }
                            //        }
                            //        catch (Exception ex)
                            //        {
                            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeMASR", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        //traceInfo = "nodeT: " + nodeT;
                            //        //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    }
                            //    if (nodeT == "Master Calendar")
                            //    {

                            //        try
                            //        {
                            //            TargetGroups = ";;;;DCAPXOwners";

                            //            if (node.Properties.Contains("Audience"))
                            //            {

                            //                traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                            //                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            //                node.Properties["Audience"] = TargetGroups;
                            //            }
                            //            else
                            //            {
                            //                node.Properties.Add("Audience", TargetGroups);
                            //            }
                            //        }
                            //        catch (Exception ex)
                            //        {
                            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeMasterCalendar", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        //traceInfo = "nodeT: " + nodeT;
                            //        //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    }

                            //    if (nodeT == "DECRE")
                            //    {

                            //        try
                            //        {
                            //            TargetGroups = ";;;;DCAPXOwners";

                            //            if (node.Properties.Contains("Audience"))
                            //            {

                            //                traceInfo = "node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                            //                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            //                node.Properties["Audience"] = TargetGroups;
                            //            }
                            //            else
                            //            {
                            //                node.Properties.Add("Audience", TargetGroups);
                            //            }
                            //        }
                            //        catch (Exception ex)
                            //        {
                            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeDECRE", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            //        }
                            //    }
                            //    else
                            //    {
                            //        //traceInfo = "nodeT: " + nodeT;
                            //        //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            //    }
                            //    oWeb.AllowUnsafeUpdates = true;
                            //    node.Update();

                            //    //oWeb.ValidateFormDigest();

                            //    oWeb.Update();
                            //}





                            ////end QL audiences


                        


 
                        traceInfo = "Remove old nodes.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("removenodes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        try
                        {

                            foreach (SPNavigationNode oldNode in oldNodes)
                            {
                                oWeb.Navigation.QuickLaunch.Delete(oldNode);
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("deleteOldNodes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        oWeb.AllowUnsafeUpdates = true;
                        oWeb.Update();
                        
                        traceInfo = "QL count: " + oWeb.Navigation.QuickLaunch.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("QLCount", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if(oWeb.Navigation.QuickLaunch.Count > 5)
                        {
                            SPNavigationNodeCollection quickLaunchMenuNodes = oWeb.Navigation.QuickLaunch;
                            foreach (SPNavigationNode node in quickLaunchMenuNodes)
                            {

                                string nodeT = node.Title;
                                string TargetGroups = "";

                                
                                if (nodeT == "MASR")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = nodeT + " node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeMASR", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                              
                                if (nodeT == "Master Calendar")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = nodeT + " node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeMasterCalendar", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                               

                                if (nodeT == "DECRE")
                                {

                                    try
                                    {
                                        TargetGroups = ";;;;DCAPXOwners";

                                        if (node.Properties.Contains("Audience"))
                                        {

                                            traceInfo = nodeT + " node.Properties['Audience']: " + node.Properties["Audience"].ToString();
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("AddAudienceForQL", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                            node.Properties["Audience"] = TargetGroups;
                                        }
                                        else
                                        {
                                            node.Properties.Add("Audience", TargetGroups);
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("nodeDECRE", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                               
                                oWeb.AllowUnsafeUpdates = true;
                                node.Update();
                                oWeb.Update();
                            }





                            //end QL audiences
                        }

                        traceInfo = "CONOPS Children should be less than 1: " + oWeb.Navigation.QuickLaunch[0].Children.Count;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("IsCONOPSChildrenCleared", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        traceInfo = "first link should be CONOPS: " + oWeb.Navigation.QuickLaunch[0].Title;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("firstLinkCheck", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        if (oWeb.Navigation.QuickLaunch[0].Children.Count < 1 && oWeb.Navigation.QuickLaunch[0].Title == "CONOPS")
                        {
                            try
                            {
                                SPNavigationNode nodeCONOPSDevelopment = new SPNavigationNode("Development", TextBox1Text + "/SitePages/CONOPSDevelopment.aspx");

                                traceInfo = "create CONOPS Development link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSDevelopment);
                                nodeCONOPSDevelopment.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddDevelopmentlink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                SPNavigationNode nodeCONOPSApproval = new SPNavigationNode("Approval", TextBox1Text + "/_layouts/DCAPXSolution/CONOPSApproval/CONOPSApproval.aspx");

                                traceInfo = "create CONOPS Approval link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSApproval);
                                nodeCONOPSApproval.Update();
                                //oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddApprovallink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                        oWeb.AllowUnsafeUpdates = true;
                        oWeb.Update();


                        traceInfo = "Try to add audience for Approval link.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingAudience", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        try
                        {
                            string TargetGroups = ";;;;CONOPSApproval,DCAPXAO,DCAPXOwners";
                            SPNavigationNode ApprovalNode = oWeb.Navigation.QuickLaunch[0].Children[1];
                            if(ApprovalNode.Title == "Approval")
                            {
                                if (ApprovalNode.Properties.Contains("Audience"))
                                {
                                    traceInfo = ApprovalNode.Title + " hasAudience: " + ApprovalNode.Properties["Audience"].ToString();
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("hasAudience", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    ApprovalNode.Properties["Audience"] = TargetGroups;
                                }
                                else
                                {
                                    traceInfo = ApprovalNode.Title + " does not have audience so adding one.";
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("hasAudience", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    ApprovalNode.Properties.Add("Audience", TargetGroups);
                                }
                                oWeb.AllowUnsafeUpdates = true;
                                ApprovalNode.Update();
                                oWeb.Update();
                            }
                            
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("failedAddApprovallink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                     


                        tr = "true";

                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }
            return tr;
        }

    }
}
