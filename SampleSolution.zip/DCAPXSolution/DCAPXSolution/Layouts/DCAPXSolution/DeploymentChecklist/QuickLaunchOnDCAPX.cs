﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Navigation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class QuickLaunchOnDCAPXClass
    {
        internal static string QuickLaunchOnDCAPX(string oSiteUrl, string traceInfo, string TextBox1Text)
        {
            string tr = "false";

            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {

                    try
                    {
                        bool clearQL = false;
                        try
                        {
                            SPNavigationNodeCollection nodesSitesDCAPX = oWeb.Navigation.QuickLaunch;

                            //bool IsInQuickLaunchCONOPSApproval = false; int conopsapprovalqlcount = 0; 
                            //bool IsInQuickLaunchCONOPSDevelopment = false; int conopsdevqlcount = 0;
                            bool IsInQuickLaunchCONOPS = false; int conopsqlcount = 0;


                            bool IsInQuickLaunchMASR = false; int maserqlcount = 0;
                            bool IsInQuickLaunchMasterCalendar = false; int mastercalqlcount = 0;
                            bool IsInQuickLaunchProgramContacts = false; int progcontqlcount = 0;
                            bool IsInQuickLaunchDECRE = false; int decreeqlcount = 0;
                            bool IsInQuickLaunchFeedback = false; int feedbackqlcount = 0;
                            int tcount = 0;

                            foreach (SPNavigationNode nodeInSitesDCAPX in nodesSitesDCAPX)
                            {
                                //if (nodeInSitesDCAPX.Title == "CONOPS Approval")
                                //{
                                //    IsInQuickLaunchCONOPSApproval = true;
                                //    conopsapprovalqlcount = conopsapprovalqlcount + 1;
                                //}
                                //if (nodeInSitesDCAPX.Title == "CONOPS Development")
                                //{
                                //    IsInQuickLaunchCONOPSDevelopment = true;
                                //    conopsdevqlcount = conopsdevqlcount + 1;
                                //}
                                if (nodeInSitesDCAPX.Title == "CONOPS")
                                {
                                    IsInQuickLaunchCONOPS = true;
                                    conopsqlcount = conopsqlcount + 1;
                                }
                                if (nodeInSitesDCAPX.Title == "MASR")
                                {
                                    IsInQuickLaunchMASR = true;
                                    maserqlcount = maserqlcount + 1;
                                }
                                if (nodeInSitesDCAPX.Title == "Master Calendar")
                                {
                                    IsInQuickLaunchMasterCalendar = true;
                                    mastercalqlcount = mastercalqlcount + 1;
                                }
                                if (nodeInSitesDCAPX.Title == "Program Contacts")
                                {
                                    IsInQuickLaunchProgramContacts = true;
                                    progcontqlcount = progcontqlcount + 1;
                                }
                                if (nodeInSitesDCAPX.Title == "DECRE")
                                {
                                    IsInQuickLaunchDECRE = true;
                                    decreeqlcount = decreeqlcount + 1;
                                }
                                if (nodeInSitesDCAPX.Title == "Feedback and Comments")
                                {
                                    IsInQuickLaunchFeedback = true;
                                    feedbackqlcount = feedbackqlcount + 1;
                                }
                                tcount = conopsqlcount + maserqlcount + mastercalqlcount + progcontqlcount + decreeqlcount + feedbackqlcount;

                            }
                            if (tcount != 6 || !IsInQuickLaunchCONOPS && !IsInQuickLaunchMASR && !IsInQuickLaunchMasterCalendar && !IsInQuickLaunchProgramContacts && !IsInQuickLaunchDECRE && !IsInQuickLaunchFeedback)
                            {
                                clearQL = true;
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        //actually -- just clear it anyway
                        clearQL = true;
                        if (clearQL)
                        {
                            traceInfo = "Clear Quick Launch menu on " + TextBox1Text;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            try
                            {
                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.QuickLaunchEnabled = true;

                                SPNavigationNodeCollection nodes = oWeb.Navigation.QuickLaunch;
                                for (int i = nodes.Count - 1; i >= 0; i--)
                                {
                                    nodes[i].Delete();
                                }
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            traceInfo = "Add links to Quick Launch menu on " + TextBox1Text;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                           
                            try
                            {
                                SPNavigationNode nodeCONOPS = new SPNavigationNode("CONOPS", TextBox1Text + "/_layouts/DCAPXSolution/CONOPS.aspx", true);
                               
                                traceInfo = "create CONOPS link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeCONOPS);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                            try
                            {
                                SPNavigationNode nodeCONOPSDevelopment = new SPNavigationNode("Development", TextBox1Text + "/SitePages/CONOPSDevelopment.aspx");

                                traceInfo = "create CONOPS Development link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSDevelopment);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            try
                            {
                                SPNavigationNode nodeCONOPSApproval = new SPNavigationNode("Approval", TextBox1Text + "/_layouts/DCAPXSolution/CONOPSApproval/CONOPSApproval.aspx");

                                traceInfo = "create CONOPS Approval link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch[0].Children.AddAsLast(nodeCONOPSApproval);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }





                            



                            try
                            {

                                SPNavigationNode nodeCONOPSApproval = oWeb.Navigation.QuickLaunch[0].Children[1];
                                string nodeT = nodeCONOPSApproval.Title;
                                string TargetGroups = ";;;;CONOPSApproval,DCAPXAO,DCAPXOwners";


                                traceInfo = "Setting Audience for Approval link";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                if (nodeT == "Approval")
                                {
                                    if (nodeCONOPSApproval.Properties.Contains("Audience"))
                                    {

                                        traceInfo = "nodeCONOPSApproval.Properties['Audience']: " + nodeCONOPSApproval.Properties["Audience"].ToString();
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                                        nodeCONOPSApproval.Properties["Audience"] = TargetGroups;
                                    }
                                    else
                                    {
                                        nodeCONOPSApproval.Properties.Add("Audience", TargetGroups);
                                    }
                                }
                                else
                                {
                                    traceInfo = "this node, nodeT is not set to Approval: " + nodeT;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }

                                nodeCONOPSApproval.Update();
                                oWeb.Update();

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            //--end CONOPS Development and Approval --


                            try
                            {
                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("MASR", TextBox1Text + "/masr", true);
                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("Master Calendar", TextBox1Text + "/Lists/MasterCalendar", true);
                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                string pcLink = "javascript:OpenPopUpPage('" + TextBox1Text + "/_layouts/DCAPXSolution/ProgramContacts/ProgramContacts.aspx')";
                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("Program Contacts", pcLink, true);
                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("DECRE", TextBox1Text + "/decre", true);
                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                            try
                            {
                                string fLink = "javascript:OpenPopUpPage('" + TextBox1Text + "/_layouts/DCAPXSolution/Feedback.aspx')";
                                SPNavigationNode nodeSitesDCAPX = new SPNavigationNode("Feedback and Comments", fLink, true);

                                oWeb.AllowUnsafeUpdates = true;
                                oWeb.Navigation.QuickLaunch.AddAsLast(nodeSitesDCAPX);
                                oWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }


                        }

                        tr = "true";

                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsQuickLaunch", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }
            return tr;
        }

    }
}
