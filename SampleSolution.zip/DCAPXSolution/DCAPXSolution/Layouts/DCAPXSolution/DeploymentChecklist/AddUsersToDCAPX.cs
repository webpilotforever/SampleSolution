﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class AddUsersToDCAPXClass
    {
        internal static void AddUsersToDCAPX(string oSiteUrl, string traceInfo, string ThisNetworkValue)
        {


            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {

                    if (ThisNetworkValue == "SIPR Net")
                    {
                        try
                        {
                            traceInfo = "addUsersToDCAPX resource\\danielnw";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("resource\\danielnw");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcedanielnw", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX resource\\aoberg";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("resource\\aoberg");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceaoberg", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX resource\\clarkrm";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("resource\\clarkrm");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceclarkrm", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX resource\\clarkr-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("resource\\clarkr-p");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceclarkr-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX SHAREPOINT\\system";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("SHAREPOINT\\system");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcesystem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                    }
                    else
                    {
                        try
                        {
                            traceInfo = "addUsersToDCAPX SHAREPOINT\\system";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("SHAREPOINT\\system");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcesystem", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX dotedresource\\danielnw-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("dotedresource\\danielnw-p");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcedanielnw-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX dotedresource\\oberga-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\oberga-p");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceoberga-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX dotedresource\\clarkrm-p";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPUser oUser = oWeb.EnsureUser("dotedresource\\clarkrm-p");
                            oUser.IsSiteAdmin = true;
                            oWeb.AllowUnsafeUpdates = true;
                            oUser.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourceclarkrm-p", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                            traceInfo = "addUsersToDCAPX dotedresource\\sp-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddUsersToDCAPX", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\sp-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsAddResourcesp-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {
                            traceInfo = "addUsersToDCAPX dotedresource\\oberga-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXoberga-test", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\oberga-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXoberga-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {
                            traceInfo = "addUsersToDCAPX dotedresource\\clarkrm-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXclarkrm-test", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\clarkrm-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXclarkrm-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                        try
                        {
                            traceInfo = "addUsersToDCAPX dotedresource\\danielnw-test";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXdanielnw-test", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            oWeb.EnsureUser("dotedresource\\danielnw-test");
                            oWeb.AllowUnsafeUpdates = true;
                            oWeb.Update();


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXdanielnw-test", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                    }

                }
            }
        }

    }
}
