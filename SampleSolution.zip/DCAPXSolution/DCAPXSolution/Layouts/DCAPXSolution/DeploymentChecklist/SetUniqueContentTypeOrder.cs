﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class SetUniqueContentTypeOrderClass
    {
        internal static string SetUniqueContentTypeOrder(string oSiteUrl, string traceInfo)
        {
            string tr = "false";


            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;
                    SPList listCONOPSDevProgress = null;
                    SPList listCONOPSApprovalProgress = null;
                    SPList listDCAPXPOCs = null;
                    SPList listFeedback = null;
                    SPList listProgramContacts = null;
                    SPList listMasterCalendar = null;
                    SPContentTypeCollection libCONOPSDevAFOTECContentTypes = null;
                    SPContentTypeCollection libCONOPSDevATECContentTypes = null;
                    SPContentTypeCollection libCONOPSDevCOTFContentTypes = null;
                    SPContentTypeCollection libCONOPSDevJITCContentTypes = null;
                    SPContentTypeCollection libCONOPSDevMCOTEAContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSAFOTECContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSATECContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSCOTFContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSJITCContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSMCOTEAContentTypes = null;
                    SPContentTypeCollection listCONOPSDevProgressContentTypes = null;
                    SPContentTypeCollection listCONOPSApprovalProgressContentTypes = null;
                    SPContentTypeCollection listProgramContactsContentTypes = null;
                    SPContentTypeCollection listFeedbackContentTypes = null;
                    SPContentTypeCollection listDCAPXPOCsContentTypes = null;
                    SPContentTypeCollection listMasterCalendarContentTypes = null;
                    SPListCollection oWebLists = oWeb.Lists;


                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }
                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                        if (oList.Title == "CONOPSDevProgress")
                        {
                            listCONOPSDevProgress = oList;
                        }
                        if (oList.Title == "CONOPSApprovalProgress")
                        {
                            listCONOPSApprovalProgress = oList;
                        }
                        if (oList.Title == "DCAPXPOCs")
                        {
                            listDCAPXPOCs = oList;
                        }
                        if (oList.Title == "Feedback")
                        {
                            listFeedback = oList;
                        }
                        if (oList.Title == "ProgramContacts")
                        {
                            listProgramContacts = oList;
                        }
                        if (oList.Title == "MasterCalendar")
                        {
                            listMasterCalendar = oList;
                        }
                    }
                    if (libCONOPSDevAFOTEC != null)
                    {
                        libCONOPSDevAFOTECContentTypes = libCONOPSDevAFOTEC.ContentTypes;
                    }
                    if (libCONOPSDevATEC != null)
                    {
                        libCONOPSDevATECContentTypes = libCONOPSDevATEC.ContentTypes;
                    }
                    if (libCONOPSDevCOTF != null)
                    {
                        libCONOPSDevCOTFContentTypes = libCONOPSDevCOTF.ContentTypes;
                    }
                    if (libCONOPSDevJITC != null)
                    {
                        libCONOPSDevJITCContentTypes = libCONOPSDevJITC.ContentTypes;
                    }
                    if (libCONOPSDevMCOTEA != null)
                    {
                        libCONOPSDevMCOTEAContentTypes = libCONOPSDevMCOTEA.ContentTypes;
                    }


                    if (listCONOPSDevWSAFOTEC != null)
                    {
                        listCONOPSDevWSAFOTECContentTypes = listCONOPSDevWSAFOTEC.ContentTypes;
                    }
                    if (listCONOPSDevWSATEC != null)
                    {
                        listCONOPSDevWSATECContentTypes = listCONOPSDevWSATEC.ContentTypes;
                    }
                    if (listCONOPSDevWSCOTF != null)
                    {
                        listCONOPSDevWSCOTFContentTypes = listCONOPSDevWSCOTF.ContentTypes;
                    }
                    if (listCONOPSDevWSJITC != null)
                    {
                        listCONOPSDevWSJITCContentTypes = listCONOPSDevWSJITC.ContentTypes;
                    }
                    if (listCONOPSDevWSMCOTEA != null)
                    {
                        listCONOPSDevWSMCOTEAContentTypes = listCONOPSDevWSMCOTEA.ContentTypes;
                    }


                    if (listCONOPSDevProgress != null)
                    {
                        listCONOPSDevProgressContentTypes = listCONOPSDevProgress.ContentTypes;
                    }
                    if (listCONOPSApprovalProgress != null)
                    {
                        listCONOPSApprovalProgressContentTypes = listCONOPSApprovalProgress.ContentTypes;
                    }
                    if (listDCAPXPOCs != null)
                    {
                        listDCAPXPOCsContentTypes = listDCAPXPOCs.ContentTypes;
                    }
                    if (listFeedback != null)
                    {
                        listFeedbackContentTypes = listFeedback.ContentTypes;
                    }
                    if (listProgramContacts != null)
                    {
                        listProgramContactsContentTypes = listProgramContacts.ContentTypes;
                    }
                    if (listMasterCalendar != null)
                    {
                        listMasterCalendarContentTypes = listMasterCalendar.ContentTypes;
                    }

                    SPContentType ctCONOPSAttachment = oWeb.ContentTypes["CONOPSAttachment"];
                    SPContentType ctWS1 = oWeb.ContentTypes["WS1"];
                    SPContentType ctWS2 = oWeb.ContentTypes["WS2"];
                    SPContentType ctWS3 = oWeb.ContentTypes["WS3"];
                    SPContentType ctWS4 = oWeb.ContentTypes["WS4"];
                    SPContentType ctCONOPSDevProgress = oWeb.ContentTypes["CONOPSDevProgress"];
                    SPContentType ctCONOPSApprovalProgress = oWeb.ContentTypes["CONOPSApprovalProgress"];
                    SPContentType ctProgramContacts = oWeb.ContentTypes["ProgramContacts"];
                    SPContentType ctFeedback = oWeb.ContentTypes["Feedback"];
                    SPContentType ctDCAPXPOCs = oWeb.ContentTypes["DCAPXPOCs"];
                    SPContentType ctMasterCalendar = oWeb.ContentTypes["MasterCalendar"];

                    if (libCONOPSDevAFOTECContentTypes[ctCONOPSAttachment.Name] != null)
                    {
                        if (libCONOPSDevAFOTEC.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctCONOPSAttachment.Name + " Content Type the default on " + libCONOPSDevAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> libCONOPSDevAFOTECctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in libCONOPSDevAFOTECContentTypes)
                                {
                                    if (ct.Name.Contains("CONOPSAttachment"))
                                    {
                                        libCONOPSDevAFOTECctOrder.Add(ct);
                                    }

                                }
                                libCONOPSDevAFOTEC.RootFolder.UniqueContentTypeOrder = libCONOPSDevAFOTECctOrder;

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                    }
                    if (libCONOPSDevATECContentTypes[ctCONOPSAttachment.Name] != null)
                    {
                        if (libCONOPSDevATEC.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctCONOPSAttachment.Name + " Content Type the default on " + libCONOPSDevATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> libCONOPSDevATECctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in libCONOPSDevATECContentTypes)
                                {
                                    if (ct.Name.Contains("CONOPSAttachment"))
                                    {
                                        libCONOPSDevATECctOrder.Add(ct);
                                    }

                                }
                                libCONOPSDevATEC.RootFolder.UniqueContentTypeOrder = libCONOPSDevATECctOrder;

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                    }
                    if (libCONOPSDevCOTFContentTypes[ctCONOPSAttachment.Name] != null)
                    {
                        if (libCONOPSDevCOTF.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctCONOPSAttachment.Name + " Content Type the default on " + libCONOPSDevCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> libCONOPSDevCOTFctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in libCONOPSDevCOTFContentTypes)
                                {
                                    if (ct.Name.Contains("CONOPSAttachment"))
                                    {
                                        libCONOPSDevCOTFctOrder.Add(ct);
                                    }

                                }
                                libCONOPSDevCOTF.RootFolder.UniqueContentTypeOrder = libCONOPSDevCOTFctOrder;

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                    }
                    if (libCONOPSDevJITCContentTypes[ctCONOPSAttachment.Name] != null)
                    {
                        if (libCONOPSDevJITC.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctCONOPSAttachment.Name + " Content Type the default on " + libCONOPSDevJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> libCONOPSDevJITCctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in libCONOPSDevJITCContentTypes)
                                {
                                    if (ct.Name.Contains("CONOPSAttachment"))
                                    {
                                        libCONOPSDevJITCctOrder.Add(ct);
                                    }

                                }
                                libCONOPSDevJITC.RootFolder.UniqueContentTypeOrder = libCONOPSDevJITCctOrder;

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                    }
                    if (libCONOPSDevMCOTEAContentTypes[ctCONOPSAttachment.Name] != null)
                    {
                        if (libCONOPSDevMCOTEA.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctCONOPSAttachment.Name + " Content Type the default on " + libCONOPSDevMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEActOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> libCONOPSDevMCOTEActOrder = new List<SPContentType>();
                                foreach (SPContentType ct in libCONOPSDevMCOTEAContentTypes)
                                {
                                    if (ct.Name.Contains("CONOPSAttachment"))
                                    {
                                        libCONOPSDevMCOTEActOrder.Add(ct);
                                    }

                                }
                                libCONOPSDevMCOTEA.RootFolder.UniqueContentTypeOrder = libCONOPSDevMCOTEActOrder;

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEActOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }

                    }
                    if (listCONOPSDevWSAFOTECContentTypes[ctWS1.Name] != null && listCONOPSDevWSAFOTECContentTypes[ctWS2.Name] != null && listCONOPSDevWSAFOTECContentTypes[ctWS3.Name] != null && listCONOPSDevWSAFOTECContentTypes[ctWS4.Name] != null)
                    {
                        if (listCONOPSDevWSAFOTEC.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctWS1.Name + " Content Type the default on " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listCONOPSDevWSAFOTECctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listCONOPSDevWSAFOTECContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listCONOPSDevWSAFOTECctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("WS1"))
                                    {
                                        listCONOPSDevWSAFOTECctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS2"))
                                    {
                                        listCONOPSDevWSAFOTECctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS3"))
                                    {
                                        listCONOPSDevWSAFOTECctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS4"))
                                    {
                                        listCONOPSDevWSAFOTECctOrder.Add(ct);
                                    }


                                }
                                listCONOPSDevWSAFOTEC.RootFolder.UniqueContentTypeOrder = listCONOPSDevWSAFOTECctOrder;



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    if (listCONOPSDevWSATECContentTypes[ctWS1.Name] != null && listCONOPSDevWSATECContentTypes[ctWS2.Name] != null && listCONOPSDevWSATECContentTypes[ctWS3.Name] != null && listCONOPSDevWSATECContentTypes[ctWS4.Name] != null)
                    {
                        if (listCONOPSDevWSATEC.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctWS1.Name + " Content Type the default on " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listCONOPSDevWSATECctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listCONOPSDevWSATECContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listCONOPSDevWSATECctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("WS1"))
                                    {
                                        listCONOPSDevWSATECctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS2"))
                                    {
                                        listCONOPSDevWSATECctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS3"))
                                    {
                                        listCONOPSDevWSATECctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS4"))
                                    {
                                        listCONOPSDevWSATECctOrder.Add(ct);
                                    }


                                }
                                listCONOPSDevWSATEC.RootFolder.UniqueContentTypeOrder = listCONOPSDevWSATECctOrder;



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }


                    if (listCONOPSDevWSCOTFContentTypes[ctWS1.Name] != null && listCONOPSDevWSCOTFContentTypes[ctWS2.Name] != null && listCONOPSDevWSCOTFContentTypes[ctWS3.Name] != null && listCONOPSDevWSCOTFContentTypes[ctWS4.Name] != null)
                    {
                        if (listCONOPSDevWSCOTF.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctWS1.Name + " Content Type the default on " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listCONOPSDevWSCOTFctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listCONOPSDevWSCOTFContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listCONOPSDevWSCOTFctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("WS1"))
                                    {
                                        listCONOPSDevWSCOTFctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS2"))
                                    {
                                        listCONOPSDevWSCOTFctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS3"))
                                    {
                                        listCONOPSDevWSCOTFctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS4"))
                                    {
                                        listCONOPSDevWSCOTFctOrder.Add(ct);
                                    }


                                }
                                listCONOPSDevWSCOTF.RootFolder.UniqueContentTypeOrder = listCONOPSDevWSCOTFctOrder;



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    if (listCONOPSDevWSJITCContentTypes[ctWS1.Name] != null && listCONOPSDevWSJITCContentTypes[ctWS2.Name] != null && listCONOPSDevWSJITCContentTypes[ctWS3.Name] != null && listCONOPSDevWSJITCContentTypes[ctWS4.Name] != null)
                    {
                        if (listCONOPSDevWSJITC.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctWS1.Name + " Content Type the default on " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listCONOPSDevWSJITCctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listCONOPSDevWSJITCContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listCONOPSDevWSJITCctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("WS1"))
                                    {
                                        listCONOPSDevWSJITCctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS2"))
                                    {
                                        listCONOPSDevWSJITCctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS3"))
                                    {
                                        listCONOPSDevWSJITCctOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS4"))
                                    {
                                        listCONOPSDevWSJITCctOrder.Add(ct);
                                    }


                                }
                                listCONOPSDevWSJITC.RootFolder.UniqueContentTypeOrder = listCONOPSDevWSJITCctOrder;



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    if (listCONOPSDevWSMCOTEAContentTypes[ctWS1.Name] != null && listCONOPSDevWSMCOTEAContentTypes[ctWS2.Name] != null && listCONOPSDevWSMCOTEAContentTypes[ctWS3.Name] != null && listCONOPSDevWSMCOTEAContentTypes[ctWS4.Name] != null)
                    {
                        if (listCONOPSDevWSMCOTEA.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctWS1.Name + " Content Type the default on " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEActOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listCONOPSDevWSMCOTEActOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listCONOPSDevWSMCOTEAContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listCONOPSDevWSMCOTEActOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("WS1"))
                                    {
                                        listCONOPSDevWSMCOTEActOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS2"))
                                    {
                                        listCONOPSDevWSMCOTEActOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS3"))
                                    {
                                        listCONOPSDevWSMCOTEActOrder.Add(ct);
                                    }
                                    if (ct.Name.Contains("WS4"))
                                    {
                                        listCONOPSDevWSMCOTEActOrder.Add(ct);
                                    }


                                }
                                listCONOPSDevWSMCOTEA.RootFolder.UniqueContentTypeOrder = listCONOPSDevWSMCOTEActOrder;



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEActOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }


                    if (listCONOPSDevProgressContentTypes[ctCONOPSDevProgress.Name] != null)
                    {
                        if (listCONOPSDevProgress.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctCONOPSDevProgress.Name + " Content Type the default on " + listCONOPSDevProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevProgressctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listCONOPSDevProgressctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listCONOPSDevProgressContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listCONOPSDevProgressctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("CONOPSDevProgress"))
                                    {
                                        listCONOPSDevProgressctOrder.Add(ct);
                                    }


                                }
                                listCONOPSDevProgress.RootFolder.UniqueContentTypeOrder = listCONOPSDevProgressctOrder;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevProgressctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    if (listCONOPSApprovalProgressContentTypes[ctCONOPSApprovalProgress.Name] != null)
                    {
                        if (listCONOPSApprovalProgress.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctCONOPSApprovalProgress.Name + " Content Type the default on " + listCONOPSApprovalProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSApprovalProgressctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listCONOPSApprovalProgressctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listCONOPSApprovalProgressContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listCONOPSApprovalProgressctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("CONOPSApprovalProgress"))
                                    {
                                        listCONOPSApprovalProgressctOrder.Add(ct);
                                    }


                                }
                                listCONOPSApprovalProgress.RootFolder.UniqueContentTypeOrder = listCONOPSApprovalProgressctOrder;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSApprovalProgressctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    if (listProgramContactsContentTypes[ctProgramContacts.Name] != null)
                    {
                        if (listProgramContacts.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctProgramContacts.Name + " Content Type the default on " + listProgramContacts.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistProgramContactsctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listProgramContactsctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listProgramContactsContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listProgramContactsctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("ProgramContacts"))
                                    {
                                        listProgramContactsctOrder.Add(ct);
                                    }


                                }
                                listProgramContacts.RootFolder.UniqueContentTypeOrder = listProgramContactsctOrder;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistProgramContactsctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }

                    if (listFeedbackContentTypes[ctFeedback.Name] != null)
                    {
                        if (listFeedback.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctFeedback.Name + " Content Type the default on " + listFeedback.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistFeedbackctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listFeedbackctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listFeedbackContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listFeedbackctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("Feedback"))
                                    {
                                        listFeedbackctOrder.Add(ct);
                                    }


                                }
                                listFeedback.RootFolder.UniqueContentTypeOrder = listFeedbackctOrder;


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistFeedbackctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    if (listDCAPXPOCsContentTypes[ctDCAPXPOCs.Name] != null)
                    {
                        if (listDCAPXPOCs.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctDCAPXPOCs.Name + " Content Type the default on " + listDCAPXPOCs.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistDCAPXPOCsctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listDCAPXPOCsctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listDCAPXPOCsContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listDCAPXPOCsctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("DCAPXPOCs"))
                                    {
                                        listDCAPXPOCsctOrder.Add(ct);
                                    }


                                }
                                listDCAPXPOCs.RootFolder.UniqueContentTypeOrder = listDCAPXPOCsctOrder;



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistDCAPXPOCsctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    if (listMasterCalendarContentTypes[ctMasterCalendar.Name] != null)
                    {
                        if (listMasterCalendar.RootFolder.UniqueContentTypeOrder == null)
                        {
                            try
                            {
                                traceInfo = "Add UniqueContentTypeOrder to make " + ctMasterCalendar.Name + " Content Type the default on " + listMasterCalendar.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistMasterCalendarctOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                List<SPContentType> listMasterCalendarctOrder = new List<SPContentType>();
                                foreach (SPContentType ct in listMasterCalendarContentTypes)
                                {
                                    if (ct.Name.Contains("Item"))
                                    {
                                        listMasterCalendarctOrder.Remove(ct);
                                    }
                                    if (ct.Name.Contains("MasterCalendar"))
                                    {
                                        listMasterCalendarctOrder.Add(ct);
                                    }


                                }
                                listMasterCalendar.RootFolder.UniqueContentTypeOrder = listMasterCalendarctOrder;



                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistMasterCalendarctOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }


                    }
                    try
                    {
                        traceInfo = "Update() lists";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetUniqueContentTypeOrder", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevAFOTEC.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevATEC.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevCOTF.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevJITC.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevMCOTEA.RootFolder.Update();

                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSAFOTEC.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSATEC.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSCOTF.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSJITC.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSMCOTEA.RootFolder.Update();

                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevProgress.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSApprovalProgress.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listProgramContacts.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listFeedback.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listDCAPXPOCs.RootFolder.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listMasterCalendar.RootFolder.Update();

                        tr = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetUniqueContentTypeOrder", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }
            return tr;
        }

    }
}
