﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class SetContentTypesClass
    {
        internal static string SetContentTypes(string oSiteUrl, string traceInfo)
        {
            string tr = "false";

            traceInfo = "setContentTypes";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            using (SPSite oSite = new SPSite(oSiteUrl))
            {
                traceInfo = "got site";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    traceInfo = "got web";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    SPDocumentLibrary libCONOPSDevAFOTEC = null;
                    SPDocumentLibrary libCONOPSDevATEC = null;
                    SPDocumentLibrary libCONOPSDevCOTF = null;
                    SPDocumentLibrary libCONOPSDevJITC = null;
                    SPDocumentLibrary libCONOPSDevMCOTEA = null;
                    SPList listCONOPSDevWSAFOTEC = null;
                    SPList listCONOPSDevWSATEC = null;
                    SPList listCONOPSDevWSCOTF = null;
                    SPList listCONOPSDevWSJITC = null;
                    SPList listCONOPSDevWSMCOTEA = null;
                    SPList listCONOPSDevProgress = null;
                    SPList listCONOPSApprovalProgress = null;
                    SPList listDCAPXPOCs = null;
                    SPList listFeedback = null;
                    SPList listProgramContacts = null;
                    SPList listMasterCalendar = null;
                    SPContentTypeCollection libCONOPSDevAFOTECContentTypes = null;
                    SPContentTypeCollection libCONOPSDevATECContentTypes = null;
                    SPContentTypeCollection libCONOPSDevCOTFContentTypes = null;
                    SPContentTypeCollection libCONOPSDevJITCContentTypes = null;
                    SPContentTypeCollection libCONOPSDevMCOTEAContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSAFOTECContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSATECContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSCOTFContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSJITCContentTypes = null;
                    SPContentTypeCollection listCONOPSDevWSMCOTEAContentTypes = null;
                    SPContentTypeCollection listCONOPSDevProgressContentTypes = null;
                    SPContentTypeCollection listCONOPSApprovalProgressContentTypes = null;
                    SPContentTypeCollection listProgramContactsContentTypes = null;
                    SPContentTypeCollection listFeedbackContentTypes = null;
                    SPContentTypeCollection listDCAPXPOCsContentTypes = null;
                    SPContentTypeCollection listMasterCalendarContentTypes = null;
                    SPListCollection oWebLists = oWeb.Lists;

                    traceInfo = "declared vars";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    foreach (SPList oList in oWebLists)
                    {
                        if (oList.BaseType == SPBaseType.DocumentLibrary)
                        {
                            if (oList.Title == "CONOPSDevAFOTEC")
                            {
                                libCONOPSDevAFOTEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevATEC")
                            {
                                libCONOPSDevATEC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevCOTF")
                            {
                                libCONOPSDevCOTF = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevJITC")
                            {
                                libCONOPSDevJITC = (SPDocumentLibrary)oList;
                            }
                            if (oList.Title == "CONOPSDevMCOTEA")
                            {
                                libCONOPSDevMCOTEA = (SPDocumentLibrary)oList;
                            }
                        }
                        if (oList.Title == "CONOPSDevWSAFOTEC")
                        {
                            listCONOPSDevWSAFOTEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSATEC")
                        {
                            listCONOPSDevWSATEC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSCOTF")
                        {
                            listCONOPSDevWSCOTF = oList;
                        }
                        if (oList.Title == "CONOPSDevWSJITC")
                        {
                            listCONOPSDevWSJITC = oList;
                        }
                        if (oList.Title == "CONOPSDevWSMCOTEA")
                        {
                            listCONOPSDevWSMCOTEA = oList;
                        }
                        if (oList.Title == "CONOPSDevProgress")
                        {
                            listCONOPSDevProgress = oList;
                        }
                        if (oList.Title == "CONOPSApprovalProgress")
                        {
                            listCONOPSApprovalProgress = oList;
                        }
                        if (oList.Title == "DCAPXPOCs")
                        {
                            listDCAPXPOCs = oList;
                        }
                        if (oList.Title == "Feedback")
                        {
                            listFeedback = oList;
                        }
                        if (oList.Title == "ProgramContacts")
                        {
                            listProgramContacts = oList;
                        }
                        if (oList.Title == "MasterCalendar")
                        {
                            listMasterCalendar = oList;
                        }
                    }
                    traceInfo = "set vars";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (libCONOPSDevAFOTEC != null)
                    {
                        libCONOPSDevAFOTECContentTypes = libCONOPSDevAFOTEC.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "libCONOPSDevAFOTEC is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (libCONOPSDevATEC != null)
                    {
                        libCONOPSDevATECContentTypes = libCONOPSDevATEC.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "libCONOPSDevATEC is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (libCONOPSDevCOTF != null)
                    {
                        libCONOPSDevCOTFContentTypes = libCONOPSDevCOTF.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "libCONOPSDevCOTF is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (libCONOPSDevJITC != null)
                    {
                        libCONOPSDevJITCContentTypes = libCONOPSDevJITC.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "libCONOPSDevJITC is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (libCONOPSDevMCOTEA != null)
                    {
                        libCONOPSDevMCOTEAContentTypes = libCONOPSDevMCOTEA.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "libCONOPSDevMCOTEA is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    traceInfo = "set lib content types";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    if (listCONOPSDevWSAFOTEC != null)
                    {
                        listCONOPSDevWSAFOTECContentTypes = listCONOPSDevWSAFOTEC.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listCONOPSDevWSAFOTEC is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listCONOPSDevWSATEC != null)
                    {
                        listCONOPSDevWSATECContentTypes = listCONOPSDevWSATEC.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listCONOPSDevWSATEC is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listCONOPSDevWSCOTF != null)
                    {
                        listCONOPSDevWSCOTFContentTypes = listCONOPSDevWSCOTF.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listCONOPSDevWSCOTF is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listCONOPSDevWSJITC != null)
                    {
                        listCONOPSDevWSJITCContentTypes = listCONOPSDevWSJITC.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listCONOPSDevWSJITC is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listCONOPSDevWSMCOTEA != null)
                    {
                        listCONOPSDevWSMCOTEAContentTypes = listCONOPSDevWSMCOTEA.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listCONOPSDevWSMCOTEA is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    traceInfo = "set conops list content types";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    if (listCONOPSDevProgress != null)
                    {
                        listCONOPSDevProgressContentTypes = listCONOPSDevProgress.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listCONOPSDevProgress is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listCONOPSApprovalProgress != null)
                    {
                        listCONOPSApprovalProgressContentTypes = listCONOPSApprovalProgress.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listCONOPSApprovalProgress is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listDCAPXPOCs != null)
                    {
                        listDCAPXPOCsContentTypes = listDCAPXPOCs.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listDCAPXPOCs is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listFeedback != null)
                    {
                        listFeedbackContentTypes = listFeedback.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listFeedback is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listProgramContacts != null)
                    {
                        listProgramContactsContentTypes = listProgramContacts.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listProgramContacts is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    if (listMasterCalendar != null)
                    {
                        listMasterCalendarContentTypes = listMasterCalendar.ContentTypes;
                    }
                    else
                    {
                        traceInfo = "listMasterCalendar is null";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    traceInfo = "set other lists content types";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    SPContentType ctCONOPSAttachment = oWeb.ContentTypes["CONOPSAttachment"];
                    SPContentType ctWS1 = oWeb.ContentTypes["WS1"];
                    SPContentType ctWS2 = oWeb.ContentTypes["WS2"];
                    SPContentType ctWS3 = oWeb.ContentTypes["WS3"];
                    SPContentType ctWS4 = oWeb.ContentTypes["WS4"];
                    SPContentType ctCONOPSDevProgress = oWeb.ContentTypes["CONOPSDevProgress"];
                    SPContentType ctCONOPSApprovalProgress = oWeb.ContentTypes["CONOPSApprovalProgress"];
                    SPContentType ctProgramContacts = oWeb.ContentTypes["ProgramContacts"];
                    SPContentType ctFeedback = oWeb.ContentTypes["Feedback"];
                    SPContentType ctDCAPXPOCs = oWeb.ContentTypes["DCAPXPOCs"];
                    SPContentType ctMasterCalendar = oWeb.ContentTypes["MasterCalendar"];

                    traceInfo = "set ct vars";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    //=================


                    if (libCONOPSDevAFOTECContentTypes[ctCONOPSAttachment.Name] == null)
                    {
                        try
                        {
                            if (!libCONOPSDevAFOTEC.IsContentTypeAllowed(ctCONOPSAttachment))
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is not allowed on the " + libCONOPSDevAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (libCONOPSDevAFOTECContentTypes[ctCONOPSAttachment.Name] != null)
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is already in use on the " + libCONOPSDevAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctCONOPSAttachment.Name + " Content Type to the " + libCONOPSDevAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                libCONOPSDevAFOTECContentTypes.Add(ctCONOPSAttachment);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevAFOTECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (libCONOPSDevATECContentTypes[ctCONOPSAttachment.Name] == null)
                    {
                        try
                        {
                            if (!libCONOPSDevATEC.IsContentTypeAllowed(ctCONOPSAttachment))
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is not allowed on the " + libCONOPSDevATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (libCONOPSDevATECContentTypes[ctCONOPSAttachment.Name] != null)
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is already in use on the " + libCONOPSDevATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctCONOPSAttachment.Name + " Content Type to the " + libCONOPSDevATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                libCONOPSDevATECContentTypes.Add(ctCONOPSAttachment);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevATECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (libCONOPSDevCOTFContentTypes[ctCONOPSAttachment.Name] == null)
                    {
                        try
                        {
                            if (!libCONOPSDevCOTF.IsContentTypeAllowed(ctCONOPSAttachment))
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is not allowed on the " + libCONOPSDevCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (libCONOPSDevCOTFContentTypes[ctCONOPSAttachment.Name] != null)
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is already in use on the " + libCONOPSDevCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctCONOPSAttachment.Name + " Content Type to the " + libCONOPSDevCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                libCONOPSDevCOTFContentTypes.Add(ctCONOPSAttachment);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevCOTFContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (libCONOPSDevJITCContentTypes[ctCONOPSAttachment.Name] == null)
                    {
                        try
                        {
                            if (!libCONOPSDevJITC.IsContentTypeAllowed(ctCONOPSAttachment))
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is not allowed on the " + libCONOPSDevJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (libCONOPSDevJITCContentTypes[ctCONOPSAttachment.Name] != null)
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is already in use on the " + libCONOPSDevJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctCONOPSAttachment.Name + " Content Type to the " + libCONOPSDevJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                libCONOPSDevJITCContentTypes.Add(ctCONOPSAttachment);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevJITCContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (libCONOPSDevMCOTEAContentTypes[ctCONOPSAttachment.Name] == null)
                    {
                        try
                        {
                            if (!libCONOPSDevMCOTEA.IsContentTypeAllowed(ctCONOPSAttachment))
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is not allowed on the " + libCONOPSDevMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (libCONOPSDevMCOTEAContentTypes[ctCONOPSAttachment.Name] != null)
                            {
                                traceInfo = "The " + ctCONOPSAttachment.Name + " Content Type is already in use on the " + libCONOPSDevMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctCONOPSAttachment.Name + " Content Type to the " + libCONOPSDevMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                libCONOPSDevMCOTEAContentTypes.Add(ctCONOPSAttachment);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslibCONOPSDevMCOTEAContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }

                    if (listCONOPSDevWSAFOTECContentTypes[ctWS1.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSAFOTEC.IsContentTypeAllowed(ctWS1))
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is not allowed on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSAFOTECContentTypes[ctWS1.Name] != null)
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is already in use on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS1.Name + " Content Type to the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSAFOTECContentTypes.Add(ctWS1);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSAFOTECContentTypes[ctWS2.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSAFOTEC.IsContentTypeAllowed(ctWS2))
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is not allowed on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSAFOTECContentTypes[ctWS2.Name] != null)
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is already in use on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS2.Name + " Content Type to the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSAFOTECContentTypes.Add(ctWS2);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSAFOTECContentTypes[ctWS3.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSAFOTEC.IsContentTypeAllowed(ctWS3))
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is not allowed on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSAFOTECContentTypes[ctWS3.Name] != null)
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is already in use on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS3.Name + " Content Type to the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSAFOTECContentTypes.Add(ctWS3);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSAFOTECContentTypes[ctWS4.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSAFOTEC.IsContentTypeAllowed(ctWS4))
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is not allowed on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSAFOTECContentTypes[ctWS4.Name] != null)
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is already in use on the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS4.Name + " Content Type to the " + listCONOPSDevWSAFOTEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSAFOTECContentTypes.Add(ctWS4);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSAFOTECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSATECContentTypes[ctWS1.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSATEC.IsContentTypeAllowed(ctWS1))
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is not allowed on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSATECContentTypes[ctWS1.Name] != null)
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is already in use on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS1.Name + " Content Type to the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSATECContentTypes.Add(ctWS1);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSATECContentTypes[ctWS2.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSATEC.IsContentTypeAllowed(ctWS2))
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is not allowed on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSATECContentTypes[ctWS2.Name] != null)
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is already in use on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS2.Name + " Content Type to the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSATECContentTypes.Add(ctWS2);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSATECContentTypes[ctWS3.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSATEC.IsContentTypeAllowed(ctWS3))
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is not allowed on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSATECContentTypes[ctWS3.Name] != null)
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is already in use on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS3.Name + " Content Type to the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSATECContentTypes.Add(ctWS3);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSATECContentTypes[ctWS4.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSATEC.IsContentTypeAllowed(ctWS4))
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is not allowed on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSATECContentTypes[ctWS4.Name] != null)
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is already in use on the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS4.Name + " Content Type to the " + listCONOPSDevWSATEC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSATECContentTypes.Add(ctWS4);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSATECContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSCOTFContentTypes[ctWS1.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSCOTF.IsContentTypeAllowed(ctWS1))
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is not allowed on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSCOTFContentTypes[ctWS1.Name] != null)
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is already in use on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS1.Name + " Content Type to the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSCOTFContentTypes.Add(ctWS1);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSCOTFContentTypes[ctWS2.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSCOTF.IsContentTypeAllowed(ctWS2))
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is not allowed on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSCOTFContentTypes[ctWS2.Name] != null)
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is already in use on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS2.Name + " Content Type to the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSCOTFContentTypes.Add(ctWS2);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSCOTFContentTypes[ctWS3.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSCOTF.IsContentTypeAllowed(ctWS3))
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is not allowed on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSCOTFContentTypes[ctWS3.Name] != null)
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is already in use on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS3.Name + " Content Type to the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSCOTFContentTypes.Add(ctWS3);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSCOTFContentTypes[ctWS4.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSCOTF.IsContentTypeAllowed(ctWS4))
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is not allowed on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSCOTFContentTypes[ctWS4.Name] != null)
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is already in use on the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS4.Name + " Content Type to the " + listCONOPSDevWSCOTF.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSCOTFContentTypes.Add(ctWS4);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSCOTFContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSJITCContentTypes[ctWS1.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSJITC.IsContentTypeAllowed(ctWS1))
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is not allowed on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSJITCContentTypes[ctWS1.Name] != null)
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is already in use on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS1.Name + " Content Type to the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSJITCContentTypes.Add(ctWS1);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSJITCContentTypes[ctWS2.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSJITC.IsContentTypeAllowed(ctWS2))
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is not allowed on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSJITCContentTypes[ctWS2.Name] != null)
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is already in use on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS2.Name + " Content Type to the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSJITCContentTypes.Add(ctWS2);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSJITCContentTypes[ctWS3.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSJITC.IsContentTypeAllowed(ctWS3))
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is not allowed on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSJITCContentTypes[ctWS3.Name] != null)
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is already in use on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS3.Name + " Content Type to the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSJITCContentTypes.Add(ctWS3);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSJITCContentTypes[ctWS4.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSJITC.IsContentTypeAllowed(ctWS4))
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is not allowed on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSJITCContentTypes[ctWS4.Name] != null)
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is already in use on the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS4.Name + " Content Type to the " + listCONOPSDevWSJITC.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSJITCContentTypes.Add(ctWS4);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSJITCContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSMCOTEAContentTypes[ctWS1.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSMCOTEA.IsContentTypeAllowed(ctWS1))
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is not allowed on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSMCOTEAContentTypes[ctWS1.Name] != null)
                            {
                                traceInfo = "The " + ctWS1.Name + " Content Type is already in use on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS1.Name + " Content Type to the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSMCOTEAContentTypes.Add(ctWS1);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSMCOTEAContentTypes[ctWS2.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSMCOTEA.IsContentTypeAllowed(ctWS2))
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is not allowed on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSMCOTEAContentTypes[ctWS2.Name] != null)
                            {
                                traceInfo = "The " + ctWS2.Name + " Content Type is already in use on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS2.Name + " Content Type to the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSMCOTEAContentTypes.Add(ctWS2);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSMCOTEAContentTypes[ctWS3.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSMCOTEA.IsContentTypeAllowed(ctWS3))
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is not allowed on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSMCOTEAContentTypes[ctWS3.Name] != null)
                            {
                                traceInfo = "The " + ctWS3.Name + " Content Type is already in use on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS3.Name + " Content Type to the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSMCOTEAContentTypes.Add(ctWS3);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSDevWSMCOTEAContentTypes[ctWS4.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevWSMCOTEA.IsContentTypeAllowed(ctWS4))
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is not allowed on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevWSMCOTEAContentTypes[ctWS4.Name] != null)
                            {
                                traceInfo = "The " + ctWS4.Name + " Content Type is already in use on the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctWS4.Name + " Content Type to the " + listCONOPSDevWSMCOTEA.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevWSMCOTEAContentTypes.Add(ctWS4);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevWSMCOTEAContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }

                    if (listCONOPSDevProgressContentTypes[ctCONOPSDevProgress.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSDevProgress.IsContentTypeAllowed(ctCONOPSDevProgress))
                            {
                                traceInfo = "The " + ctCONOPSDevProgress.Name + " Content Type is not allowed on the " + listCONOPSDevProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevProgressContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSDevProgressContentTypes[ctCONOPSDevProgress.Name] != null)
                            {
                                traceInfo = "The " + ctCONOPSDevProgress.Name + " Content Type is already in use on the " + listCONOPSDevProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevProgressContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctCONOPSDevProgress.Name + " Content Type to the " + listCONOPSDevProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevProgressContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSDevProgressContentTypes.Add(ctCONOPSDevProgress);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSDevProgressContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listCONOPSApprovalProgressContentTypes[ctCONOPSApprovalProgress.Name] == null)
                    {
                        try
                        {
                            if (!listCONOPSApprovalProgress.IsContentTypeAllowed(ctCONOPSApprovalProgress))
                            {
                                traceInfo = "The " + ctCONOPSApprovalProgress.Name + " Content Type is not allowed on the " + listCONOPSApprovalProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSApprovalProgressContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listCONOPSApprovalProgressContentTypes[ctCONOPSApprovalProgress.Name] != null)
                            {
                                traceInfo = "The " + ctCONOPSApprovalProgress.Name + " Content Type is already in use on the " + listCONOPSApprovalProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSApprovalProgressContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctCONOPSApprovalProgress.Name + " Content Type to the " + listCONOPSApprovalProgress.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSApprovalProgressContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listCONOPSApprovalProgressContentTypes.Add(ctCONOPSApprovalProgress);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistCONOPSApprovalProgressContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listFeedbackContentTypes[ctFeedback.Name] == null)
                    {
                        try
                        {
                            if (!listFeedback.IsContentTypeAllowed(ctFeedback))
                            {
                                traceInfo = "The " + ctFeedback.Name + " Content Type is not allowed on the " + listFeedback.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistFeedbackContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listFeedbackContentTypes[ctFeedback.Name] != null)
                            {
                                traceInfo = "The " + ctFeedback.Name + " Content Type is already in use on the " + listFeedback.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistFeedbackContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctFeedback.Name + " Content Type to the " + listFeedback.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistFeedbackContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listFeedbackContentTypes.Add(ctFeedback);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistFeedbackContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }
                    if (listDCAPXPOCsContentTypes[ctDCAPXPOCs.Name] == null)
                    {
                        try
                        {
                            if (!listDCAPXPOCs.IsContentTypeAllowed(ctDCAPXPOCs))
                            {
                                traceInfo = "The " + ctDCAPXPOCs.Name + " Content Type is not allowed on the " + listDCAPXPOCs.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistDCAPXPOCsContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listDCAPXPOCsContentTypes[ctDCAPXPOCs.Name] != null)
                            {
                                traceInfo = "The " + ctDCAPXPOCs.Name + " Content Type is already in use on the " + listDCAPXPOCs.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistDCAPXPOCsContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctDCAPXPOCs.Name + " Content Type to the " + listDCAPXPOCs.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistDCAPXPOCsContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listDCAPXPOCsContentTypes.Add(ctDCAPXPOCs);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistDCAPXPOCsContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }

                    if (listProgramContactsContentTypes[ctProgramContacts.Name] == null)
                    {
                        try
                        {
                            if (!listProgramContacts.IsContentTypeAllowed(ctProgramContacts))
                            {
                                traceInfo = "The " + ctProgramContacts.Name + " Content Type is not allowed on the " + listProgramContacts.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistProgramContactsContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listProgramContactsContentTypes[ctProgramContacts.Name] != null)
                            {
                                traceInfo = "The " + ctProgramContacts.Name + " Content Type is already in use on the " + listProgramContacts.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistProgramContactsContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctProgramContacts.Name + " Content Type to the " + listProgramContacts.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistProgramContactsContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listProgramContactsContentTypes.Add(ctProgramContacts);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistProgramContactsContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }

                    if (listMasterCalendarContentTypes[ctMasterCalendar.Name] == null)
                    {
                        try
                        {
                            if (!listMasterCalendar.IsContentTypeAllowed(ctMasterCalendar))
                            {
                                traceInfo = "The " + ctMasterCalendar.Name + " Content Type is not allowed on the " + listMasterCalendar.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistMasterCalendarContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else if (listMasterCalendarContentTypes[ctMasterCalendar.Name] != null)
                            {
                                traceInfo = "The " + ctMasterCalendar.Name + " Content Type is already in use on the " + listMasterCalendar.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistMasterCalendarContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            }
                            else
                            {
                                traceInfo = "Now add " + ctMasterCalendar.Name + " Content Type to the " + listMasterCalendar.Title + " list";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistMasterCalendarContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                listMasterCalendarContentTypes.Add(ctMasterCalendar);


                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventslistMasterCalendarContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                    }

                    try
                    {
                        traceInfo = "Update() lists";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        libCONOPSDevMCOTEA.Update();


                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSAFOTEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSATEC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSCOTF.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSJITC.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevWSMCOTEA.Update();

                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSDevProgress.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listCONOPSApprovalProgress.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listProgramContacts.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listFeedback.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listDCAPXPOCs.Update();
                        oWeb.AllowUnsafeUpdates = true;
                        listMasterCalendar.Update();

                        tr = "true";
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventssetContentTypes", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }

                }
            }


            return tr;
        }

    }
}
