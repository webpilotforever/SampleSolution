﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class RemoveGroupsSubWebsClass
    {
        internal static string RemoveGroupsSubWebs(string oSiteUrl, string traceInfo)
        {
            string tr = "false";

            try
            {

                using (SPSite oSite = new SPSite(oSiteUrl))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        using (SPWeb amWeb = oWeb.Webs["am"])
                        {
                            traceInfo = "amWeb RemoveGroups";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsamWebRemoveGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                SPGroupCollection collGroups = amWeb.Groups;
                                if (collGroups["CONOPSApproval"] != null)
                                {
                                    collGroups.Remove("CONOPSApproval");
                                }
                                if (collGroups["CONOPSDevReadersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersAFOTEC");
                                }
                                if (collGroups["CONOPSDevReadersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersATEC");
                                }
                                if (collGroups["CONOPSDevReadersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersCOTF");
                                }
                                if (collGroups["CONOPSDevReadersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersJITC");
                                }
                                if (collGroups["CONOPSDevReadersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersMCOTEA");
                                }
                                if (collGroups["CONOPSDevSubmittersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersAFOTEC");
                                }
                                if (collGroups["CONOPSDevSubmittersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersATEC");
                                }
                                if (collGroups["CONOPSDevSubmittersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersCOTF");
                                }
                                if (collGroups["CONOPSDevSubmittersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersJITC");
                                }
                                if (collGroups["CONOPSDevSubmittersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersMCOTEA");
                                }

                                amWeb.AllowUnsafeUpdates = true;
                                amWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveGroupsSubWebs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }



                        }
                        //using (SPWeb aadWeb = oWeb.Webs["aad"])
                        //{
                        //    traceInfo = "aadWeb RemoveGroups";
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaadWebRemoveGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        //    try
                        //    {
                        //        SPGroupCollection collGroups = aadWeb.Groups;
                        //        if (collGroups["CONOPSApproval"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSApproval");
                        //        }
                        //        if (collGroups["CONOPSDevReadersAFOTEC"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevReadersAFOTEC");
                        //        }
                        //        if (collGroups["CONOPSDevReadersATEC"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevReadersATEC");
                        //        }
                        //        if (collGroups["CONOPSDevReadersCOTF"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevReadersCOTF");
                        //        }
                        //        if (collGroups["CONOPSDevReadersJITC"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevReadersJITC");
                        //        }
                        //        if (collGroups["CONOPSDevReadersMCOTEA"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevReadersMCOTEA");
                        //        }
                        //        if (collGroups["CONOPSDevSubmittersAFOTEC"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevSubmittersAFOTEC");
                        //        }
                        //        if (collGroups["CONOPSDevSubmittersATEC"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevSubmittersATEC");
                        //        }
                        //        if (collGroups["CONOPSDevSubmittersCOTF"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevSubmittersCOTF");
                        //        }
                        //        if (collGroups["CONOPSDevSubmittersJITC"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevSubmittersJITC");
                        //        }
                        //        if (collGroups["CONOPSDevSubmittersMCOTEA"] != null)
                        //        {
                        //            collGroups.Remove("CONOPSDevSubmittersMCOTEA");
                        //        }

                        //        aadWeb.AllowUnsafeUpdates = true;
                        //        aadWeb.Update();
                        //    }
                        //    catch (Exception ex)
                        //    {
                        //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveGroupsSubWebs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        //    }

                        //}
                        using (SPWeb decreWeb = oWeb.Webs["decre"])
                        {
                            traceInfo = "decreWeb RemoveGroups";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdecreWebRemoveGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                SPGroupCollection collGroups = decreWeb.Groups;
                                if (collGroups["CONOPSApproval"] != null)
                                {
                                    collGroups.Remove("CONOPSApproval");
                                }
                                if (collGroups["CONOPSDevReadersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersAFOTEC");
                                }
                                if (collGroups["CONOPSDevReadersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersATEC");
                                }
                                if (collGroups["CONOPSDevReadersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersCOTF");
                                }
                                if (collGroups["CONOPSDevReadersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersJITC");
                                }
                                if (collGroups["CONOPSDevReadersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersMCOTEA");
                                }
                                if (collGroups["CONOPSDevSubmittersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersAFOTEC");
                                }
                                if (collGroups["CONOPSDevSubmittersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersATEC");
                                }
                                if (collGroups["CONOPSDevSubmittersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersCOTF");
                                }
                                if (collGroups["CONOPSDevSubmittersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersJITC");
                                }
                                if (collGroups["CONOPSDevSubmittersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersMCOTEA");
                                }

                                decreWeb.AllowUnsafeUpdates = true;
                                decreWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveGroupsSubWebs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }

                        }
                        using (SPWeb masrWeb = oWeb.Webs["masr"])
                        {
                            traceInfo = "masrWeb RemoveGroups";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsmasrWebRemoveGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                SPGroupCollection collGroups = masrWeb.Groups;
                                if (collGroups["CONOPSApproval"] != null)
                                {
                                    collGroups.Remove("CONOPSApproval");
                                }
                                if (collGroups["CONOPSDevReadersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersAFOTEC");
                                }
                                if (collGroups["CONOPSDevReadersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersATEC");
                                }
                                if (collGroups["CONOPSDevReadersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersCOTF");
                                }
                                if (collGroups["CONOPSDevReadersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersJITC");
                                }
                                if (collGroups["CONOPSDevReadersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersMCOTEA");
                                }
                                if (collGroups["CONOPSDevSubmittersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersAFOTEC");
                                }
                                if (collGroups["CONOPSDevSubmittersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersATEC");
                                }
                                if (collGroups["CONOPSDevSubmittersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersCOTF");
                                }
                                if (collGroups["CONOPSDevSubmittersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersJITC");
                                }
                                if (collGroups["CONOPSDevSubmittersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersMCOTEA");
                                }

                                masrWeb.AllowUnsafeUpdates = true;
                                masrWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveGroupsSubWebs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }

                        }
                        using (SPWeb raWeb = oWeb.Webs["ra"])
                        {
                            traceInfo = "raWeb RemoveGroups";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsraWebRemoveGroup", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            try
                            {
                                SPGroupCollection collGroups = raWeb.Groups;
                                if (collGroups["CONOPSApproval"] != null)
                                {
                                    collGroups.Remove("CONOPSApproval");
                                }
                                if (collGroups["CONOPSDevReadersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersAFOTEC");
                                }
                                if (collGroups["CONOPSDevReadersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersATEC");
                                }
                                if (collGroups["CONOPSDevReadersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersCOTF");
                                }
                                if (collGroups["CONOPSDevReadersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersJITC");
                                }
                                if (collGroups["CONOPSDevReadersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevReadersMCOTEA");
                                }
                                if (collGroups["CONOPSDevSubmittersAFOTEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersAFOTEC");
                                }
                                if (collGroups["CONOPSDevSubmittersATEC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersATEC");
                                }
                                if (collGroups["CONOPSDevSubmittersCOTF"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersCOTF");
                                }
                                if (collGroups["CONOPSDevSubmittersJITC"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersJITC");
                                }
                                if (collGroups["CONOPSDevSubmittersMCOTEA"] != null)
                                {
                                    collGroups.Remove("CONOPSDevSubmittersMCOTEA");
                                }

                                raWeb.AllowUnsafeUpdates = true;
                                raWeb.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveGroupsSubWebs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                            }

                        }
                    }
                }

                tr = "true";

            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("Group cannot be found."))
                {
                    tr = "true";
                }
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsremoveGroupsSubWebs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            }

            return tr;
        }

    }
}
