﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Administration.Claims;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DCAPXSolution.Layouts.DCAPXSolution.DeploymentChecklist
{
    class AddInitialUsersToGroupsClass
    {
        internal static string AddInitialUsersToGroups(string oSiteUrl, string traceInfo, string ThisNetworkValue)
        {
            string tr = "false";
            
            //setting to true so deployment checklist will not abort on error
            tr = "true";

            if (ThisNetworkValue == "SIPR Net")
            {

                SPClaimProviderManager cpm = SPClaimProviderManager.Local;
                SPClaim AllisonClaim = null;
                SPClaim NealClaim = null;
                SPClaim BobClaim = null;
                SPClaim Bob2Claim = null;

                try
                {
                    AllisonClaim = cpm.ConvertIdentifierToClaim("resource\\aoberg", SPIdentifierTypes.WindowsSamAccountName);
                    NealClaim = cpm.ConvertIdentifierToClaim("resource\\danielnwg", SPIdentifierTypes.WindowsSamAccountName);
                    BobClaim = cpm.ConvertIdentifierToClaim("resource\\clarkrm", SPIdentifierTypes.WindowsSamAccountName);
                    Bob2Claim = cpm.ConvertIdentifierToClaim("resource\\clarkr-p", SPIdentifierTypes.WindowsSamAccountName);



                }
                catch (Exception ex)
                {

                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                }

                using (SPSite oSite = new SPSite(oSiteUrl))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {

                        SPUser Allison = null;
                        SPUser Neal = null;
                        SPUser Bob = null;
                        SPUser Bob2 = null;
                        
                        try
                        {

                            Allison = oWeb.EnsureUser(AllisonClaim.ToEncodedString());
                            Neal = oWeb.EnsureUser(NealClaim.ToEncodedString());
                            Bob = oWeb.EnsureUser(BobClaim.ToEncodedString());
                            Bob2 = oWeb.EnsureUser(Bob2Claim.ToEncodedString()); 
                          


                        }
                        catch (Exception ex)
                        {

                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }
                        try
                        {
                           

                            SPGroup DCAPXOwners = oWeb.SiteGroups["DCAPXOwners"];
                            SPGroup DCAPXOTA = oWeb.SiteGroups["DCAPXOTA"];
                            SPGroup DCAPXAO = oWeb.SiteGroups["DCAPXAO"];
                            SPGroup CONOPSDevReadersAFOTEC = oWeb.SiteGroups["CONOPSDevReadersAFOTEC"];
                            SPGroup CONOPSDevReadersATEC = oWeb.SiteGroups["CONOPSDevReadersATEC"];
                            SPGroup CONOPSDevReadersCOTF = oWeb.SiteGroups["CONOPSDevReadersCOTF"];

                            SPGroup CONOPSDevSubmittersAFOTEC = oWeb.SiteGroups["CONOPSDevSubmittersAFOTEC"];
                            SPGroup CONOPSDevSubmittersATEC = oWeb.SiteGroups["CONOPSDevSubmittersATEC"];
                            SPGroup CONOPSDevSubmittersCOTF = oWeb.SiteGroups["CONOPSDevSubmittersCOTF"];

                            try
                            {
                                traceInfo = "Adding resource\\aoberg to " + CONOPSDevReadersAFOTEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersAFOTEC.AddUser(Allison);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersAFOTEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\aoberg to " + CONOPSDevSubmittersAFOTEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersAFOTEC.AddUser(Allison);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersAFOTEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\aoberg to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(Allison);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding resource\\danielnw to " + CONOPSDevReadersATEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersATEC.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersATEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\danielnw to " + CONOPSDevSubmittersATEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersATEC.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersATEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\danielnw to " + DCAPXOwners.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOwners.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOwners.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\danielnw to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding resource\\clarkrm to " + CONOPSDevReadersCOTF.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersCOTF.AddUser(Bob);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersCOTF.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\clarkrm to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(Bob);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\clarkr-p to " + CONOPSDevReadersCOTF.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersCOTF.AddUser(Bob2);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersCOTF.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\clarkr-p to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(Bob2);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\clarkrm to " + CONOPSDevSubmittersCOTF.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersCOTF.AddUser(Bob);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersCOTF.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\clarkr-p to " + CONOPSDevSubmittersCOTF.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersCOTF.AddUser(Bob2);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersCOTF.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding resource\\clarkr-p to " + DCAPXOwners.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOwners.AddUser(Bob2);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOwners.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            tr = "true";
                        }
                        catch (Exception ex)
                        {
                        
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                    }
                }

            }
            else
            {
                using (SPSite oSite = new SPSite(oSiteUrl))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {

                        try
                        {
                            SPUser Allison = oWeb.AllUsers["dotedresource\\oberga-p"];
                            SPUser Neal = oWeb.AllUsers["dotedresource\\danielnw-p"];
                            SPUser Bob = oWeb.AllUsers["dotedresource\\clarkrm-p"];
                            SPUser SPTest = oWeb.AllUsers["dotedresource\\sp-test"];
                            SPUser AllisonTest = oWeb.AllUsers["dotedresource\\oberga-test"];
                            SPUser BobTest = oWeb.AllUsers["dotedresource\\clarkrm-test"];
                            SPUser NealTest = oWeb.AllUsers["dotedresource\\danielnw-test"];


                            SPGroup DCAPXOwners = oWeb.SiteGroups["DCAPXOwners"];
                            SPGroup DCAPXOTA = oWeb.SiteGroups["DCAPXOTA"];
                            SPGroup DCAPXAO = oWeb.SiteGroups["DCAPXAO"];
                            SPGroup CONOPSDevReadersAFOTEC = oWeb.SiteGroups["CONOPSDevReadersAFOTEC"];
                            SPGroup CONOPSDevReadersATEC = oWeb.SiteGroups["CONOPSDevReadersATEC"];
                            SPGroup CONOPSDevReadersCOTF = oWeb.SiteGroups["CONOPSDevReadersCOTF"];
                            SPGroup CONOPSDevReadersMCOTEA = oWeb.SiteGroups["CONOPSDevReadersMCOTEA"];

                            SPGroup CONOPSDevSubmittersAFOTEC = oWeb.SiteGroups["CONOPSDevSubmittersAFOTEC"];
                            SPGroup CONOPSDevSubmittersATEC = oWeb.SiteGroups["CONOPSDevSubmittersATEC"];
                            SPGroup CONOPSDevSubmittersCOTF = oWeb.SiteGroups["CONOPSDevSubmittersCOTF"];
                            SPGroup CONOPSDevSubmittersMCOTEA = oWeb.SiteGroups["CONOPSDevSubmittersMCOTEA"];
                            try
                            {
                                traceInfo = "Adding dotedresource\\oberga-p to " + CONOPSDevReadersAFOTEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersAFOTEC.AddUser(Allison);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersAFOTEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\oberga-p to " + CONOPSDevSubmittersAFOTEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersAFOTEC.AddUser(Allison);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersAFOTEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\oberga-p to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(Allison);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding dotedresource\\danielnw-p to " + CONOPSDevReadersATEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersATEC.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersATEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\danielnw-p to " + CONOPSDevSubmittersATEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersATEC.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersATEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\danielnw-p to " + DCAPXOwners.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOwners.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOwners.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\danielnw-p to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(Neal);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\clarkrm-p to " + CONOPSDevReadersCOTF.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersCOTF.AddUser(Bob);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersCOTF.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding dotedresource\\clarkrm-p to " + CONOPSDevSubmittersCOTF.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersCOTF.AddUser(Bob);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersCOTF.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\clarkrm-p to " + DCAPXOwners.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOwners.AddUser(Bob);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOwners.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\clarkrm-p to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(Bob);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }
                            try
                            {
                                traceInfo = "Adding dotedresource\\sp-test to " + CONOPSDevReadersMCOTEA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersMCOTEA.AddUser(SPTest);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersMCOTEA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding dotedresource\\danielnw-test to " + CONOPSDevReadersATEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersATEC.AddUser(NealTest);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersATEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }


                            try
                            {
                                traceInfo = "Adding dotedresource\\oberga-test to " + CONOPSDevReadersAFOTEC.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersAFOTEC.AddUser(AllisonTest);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersAFOTEC.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding dotedresource\\clarkrm-test to " + CONOPSDevReadersCOTF.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevReadersCOTF.AddUser(BobTest);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevReadersCOTF.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }



                            try
                            {
                                traceInfo = "Adding dotedresource\\sp-test to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(SPTest);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }


                            try
                            {
                                traceInfo = "Adding dotedresource\\oberga-test to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(AllisonTest);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding dotedresource\\clarkrm-test to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(BobTest);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding dotedresource\\danielnw-test to " + DCAPXOTA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                DCAPXOTA.AddUser(NealTest);
                                oWeb.AllowUnsafeUpdates = true;
                                DCAPXOTA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }

                            try
                            {
                                traceInfo = "Adding dotedresource\\sp-test to " + CONOPSDevSubmittersMCOTEA.Name;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); //traceInfoDiv.InnerHtml += traceInfo + "<br />";
                                CONOPSDevSubmittersMCOTEA.AddUser(SPTest);
                                oWeb.AllowUnsafeUpdates = true;
                                CONOPSDevSubmittersMCOTEA.Update();
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                            }



                            tr = "true";
                        }
                        catch (Exception ex)
                        {
                           
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsaddInitialUsersToGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); //traceInfoDiv.InnerHtml += ex.Message + "<br />";
                        }

                    }
                }
            }

            return tr;
        }

    }
}
