﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DCAPXSolution.Layouts.DCAPXSolution
{
    public partial class CONOPS : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
