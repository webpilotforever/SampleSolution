using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;

namespace DCAPXSolution.Features.Feature3
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>
    /// 


    [Guid("8528b4bc-11e6-44d1-8b95-ec473c1ecaf1")]
    public class Feature3EventReceiver : SPFeatureReceiver
    {
        

        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {



            string featureName = "DCAPXSolution_Feature3";

            var traceInfo = "Set Feature Name to: " + featureName;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            DateTime thisUpdate = DateTime.Now;
            string todaysUpdate = "";

            todaysUpdate = thisUpdate.ToString("d");

            using (SPSite site = properties.Feature.Parent as SPSite)
            {

                traceInfo = "Site hostname: " + site.HostName;

                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                using (SPWeb web = site.RootWeb)
                {


                    if (web.Url.Contains("/sites/"))
                    {
                        //Update child content types with any declarative changes made to parent content types.
                        //(This method addresses added fieldlinks. If you delete a fieldlink from a content type, just use browser to remove it from list content type.)
                        
                        //(I like to make changes declaratively so I can see all fieldlinks in the Visual Studio GUI.)

                        try
                        {
                            SPContentType ctAssessment = web.ContentTypes["Assessment"];
                            SPList AssessmentList = web.Lists["Assessment"];
                            SPContentType AssessmentListCT = AssessmentList.ContentTypes["Assessment"];

                            foreach (SPFieldLink fieldlink in ctAssessment.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //AssessmentListCT will show fieldlink even if does not show in browser, so test on AssessmentList field instead.
                                            fld2 = AssessmentList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            AssessmentListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            AssessmentListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectAssessment", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctAssessmentProgress = web.ContentTypes["AssessmentProgress"];
                            SPList AssessmentProgressList = web.Lists["AssessmentProgress"];
                            SPContentType AssessmentProgressListCT = AssessmentProgressList.ContentTypes["AssessmentProgress"];

                            foreach (SPFieldLink fieldlink in ctAssessmentProgress.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //AssessmentProgressListCT will show fieldlink even if does not show in browser, so test on AssessmentProgressList field instead.
                                            fld2 = AssessmentProgressList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            AssessmentProgressListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            AssessmentProgressListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectAssessmentProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctCONOPSApprovalProgress = web.ContentTypes["CONOPSApprovalProgress"];
                            SPList CONOPSApprovalProgressList = web.Lists["CONOPSApprovalProgress"];
                            SPContentType CONOPSApprovalProgressListCT = CONOPSApprovalProgressList.ContentTypes["CONOPSApprovalProgress"];

                            foreach (SPFieldLink fieldlink in ctCONOPSApprovalProgress.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //CONOPSApprovalProgressListCT will show fieldlink even if does not show in browser, so test on CONOPSApprovalProgressList field instead.
                                            fld2 = CONOPSApprovalProgressList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            CONOPSApprovalProgressListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            CONOPSApprovalProgressListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectCONOPSApprovalProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctCONOPSAttachment = web.ContentTypes["CONOPSAttachment"];
                            SPList CONOPSAttachmentList = web.Lists["CONOPSAttachment"];
                            SPContentType CONOPSAttachmentListCT = CONOPSAttachmentList.ContentTypes["CONOPSAttachment"];

                            foreach (SPFieldLink fieldlink in ctCONOPSAttachment.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //CONOPSAttachmentListCT will show fieldlink even if does not show in browser, so test on CONOPSAttachmentList field instead.
                                            fld2 = CONOPSAttachmentList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            CONOPSAttachmentListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            CONOPSAttachmentListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectCONOPSAttachment", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctCONOPSDevProgress = web.ContentTypes["CONOPSDevProgress"];
                            SPList CONOPSDevProgressList = web.Lists["CONOPSDevProgress"];
                            SPContentType CONOPSDevProgressListCT = CONOPSDevProgressList.ContentTypes["CONOPSDevProgress"];

                            foreach (SPFieldLink fieldlink in ctCONOPSDevProgress.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //CONOPSDevProgressListCT will show fieldlink even if does not show in browser, so test on CONOPSDevProgressList field instead.
                                            fld2 = CONOPSDevProgressList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            CONOPSDevProgressListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            CONOPSDevProgressListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectCONOPSDevProgress", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctDCAPXPOCs = web.ContentTypes["DCAPXPOCs"];
                            SPList DCAPXPOCsList = web.Lists["DCAPXPOCs"];
                            SPContentType DCAPXPOCsListCT = DCAPXPOCsList.ContentTypes["DCAPXPOCs"];

                            foreach (SPFieldLink fieldlink in ctDCAPXPOCs.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //DCAPXPOCsListCT will show fieldlink even if does not show in browser, so test on DCAPXPOCsList field instead.
                                            fld2 = DCAPXPOCsList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            DCAPXPOCsListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            DCAPXPOCsListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectDCAPXPOCs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                       
                        try
                        {
                            //Here is the classic way of adding a field (fieldlink) to a content type that had been defined declaritively and is in use.
                            //But VS content type GUI will only show fields added declaritively (through the GUI). You can use the browser to add the field to the list or list content type to sync them up, but this step may be forgotten. 


                            //SPContentType ctFeedback = web.ContentTypes["Feedback"];
                            //SPField ccmd = web.Fields["CCMD"];

                            //SPFieldLink fldlnk = new SPFieldLink(ccmd);

                            //if (null == ctFeedback.FieldLinks[fldlnk.Id])
                            //{
                            //    ctFeedback.FieldLinks.Add(fldlnk);
                            //    ctFeedback.Update(true);
                            //}

                            //To ensure the children are updated simply calling ct.Update(true) will not work. 
                            //So update the list with the new field as you would through the browser. 

                            SPContentType ctFeedback = web.ContentTypes["Feedback"];
                            SPList FeedbackList = web.Lists["Feedback"];
                            SPContentType FeedbackListCT = FeedbackList.ContentTypes["Feedback"];

                            foreach (SPFieldLink fieldlink in ctFeedback.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //FeedbackListCT will show fieldlink even if does not show in browser, so test on FeedbackList field instead.
                                            fld2 = FeedbackList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            FeedbackListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            FeedbackListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectFeedback", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }

                        try
                        {
                            SPContentType ctMasterCalendar = web.ContentTypes["MasterCalendar"];
                            SPList MasterCalendarList = web.Lists["MasterCalendar"];
                            SPContentType MasterCalendarListCT = MasterCalendarList.ContentTypes["MasterCalendar"];

                            foreach (SPFieldLink fieldlink in ctMasterCalendar.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //MasterCalendarListCT will show fieldlink even if does not show in browser, so test on MasterCalendarList field instead.
                                            fld2 = MasterCalendarList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            MasterCalendarListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            MasterCalendarListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectMasterCalendar", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctProgramContacts = web.ContentTypes["ProgramContacts"];
                            SPList ProgramContactsList = web.Lists["ProgramContacts"];
                            SPContentType ProgramContactsListCT = ProgramContactsList.ContentTypes["ProgramContacts"];

                            foreach (SPFieldLink fieldlink in ctProgramContacts.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //ProgramContactsListCT will show fieldlink even if does not show in browser, so test on ProgramContactsList field instead.
                                            fld2 = ProgramContactsList.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            ProgramContactsListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            ProgramContactsListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctWS1 = web.ContentTypes["WS1"];
                            SPList WS1List = web.Lists["WS1"];
                            SPContentType WS1ListCT = WS1List.ContentTypes["WS1"];

                            foreach (SPFieldLink fieldlink in ctWS1.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //WS1ListCT will show fieldlink even if does not show in browser, so test on WS1List field instead.
                                            fld2 = WS1List.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            WS1ListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            WS1ListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectWS1", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        try
                        {
                            SPContentType ctWS2 = web.ContentTypes["WS2"];
                            SPList WS2List = web.Lists["WS2"];
                            SPContentType WS2ListCT = WS2List.ContentTypes["WS2"];

                            foreach (SPFieldLink fieldlink in ctWS2.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //WS2ListCT will show fieldlink even if does not show in browser, so test on WS2List field instead.
                                            fld2 = WS2List.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            WS2ListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            WS2ListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectWS2", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }

                        try
                        {
                            SPContentType ctWS3 = web.ContentTypes["WS3"];
                            SPList WS3List = web.Lists["WS3"];
                            SPContentType WS3ListCT = WS3List.ContentTypes["WS3"];

                            foreach (SPFieldLink fieldlink in ctWS3.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //WS3ListCT will show fieldlink even if does not show in browser, so test on WS3List field instead.
                                            fld2 = WS3List.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            WS3ListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            WS3ListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectWS3", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }

                        try
                        {
                            SPContentType ctWS4 = web.ContentTypes["WS4"];
                            SPList WS4List = web.Lists["WS4"];
                            SPContentType WS4ListCT = WS4List.ContentTypes["WS4"];

                            foreach (SPFieldLink fieldlink in ctWS4.FieldLinks)
                            {
                                //traceInfo = "fieldlink.Name: " + fieldlink.Name;
                                //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ctFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                if (fieldlink.Name != "ContentType" && fieldlink.Name != "Title")
                                {

                                    SPField fld = null;
                                    SPField fld2 = null;
                                    try
                                    {

                                        fld = web.Fields[fieldlink.Name];
                                    }
                                    catch { }
                                    try
                                    {

                                        if (fld != null)
                                        {
                                            //WS4ListCT will show fieldlink even if does not show in browser, so test on WS4List field instead.
                                            fld2 = WS4List.Fields[fld.Id];
                                        }
                                    }
                                    catch { }

                                    if (fld2 == null)
                                    {

                                        try
                                        {
                                            traceInfo = "Adding fieldlink to list ct";
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addingFieldLink", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                            SPFieldLink fldlnk = new SPFieldLink(fld);
                                            WS4ListCT.FieldLinks.Add(fldlnk);

                                            web.AllowUnsafeUpdates = true;
                                            WS4ListCT.Update();
                                        }
                                        catch (Exception ex)
                                        {
                                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("addMissingFieldLink", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                        }
                                    }

                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updatectWS4", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }

                    }




                }
            }


        }



        // Uncomment the method below to handle the event raised before a feature is deactivated.

        //public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        //{
           
        //    string traceInfo = "Deactivate ProgramContactsEventReceiver";
        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature3Deactivating", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

        //    using (SPSite site = properties.Feature.Parent as SPSite)
        //    {
        //        using (SPWeb web = site.RootWeb)
        //        { 
                
        //            try{

                        
        //            }
        //            catch (Exception ex)
        //            {
        //                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature3Deactivating", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
        //            }
        //        }
        //    }
        //}


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{

        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
