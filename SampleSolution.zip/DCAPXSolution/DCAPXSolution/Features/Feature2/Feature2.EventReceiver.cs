using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using System.IO;
using Microsoft.SharePoint.Administration;

namespace DCAPXSolution.Features.Feature2
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("0bcf2eb3-0d6c-476b-b306-304f422d1e4a")]
    public class Feature2EventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.
        #region Public constant members

        /// <summary>
        /// define the name of file
        /// </summary>



        public const string WebAppRootWebHomePage = "DCAPXInfo.aspx";
        public const string HomeInfoPage = "HomeInfoPage.webpart";
        public const string DCAPXSeal = "DCAPXSeal.webpart";

        public const string CONOPSDevPageHome = "CONOPSDevelopment.aspx";
        public const string CONOPSDevProgressChartWebPart = "CONOPSDevProgressChart.webpart";
        
        public const string CONOPSDevPageWS1 = "CONOPSDevWS1.aspx";
        public const string CONOPSDevWorksheetWebPartWS1 = "CONOPSDevWS1.webpart";

        public const string CONOPSDevPageWS2 = "CONOPSDevWS2.aspx";
        public const string CONOPSDevWorksheetWebPartWS2 = "CONOPSDevWS2.webpart";

        public const string CONOPSDevPageWS3 = "CONOPSDevWS3.aspx";
        public const string CONOPSDevWorksheetWebPartWS3 = "CONOPSDevWS3.webpart";

        public const string CONOPSDevPageWS4 = "CONOPSDevWS4.aspx";
        public const string CONOPSDevWorksheetWebPartWS4 = "CONOPSDevWS4.webpart";

        public const string CONOPSDevReviewSubmitWorksheets = "CONOPSDevReviewSubmitWorksheets.aspx";
        public const string CONOPSDevReviewWebPart = "CONOPSDevReview.webpart";

        public const string CONOPSDevUpload = "CONOPSDevUpload.aspx";
        public const string CONOPSDevUploadDocsWebPart = "CONOPSDevUploadDocs.webpart";

        public const string CONOPSDevWSButtonWebPart = "CONOPSDevButtons.webpart";

        public const string ViewCONOPSWebPart = "ViewCONOPS.webpart";


        #endregion



        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            
            
            
            string featureName = "DCAPXSolution_Feature2";

            var traceInfo = "Set Feature Name to: " + featureName;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //SPSite site = properties.Feature.Parent as SPSite;

            
            using (SPSite site = properties.Feature.Parent as SPSite)
            {

                traceInfo = "Site hostname: " + site.HostName;
            
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            
                using (SPWeb web = site.RootWeb)
                {

                    if (!web.Url.Contains("/sites/"))
                    {
                        traceInfo = "This is the WebAppRootWeb.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        string featurePathDCAPXSealWebPart = DCAPXSolution.WebAppRootWeb.createWebAppRootWebPages.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "DCAPXSeal", featureName);

                        traceInfo = "featurePathDCAPXSealWebPart: " + featurePathDCAPXSealWebPart;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string featurePathHomeInfoPageWebPart = DCAPXSolution.WebAppRootWeb.createWebAppRootWebPages.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "HomeInfoPage", featureName);
                        traceInfo = "featurePathHomeInfoPageWebPartWS1: " + featurePathHomeInfoPageWebPart;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            string webPartHomeInfoPage = Path.Combine(featurePathHomeInfoPageWebPart, HomeInfoPage);
                            string webPartDCAPXSeal = Path.Combine(featurePathDCAPXSealWebPart, DCAPXSeal);

                            traceInfo = "webPartHomeInfoPage: " + webPartHomeInfoPage + " webPartDCAPXSeal: " + webPartDCAPXSeal;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("webPartHomeInfoPage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.WebAppRootWeb.createWebAppRootWebPages.CreateWebPartPage(web.Url, WebAppRootWebHomePage, webPartHomeInfoPage, webPartDCAPXSeal, featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("webPartHomeInfoPage", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                    else
                    {


                        //try
                        //{

                        //    string featurePathViewCONOPS = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "ViewCONOPS", featureName);

                        //    string webPartViewCONOPS = Path.Combine(featurePathViewCONOPS, ViewCONOPSWebPart);

                        //    traceInfo = "webPartFile: " + webPartViewCONOPS;
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        //    DCAPXSolution.sitesDCAPXRootWeb.updateDCAPXHomePage.updatePage(web.Site.Url, true, webPartViewCONOPS);

                            

                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateDCAPXHomePage", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        //}

                        traceInfo = "web: " + web.Title + " properties.Definition.RootDirectory: " + properties.Definition.RootDirectory;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        
                        string featurePathButtonWebPart = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevButtons", featureName);
                        traceInfo = "featurePathButtonWebPart: " + featurePathButtonWebPart;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        string featurePathWorksheetWebPartWS1 = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevWS1", featureName);
                        traceInfo = "featurePathWorksheetWebPartWS1: " + featurePathWorksheetWebPartWS1;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            string webPartWorksheet = Path.Combine(featurePathWorksheetWebPartWS1, CONOPSDevWorksheetWebPartWS1);
                            string webPartButton = Path.Combine(featurePathButtonWebPart, CONOPSDevWSButtonWebPart);

                            traceInfo = "webPartWorksheet: " + webPartWorksheet + " webPartButton: " + webPartButton;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("webPartWorksheet", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.CreateWebPartPage(web.Url, CONOPSDevPageWS1, webPartWorksheet, webPartButton, featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("webPartWorksheet", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }

                        string featurePathWorksheetWebPartWS2 = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevWS2", featureName);
                        traceInfo = "featurePathWorksheetWebPartWS2: " + featurePathWorksheetWebPartWS2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            string webPartWorksheet = Path.Combine(featurePathWorksheetWebPartWS2, CONOPSDevWorksheetWebPartWS2);
                            string webPartButton = Path.Combine(featurePathButtonWebPart, CONOPSDevWSButtonWebPart);

                            traceInfo = "webPartWorksheet: " + webPartWorksheet + " webPartButton: " + webPartButton;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathWorksheetWebPartWS2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.CreateWebPartPage(web.Url, CONOPSDevPageWS2, webPartWorksheet, webPartButton, featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathWorksheetWebPartWS2", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        string featurePathWorksheetWebPartWS3 = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevWS3", featureName);
                        traceInfo = "featurePathWorksheetWebPartWS3: " + featurePathWorksheetWebPartWS3;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        try
                        {
                            string webPartWorksheet = Path.Combine(featurePathWorksheetWebPartWS3, CONOPSDevWorksheetWebPartWS3);
                            string webPartButton = Path.Combine(featurePathButtonWebPart, CONOPSDevWSButtonWebPart);

                            traceInfo = "webPartWorksheet: " + webPartWorksheet + " webPartButton: " + webPartButton;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathWorksheetWebPartWS3", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.CreateWebPartPage(web.Url, CONOPSDevPageWS3, webPartWorksheet, webPartButton, featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathWorksheetWebPartWS3", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        string featurePathWorksheetWebPartWS4 = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevWS4", featureName);
                        traceInfo = "featurePathWorksheetWebPartWS4: " + featurePathWorksheetWebPartWS4;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        try
                        {
                            string webPartWorksheet = Path.Combine(featurePathWorksheetWebPartWS4, CONOPSDevWorksheetWebPartWS4);
                            string webPartButton = Path.Combine(featurePathButtonWebPart, CONOPSDevWSButtonWebPart);

                            traceInfo = "webPartFile: " + webPartWorksheet + " webPartFile2: " + webPartButton;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathWorksheetWebPartWS4", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.CreateWebPartPage(web.Url, CONOPSDevPageWS4, webPartWorksheet, webPartButton, featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathWorksheetWebPartWS4", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        //ReviewSubmit
                        string featurePathReviewWebPart = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevReview", featureName);
                        traceInfo = "featurePathReviewWebPart: " + featurePathReviewWebPart;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        try
                        {
                            string webPartReview = Path.Combine(featurePathReviewWebPart, CONOPSDevReviewWebPart);
                            string webPartButton = Path.Combine(featurePathButtonWebPart, CONOPSDevWSButtonWebPart);

                            traceInfo = "webPartFile: " + webPartReview + " webPartFile2: " + webPartButton;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathReviewWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.CreateWebPartPage(web.Url, CONOPSDevReviewSubmitWorksheets, webPartReview, webPartButton, featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathReviewWebPart", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        //CONOPSDevUpload
                        string featurePathCONOPSDevUploadWebPart = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevUploadDocs", featureName);
                        traceInfo = "featurePathCONOPSDevUploadWebPart: " + featurePathCONOPSDevUploadWebPart;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathCONOPSDevUploadWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        try
                        {
                            string webPartCONOPSDevUpload = Path.Combine(featurePathCONOPSDevUploadWebPart, CONOPSDevUploadDocsWebPart);

                            traceInfo = "webPartFile: " + webPartCONOPSDevUpload;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathCONOPSDevUploadWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.CreateWebPartPage(web.Url, CONOPSDevUpload, webPartCONOPSDevUpload, "None", featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathCONOPSDevUploadWebPart", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        //CONOPS Dev Home
                        string featurePathCONOPSDevProgressChart = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "CONOPSDevProgressChart", featureName);
                        traceInfo = "featurePathCONOPSDevProgressChart: " + featurePathCONOPSDevProgressChart;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        try
                        {
                            string webPartCONOPSDevProgressChart = Path.Combine(featurePathCONOPSDevProgressChart, CONOPSDevProgressChartWebPart);
                            string webPartButton = Path.Combine(featurePathButtonWebPart, CONOPSDevWSButtonWebPart);

                            traceInfo = "webPartFile: " + webPartCONOPSDevProgressChart + " webPartFile2: " + webPartButton;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.CreateWebPartPage(web.Url, CONOPSDevPageHome, webPartCONOPSDevProgressChart, webPartButton, featureName);
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathCONOPSDevProgressChart", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                        // end CONOPS Dev Home

                        try
                        {

                            string featurePathViewCONOPS = DCAPXSolution.CONOPSDevModule.createCONOPSDevPage.GetWebPartFolderPath(web.Url, properties.Definition.RootDirectory, "ViewCONOPS", featureName);

                            string webPartViewCONOPS = Path.Combine(featurePathViewCONOPS, ViewCONOPSWebPart);

                            traceInfo = "webPartFile: " + webPartViewCONOPS;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("featurePathViewCONOPS", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            DCAPXSolution.sitesDCAPXRootWeb.updateDCAPXHomePage.updatePage(web.Site.Url, true, webPartViewCONOPS);



                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("updateDCAPXHomePage", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }
                    }
                
                
                
                    
                }
            }

            


            //if (site != null)
            //{
            //    traceInfo = "Disposing of site object during feature activation.";
            //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                
            //    site.Dispose();
            //}

        }


        // Uncomment the method below to handle the event raised before a feature is deactivated.
  
        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            
            
            
            string traceInfo = "Deleting web parts.";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Deactivating", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            using(SPSite site = properties.Feature.Parent as SPSite)
            {
                using (SPWeb web = site.RootWeb)
                {
                    if (!web.Url.Contains("/sites/"))
                    {
                        deleteWebPart("dcapxsolution_homeinfopage.webpart", site);
                        deleteWebPart("dcapxsolution_dcapxseal.webpart", site);
                        

                        traceInfo = "Deleting WebAppRootWeb pages.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Deactivating", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        deletePage("DCAPXInfo.aspx", web);


                    }
                    else
                    {
                        try
                        {
                            DCAPXSolution.sitesDCAPXRootWeb.updateDCAPXHomePage.updatePage(web.Site.Url, false, "");
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Ex", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        }

                        deleteWebPart("dcapxsolution_conopsdevws1.webpart", site);
                        deleteWebPart("dcapxsolution_conopsdevws2.webpart", site);
                        deleteWebPart("dcapxsolution_conopsdevws3.webpart", site);
                        deleteWebPart("dcapxsolution_conopsdevws4.webpart", site);
                        deleteWebPart("dcapxsolution_conopsdevprogresschart.webpart", site);
                        deleteWebPart("dcapxsolution_conopsdevreview.webpart", site);
                        deleteWebPart("dcapxsolution_conopsdevbuttons.webpart", site);
                        deleteWebPart("dcapxsolution_conopsdevuploaddocs.webpart", site);
                        deleteWebPart("dcapxsolution_viewconops.webpart", site);

                        traceInfo = "Deleting CONOPSDevWS pages.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Deactivating", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        deletePage("CONOPSDevWS1.aspx", web);
                        deletePage("CONOPSDevWS2.aspx", web);
                        deletePage("CONOPSDevWS3.aspx", web);
                        deletePage("CONOPSDevWS4.aspx", web);
                        deletePage("CONOPSDevelopment.aspx", web);
                        deletePage("CONOPSDevReviewSubmitWorksheets.aspx", web);
                        deletePage("CONOPSDevUpload.aspx", web);

                        //!Important - do not delete this comment.
                        //Nevermind this...You will not be able to delete fields already in use, so just overwrite them (Overwrite="TRUE" in xml-definition file and see msdn for example -- This produced The local device is already in use error because Overwrite="TRUE" means force use of this xml, but an xml-definition may not have a field id --- so forget it or use this not for the initial authoring, but to force a replacement of a field - just remember to not include the field id in the xml)
                        traceInfo = "Deleting Custom Site Columns";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Deactivating", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPFieldCollection webFields = web.Fields;
                        foreach (SPField f in webFields)
                        {
                            string fGroup = f.Group;
                            if (fGroup == "Custom Site Columns")
                            {
                                try
                                {
                                    traceInfo = "Deleting " + f.Title;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Deactivating", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    f.Delete();

                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Deactivating", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    // DCAPXEventsFeature2Deactivating	0000	Unexpected	Site columns which are included in content types or on lists cannot be deleted. Please remove all instances of this site column prior to deleting it.	
                                }

                            }
                        }

                        traceInfo = "Not deleting Content Types because cannot delete them when they are in use.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Deactivating", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    
                }
            }
         
        }

        private void deletePage(string pageName, SPWeb web)
        {
            
            
            string traceInfo = "";
            traceInfo = "Deactivating Feature2 so removing " + pageName;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            
            if (pageName.Contains("DCAPXInfo"))
            {
                traceInfo = "Deleting DCAPXInfo.aspx and resetting WelcomePage to Home.aspx";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                web.AllowUnsafeUpdates = true;
                SPFolder WebAppSitePages = web.GetFolder("SitePages");
                SPFileCollection SitePagesFiles = WebAppSitePages.Files;
                try
                {
                    traceInfo = "Try to delete page now: " + pageName;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    SitePagesFiles[pageName].Delete();
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Ex", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                }
                finally
                {
                    //Reset WelcomePage to Home.aspx
                    try
                    {
                        SPFolder oFolder = web.RootFolder;
                        oFolder.WelcomePage = "SitePages/Home.aspx";
                        oFolder.Update();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace); 

                    }

                }

            }
            else
            {
                string urlToSitePages = web.ServerRelativeUrl + "/SitePages";
                traceInfo = "Get libraryFolder: /SitePages: " + urlToSitePages;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                web.AllowUnsafeUpdates = true;
                SPFolder SitePages = web.GetFolder(urlToSitePages);
                SPFileCollection SitePagesFiles = SitePages.Files;
                try
                {
                    traceInfo = "Try to delete page now: " + pageName;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    SitePagesFiles[urlToSitePages + "/" + pageName].Delete();
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Ex", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                }
            }
            
            
        }



        private void deleteWebPart(string webPartName, SPSite site)
        {

            string traceInfo = "";
            traceInfo = "Deactivating Feature2 so removing " + webPartName;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            int itemToDelete = 0;
            site.AllowUnsafeUpdates = true;
            SPList list = site.GetCatalog(SPListTemplateType.WebPartCatalog);
            foreach (SPListItem item in list.Items)
            {

                if (item["Web Part"].ToString().ToLower() == webPartName)
                {
                    itemToDelete = item.ID;
                    break;
                }

            }
           
            try
            {
                if (itemToDelete > 0)
                {
                    SPListItem item = list.GetItemById(itemToDelete);
                    item.Delete();
                }
                traceInfo = "Deactivating Feature2 so removing " + webPartName;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                list.Update();

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeature2Ex", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            }

        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
