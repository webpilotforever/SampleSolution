using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;


namespace DCAPXSolution.Features.Feature1
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("d0c3eaa1-5f7d-4a03-b189-0f07be5dd270")]
    public class Feature1EventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {

            //SPSite psite = properties.Feature.Parent as SPSite;

            //Guid siteID = psite.ID;


            //SPSecurity.RunWithElevatedPrivileges(() =>
            //{
            //    using (SPSite siteCollection = new SPSite(siteID))
            //    {
            //        using (SPWeb topLevelSite = siteCollection.OpenWeb())
            //        { 
            //            //Calculate relative path to site from Web Application root.
            //            string WebAppRelativePath = topLevelSite.ServerRelativeUrl;
            //            if (!WebAppRelativePath.EndsWith("/"))
            //            {
            //                WebAppRelativePath += "/";
            //            }
            //            var traceInfo = "Feature1 activated. WebAppRelativePath: " + WebAppRelativePath; // /sites/DCAPXDev/
            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            //            // Enumerate through each site and apply custom branding. 
            //            foreach (SPWeb site in siteCollection.AllWebs)
            //            {
            //                site.MasterUrl = WebAppRelativePath + "_catalogs/masterpage/DCAPX.master";
            //                site.CustomMasterUrl = WebAppRelativePath + "_catalogs/masterpage/DCAPX.master";
            //                site.UIVersion = 4;
            //                site.AllowUnsafeUpdates = true;
            //                try
            //                {
            //                    site.Update();
            //                }
            //                catch (Exception ex)
            //                {
            //                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            //                }
            //            }
            //        }
            //    }
            //});







            //string urlToSite = psite.Url;





            //using (SPSite siteCollection = new SPSite(urlToSite))
            //{
            //    using (SPWeb topLevelSite = siteCollection.OpenWeb())
            //    {
            //        //Calculate relative path to site from Web Application root.
            //        string WebAppRelativePath = topLevelSite.ServerRelativeUrl;
            //        if (!WebAppRelativePath.EndsWith("/"))
            //        {
            //            WebAppRelativePath += "/";
            //        }
            //        var traceInfo = "Feature1 activated. WebAppRelativePath: " + WebAppRelativePath; // /sites/DCAPXDev/
            //        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            //        // Enumerate through each site and apply custom branding. 
            //        foreach (SPWeb site in siteCollection.AllWebs)
            //        {
            //            site.MasterUrl = WebAppRelativePath + "_catalogs/masterpage/DCAPX.master";
            //            site.CustomMasterUrl = WebAppRelativePath + "_catalogs/masterpage/DCAPX.master";
            //            site.UIVersion = 4;
            //            site.AllowUnsafeUpdates = true;
            //            try
            //            {
            //                site.Update();
            //            }
            //            catch (Exception ex)
            //            {
            //                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            //            }
            //        }


            //    }
            //}






             SPSite siteCollection = properties.Feature.Parent as SPSite;
             if (siteCollection != null)
             {
                 SPWeb topLevelSite = siteCollection.RootWeb;//Calculate relative path to site from Web Application root.
                 string WebAppRelativePath = topLevelSite.ServerRelativeUrl;
                 if (!WebAppRelativePath.EndsWith("/"))
                 {
                     WebAppRelativePath += "/";
                 }
                 var traceInfo = "Feature1 activated. WebAppRelativePath: " + WebAppRelativePath; // /sites/DCAPXDev/
                 SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                 // Enumerate through each site and apply custom branding. 
                 foreach (SPWeb site in siteCollection.AllWebs)
                 {
                     site.MasterUrl = WebAppRelativePath + "_catalogs/masterpage/DCAPX.master";
                     site.CustomMasterUrl = WebAppRelativePath + "_catalogs/masterpage/DCAPX.master";
                     site.UIVersion = 4;
                     site.AllowUnsafeUpdates = true;
                     try
                     {
                         site.Update();
                     }
                     catch (Exception ex)
                     {
                         SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                     }
                 }

             }








        }




        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {

            //SPSite psite = properties.Feature.Parent as SPSite;

            //Guid siteID = psite.ID;


            //SPSecurity.RunWithElevatedPrivileges(() =>
            //{
            //    using (SPSite siteCollection = new SPSite(siteID))
            //    {
            //        using (SPWeb topLevelSite = siteCollection.OpenWeb())
            //        { 
            //            // Calculate relative path to site from Web Application root.
            //            string WebAppRelativePath = topLevelSite.ServerRelativeUrl;
            //            if (!WebAppRelativePath.EndsWith("/"))
            //            {
            //                WebAppRelativePath += "/";
            //            }
            //            var traceInfo = "Feature1 deactivating. WebAppRelativePath: " + WebAppRelativePath; // /sites/DCAPXDev/
            //            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //            // Enumerate through each site and remove custom branding. 
            //            foreach (SPWeb site in siteCollection.AllWebs)
            //            {
            //                site.MasterUrl = WebAppRelativePath + "_catalogs/masterpage/v4.master";
            //                site.CustomMasterUrl = WebAppRelativePath + "_catalogs/masterpage/v4.master";
            //                site.AllowUnsafeUpdates = true;
            //                try
            //                {
            //                    site.Update();
            //                }
            //                catch (Exception ex)
            //                {
            //                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

            //                }
            //            }
            //        }
            //    }
            //});






            SPSite siteCollection = properties.Feature.Parent as SPSite;
            if (siteCollection != null)
            {
                SPWeb topLevelSite = siteCollection.RootWeb;

                // Calculate relative path to site from Web Application root.
                string WebAppRelativePath = topLevelSite.ServerRelativeUrl;
                if (!WebAppRelativePath.EndsWith("/"))
                {
                    WebAppRelativePath += "/";
                }
                var traceInfo = "Feature1 deactivating. WebAppRelativePath: " + WebAppRelativePath; // /sites/DCAPXDev/
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                // Enumerate through each site and remove custom branding. 
                foreach (SPWeb site in siteCollection.AllWebs)
                {
                    site.MasterUrl = WebAppRelativePath + "_catalogs/masterpage/v4.master";
                    site.CustomMasterUrl = WebAppRelativePath + "_catalogs/masterpage/v4.master";
                    site.AllowUnsafeUpdates = true;
                    try
                    {
                        site.Update();
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                    }
                }

            }

        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
