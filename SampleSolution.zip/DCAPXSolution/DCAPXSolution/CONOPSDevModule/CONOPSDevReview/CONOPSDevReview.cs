﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Generic;

namespace DCAPXSolution.CONOPSDevModule.CONOPSDevReview
{
    [ToolboxItemAttribute(false)]
    public class CONOPSDevReview : WebPart
    {
        protected override void CreateChildControls()
        {
            string traceInfo = "";

            if (!Page.Request.Url.Query.Contains("IsDlg=1"))
            {
                this.Controls.Add(new LiteralControl("<table width=\"100%\" class=\"WSOTATable ms-rteFontSize-3 ms-rteTable-0\" cellspacing=\"0\"><tbody><tr class=\"ms-rteFontSize-3 ms-rteTableEvenRow-0\"><td class=\"ms-rteFontSize-3 ms-rteTableEvenCol-0\"><div title='OTAshort' class=\"WSOTADiv WSOTA\">OTA</div></td></tr>" +
                "<tr class=\"ms-rteFontSize-3 ms-rteTableOddRow-0\"><td class=\"ms-rteFontSize-3 ms-rteTableEvenCol-0\">​</td></tr></tbody></table>"));

                this.Controls.Add(new LiteralControl("<table class=\"WSReviewFYTable ms-rteTable-default\" cellspacing=\"0\" style=\"width: 100%; font-size: 1em\"><tbody><tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS1ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div></td>" +
                "<td class=\"ms-rteTableOddCol-default ms-rteFontSize-4\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>FY</strong></span><strong> BUDGET WORKSHEET #1: CORE PERSONNEL COSTS​</strong></div></td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\" style=\"text-align: center\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"width: 1146px\"><strong>Military/Government Civilian​ ​ ​ ​ ​</strong></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\" style=\"text-align: right\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Number of personnel: <span class=\"ReviewWS1NumOfMilPersonnel\"> MilitaryOrGovernmentCivilianCountWS1 </span> ​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">&#160;</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Sub-Total:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS1MilSubTotal\">MilitarySubTotalWS1</span></td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><span>​</span><span><strong>Contractors</strong></span></td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Number of contractors: <span class=\"ReviewWS1NumOfContractors\">ContractorCountWS1</span>​</td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Contract: <span class=\"ReviewWS1Contract\">ContractsWS1String</span>​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">&#160;</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Sub-Total:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS1ContractsSubTotal\">ContractsSubTotalWS1</span></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS1Total\">TotalWS1</span>​</td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS1AttachmentsAdd\">Add Attachment</div>​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS2ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div>​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>FY</strong></span><strong> BUDGET WORKSHEET #2: ASSESSMENT COSTS​</strong></div></td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Venue: <span class=\"WS2Venue\">VenuesWS2String</span></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS2Total\">TotalWS2</span>​</td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS2AttachmentsAdd\">Add Attachment</div></td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS3ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div></td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>FY</strong></span><strong> BUDGET WORKSHEET #3: NON-ASSESSMENT TRAVEL​</strong></div></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS3Total\">TotalWS3</span>​</td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS3AttachmentsAdd\">Add Attachment</div>​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS4ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div>​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>FY</strong></span><strong> BUDGET WORKSHEET #4: NON-ASSESSMENT SUPPORT COSTS​</strong></div></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS4Total\">TotalWS4</span></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS4AttachmentsAdd\">Add Attachment</div></td></tr></tbody></table>" +
                "<div class=\"WSNav\"><div title=\"Review OK\" class=\"WSBtnReviewFYOK\">FY <span class=\"WSFY\">FY</span> CONOPS WORKSHEETS OK</div></div>"));

                this.Controls.Add(new LiteralControl("<table width=\"100%\" class=\"WSReviewSubmitTable ms-rteTable-default\" cellspacing=\"0\" style=\"text-align: center; font-size: 1em\"><tbody><tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteThemeBackColor-1-3 WSReviewCurrentFYColor ms-rteTableEvenCol-default\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-3 WSReviewNextFYColor ms-rteTableOddCol-default\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-3 WSReviewFutureFYColor ms-rteTableEvenCol-default\">​</td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-1 ms-rteTableEvenRow-default\"><td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewCurrentFYCell ms-rteTableEvenCol-default\"><div>&#160; <div class=\"WSReviewCurrentFYBlock\">FY <span class=\"WSFY\">FY</span> CONOPS WORKSHEETS</div></div></td>" +
                "<td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewNextFYCell ms-rteTableOddCol-default\"><div>&#160; <div class=\"WSReviewNextFYBlock\">FY <span class=\"WSFYNext\">FY</span> CONOPS WORKSHEETS</div></div></td>" +
                "<td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewFutureFYCell ms-rteTableEvenCol-default\"><div>&#160; <div class=\"WSReviewFutureFYBlock\">FY <span class=\"WSFYFuture\">FY</span> CONOPS WORKSHEETS</div></div></td></tr>" +
                "</tbody></table>"));
           
            }
            else
            {
                DateTime dCurrent = DateTime.Now;
                dCurrent = dCurrent.AddYears(1);
                int dCurrentYear = dCurrent.Year;
                string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16
                traceInfo = "CurrentFYforAcceptingCONOPS: " + CurrentFYforAcceptingCONOPS;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                DateTime dNext = DateTime.Now;
                dNext = dNext.AddYears(2);
                int dNextYear = dNext.Year;
                string NextFYforAcceptingCONOPS = dNextYear.ToString().Substring(2); // 17
                traceInfo = "NextFYforAcceptingCONOPS: " + NextFYforAcceptingCONOPS;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                DateTime dFuture = DateTime.Now;
                dFuture = dFuture.AddYears(3);
                int dFutureYear = dFuture.Year;
                string FutureFYforAcceptingCONOPS = dFutureYear.ToString().Substring(2); // 18
                traceInfo = "FutureFYforAcceptingCONOPS: " + FutureFYforAcceptingCONOPS;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                string summaryFY = "";

                Dictionary<string, string> showTableKey = new Dictionary<string, string>();
                showTableKey.Add("current", CurrentFYforAcceptingCONOPS);
                showTableKey.Add("next", NextFYforAcceptingCONOPS);
                showTableKey.Add("future", FutureFYforAcceptingCONOPS);
                showTableKey.Add("submit", CurrentFYforAcceptingCONOPS);

      

                string showTableString = Page.Request.QueryString["showTable"].ToString();
                
                summaryFY = showTableKey[showTableString];


                Dictionary<string, string> OTADictionary = new Dictionary<string, string>();
                OTADictionary.Add("AFOTEC", "Air Force Operational Test and Evaluation Center");
                OTADictionary.Add("ATEC", "Army Test and Evaluation Command");
                OTADictionary.Add("COTF", "Commander Operational Test and Evaluation Force");
                OTADictionary.Add("JITC", "Joint Interoperability Test Command");
                OTADictionary.Add("MCOTEA", "Marine Corps Operational Test and Evaluation Activity");

                string OTA = "";
                string OTAshort = "";

                SPWeb oWebsiteRoot = SPContext.Current.Site.RootWeb;
                SPList oList = oWebsiteRoot.Lists["ProgramContacts"];


                SPQuery oQuery = new SPQuery();
                oQuery.Query = "<Where><Eq><FieldRef Name='Account'/>" +
                    "<Value Type='Integer'><UserID/></Value></Eq></Where>";
                SPListItemCollection collListItems = oList.GetItems(oQuery);
                foreach (SPListItem oListItem in collListItems)
                {
                    OTAshort = oListItem["OperationalTestAgency"].ToString();
                    OTA = OTADictionary[oListItem["OperationalTestAgency"].ToString()];

                }
                traceInfo = "Got OTA: " + OTA + " OTAshort: " + OTAshort;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                string CONOPSWSList = "CONOPSDevWS" + OTAshort;
                SPList oList2 = oWebsiteRoot.Lists[CONOPSWSList];
                traceInfo = "Get items from CONOPSWSList: " + CONOPSWSList;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);



                //----- QUERIES -----------------------------
                //int fromId = 0;

                string DateDraftSavedWS1 = "";
                string DateDraftSavedWS2 = "";
                string DateDraftSavedWS3 = "";
                string DateDraftSavedWS4 = "";
                string TotalWS1 = "";
                string TotalWS2 = "";
                string TotalWS3 = "";
                string TotalWS4 = "";
                int MilitaryOrGovernmentCivilianCountWS1 = 0;
                string MilitarySubTotalWS1 = "";
                int ContractorCountWS1 = 0;
                List<string> ContractsWS1 = new List<string>();
                string ContractsSubTotalWS1 = "";
                List<string> VenuesWS2 = new List<string>();


                string TitleMilitarySubTotal = "MilitarySubTotal";
                string TitleContract = "Contract";
                string TitleContractsSubTotal = "ContractsSubTotal";
                string TitleTotal = "Total";
                string EmployerMilitaryOrGovernmentCivilian = "MilitaryOrGovernmentCivilian";
                string EmployerContractor = "Contractor";
                string TitleVenueSubTotal = "VenueSubTotal";



                SPQuery oQueryWS1 = new SPQuery();
                oQueryWS1.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + summaryFY + "</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS1</Value></Eq></And></Where>";
                SPListItemCollection collListItemsWS1 = oList2.GetItems(oQueryWS1);
                traceInfo = "Count: " + collListItemsWS1.Count;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                foreach (SPListItem oListItem in collListItemsWS1)
                {
                    try
                    {
                        traceInfo = "ID: " + oListItem.ID.ToString() + " Title: " + oListItem.Title.ToString();
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        if (DateDraftSavedWS1 != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS1 != "")
                        {
                            break;
                        }
                        else
                        {
                            DateDraftSavedWS1 = oListItem["DateDraftSaved"].ToString();
                        }
                        if (oListItem["Employer"] != null)
                        {
                            if (EmployerMilitaryOrGovernmentCivilian == oListItem["Employer"].ToString())
                            {
                                MilitaryOrGovernmentCivilianCountWS1 = MilitaryOrGovernmentCivilianCountWS1 + 1;

                            }
                            if (EmployerContractor == oListItem["Employer"].ToString())
                            {
                                ContractorCountWS1 = ContractorCountWS1 + 1;

                            }
                        }

                        else if (TitleMilitarySubTotal == oListItem["Title"].ToString())
                        {
                            if (oListItem["MilitarySubTotal"] != null)
                            {
                                MilitarySubTotalWS1 = oListItem["MilitarySubTotal"].ToString();
                            }

                        }

                        else if (TitleContract == oListItem["Title"].ToString())
                        {
                            if (oListItem["Contract"] != null)
                            {
                                ContractsWS1.Add(oListItem["Contract"].ToString());
                                traceInfo = "ContractsWS1: " + ContractsWS1;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                        }
                        else if (TitleContractsSubTotal == oListItem["Title"].ToString())
                        {
                            if (ContractsSubTotalWS1 == "")
                            {
                                if (oListItem["ContractsSubTotal"] != null)
                                {
                                    ContractsSubTotalWS1 = oListItem["ContractsSubTotal"].ToString();
                                    traceInfo = "ContractsSubTotalWS1: " + ContractsSubTotalWS1;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                }
                            }

                        }
                        else if (TitleTotal == oListItem["Title"].ToString())
                        {
                            if (oListItem["Total"] != null)
                            {
                                TotalWS1 = oListItem["Total"].ToString();
                                traceInfo = "TotalWS1: " + TotalWS1;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXCONOPSDevReview", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }

                SPQuery oQueryWS2 = new SPQuery();
                oQueryWS2.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + summaryFY + "</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS2</Value></Eq></And></Where>";
                SPListItemCollection collListItemsWS2 = oList2.GetItems(oQueryWS2);
                foreach (SPListItem oListItem in collListItemsWS2)
                {
                    try{
                    traceInfo = "ID: " + oListItem["ID"].ToString() + " Title: " + oListItem["Title"].ToString() + " DateDraftSaved: " + oListItem["DateDraftSaved"].ToString();
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (DateDraftSavedWS2 != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS2 != "")
                    {
                        //fromId = Int32.Parse(oListItem["ID"].ToString()) + 1;
                        break;
                    }
                    else
                    {
                        DateDraftSavedWS2 = oListItem["DateDraftSaved"].ToString();
                    }

                    if (TitleTotal == oListItem["Title"].ToString())
                    {

                        TotalWS2 = oListItem["Total"].ToString();
                        traceInfo = "TotalWS2: " + TotalWS2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    else if (TitleVenueSubTotal == oListItem["Title"].ToString())
                    {
                        VenuesWS2.Add(" " + oListItem["Venue"].ToString());
                        traceInfo = "VenuesWS2: " + VenuesWS2;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXCONOPSDevReview", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }

                SPQuery oQueryWS3 = new SPQuery();
                oQueryWS3.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + summaryFY + "</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS3</Value></Eq></And></Where>";
                SPListItemCollection collListItemsWS3 = oList2.GetItems(oQueryWS3);
                foreach (SPListItem oListItem in collListItemsWS3)
                {
                    try{
                    traceInfo = "ID: " + oListItem["ID"].ToString() + " Title: " + oListItem["Title"].ToString() + " DateDraftSaved: " + oListItem["DateDraftSaved"].ToString();
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (DateDraftSavedWS3 != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS3 != "")
                    {
                        //fromId = Int32.Parse(oListItem["ID"].ToString()) + 1;
                        break;
                    }
                    else
                    {
                        DateDraftSavedWS3 = oListItem["DateDraftSaved"].ToString();
                    }

                    if (TitleTotal == oListItem["Title"].ToString())
                    {
                        TotalWS3 = oListItem["Total"].ToString();
                        traceInfo = "TotalWS3: " + TotalWS3;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXCONOPSDevReview", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }


                SPQuery oQueryWS4 = new SPQuery();
                oQueryWS4.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + summaryFY + "</Value></Eq><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></And><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS4</Value></Eq></And></Where>";
                SPListItemCollection collListItemsWS4 = oList2.GetItems(oQueryWS4);
                foreach (SPListItem oListItem in collListItemsWS4)
                {
                    try{
                    traceInfo = "ID: " + oListItem["ID"].ToString() + " Title: " + oListItem["Title"].ToString() + " DateDraftSaved: " + oListItem["DateDraftSaved"].ToString();
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (DateDraftSavedWS4 != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS4 != "")
                    {
                        //fromId = Int32.Parse(oListItem["ID"].ToString()) + 1;
                        break;
                    }
                    else
                    {
                        DateDraftSavedWS4 = oListItem["DateDraftSaved"].ToString();
                    }

                    if (TitleTotal == oListItem["Title"].ToString())
                    {
                        TotalWS4 = oListItem["Total"].ToString();
                        traceInfo = "TotalWS4: " + TotalWS4;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevReview", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXCONOPSDevReview", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }

                string ContractsWS1String = "";
                string VenuesWS2String = "";

                foreach (String contract in ContractsWS1)
                {
                    ContractsWS1String += contract + ", ";
                }
                foreach (String venue in VenuesWS2)
                {
                    VenuesWS2String += venue + ", ";
                }
                char[] charsToTrim = { ',', ' ' };
                ContractsWS1String = ContractsWS1String.TrimEnd(charsToTrim);
                VenuesWS2String = VenuesWS2String.TrimEnd(charsToTrim);


                //----- end QUERIES -----------------------
                this.Controls.Add(new LiteralControl("<table width=\"100%\" class=\"WSOTATable ms-rteFontSize-3 ms-rteTable-0\" cellspacing=\"0\"><tbody><tr class=\"ms-rteFontSize-3 ms-rteTableEvenRow-0\"><td class=\"ms-rteFontSize-3 ms-rteTableEvenCol-0\"><div title='" + OTAshort + "' class=\"WSOTADiv WSOTA\">" + OTA.ToUpper() + "</div></td></tr>" +
                "<tr class=\"ms-rteFontSize-3 ms-rteTableOddRow-0\"><td class=\"ms-rteFontSize-3 ms-rteTableEvenCol-0\">​</td></tr></tbody></table>"));
                if (Page.Request.Url.ToString().Contains("CONOPSDevReviewSubmitWorksheets"))
                {
                    if (Page.Request.QueryString["showTable"] == "current" || Page.Request.QueryString["showTable"] == "next" || Page.Request.QueryString["showTable"] == "future")
                    {
                        this.Controls.Add(new LiteralControl("<table width=\"100%\" class=\"WSReviewSubmitTable ms-rteTable-default\" cellspacing=\"0\" style=\"margin-top: 0; text-align: center; font-size: 1em\"><tbody><tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteThemeBackColor-1-3 WSReviewCurrentFYColor ms-rteTableEvenCol-default\">​</td>" +
                        "<td class=\"ms-rteThemeBackColor-1-3 WSReviewNextFYColor ms-rteTableOddCol-default\">​</td>" +
                        "<td class=\"ms-rteThemeBackColor-1-3 WSReviewFutureFYColor ms-rteTableEvenCol-default\">​</td></tr>" +
                        "<tr class=\"ms-rteThemeBackColor-1-1 ms-rteTableEvenRow-default\"><td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewCurrentFYCell ms-rteTableEvenCol-default\"><div>&#160; <div class=\"WSReviewCurrentFYBlock\">FY <span class=\"WSFY\">" + CurrentFYforAcceptingCONOPS + "</span> CONOPS WORKSHEETS</div></div></td>" +
                        "<td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewNextFYCell ms-rteTableOddCol-default\"><div>&#160; <div class=\"WSReviewNextFYBlock\">FY <span class=\"WSFYNext\">" + NextFYforAcceptingCONOPS + "</span> CONOPS WORKSHEETS</div></div></td>" +
                        "<td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewFutureFYCell ms-rteTableEvenCol-default\"><div>&#160; <div class=\"WSReviewFutureFYBlock\">FY <span class=\"WSFYFuture\">" + FutureFYforAcceptingCONOPS + "</span> CONOPS WORKSHEETS</div></div></td></tr>" +
                        "</tbody></table>"));
                    }

                }
                this.Controls.Add(new LiteralControl("<table class=\"WSReviewFYTable ms-rteTable-default\" cellspacing=\"0\" style=\"width: 100%; font-size: 1em\"><tbody><tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS1ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div></td>" +
                "<td class=\"ms-rteTableOddCol-default ms-rteFontSize-4\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>" + showTableKey[Page.Request.QueryString["showTable"]] + "</strong></span><strong> BUDGET WORKSHEET #1: CORE PERSONNEL COSTS​</strong></div></td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\" style=\"text-align: center\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"width: 1146px\"><strong>Military/Government Civilian​ ​ ​ ​ ​</strong></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\" style=\"text-align: right\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Number of personnel: <span class=\"ReviewWS1NumOfMilPersonnel\">" + MilitaryOrGovernmentCivilianCountWS1 + "​</span> ​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">&#160;</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Sub-Total:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS1MilSubTotal\">" + MilitarySubTotalWS1 + "</span></td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><span>​</span><span><strong>Contractors</strong></span></td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Number of contractors: <span class=\"ReviewWS1NumOfContractors\">" + ContractorCountWS1 + "</span>​</td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Contract: <span class=\"ReviewWS1Contract\">" + ContractsWS1String + "</span>​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">&#160;</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Sub-Total:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS1ContractsSubTotal\">" + ContractsSubTotalWS1 + "</span></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS1Total\">" + TotalWS1 + "</span>​</td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS1AttachmentsAdd\">Add Attachment</div>​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS2ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div>​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>" + showTableKey[Page.Request.QueryString["showTable"]] + "</strong></span><strong> BUDGET WORKSHEET #2: ASSESSMENT COSTS​</strong></div></td></tr>" +
                "<tr class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-1-0 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: center; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-1-0 ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\">Venue: <span class=\"WS2Venue\">" + VenuesWS2String + "​</span></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS2Total\">" + TotalWS2 + "</span>​</td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS2AttachmentsAdd\">Add Attachment</div></td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS3ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div></td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>" + showTableKey[Page.Request.QueryString["showTable"]] + "</strong></span><strong> BUDGET WORKSHEET #3: NON-ASSESSMENT TRAVEL​</strong></div></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS3Total\">" + TotalWS3 + "</span>​</td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span>​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS3AttachmentsAdd\">Add Attachment</div>​</td></tr>" +
                "<tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WS4ReviewPrint\">View</div></td><td class=\"ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 40px; vertical-align: middle; text-align: center;\"><div class=\"WSReviewEdit\">Edit​</div>​</td>" +
                "<td class=\"ms-rteTableOddCol-default\" colspan=\"2\" style=\"text-align: center; width: 1146px\"><div class=\"WSTitle\"><strong>FY </strong><span class=\"WSFY\"><strong>" + showTableKey[Page.Request.QueryString["showTable"]] + "</strong></span><strong> BUDGET WORKSHEET #4: NON-ASSESSMENT SUPPORT COSTS​</strong></div></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Total:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\"><span class=\"ReviewWS4Total\">" + TotalWS4 + "</span></td></tr>" +
                "<tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"width: 33px\">​</td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"1\" style=\"text-align: right; width: 33px\">​</td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: right; width: 198px\"><span><strong>Attachments:</strong></span></td>" +
                "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align: center; width: 214px\">​<div class=\"ReviewWS4AttachmentsAdd\">Add Attachment</div></td></tr></tbody></table>" +
                "<div class=\"WSNav\"><div title=\"Review OK\" class=\"WSBtnReviewFYOK\">FY <span class=\"WSFY\">" + showTableKey[Page.Request.QueryString["showTable"]] + "</span> CONOPS WORKSHEETS OK</div></div>"));



                if (Page.Request.Url.ToString().Contains("CONOPSDevReviewSubmitWorksheets"))
                {
                    if (Page.Request.QueryString["showTable"] == "submit")
                    {
                        this.Controls.Add(new LiteralControl("<table width=\"100%\" class=\"WSReviewSubmitTable ms-rteTable-default\" cellspacing=\"0\" style=\"text-align: center; font-size: 1em\"><tbody><tr class=\"ms-rteTableOddRow-default\"><td class=\"ms-rteThemeBackColor-1-3 WSReviewCurrentFYColor ms-rteTableEvenCol-default\">​</td>" +
                        "<td class=\"ms-rteThemeBackColor-1-3 WSReviewNextFYColor ms-rteTableOddCol-default\">​</td>" +
                        "<td class=\"ms-rteThemeBackColor-1-3 WSReviewFutureFYColor ms-rteTableEvenCol-default\">​</td></tr>" +
                        "<tr class=\"ms-rteThemeBackColor-1-1 ms-rteTableEvenRow-default\"><td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewCurrentFYCell ms-rteTableEvenCol-default\"><div>&#160; <div class=\"WSReviewCurrentFYBlock\">FY <span class=\"WSFY\">" + CurrentFYforAcceptingCONOPS + "</span> CONOPS WORKSHEETS</div></div></td>" +
                        "<td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewNextFYCell ms-rteTableOddCol-default\"><div>&#160; <div class=\"WSReviewNextFYBlock\">FY <span class=\"WSFYNext\">" + NextFYforAcceptingCONOPS + "</span> CONOPS WORKSHEETS</div></div></td>" +
                        "<td align=\"center\" class=\"ms-rteThemeBackColor-1-1 WSReviewFutureFYCell ms-rteTableEvenCol-default\"><div>&#160; <div class=\"WSReviewFutureFYBlock\">FY <span class=\"WSFYFuture\">" + FutureFYforAcceptingCONOPS + "</span> CONOPS WORKSHEETS</div></div></td></tr>" +
                        "</tbody></table>" +
                        "<table width=\"100%\" class=\"WSReviewSubmitTableAttachments ms-rteTable-default\" cellspacing=\"0\" style=\"text-align: center; font-size: 1em\"><tbody>" +    
                        "<tr>" +
                        "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\" style=\"text-align: center\"><span><strong>Approval Memo (PDF)</strong></span>​</td>"+
                        "</tr>"+
                        "<tr>" +
                        "<td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" style=\"text-align:center\"><div class=\"SubmitAttachmentsAdd\">Add Attachment</div></td>" +
                        "</tr>"+
                        "</tbody></table>​"));
                    }
                     
                }

               
            }


            
  
        }
    }
}
