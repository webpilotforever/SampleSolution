﻿using System;
using System.ComponentModel;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using System.IO;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;

namespace DCAPXSolution.CONOPSDevModule.CONOPSDevUploadDocs
{
    [ToolboxItemAttribute(false)]
    public partial class CONOPSDevUploadDocs : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public CONOPSDevUploadDocs()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            var traceInfo = "CONOPSDevUploadDocs";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            
            string ota = Page.Request.QueryString["ota"];
            string pUrl = Page.Request.Url.ToString();
            
            bool IsListContributor = isListContributorCheck();

            if (Page.Request.QueryString["docOps"] == "delete")
            {
                FileUpload1.Visible = false;
                Button1Upload.Visible = false;
                ButtonDelete.Visible = true;

                string docName = Page.Request.QueryString["docName"];
                UploadInstructions1.Text = "Click Delete to remove the following attachment:";
                UploadInstructions2.Text = SPHttpUtility.HtmlDecode(docName) + "." + Page.Request.QueryString["docExt"];
                UploadInstructions2.Font.Bold = true;
                UploadInstructions3.Text = "Click Cancel to close this dialog.";
            }

            if (IsListContributor)
            {
                traceInfo = "Current user is authorized to contribute to this CONOPSDev library";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            }
            else
            {
                traceInfo = "Not authorized.";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                NotAuthorizedToUpload.Visible = true;
                FileUpload1.Visible = false;
                Button1Upload.Visible = false;
                ButtonDelete.Visible = false;
                ButtonCancel.Visible = false;
                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert(\"Not authorized.\"); SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");

            }
           
        }

        private bool isListContributorCheck()
        {

            bool IsListContributor = false;
            using (SPSite oSiteCollection = new SPSite(Page.Request.Url.ToString()))
            {
                var traceInfo = "OpenWeb";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                using (SPWeb oWebsiteRoot = oSiteCollection.OpenWeb())
                {
                    try
                    {
                        string oUser = Page.User.Identity.Name;

                        traceInfo = "oUser: " + oUser;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        SPUser oSPUser = oWebsiteRoot.AllUsers[oUser];
                        traceInfo = "oSPUser.LoginName: " + oSPUser.LoginName + " oSPUser.ID: " + oSPUser.ID;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        traceInfo = "Get oSPUser.Groups";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPGroupCollection currentUsersGroups = oSPUser.Groups;

                        foreach (SPGroup group in currentUsersGroups)
                        {
                            string groupName = group.Name;
                            if (groupName.Contains("CONOPSDevSubmitters" + Page.Request.QueryString["ota"]) || groupName.Contains("CONOPSApproval") || groupName.Contains("DCAPXAO") || groupName.Contains("DCAPXOwners"))
                            {
                                IsListContributor = true;
                            }
                        }


                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }
            }

            return IsListContributor;
            
        }



        protected void Button1Upload_Click(object sender, EventArgs e)
        {

            var traceInfo = "Button1Upload_Click";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            
            string ota = Page.Request.QueryString["ota"];
            string pUrl = Page.Request.Url.ToString();
            string uName = Page.User.Identity.Name;
            string siteUrlAsString = "";
            string docLibAsString = "";
            string fileNameAsString = "";
            Guid siteID;
            bool IsListContributor = isListContributorCheck();

            //Set siteID
            using (SPSite oSite = new SPSite(pUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    siteID = oSite.ID;
                }
            }

            if (IsListContributor)
            {
                traceInfo = "Current user is authorized to contribute to this CONOPSDev library";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb web = site.RootWeb)
                        {

                            try
                            {

                                string docLib = "CONOPSDev" + ota;
                                siteUrlAsString = site.Url;
                                docLibAsString = docLib;

                                //------------- Query for conflicts ----------------
                                bool conflict = false;

                                SPList oList = web.Lists[docLib];
                                SPListItemCollection oListItems = oList.Items;

                                foreach (SPListItem oItem in oListItems)
                                {
                                    string oItemName = oItem.Name;

                                    if (FileUpload1.FileName.Contains(oItemName))
                                    {
                                        conflict = true;
                                    }
                                }
                                if (conflict)
                                {
                                    Page.ClientScript.RegisterStartupScript(typeof(Page), "conflictMessage", "<script type=\"text/javascript\">alert(\"A file of the same name already exists. Please rename the file and try again.\");</script>"); // conflict message
                                    Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialogs1", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>"); // close dialog

                                }
                                else
                                {
                                    // Proepare to Upload
                                    web.AllowUnsafeUpdates = true;
                                    
                                    Boolean replaceExistingFiles = false;

                                    if (FileUpload1.PostedFile != null)
                                    {
                                        Stream fStream = FileUpload1.PostedFile.InputStream;
                                        byte[] contents = new byte[fStream.Length];
                                        fStream.Read(contents, 0, (int)fStream.Length);
                                        fStream.Close();
                                        string Filename = FileUpload1.FileName;
                                        fileNameAsString = Filename;

                                        fileNameAsString = SPHttpUtility.HtmlEncode(fileNameAsString);

                                        string destUrl = site.Url + "/" + docLib + "/" + Filename;
                                        SPUtility.ValidateFormDigest();
                                        web.Files.Add(destUrl, contents, replaceExistingFiles);
                                    }
                                    else
                                    {
                                        throw new FileNotFoundException("File Not Found.");
                                    }
                                    
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadWebPart", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                                NotAuthorizedToUpload.Text = ex.Message;

                                NotAuthorizedToUpload.Visible = true;
                                FileUpload1.Visible = false;
                                Button1Upload.Visible = false;
                                ButtonDelete.Visible = false;
                                ButtonCancel.Visible = false;
                                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert(\"Not authorized.\"); SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");

                            }



                        }
                    }
                });
                updateMetaData(ota, pUrl, uName, siteUrlAsString, docLibAsString, fileNameAsString, siteID, IsListContributor);

            }
            

 
        }

        private void updateMetaData(string ota, string pUrl, string uName, string siteUrlAsString, string docLibAsString, string fileNameAsString, Guid siteID, bool IsListContributor)
        {
            string summaryWS = Page.Request.QueryString["summaryWS"];
            string summaryFY = Page.Request.QueryString["summaryFY"];
            
            SPUser user = null;

            //Set user
            using (SPSite oSite = new SPSite(pUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    try
                    {
                        user = oWeb.AllUsers[uName];
                    }
                    catch { }
                    
                }
            }

            if (IsListContributor)
            {
                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb web = site.RootWeb)
                        {

                            try
                            {

                                SPList oList = web.Lists[docLibAsString];
                                
                                var traceInfo = "got oList: " + oList.Title;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevUploadWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                
                                SPFieldUserValue currentUser = new SPFieldUserValue(web, user.ID, user.Name);

                                DateTime DateDraftSaved = DateTime.Now;

                                DateTime twentyFifteen = new DateTime(2015, 1, 1);
                                long elapsedTicks = DateDraftSaved.Ticks - twentyFifteen.Ticks;

                                // get snapshot of time                           
                                var DateDraftSavedSnapShot = DateDraftSaved;
                                var TimeDraftSavedSnapShot = elapsedTicks;

                                SPQuery oQuery = new SPQuery();
                                oQuery.Query = "<Where><Eq><FieldRef Name=\"FileLeafRef\"/><Value Type=\"Text\">" + SPHttpUtility.HtmlDecode(fileNameAsString) + "</Value></Eq></Where>";
                                SPListItemCollection collListItems = oList.GetItems(oQuery);

                                foreach (SPListItem oListItem in collListItems)
                                {
                                    if (summaryWS != "None")
                                    {
                                        oListItem["WS"] = summaryWS;
                                    }
                                    else 
                                    {
                                        oListItem["Title"] = "Approval Memo";
                                    }
                                    
                                    oListItem["OTA"] = ota;
                                    oListItem["FY"] = summaryFY;
                                    oListItem["DateDraftSaved"] = DateDraftSavedSnapShot;
                                    oListItem["Submitted"] = "No";
                                    oListItem["TimeDraftSaved"] = TimeDraftSavedSnapShot;

                                    //string DraftSavedBy = oSPUser.ID + ";#" + oSPUser.LoginName;
                                    //oListItem["DraftSavedBy"] = DraftSavedBy;
                                    oListItem["DraftSavedBy"] = currentUser;
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;


                                    web.AllowUnsafeUpdates = true;
                                    SPUtility.ValidateFormDigest();
                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeedback", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }
                    }
                });

                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialogs1", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>"); // close dialog

            }

        }

        protected void ButtonDelete_Click(object sender, EventArgs e)
        {
            var traceInfo = "ButtonDelete_Click";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevDeleteDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string ota = Page.Request.QueryString["ota"];
            string pUrl = Page.Request.Url.ToString();
            string uName = Page.User.Identity.Name;
            string docID = Page.Request.QueryString["docId"];
            string siteUrlAsString = "";
            string docLibAsString = "";
            Guid siteID;
            bool IsListContributor = isListContributorCheck();

            //Set siteID
            using (SPSite oSite = new SPSite(pUrl))
            {
                using (SPWeb oWeb = oSite.OpenWeb())
                {
                    siteID = oSite.ID;
                }
            }

            if (IsListContributor)
            {
                traceInfo = "Current user is authorized to contribute to this CONOPSDev library";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevDeleteDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                
                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb web = site.RootWeb)
                        {

                            try
                            {
                                string docLib = "";
                                docLib = "CONOPSDev" + ota;


                                siteUrlAsString = site.Url;
                                docLibAsString = docLib;

                                int docId = Int32.Parse(docID);

                                web.AllowUnsafeUpdates = true;
                                
                                SPList oList = web.Lists[docLibAsString];
                                SPListItemCollection collListItems = oList.Items;
                                
                                SPUtility.ValidateFormDigest();
                                collListItems.DeleteItemById(docId);


                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsFeedback", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                        }
                    }
                });
                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialogs1", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>"); // close dialog

            }
            else
            {
                traceInfo = "Not authorized.";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevDeleteDocs", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                NotAuthorizedToUpload.Visible = true;
                FileUpload1.Visible = false;
                Button1Upload.Visible = false;
                ButtonDelete.Visible = false;
                ButtonCancel.Visible = false;


                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert(\"Not authorized.\"); SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");

            }
            
        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialogs1", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>"); // close dialog

        }
    }
}
