﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Administration;
using System.Collections.Generic;
using Microsoft.SharePoint.Utilities;

namespace DCAPXSolution.CONOPSDevModule.CONOPSDevProgressChart
{
    [ToolboxItemAttribute(false)]
    public class CONOPSDevProgressChart : WebPart
    {
        protected override void CreateChildControls()
        {
            CssRegistration.Register("/_layouts/DCAPXSolution/CustomCSSFiles/CONOPSDevProgressChart.css");
           

            string traceInfo = "";


            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16
            traceInfo = "CurrentFYforAcceptingCONOPS: " + CurrentFYforAcceptingCONOPS;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 
            

            DateTime dNext = DateTime.Now;
            dNext = dNext.AddYears(2);
            int dNextYear = dNext.Year;
            string NextFYforAcceptingCONOPS = dNextYear.ToString().Substring(2); // 17
            traceInfo = "NextFYforAcceptingCONOPS: " + NextFYforAcceptingCONOPS;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 
            
            DateTime dFuture = DateTime.Now;
            dFuture = dFuture.AddYears(3);
            int dFutureYear = dFuture.Year;
            string FutureFYforAcceptingCONOPS = dFutureYear.ToString().Substring(2); // 18
            traceInfo = "FutureFYforAcceptingCONOPS: " + FutureFYforAcceptingCONOPS;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 
            
            Dictionary<string, string> OTADictionary = new Dictionary<string,string>();
            OTADictionary.Add("AFOTEC", "Air Force Operational Test and Evaluation Center");
            OTADictionary.Add("ATEC", "Army Test and Evaluation Command");
            OTADictionary.Add("COTF", "Commander Operational Test and Evaluation Force");
            OTADictionary.Add("JITC", "Joint Interoperability Test Command");
            OTADictionary.Add("MCOTEA", "Marine Corps Operational Test and Evaluation Activity");           
            
            string OTA = "";
            string OTAshort = "";
            
            SPWeb oWebsiteRoot = SPContext.Current.Site.RootWeb;           
            SPList oList = oWebsiteRoot.Lists["ProgramContacts"];



            //SPSite mysite = SPContext.Current.Site;
            string mysiteurl = oWebsiteRoot.ServerRelativeUrl;

            traceInfo = "mysiteurl: " + mysiteurl;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 
         


            traceInfo = "Get OTA.";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string ModuleAccess = "";

            SPQuery oQuery = new SPQuery();          
            oQuery.Query = "<Where><Eq><FieldRef Name='Account'/>" +
                "<Value Type='Integer'><UserID/></Value></Eq></Where>"; 
            SPListItemCollection collListItems = oList.GetItems(oQuery);
            foreach(SPListItem oListItem in collListItems)
            {
                OTAshort = oListItem["OperationalTestAgency"].ToString();
                OTA = OTADictionary[oListItem["OperationalTestAgency"].ToString()];

                try
                {
                    ModuleAccess = oListItem["ModuleAccess"].ToString();
                    traceInfo = "ModuleAccess: " + ModuleAccess;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ModuleAccess", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ModuleAccess", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }

                //another way to get the value
                //string[] ma = oListItem["ModuleAccess"].ToString().Split(new string[] { ";#" }, StringSplitOptions.RemoveEmptyEntries);

                //foreach (string value in ma)
                //{
                //    traceInfo = "value: " + value;
                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsdeleteBtnClick", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //    if (value.Contains("Submitters"))
                //    {

                //        IsListContributor = true;

                //    }
                //}
                //end another way
            }
            
            //hidden field for ota readers so page will not spaz
            try
            {
                HiddenField isSubmitter = new HiddenField();
                isSubmitter.ID = "isSubmitter";
                if (!ModuleAccess.Contains("Submitters"))
                {

                    isSubmitter.Value = "No";

                    try
                    {
                        string oUser = Page.User.Identity.Name;
                        SPUser oSPUser = oWebsiteRoot.AllUsers[oUser];
                        SPGroupCollection currentUsersGroups = oSPUser.Groups;

                        foreach (SPGroup group in currentUsersGroups)
                        {
                            string groupName = group.Name;
                            if (groupName.Contains("CONOPSDevSubmitters") || groupName.Contains("CONOPSApproval") || groupName.Contains("DCAPXAO") || groupName.Contains("DCAPXOwners"))
                            {
                                isSubmitter.Value = "Yes";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("currentUsersGroups", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }

                this.Controls.Add(isSubmitter);

            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("isSubmitter", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }

            //end hidden field







            this.Controls.Add(new LiteralControl("<span class=\"CONOPSDevPageTitle\">CONOPS Development Module</span>" +
            "<span title='"+OTAshort+"' class=\"OTATitleCONOPSDev\" style=\"text-align: center\">" + OTA + "</span>" +
            "<div class=\"WSReviewLinks\"><a href=\"/SitePages/CONOPSDevReviewSubmitWorksheets.aspx\">FY 15 worksheets</a> |&#160; <a href=\"/SitePages/CONOPSDevReviewSubmitWorksheets.aspx\">FY 16 worksheets</a>&#160; |&#160; <a href=\"/SitePages/CONOPSDevReviewSubmitWorksheets.aspx\">FY 17 worksheets&#160;</a>&#160;&#160;</div>" +
            "<div class=\"CONOPSDevSubmittedMsg\"></div>" +
            "<div class=\"CONOPSDevPositionTableMsg\" style=\"text-align: center; font-weight: bold\">editing worksheet&#160;</div>" +
            "<div class=\"CONOPSDevPositionTablePrime\">&#160;</div>" +
            "<table width=\"100%\" class=\"CONOPSDevPositionTable \" cellspacing=\"0\" summary=\"CONOPS Development Progress Chart\" style=\"font-size: 1em\"><tbody><tr class=\"CONOPSDevProgressRow1a\" style=\"text-align: center\"><td class=\"CONOPSDevCurrentFYWS1a\">​</td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevCurrentFYWS2a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevCurrentFYWS3a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevCurrentFYWS4a\"><span>&#160; ​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevCurrentFYRSa\"><span>​</span><span>​</span><span>&#160;​</span></td></tr>" +
            "<tr class=\"CONOPSDevProgressRow1b\" style=\"text-align: center\"><td class=\"CONOPSDevPositionTitle CONOPSDevCurrentFYWS1b\">​<span id=\"wsTitleA\">FY 15 Budget </span><span id=\"wsTitleB\">Worksheet #1: </span><span id=\"wsTitleC\">Core Personnel Costs</span></td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/></td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevCurrentFYWS2b\"><span id=\"wsTitleA\">FY 15 Budget </span><span id=\"wsTitleB\">Worksheet #2: </span><span id=\"wsTitleC\">Assessment Costs</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevCurrentFYWS3b\"><span id=\"wsTitleA\">FY 15 Budget </span><span id=\"wsTitleB\">Worksheet #3: </span><span id=\"wsTitleC\">Non-Assessment Travel</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevCurrentFYWS4b\"><span id=\"wsTitleA\">FY 15 Budget </span><span id=\"wsTitleB\">Worksheet #4: </span><span id=\"wsTitleC\">Non-Assessment Support</span></td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevCurrentFYRSb\"><span id=\"wsTitleA\">FY 15 Budget </span><span id=\"wsTitleB\">Worksheets </span><span id=\"wsTitleC\">Review</span></td></tr>" +
            "<tr style=\"text-align: center\"><td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td></tr>" +
            "<tr class=\"CONOPSDevProgressRow2a\" style=\"text-align: center\"><td class=\"CONOPSDevNextFYWS1a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevNextFYWS2a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevNextFYWS3a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevNextFYWS4a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevNextFYRSa\"><span>&#160;​</span></td></tr>" +
            "<tr class=\"CONOPSDevProgressRow2b\" style=\"text-align: center\"><td class=\"CONOPSDevPositionTitle CONOPSDevNextFYWS1b\"><span id=\"wsTitleA\">FY 16 Budget </span><span id=\"wsTitleB\">Worksheet #1: </span><span id=\"wsTitleC\">Core Personnel Costs</span></td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevNextFYWS2b\"><span id=\"wsTitleA\">FY 16 Budget </span><span id=\"wsTitleB\">Worksheet #2: </span><span id=\"wsTitleC\">Assessment Costs</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevNextFYWS3b\"><span id=\"wsTitleA\">FY 16 Budget </span><span id=\"wsTitleB\">Worksheet #3: </span><span id=\"wsTitleC\">Non-Assessment Travel</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevNextFYWS4b\"><span id=\"wsTitleA\">FY 16 Budget </span><span id=\"wsTitleB\">Worksheet #4: </span><span id=\"wsTitleC\">Non-Assessment Support</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevNextFYRSb\"><span id=\"wsTitleA\">FY 16 Budget </span><span id=\"wsTitleB\">Worksheets </span><span id=\"wsTitleC\">Review</span>​</td></tr>" +
            "<tr style=\"text-align: center\"><td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td></tr>" +
            "<tr class=\"CONOPSDevProgressRow3a\" style=\"text-align: center\"><td class=\"CONOPSDevFutureFYWS1a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevFutureFYWS2a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevFutureFYWS3a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevFutureFYWS4a\"><span>&#160;​</span></td>" +
            "<td>​</td>" +
            "<td class=\"CONOPSDevFutureFYRSa\"><span>&#160;​</span></td></tr>" +
            "<tr class=\"CONOPSDevProgressRow3b\" style=\"text-align: center\"><td class=\"CONOPSDevPositionTitle CONOPSDevFutureFYWS1b\"><span id=\"wsTitleA\">FY 17 Budget </span><span id=\"wsTitleB\">Worksheet #1: </span><span id=\"wsTitleC\">Core Personnel Costs</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevFutureFYWS2b\"><span id=\"wsTitleA\">FY 17 Budget </span><span id=\"wsTitleB\">Worksheet #2: </span><span id=\"wsTitleC\">Assessment Costs</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevFutureFYWS3b\"><span id=\"wsTitleA\">FY 17 Budget </span><span id=\"wsTitleB\">Worksheet #3: </span><span id=\"wsTitleC\">Non-Assessment Travel</span>​</td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevFutureFYWS4b\"><span id=\"wsTitleA\">FY 17 Budget </span><span id=\"wsTitleB\">Worksheet #4: </span><span id=\"wsTitleC\">Non-Assessment Support</span></td>" +
            "<td><img alt=\"arrow\" src=\"/_layouts/Images/DCAPXSolution/rarrow.png\" style=\"margin: 5px; vertical-align: middle\"/>​</td>" +
            "<td class=\"CONOPSDevPositionTitle CONOPSDevFutureFYRSb\"><span id=\"wsTitleA\">FY 17 Budget </span><span id=\"wsTitleB\">Worksheets </span><span id=\"wsTitleC\">Review</span></td></tr>" +
            "<tr style=\"text-align: center\"><td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td>" +
            "<td>​</td></tr>" +
            "<tr class=\"CONOPSDevProgressRow4a\"><td colspan=\"7\" style=\"text-align: center\"><span>&#160;​</span></td>" +
            "<td colspan=\"2\" style=\"text-align: center\">​</td></tr>" +
            "<tr class=\"CONOPSDevProgressRow4b\"><td class=\"CONOPSDevPositionTitle\" colspan=\"7\" style=\"text-align: center\">Review/Submit CONOPS to DOT&amp;E ​</td>" +
            "<td colspan=\"2\" style=\"text-align: center\">​</td></tr></tbody></table>"));
            
            //"<p>&#160;</p>" +
            //"<div class=\"CONOPSDevReload\" style=\"text-align: center\"><input title=\"Continue\" id=\"ButtonContinue\" type=\"button\" value=\"Continue\"/>&#160;</div>"));

            SPList oListCONOPSDevProgress = oWebsiteRoot.Lists["CONOPSDevProgress"];

            traceInfo = "Get CONOPSDevProgress. OTAshort: " + OTAshort;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);




            
            SPQuery oQueryCONOPSDevProgress = new SPQuery();
            oQueryCONOPSDevProgress.Query = "<Where><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + OTAshort + "</Value></Eq></Where>";
            SPListItemCollection collListItemsCONOPSDevProgress = oListCONOPSDevProgress.GetItems(oQueryCONOPSDevProgress);

          
            traceInfo = "collListItemsCONOPSDevProgress.Count: " + collListItemsCONOPSDevProgress.Count;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            bool listWorksheets = false;
            foreach (SPListItem oListItem in collListItemsCONOPSDevProgress)
            {
                string ws1Progress = oListItem["WS1Progress"].ToString();

                if (ws1Progress == "Draft Completed" || ws1Progress == "Submitted")
                {
                    if (ws1Progress == "Draft Completed")
                    {
                        this.Controls.Add(new LiteralControl("<div class=\"viewWorksheetsButtonDiv\"><input class='viewWorksheetsButton' type='button' value='View Draft Worksheets' />"));

                    }
                    if (ws1Progress == "Submitted")
                    {
                        this.Controls.Add(new LiteralControl("<div class=\"viewWorksheetsButtonDiv\"><input class='viewWorksheetsButton' type='button' value='View Submitted Worksheets' />"));

                    }
                    
                    this.Controls.Add(new LiteralControl("<div id=\"worksheetsList\" style=\"text-align: center; display: none\"><ul class='drafts'>"));
                    
                    listWorksheets = true;
                    
                    break;
                }
            }
            if (listWorksheets)
            {
                foreach (SPListItem oListItem in collListItemsCONOPSDevProgress)
                {
                    string forfy = "";
                    string fy = "";


                    forfy = oListItem["ForFY"].ToString();

                    traceInfo = "forfy: " + forfy;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    if (forfy == "Current")
                    {
                        fy = CurrentFYforAcceptingCONOPS;
                    }
                    else if (forfy == "Next")
                    {
                        fy = NextFYforAcceptingCONOPS;
                    }
                    else if (forfy == "Future")
                    {
                        fy = FutureFYforAcceptingCONOPS;
                    }

                    traceInfo = "fy: " + fy;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    string ws1Progress = oListItem["WS1Progress"].ToString();
                    string ws2Progress = oListItem["WS2Progress"].ToString();
                    string ws3Progress = oListItem["WS3Progress"].ToString();
                    string ws4Progress = oListItem["WS4Progress"].ToString();

                    traceInfo = "ws1Progress: " + ws1Progress;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    traceInfo = "ws2Progress: " + ws2Progress;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    traceInfo = "ws3Progress: " + ws3Progress;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    traceInfo = "ws4Progress: " + ws4Progress;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    traceInfo = "mysiteurl: " + mysiteurl;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    traceInfo = "OTA: " + OTA;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    traceInfo = "fy: " + fy;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    

                    //Last modified by should be from CONOPSDevProgress
                    if (ws1Progress == "Draft Completed" || ws1Progress == "Submitted")
                    {
                        string ws = "1";
                        string submitted = "no";
                        string modby = oListItem["Editor"].ToString(); modby = modby.Substring(modby.IndexOf(";#") + 2);
                        if (ws1Progress == "Submitted") { submitted = "yes"; }
                        string wslinkhref = mysiteurl + "/_layouts/DCAPXSolution/CONOPSDevelopment/WS1.aspx?ota=" + SPHttpUtility.HtmlEncode(OTA) + "&otashort=" + SPHttpUtility.HtmlEncode(OTAshort) + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted;
                        string wslink = "javascript:OpenPopUpPage('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy + " Budget Worksheet #1: Core Personnel Costs";
                        traceInfo = "<li><a href=\"" + wslink + "\">" + wslinkText + "</a> Last modified by " + modby + "</li>";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        this.Controls.Add(new LiteralControl("<li><a href=\"" + wslink + "\">" + wslinkText + "</a> (Last modified by " + modby + ")</li>"));
                    }
                    if (ws2Progress == "Draft Completed" || ws2Progress == "Submitted")
                    {

                        string ws = "2";
                        string submitted = "no";
                        string modby = oListItem["Editor"].ToString(); modby = modby.Substring(modby.IndexOf(";#") + 2);
                        if (ws2Progress == "Submitted") { submitted = "yes"; }
                        string wslinkhref = mysiteurl + "/_layouts/DCAPXSolution/CONOPSDevelopment/WS2.aspx?ota=" + SPHttpUtility.HtmlEncode(OTA) + "&otashort=" + SPHttpUtility.HtmlEncode(OTAshort) + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted;
                        string wslink = "javascript:OpenPopUpPage('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy + " Budget Worksheet #2: Assessment Costs";
                        traceInfo = "<li><a href=\"" + wslink + "\">" + wslinkText + "</a> " + modby + "</li>";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        this.Controls.Add(new LiteralControl("<li><a href=\"" + wslink + "\">" + wslinkText + "</a> (Last modified by " + modby + ")</li>"));

                    }
                    if (ws3Progress == "Draft Completed" || ws3Progress == "Submitted")
                    {
                        string ws = "3";
                        string submitted = "no";
                        string modby = oListItem["Editor"].ToString(); modby = modby.Substring(modby.IndexOf(";#") + 2);
                        if (ws3Progress == "Submitted") { submitted = "yes"; }
                        string wslinkhref = mysiteurl + "/_layouts/DCAPXSolution/CONOPSDevelopment/WS3.aspx?ota=" + SPHttpUtility.HtmlEncode(OTA) + "&otashort=" + SPHttpUtility.HtmlEncode(OTAshort) + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted;
                        string wslink = "javascript:OpenPopUpPage('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy + " Budget Worksheet #3: Non-Assessment Travel​";
                        traceInfo = "<li><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        this.Controls.Add(new LiteralControl("<li><a href=\"" + wslink + "\">" + wslinkText + "</a> (Last modified by " + modby + ")</li>"));

                    }
                    if (ws4Progress == "Draft Completed" || ws4Progress == "Submitted")
                    {
                        string ws = "4";
                        string submitted = "no";
                        string modby = oListItem["Editor"].ToString(); modby = modby.Substring(modby.IndexOf(";#") + 2);
                        if (ws4Progress == "Submitted") { submitted = "yes"; }
                        string wslinkhref = mysiteurl + "/_layouts/DCAPXSolution/CONOPSDevelopment/WS4.aspx?ota=" + SPHttpUtility.HtmlEncode(OTA) + "&otashort=" + SPHttpUtility.HtmlEncode(OTAshort) + "&fy=" + fy + "&ws=" + ws + "&submitted=" + submitted;
                        string wslink = "javascript:OpenPopUpPage('" + wslinkhref + "')";
                        string wslinkText = "FY " + fy + " Budget Worksheet #4: Non-Assessment Support";
                        traceInfo = "<li><a href=\"" + wslink + "\">" + wslinkText + "</a></li>";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevProgressChart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        this.Controls.Add(new LiteralControl("<li><a href=\"" + wslink + "\">" + wslinkText + "</a> (Last modified by " + modby + ")</li>"));

                    }



                }

                this.Controls.Add(new LiteralControl("</ul></div>"));
            }
            

            


               
          

        }
    }
}
