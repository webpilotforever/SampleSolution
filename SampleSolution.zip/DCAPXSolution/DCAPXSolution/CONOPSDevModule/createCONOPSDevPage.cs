﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint;
using System.IO;
using Microsoft.SharePoint.Utilities;
using System.Xml;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.Administration;

namespace DCAPXSolution.CONOPSDevModule
{
    class createCONOPSDevPage
    {
        /// <summary>
        /// Create Web Part Page and add Web Part
        /// </summary>
        /// <param name="web">SPWeb object</param>
        /// <param name="CONOPSDevPage">File name to create</param>
        /// <param name="webPartWorksheetPath">Web part file path</param>
        /// <param name="webPartButtonPath">Web part file path</param>
        public static void CreateWebPartPage(string webUrl, string CONOPSDevPage, string webPartWorksheetPath, string webPartButtonPath, string featureName)
        {
            using (SPSite oSite = new SPSite(webUrl))
            {
                using (SPWeb web = oSite.OpenWeb())
                {
                    var traceInfo = "Get hive.";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    string templateFilename = "spstd1.aspx";
                    //  C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\14\TEMPLATE\1033\STS\DOCTEMP\SMARTPGS
                    string hive = SPUtility.GetGenericSetupPath("TEMPLATE\\1033\\STS\\DOCTEMP\\SMARTPGS\\");

                    using (FileStream stream = new FileStream(hive + templateFilename, FileMode.Open))
                    {
                        string urlToSitePages = web.ServerRelativeUrl + "/SitePages";
                        traceInfo = "Get libraryFolder: /SitePages: " + urlToSitePages;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        web.AllowUnsafeUpdates = true;
                        //SPUtility.ValidateFormDigest(); 

                        SPFolder SitePages = web.GetFolder(urlToSitePages);

                        SPFileCollection SitePagesFiles = SitePages.Files;
                        FileStream worksheetWebPart = File.OpenRead(webPartWorksheetPath);
                        FileStream buttonWebPart = null;
                        if (webPartButtonPath != "None")
                        {
                            buttonWebPart = File.OpenRead(webPartButtonPath);
                        }

                        SPFile newSitePagesFile = SitePagesFiles.Add(CONOPSDevPage, stream, true);

                        if (newSitePagesFile.CheckOutType == SPFile.SPCheckOutType.None)
                        {
                            newSitePagesFile.CheckOut();
                        }
                        SPLimitedWebPartManager wpmngr = newSitePagesFile.Web.GetLimitedWebPartManager(newSitePagesFile.ServerRelativeUrl, PersonalizationScope.Shared);

                        string error = string.Empty;
                        web.AllowUnsafeUpdates = true;
                        //SPUtility.ValidateFormDigest(); 
                        System.Web.UI.WebControls.WebParts.WebPart webpartWorksheet = wpmngr.ImportWebPart(XmlReader.Create(worksheetWebPart), out error);
                        wpmngr.AddWebPart(webpartWorksheet, "FullPage", 0);

                        if (buttonWebPart != null)
                        {
                            web.AllowUnsafeUpdates = true;
                            //SPUtility.ValidateFormDigest(); 
                            System.Web.UI.WebControls.WebParts.WebPart webpartButton = wpmngr.ImportWebPart(XmlReader.Create(buttonWebPart), out error);
                            wpmngr.AddWebPart(webpartButton, "FullPage", 1);

                        }

                        web.AllowUnsafeUpdates = true;
                        //SPUtility.ValidateFormDigest(); 
                        newSitePagesFile.CheckIn(string.Format("File added by '{0}' feature", featureName), SPCheckinType.MajorCheckIn);
                        web.AllowUnsafeUpdates = true;
                        //SPUtility.ValidateFormDigest(); 
                        //newSitePagesFile.Publish(string.Format("File published by '{0}' feature", featureName)); // You can only publish, unpublish  documents in a minor version enabled list
                        web.AllowUnsafeUpdates = true;
                        //SPUtility.ValidateFormDigest(); 
                        //newSitePagesFile.Approve(string.Format("File published by '{0}' feature", featureName)); // You can only approve or reject documents in a list for which content approval has been enabled.
                    }
                }

            }
            
          
        }
        /// <summary>
        /// This method will return Web Part Folder Path
        /// </summary>
        /// <param name="web">SPWeb object</param>
        /// <param name="rootDirectory">Feature folder path</param>
        /// <returns>Returns Web Part Folder Path</returns>
        public static string GetWebPartFolderPath(string webUrl, string rootDirectory, string webPartName, string featureName)
        {
            using (SPSite oSite = new SPSite(webUrl))
            {
                using (SPWeb web = oSite.OpenWeb())
                {
                    string[] folders = rootDirectory.Split(new char[] { '\\' });
                    var traceInfo = "Setting rootDirectory to this: " + rootDirectory;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    return string.Join("/", folders, 0, folders.Length - 1) + "/" + featureName + "/" + webPartName;
            
                }

            }
            
            
            
        }
    }
}
