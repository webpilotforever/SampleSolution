﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DCAPXSolution.CONOPSDevModule.CONOPSDevWS4
{
    [ToolboxItemAttribute(false)]
    public class CONOPSDevWS4 : WebPart
    {
        protected override void CreateChildControls()
        {
            this.Controls.Add(new LiteralControl("<table width=\"100%\" class=\"WSOTATable ms-rteFontSize-3 ms-rteTable-0\" cellspacing=\"0\"><tr class=\"ms-rteFontSize-3 ms-rteTableEvenRow-0\"><td class=\"ms-rteFontSize-3 ms-rteTableEvenCol-0\"><div class=\"WSOTADiv WSOTA\">OTA </div></td></tr><tr class=\"ms-rteFontSize-3 ms-rteTableOddRow-0\"><td class=\"ms-rteFontSize-3 ms-rteTableEvenCol-0\">​ </td></tr></table>​ <table width=\"100%\" class=\"ms-rteTable-default\" cellspacing=\"0\" style=\"font-size: 1em\"><tr class=\"ms-rteTableEvenRow-default\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"5\" style=\"text-align: center\"><strong><div class=\"WSTitle\">FY <span class=\"WSFY\">15</span> BUDGET WORKSHEET #4: NON-ASSESSMENT SUPPORT COSTS​</div></strong></td></tr><tr class=\"WSColHeaders ms-rteThemeBackColor-5-2 ms-rteTableOddRow-default\" style=\"text-align: center\"><td class=\"ms-rteThemeBackColor-5-2 ms-rteTableEvenCol-default\" colspan=\"2\"><strong>Item Description</strong></td><td class=\"ms-rteThemeBackColor-5-2 ms-rteTableOddCol-default\"><strong>Number​</strong></td><td class=\"ms-rteThemeBackColor-5-2 ms-rteTableEvenCol-default\"><strong>Remarks​</strong></td><td class=\"ms-rteThemeBackColor-5-2 ms-rteTableOddCol-default\"><strong>Funding</strong>​</td></tr><tr class=\"WSColDesc ms-rteTableEvenRow-default\" style=\"text-align: center\"><td class=\"ms-rteTableEvenCol-default\" colspan=\"2\"><em>Provide a description of each item, service, or training course</em></td><td class=\"ms-rteTableOddCol-default\"><em>Identify the number of items for purchase or the number of people attending the training</em></td><td class=\"ms-rteTableEvenCol-default\"><em>Provide any comments to help clarify your cost estimates</em></td><td class=\"ms-rteTableOddCol-default\"><em>Estimated cost for each item/service/training course</em></td></tr><tr class=\"ms-rteTableOddRow-default\" style=\"text-align: center\"><td class=\"ms-rteTableEvenCol-default\" style=\"width: 18px\"><div title=\"Delete row\" class=\"WSBtnDeleteRow\">–</div><div title=\"Add row\" class=\"WSBtnAddRow\">+</div></td><td class=\"ms-rteTableOddCol-default\">​<input name=\"CONOPSDevTitle\" title=\"Item Description\" id=\"Title\" type=\"text\" size=\"16\" style=\"width: 130px\" /></td><td class=\"ms-rteTableEvenCol-default\"><input name=\"CONOPSDevNumber\" title=\"Number\" id=\"Number\" type=\"text\" />​</td><td class=\"ms-rteTableOddCol-default\"><input name=\"CONOPSDevRemarks\" title=\"Remarks\" id=\"Remarks\" type=\"text\" style=\"width: 130px\" /></td><td class=\"ms-rteTableEvenCol-default\"><input name=\"CONOPSDevFunding\" title=\"Funding\" id=\"Funding\" type=\"text\" size=\"10\" style=\"width: 83px\" /><input name=\"CONOPSDevContentTypeId\" id=\"ContentTypeId\" type=\"hidden\" /></td></tr><tr class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenRow-default\" style=\"text-align: center\"><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableEvenCol-default\" colspan=\"4\" style=\"text-align: right\">​<span> </span><strong>Total:</strong><span>​</span></td><td class=\"ms-rteThemeBackColor-9-1 ms-rteTableOddCol-default\"><input name=\"CONOPSDevTotal\" title=\"Total\" id=\"Total\" type=\"text\" size=\"10\" value=\"0\" style=\"width: 83px\" />​<input name=\"CONOPSDevContentTypeId\" id=\"ContentTypeId\" type=\"hidden\" /></td></tr></table>" +
                                            "<div class=\"WSNav\"><div title=\"Save worksheet\" class=\"WSBtnSaveAndNext\">Save FY <span class=\"WSFY\">00</span> Budget Worksheet #4: Non-Assessment Support Costs​</div></div></div"));


        }
    }
}
