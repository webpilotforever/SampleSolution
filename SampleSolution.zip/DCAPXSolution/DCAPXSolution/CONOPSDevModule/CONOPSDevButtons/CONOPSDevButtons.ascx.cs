﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System.Web.UI.WebControls;
using System.Web;
using System.Collections.Specialized;
using System.Net;
using System.Web.UI.HtmlControls;
using System.Web.UI;
using System.Text.RegularExpressions;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System.Collections.Generic;




namespace DCAPXSolution.CONOPSDevModule.CONOPSDevButtons
{
    [ToolboxItemAttribute(false)]
    public partial class CONOPSDevButtons : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public CONOPSDevButtons()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //==== CONOPSDevAttachments ====
            if (Page.Request.Url.ToString().Contains("CONOPSDevReviewSubmitWorksheets") && (Page.Request.QueryString["showTable"] == "current" || Page.Request.QueryString["showTable"] == "next" || Page.Request.QueryString["showTable"] == "future" || Page.Request.QueryString["showTable"] == "submit"))
            {
                string summaryFY = Page.Request.QueryString["summaryFY"]; // example: 16, 17, or 18
                
                string ota = Page.Request.QueryString["ota"];

                string siteName = Page.Request.Url.ToString();
                siteName = siteName.Substring(siteName.IndexOf("DCAPX"));
                siteName = siteName.Substring(0, siteName.IndexOf("/"));
                var traceInfo = "siteName: " + siteName;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPList oList = SPContext.Current.Web.GetList("/sites/" + siteName + "/CONOPSDev" + ota); // example: /CONOPSDevATEC
                string listId = oList.ID.ToString();
                CONOPSDevLibID.Text = SPHttpUtility.HtmlEncode(listId);
                traceInfo = "listId: " + listId + " CONOPSDevLibID.Text: " + CONOPSDevLibID.Text + " lib: " + "CONOPSDev" + ota;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                SPQuery oQuery = new SPQuery();
                oQuery.Query = "" +
                    "<GroupBy Collapse=\"TRUE\" GroupLimit=\"30\">" +
                        "<FieldRef Name=\"WS\"/>" +
                    "</GroupBy>" +
                        "<OrderBy>" +
                            "<FieldRef Name=\"FileLeafRef\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + summaryFY + "</Value>" +
                                "</Eq>" +
                                "<Neq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Neq>" +
                            "</And>" +
                        "</Where>";

                SPQuery oQueryForSubmit = new SPQuery();
                oQueryForSubmit.Query = "" +
                    
                        "<OrderBy>" +
                            "<FieldRef Name=\"FileLeafRef\"/>" +
                        "</OrderBy>" +
                        "<Where>" +
                            "<And>" +
                                "<Eq>" +
                                    "<FieldRef Name=\"FY\"/>" +
                                    "<Value Type=\"Text\">" + summaryFY + "</Value>" +
                                "</Eq>" +
                                "<Neq>" +
                                    "<FieldRef Name=\"Submitted\"/>" +
                                    "<Value Type=\"Text\">Yes</Value>" +
                                "</Neq>" +
                            "</And>" +
                                
                        "</Where>";


                //SPListItemCollection collListItems = oList.GetItems(oQuery);
                
                SPListItemCollection collListItems = null;
                
                if (Page.Request.QueryString["showTable"] == "submit")
                {
                    collListItems = oList.GetItems(oQueryForSubmit);

                }
                else
                {
                    collListItems = oList.GetItems(oQuery);
                }

                int count = collListItems.Count;
                traceInfo = "collListItems.Count: " + collListItems.Count;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                int i = 2;
                CONOPSDevAttachments.Text = "";

                string splitter = "|||";

                foreach (SPListItem oListItem in collListItems)
                {
                    if (i > count)
                    {
                        splitter = "";
                    }
                    string wst = "";

                    if (oListItem["WS"] != null)
                    {
                        wst = oListItem["WS"].ToString();
                        traceInfo = "oListItem[WS].ToString(): " + oListItem["WS"].ToString();
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                    }
                    CONOPSDevAttachments.Text += "" +
                        SPHttpUtility.HtmlEncode(wst) +
                        "," +
                        SPHttpUtility.HtmlEncode(oListItem.ID.ToString()) +
                        "," +
                        SPHttpUtility.HtmlEncode(oListItem["FileRef"].ToString()) +
                        "," +
                        SPHttpUtility.HtmlEncode(oListItem["FileLeafRef"].ToString()) +
                        splitter;

                    i++;
                }
                traceInfo = "CONOPSDevAttachments.Text: " + CONOPSDevAttachments.Text;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            }           
            
               

            

            //=== end CONOPSDevAttachments ====
            
            //-------------
            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16

            DateTime dNext = DateTime.Now;
            dNext = dNext.AddYears(2);
            int dNextYear = dNext.Year;
            string NextFYforAcceptingCONOPS = dNextYear.ToString().Substring(2); // 17

            DateTime dFuture = DateTime.Now;
            dFuture = dFuture.AddYears(3);
            int dFutureYear = dFuture.Year;
            string FutureFYforAcceptingCONOPS = dFutureYear.ToString().Substring(2); // 18

            string FY = Page.Request.QueryString["summaryFY"];
            
            
            
            // Continue button
            if (Page.Request.Url.ToString().Contains("CONOPSDevelopment.aspx"))
            {

                //if (Page.Request.QueryString["showdrafts"] == "true")
                //{
                //    CONOPSDevButton.Visible = false;
                //}
                CONOPSDevButton.Text = "Continue";
                //string usersOTA = "";

                bool IsListContributor = false;
                using (SPSite oSiteCollection = new SPSite(Page.Request.Url.ToString()))
                {
                    var traceInfo = "OpenWeb";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    using (SPWeb oWebsiteRoot = oSiteCollection.OpenWeb())
                    {
                        try
                        {
                            string oUser = Page.User.Identity.Name;

                            traceInfo = "oUser: " + oUser;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            SPUser oSPUser = oWebsiteRoot.AllUsers[oUser];
                            traceInfo = "oSPUser.LoginName: " + oSPUser.LoginName + " oSPUser.ID: " + oSPUser.ID;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            traceInfo = "Get oSPUser.Groups";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            SPGroupCollection currentUsersGroups = oSPUser.Groups;

                            foreach (SPGroup group in currentUsersGroups)
                            {
                                string groupName = group.Name;
                                if (groupName.Contains("CONOPSDevSubmitters" + Page.Request.QueryString["ota"]) || groupName.Contains("CONOPSApproval") || groupName.Contains("DCAPXAO") || groupName.Contains("DCAPXOwners"))
                                {
                                    IsListContributor = true;
                                }
                            }


                         

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEvents", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                    }
                }
                if (!IsListContributor)
                {
                    
                    CONOPSDevButton.Visible = false;


                    
                }


            }

            // Save WS button
            if (Page.Request.Url.ToString().Contains("CONOPSDevWS"))
            {

                if(Page.Request.Url.ToString().Contains("CONOPSDevWS1"))
                {
                    CONOPSDevButton.Text = "Save FY " + FY + " Budget Worksheet #1: Core Personnel Costs";
                
                }
                if (Page.Request.Url.ToString().Contains("CONOPSDevWS2"))
                {
                    CONOPSDevButton.Text = "Save FY " + FY + " Budget Worksheet #2: Assessment Costs";

                }
                if (Page.Request.Url.ToString().Contains("CONOPSDevWS3"))
                {
                    CONOPSDevButton.Text = "Save FY " + FY + " Budget Worksheet #3: Non-Assessment Travel";

                }
                if (Page.Request.Url.ToString().Contains("CONOPSDevWS4"))
                {
                    CONOPSDevButton.Text = "Save FY " + FY + " Budget Worksheet #4: Non-Assessment Support Costs";

                }
                if (!Page.IsPostBack && (Page.Request.QueryString["showTable"] == "next" || Page.Request.QueryString["showTable"] == "future"))
                {
                    // Query for currentFY param worksheets to prepop next or future ws
                    bool usecurrentFYForPrePop = false;
                    using (SPSite oSiteCollection = new SPSite(Page.Request.Url.ToString()))
                    {
                        var traceInfo = "OpenWeb";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        using (SPWeb oWebsiteRoot = oSiteCollection.OpenWeb())
                        {
                            


                            try
                            {
                                string wsNum = "WS" + CONOPSDevButton.Text.Substring(CONOPSDevButton.Text.IndexOf("#")+1, 1);
                                
                                traceInfo = "wsNum: " + wsNum;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                string wsList = "CONOPSDevWS" + Page.Request.QueryString["ota"];

                                SPList oList = oWebsiteRoot.Lists[wsList];

                                SPQuery oQueryOfWSList = new SPQuery();
                                oQueryOfWSList.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">" + wsNum + "</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type\"Text\">" + Page.Request.QueryString["currentFY"] + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWSList = oList.GetItems(oQueryOfWSList);

                                if (collListItemsWSList.Count > 1)
                                {
                                    usecurrentFYForPrePop = true;
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }

                    }
                   
                    // If none exist, then query for CurrentFYforAcceptingCONOPS worksheets to prepop next or future ws
                    if (usecurrentFYForPrePop)
                    {

                        var traceInfo = "usecurrentFYForPrePop should be true: " + usecurrentFYForPrePop + " So setting button attr to be found by CONOPSDevPrePop.js.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        // using method below because calling js always happened before js/jqery could load
                        // so assumption is that the tooltip will always be set before the js/jquery (CONOPSDevWSPrePop.js ) can load. Then using jq to look for title attr to determine which prepop function to call.
                        // added CONOPSDevWSPrePop.js functions to Global.js
                        CONOPSDevButton.ToolTip = "Save worksheet";


                    }
                    else
                    {
                        var traceInfo = "usecurrentFYForPrePop should be false: " + usecurrentFYForPrePop + " So setting button attr to be found by CONOPSDevPrePop.js.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsPrepop", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        CONOPSDevButton.ToolTip = "";
                    }

                }
                
            }

            // Submit CONOPS to DOT&E
            if (Page.Request.Url.ToString().Contains("CONOPSDevReviewSubmitWorksheets") && Page.Request.QueryString["showTable"]=="submit")
            {
           

                CONOPSDevButton.ToolTip = "Submit CONOPS to DOT&E";
                CONOPSDevButton.Text = "Submit CONOPS to DOT&E";

                if (Page.IsPostBack)
                {
                    var traceInfo = "IsPostBack is true: " + Page.IsPostBack + " So closeDialog.";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");

                }
                
                
            }
            
        }
        protected void CONOPSDevButton_Click(object sender, EventArgs e)
        {
            string traceInfo = "";
            Button clickedButton = (Button)sender; 

            string wsList = "CONOPSDevWS" + Page.Request.QueryString["ota"];
            string wsLib = "CONOPSDev" + Page.Request.QueryString["ota"];
            string ota = Page.Request.QueryString["ota"];
            bool IsListContributor = false;

            SPUser user;
            Guid siteID;


            using (SPSite oSite = new SPSite(Page.Request.Url.ToString()))
            {
                using (SPWeb oWeb = oSite.RootWeb)
                {
                    user = oWeb.CurrentUser;
                    siteID = oSite.ID;

                    SPGroupCollection currentUsersGroups = user.Groups;

                    foreach (SPGroup group in currentUsersGroups)
                    {
                        string groupName = group.Name;
                        if (groupName.Contains("CONOPSDevSubmitters" + ota) || groupName.Contains("CONOPSApproval") || groupName.Contains("DCAPXAO") || groupName.Contains("DCAPXOwners"))
                        {
                            IsListContributor = true;

                            traceInfo = "IsListContributor should be true: " + IsListContributor;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
              
                        }
                    }

                }

            }


            // Continue button should refresh the page.
            if (Page.Request.Url.ToString().Contains("CONOPSDevelopment.aspx"))
            {
                // needs to only load up to the search
                //Button clickedButton = (Button)sender; 
                traceInfo = "CONOPSDevButton 'Continue' clicked. clickedButton.ID: " + clickedButton.ID;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevButtons", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo); 
               

                string urlMinusSearch = Page.Request.Url.ToString();
                urlMinusSearch = urlMinusSearch.Substring(0, urlMinusSearch.IndexOf("?"));

                
                traceInfo = "urlMinusSearch: "+urlMinusSearch;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevButtons", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                Page.Response.Redirect(urlMinusSearch);
                 
            }
            else if (Page.Request.Url.ToString().Contains("CONOPSDevReviewSubmitWorksheets") && Page.Request.QueryString["showTable"]=="submit")
            {
                //clickedButton.Text = "Submitting. Please wait...";
                
                traceInfo = "CONOPSDevButton 'Submit CONOPS to DOT&E' clicked.";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                
                DateTime DateDraftSaved = DateTime.Now;

                DateTime twentyFifteen = new DateTime(2015, 1, 1);
                long elapsedTicks = DateDraftSaved.Ticks - twentyFifteen.Ticks;



                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb web = site.RootWeb)
                        {

                            try
                            {

                                traceInfo = "CONOPSDevSubmit";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPFieldUserValue currentUser = new SPFieldUserValue(web, user.ID, user.Name);

                                SPList oList = web.Lists[wsList];
                                SPList oListLib = web.Lists[wsLib]; 


                                DateTime dCurrent = DateTime.Now;
                                dCurrent = dCurrent.AddYears(1);
                                int dCurrentYear = dCurrent.Year;
                                string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 16

                                DateTime dNext = DateTime.Now;
                                dNext = dNext.AddYears(2);
                                int dNextYear = dNext.Year;
                                string NextFYforAcceptingCONOPS = dNextYear.ToString().Substring(2); // 17

                                DateTime dFuture = DateTime.Now;
                                dFuture = dFuture.AddYears(3);
                                int dFutureYear = dFuture.Year;
                                string FutureFYforAcceptingCONOPS = dFutureYear.ToString().Substring(2); // 18

                                //range vars
                                string FirstItemIDCurrentFYWS1 = "";
                                string FirstItemIDNextFYWS1 = "";
                                string FirstItemIDFutureFYWS1 = "";

                                string LastItemIDCurrentFYWS1 = "";
                                string LastItemIDNextFYWS1 = "";
                                string LastItemIDFutureFYWS1 = "";

                                string FirstItemIDCurrentFYWS2 = "";
                                string FirstItemIDNextFYWS2 = "";
                                string FirstItemIDFutureFYWS2 = "";

                                string LastItemIDCurrentFYWS2 = "";
                                string LastItemIDNextFYWS2 = "";
                                string LastItemIDFutureFYWS2 = "";

                                string FirstItemIDCurrentFYWS3 = "";
                                string FirstItemIDNextFYWS3 = "";
                                string FirstItemIDFutureFYWS3 = "";

                                string LastItemIDCurrentFYWS3 = "";
                                string LastItemIDNextFYWS3 = "";
                                string LastItemIDFutureFYWS3 = "";

                                string FirstItemIDCurrentFYWS4 = "";
                                string FirstItemIDNextFYWS4 = "";
                                string FirstItemIDFutureFYWS4 = "";

                                string LastItemIDCurrentFYWS4 = "";
                                string LastItemIDNextFYWS4 = "";
                                string LastItemIDFutureFYWS4 = "";







                               
                                traceInfo = "oQueryWSLib next";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                
                                //---- WS LIST LIB TO SUBMITTED ---------

                                SPQuery oQueryWSLib = new SPQuery();
                                //oQueryWSLib.Query = "<Where><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq></Where>";
                                oQueryWSLib.Query = "" +
                                           "<OrderBy>" +
                                               "<FieldRef Name=\"ID\" Ascending=\"FALSE\"/>" +
                                           "</OrderBy>" +
                                           "<Where>" +
                                                "<And>" +
                                                   "<Geq>" +
                                                       "<FieldRef Name=\"FY\"/>" +
                                                       "<Value Type=\"Text\">" + CurrentFYforAcceptingCONOPS + "</Value>" + 
                                                   "</Geq>" + 
                                                   "<Neq>" +
                                                       "<FieldRef Name=\"Submitted\"/>" +
                                                       "<Value Type=\"Text\">Yes</Value>" +
                                                   "</Neq>" +
                                               "</And>" +
                                           "</Where>";
                                
                                
                                
                                SPListItemCollection collListItemsWSLib = oListLib.GetItems(oQueryWSLib);

                               




                                
                                List<string> itemsForSecondPass = new List<string>();
                                
                                foreach (SPListItem oListItem in collListItemsWSLib)
                                {
                                    itemsForSecondPass.Add(oListItem.ID.ToString());

                                    //VERSION 3.0 BASELINE OTA SUBMISSION
                                    string appendFileName = "_ID" + oListItem.ID.ToString();
                                    string baseName = oListItem["BaseName"].ToString();

                                    traceInfo = "baseName: " + baseName + " appendFileName: " + appendFileName;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    oListItem["BaseName"] = baseName + appendFileName;

                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list lib to Submitted: " + wsLib;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    web.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }
                                //=====UPDATE METADATA AGAIN AS START OF CONOPSAPPROVAL====



                                foreach (string itemForSecondPass in itemsForSecondPass)
                                {
                                    //version 4.0 AO Recommendation
                                    SPListItem oitemForSecondPass = oListLib.GetItemById(Int32.Parse(itemForSecondPass));

                                    oitemForSecondPass["Submitted"] = "";
                                    oitemForSecondPass["SubmittedFY"] = "";
                                    oitemForSecondPass["SubmittedBy"] = "";
                                    oitemForSecondPass["SubmittedOn"] = "";
                                    oitemForSecondPass["CONOPSApproval"] = "AO Recommendation";

                                    web.AllowUnsafeUpdates = true;

                                    oitemForSecondPass.Update();
                                }











                                //---- WS LIST set range vars ------

                                traceInfo = "CONOPSDevSubmit";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    

                                //Current
                                string DateDraftSavedWS1Current = "";

                                SPQuery oQueryWS1Current = new SPQuery();
                                oQueryWS1Current.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS1</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + CurrentFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS1Current = oList.GetItems(oQueryWS1Current);

                                foreach (SPListItem oListItem in collListItemsWS1Current)
                                {

                                    if (DateDraftSavedWS1Current != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS1Current != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS1Current = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDCurrentFYWS1=="")
                                    {
                                        LastItemIDCurrentFYWS1 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDCurrentFYWS1 = oListItem.ID.ToString();
                                 
                                }

                                traceInfo = "FirstItemIDCurrentFYWS1: " + FirstItemIDCurrentFYWS1 + " LastItemIDCurrentFYWS1: " + LastItemIDCurrentFYWS1;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                

                                string DateDraftSavedWS2Current = "";

                                SPQuery oQueryWS2Current = new SPQuery();
                                oQueryWS2Current.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS2</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + CurrentFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS2Current = oList.GetItems(oQueryWS2Current);

                                foreach (SPListItem oListItem in collListItemsWS2Current)
                                {

                                    if (DateDraftSavedWS2Current != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS2Current != "")
                                    {

                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS2Current = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDCurrentFYWS2 == "")
                                    {
                                        LastItemIDCurrentFYWS2 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDCurrentFYWS2 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS3Current = "";

                                SPQuery oQueryWS3Current = new SPQuery();
                                oQueryWS3Current.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS3</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + CurrentFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS3Current = oList.GetItems(oQueryWS3Current);

                                foreach (SPListItem oListItem in collListItemsWS3Current)
                                {

                                    if (DateDraftSavedWS3Current != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS3Current != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS3Current = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDCurrentFYWS3 == "")
                                    {
                                        LastItemIDCurrentFYWS3 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDCurrentFYWS3 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS4Current = "";

                                SPQuery oQueryWS4Current = new SPQuery();
                                oQueryWS4Current.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS4</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + CurrentFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS4Current = oList.GetItems(oQueryWS4Current);

                                foreach (SPListItem oListItem in collListItemsWS4Current)
                                {

                                    if (DateDraftSavedWS4Current != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS4Current != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS4Current = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDCurrentFYWS4 == "")
                                    {
                                        LastItemIDCurrentFYWS4 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDCurrentFYWS4 = oListItem.ID.ToString();

                                }

                                //Next
                                string DateDraftSavedWS1Next = "";

                                SPQuery oQueryWS1Next = new SPQuery();
                                oQueryWS1Next.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS1</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + NextFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS1Next = oList.GetItems(oQueryWS1Next);

                                foreach (SPListItem oListItem in collListItemsWS1Next)
                                {

                                    if (DateDraftSavedWS1Next != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS1Next != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS1Next = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDNextFYWS1 == "")
                                    {
                                        LastItemIDNextFYWS1 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDNextFYWS1 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS2Next = "";

                                SPQuery oQueryWS2Next = new SPQuery();
                                oQueryWS2Next.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS2</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + NextFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS2Next = oList.GetItems(oQueryWS2Next);

                                foreach (SPListItem oListItem in collListItemsWS2Next)
                                {

                                    if (DateDraftSavedWS2Next != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS2Next != "")
                                    {

                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS2Next = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDNextFYWS2 == "")
                                    {
                                        LastItemIDNextFYWS2 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDNextFYWS2 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS3Next = "";

                                SPQuery oQueryWS3Next = new SPQuery();
                                oQueryWS3Next.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS3</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + NextFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS3Next = oList.GetItems(oQueryWS3Next);

                                foreach (SPListItem oListItem in collListItemsWS3Next)
                                {

                                    if (DateDraftSavedWS3Next != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS3Next != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS3Next = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDNextFYWS3 == "")
                                    {
                                        LastItemIDNextFYWS3 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDNextFYWS3 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS4Next = "";

                                SPQuery oQueryWS4Next = new SPQuery();
                                oQueryWS4Next.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS4</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + NextFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS4Next = oList.GetItems(oQueryWS4Next);

                                foreach (SPListItem oListItem in collListItemsWS4Next)
                                {

                                    if (DateDraftSavedWS4Next != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS4Next != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS4Next = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDNextFYWS4 == "")
                                    {
                                        LastItemIDNextFYWS4 = oListItem.ID.ToString();
                                    }
                                   FirstItemIDNextFYWS4 = oListItem.ID.ToString();

                                }

                                //Future
                                string DateDraftSavedWS1Future = "";

                                SPQuery oQueryWS1Future = new SPQuery();
                                oQueryWS1Future.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS1</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + FutureFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS1Future = oList.GetItems(oQueryWS1Future);

                                foreach (SPListItem oListItem in collListItemsWS1Future)
                                {

                                    if (DateDraftSavedWS1Future != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS1Future != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS1Future = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDFutureFYWS1 == "")
                                    {
                                        LastItemIDFutureFYWS1 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDFutureFYWS1 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS2Future = "";

                                SPQuery oQueryWS2Future = new SPQuery();
                                oQueryWS2Future.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS2</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + FutureFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS2Future = oList.GetItems(oQueryWS2Future);

                                foreach (SPListItem oListItem in collListItemsWS2Future)
                                {

                                    if (DateDraftSavedWS2Future != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS2Future != "")
                                    {

                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS2Future = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDFutureFYWS2 == "")
                                    {
                                        LastItemIDFutureFYWS2 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDFutureFYWS2 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS3Future = "";

                                SPQuery oQueryWS3Future = new SPQuery();
                                oQueryWS3Future.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS3</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + FutureFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS3Future = oList.GetItems(oQueryWS3Future);

                                foreach (SPListItem oListItem in collListItemsWS3Future)
                                {

                                    if (DateDraftSavedWS3Future != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS3Future != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS3Future = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDFutureFYWS3 == "")
                                    {
                                        LastItemIDFutureFYWS3 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDFutureFYWS3 = oListItem.ID.ToString();

                                }

                                string DateDraftSavedWS4Future = "";

                                SPQuery oQueryWS4Future = new SPQuery();
                                oQueryWS4Future.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"FALSE\"/></OrderBy><Where><And><And><Neq><FieldRef Name=\"Submitted\"/><Value Type=\"Text\">Yes</Value></Neq><Eq><FieldRef Name=\"ContentType\"/><Value Type=\"Computed\">WS4</Value></Eq></And><Eq><FieldRef Name=\"FY\"/><Value Type=\"Text\">" + FutureFYforAcceptingCONOPS + "</Value></Eq></And></Where>";
                                SPListItemCollection collListItemsWS4Future = oList.GetItems(oQueryWS4Future);

                                foreach (SPListItem oListItem in collListItemsWS4Future)
                                {

                                    if (DateDraftSavedWS4Future != oListItem["DateDraftSaved"].ToString() && DateDraftSavedWS4Future != "")
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        DateDraftSavedWS4Future = oListItem["DateDraftSaved"].ToString();
                                    }
                                    if (LastItemIDFutureFYWS4 == "")
                                    {
                                        LastItemIDFutureFYWS4 = oListItem.ID.ToString();
                                    }
                                    FirstItemIDFutureFYWS4 = oListItem.ID.ToString();

                                }

                                //UPDATE WS LIST

                                traceInfo = "Update WS List";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                
                                SPQuery oQueryWS1Currentb = new SPQuery();
                                oQueryWS1Currentb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDCurrentFYWS1 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDCurrentFYWS1 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS1Currentb = oList.GetItems(oQueryWS1Currentb);
                                foreach (SPListItem oListItem in collListItemsWS1Currentb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS2Currentb = new SPQuery();
                                oQueryWS2Currentb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDCurrentFYWS2 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDCurrentFYWS2 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS2Currentb = oList.GetItems(oQueryWS2Currentb);
                                foreach (SPListItem oListItem in collListItemsWS2Currentb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS3Currentb = new SPQuery();
                                oQueryWS3Currentb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDCurrentFYWS3 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDCurrentFYWS3 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS3Currentb = oList.GetItems(oQueryWS3Currentb);
                                foreach (SPListItem oListItem in collListItemsWS3Currentb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS4Currentb = new SPQuery();
                                oQueryWS4Currentb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDCurrentFYWS4 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDCurrentFYWS4 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS4Currentb = oList.GetItems(oQueryWS4Currentb);
                                foreach (SPListItem oListItem in collListItemsWS4Currentb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }


                                SPQuery oQueryWS1Nextb = new SPQuery();
                                oQueryWS1Nextb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDNextFYWS1 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDNextFYWS1 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS1Nextb = oList.GetItems(oQueryWS1Nextb);
                                foreach (SPListItem oListItem in collListItemsWS1Nextb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = NextFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS2Nextb = new SPQuery();
                                oQueryWS2Nextb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDNextFYWS2 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDNextFYWS2 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS2Nextb = oList.GetItems(oQueryWS2Nextb);
                                foreach (SPListItem oListItem in collListItemsWS2Nextb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = NextFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS3Nextb = new SPQuery();
                                oQueryWS3Nextb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDNextFYWS3 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDNextFYWS3 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS3Nextb = oList.GetItems(oQueryWS3Nextb);
                                foreach (SPListItem oListItem in collListItemsWS3Nextb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = NextFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS4Nextb = new SPQuery();
                                oQueryWS4Nextb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDNextFYWS4 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDNextFYWS4 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS4Nextb = oList.GetItems(oQueryWS4Nextb);
                                foreach (SPListItem oListItem in collListItemsWS4Nextb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = NextFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }



                                SPQuery oQueryWS1Futureb = new SPQuery();
                                oQueryWS1Futureb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDFutureFYWS1 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDFutureFYWS1 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS1Futureb = oList.GetItems(oQueryWS1Futureb);
                                foreach (SPListItem oListItem in collListItemsWS1Futureb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = FutureFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS2Futureb = new SPQuery();
                                oQueryWS2Futureb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDFutureFYWS2 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDFutureFYWS2 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS2Futureb = oList.GetItems(oQueryWS2Futureb);
                                foreach (SPListItem oListItem in collListItemsWS2Futureb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = FutureFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS3Futureb = new SPQuery();
                                oQueryWS3Futureb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDFutureFYWS3 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDFutureFYWS3 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS3Futureb = oList.GetItems(oQueryWS3Futureb);
                                foreach (SPListItem oListItem in collListItemsWS3Futureb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = FutureFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                SPQuery oQueryWS4Futureb = new SPQuery();
                                oQueryWS4Futureb.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\"/></OrderBy><Where><And><Geq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + FirstItemIDFutureFYWS4 + "</Value></Geq><Leq><FieldRef Name=\"ID\"/><Value Type=\"Integer\">" + LastItemIDFutureFYWS4 + "</Value></Leq></And></Where>";
                                SPListItemCollection collListItemsWS4Futureb = oList.GetItems(oQueryWS4Futureb);
                                foreach (SPListItem oListItem in collListItemsWS4Futureb)
                                {
                                    oListItem["Submitted"] = "Yes";
                                    oListItem["SubmittedFY"] = FutureFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    oListItem["CONOPSApproval"] = "Baseline OTA Submission";
                                    oListItem["Author"] = currentUser;
                                    oListItem["Editor"] = currentUser;
                                    traceInfo = "Update WS list to Submitted: " + wsList;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                    web.AllowUnsafeUpdates = true;
                                    oListItem.Update();
                                }
                                

                                //----- CONOPSDEVPROGRESS TO SUBMITTED -----

                                SPList CONOPSDevProgress = web.Lists["CONOPSDevProgress"];

                                traceInfo = "got CONOPSDevProgress: " + CONOPSDevProgress.Title;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPQuery oQueryCONOPSDevProgress = new SPQuery();
                                oQueryCONOPSDevProgress.Query = "<Where><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + ota + "</Value></Eq></Where>";
                                SPListItemCollection collListItemsCONOPSDevProgress = CONOPSDevProgress.GetItems(oQueryCONOPSDevProgress);

                                foreach (SPListItem oListItem in collListItemsCONOPSDevProgress)
                                {
                                    oListItem["WS1Progress"] = "Submitted";
                                    oListItem["WS2Progress"] = "Submitted";
                                    oListItem["WS3Progress"] = "Submitted";
                                    oListItem["WS4Progress"] = "Submitted";
                                    oListItem["WSReview"] = "Submitted";
                                    oListItem["SubmittedFY"] = CurrentFYforAcceptingCONOPS;
                                    string SubmittedBy = user.ID + ";#" + user.LoginName;
                                    oListItem["SubmittedBy"] = SubmittedBy;
                                    oListItem["SubmittedOn"] = DateDraftSaved;
                                    
                                    oListItem["Editor"] = currentUser;

                                    traceInfo = "Update CONOPSDevProgress list to Submitted for OTA: " + ota;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    web.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }


                                

                                //----- CONOPSAPPROVALPROGRESS TO SUBMITTED -----

                                SPList CONOPSApprovalProgress = web.Lists["CONOPSApprovalProgress"];

                                traceInfo = "got CONOPSApprovalProgress: " + CONOPSApprovalProgress.Title;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
                                oQueryCONOPSApprovalProgress.Query = "<Where><Eq><FieldRef Name='OperationalTestAgency'/><Value Type='Text'>" + ota + "</Value></Eq></Where>";
                                SPListItemCollection collListItemsCONOPSApprovalProgress = CONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);

                                foreach (SPListItem oListItem in collListItemsCONOPSApprovalProgress)
                                {
                                    oListItem["CONOPSApproval"] = "AO Recommendation";
                                   
                                    traceInfo = "Update CONOPSApprovalProgress list for OTA: " + ota;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    web.AllowUnsafeUpdates = true;

                                    oListItem.Update();
                                }
                                
                                duplicateSubmittedItemsToInitiateCONOPSApproval(currentUser, siteID, oList, oListLib, traceInfo, collListItemsWS1Currentb, collListItemsWS2Currentb, collListItemsWS3Currentb, collListItemsWS4Currentb);

                            
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevSubmit", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }



                        }
                    }
                });



            }
           
            else if (Page.Request.Url.ToString().Contains("CONOPSDevWS")) // CONOPSDevWS1-4
            {
                traceInfo = "CONOPSDevButton 'Save' clicked.";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCONOPSDevButtons", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                if (IsListContributor)
                {
                    traceInfo = "Current user is authorized to contribute to this CONOPSDevWS list";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    if (HttpContext.Current != null)
                    {
                        if (Page.Response != null)
                        {

                            var response = Page.Response;
                            var request = HttpContext.Current.Request;
                            NameValueCollection coll;
                            coll = request.Form;
                           
                            string pattern = @"\D";
                            Regex rgx = new Regex(pattern);

                            string pattern2 = @"\d";
                            Regex rgx2 = new Regex(pattern2);

                            //string wsList = "CONOPSDevWS" + request.QueryString["ota"];
                            DateTime DateDraftSaved = DateTime.Now;

                            DateTime twentyFifteen = new DateTime(2015, 1, 1);
                            long elapsedTicks = DateDraftSaved.Ticks - twentyFifteen.Ticks;
 
                            // get snapshot of time                           
                            var DateDraftSavedSnapShot = DateDraftSaved;
                            var TimeDraftSavedSnapShot = elapsedTicks;

                            List<string> rowNums = new List<string>();



                           



                            // get unique rowNums
                            foreach (String s in coll.AllKeys)
                            {
                                string rowNum = rgx.Replace(s, ""); // 3
                                string sWithNoNum = rgx2.Replace(s, "");
                                //Page.Response.Write("sWithNoNum: " + sWithNoNum + "<br/>");
                                if (sWithNoNum.StartsWith("CONOPSDev"))
                                {
                                    if(!rowNums.Contains(rowNum))
                                    {
                                        rowNums.Add(rowNum);
                                    }
                                }
                            }
                            foreach(string rowNum in rowNums)
                            {
                                gotRow(coll, rowNum, rgx, rgx2, DateDraftSavedSnapShot, TimeDraftSavedSnapShot, wsList);
                            }

                          


                        }

                    }

                }
                else
                {
                    traceInfo = "Current user is not authorized to contribute to this CONOPSDevWS list";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert(\"Current user is not authorized to contribute to this CONOPSDevWS list\"); SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");
                }
            }
            else if (Page.Request.Url.ToString().Contains("CONOPSDevReviewSubmitWorksheets") && (Page.Request.QueryString["showTable"] == "current" || Page.Request.QueryString["showTable"] == "next" || Page.Request.QueryString["showTable"] == "future"))
            {
                
                traceInfo = "CONOPSDevButton 'FY OK' clicked.";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                
                if (IsListContributor)
                {
                    traceInfo = "Current user is authorized to contribute to the CONOPSDevWS lists";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    updateCONOPSDevProgress();

                }
                else
                {
                    traceInfo = "Current user is not authorized to contribute to the CONOPSDevWS lists";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert(\"Current user is not authorized to contribute to this CONOPSDevWS list\"); SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");
                }
                

            }
            

        }

        private void duplicateSubmittedItemsToInitiateCONOPSApproval(SPFieldUserValue currentUser, Guid siteID, SPList oList, SPList oListLib, string traceInfo, SPListItemCollection collListItemsWS1Currentb, SPListItemCollection collListItemsWS2Currentb, SPListItemCollection collListItemsWS3Currentb, SPListItemCollection collListItemsWS4Currentb)
        {
            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb web = site.RootWeb)
                    {
                        traceInfo = "CONOPSDevDuplicate";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevDuplicate", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        try
                        {



                            foreach (SPListItem oListItem in collListItemsWS1Currentb)
                            {
                                SPListItem newListItem = oList.Items.Add();
                                newListItem["ContentTypeId"] = oListItem.ContentTypeId;
                                newListItem["Title"] = oListItem["Title"].ToString();
                                newListItem["CONOPSApproval"] = "AO Recommendation";
                                newListItem["DateDraftSaved"] = oListItem["DateDraftSaved"];
                                newListItem["TimeDraftSaved"] = oListItem["TimeDraftSaved"];
                                newListItem["DraftSavedBy"] = oListItem["DraftSavedBy"];
                                newListItem["Author"] = currentUser;
                                newListItem["Editor"] = currentUser;

                                if (oListItem["DutyTitlePosition"] != null) { newListItem["DutyTitlePosition"] = oListItem["DutyTitlePosition"].ToString(); }
                                if (oListItem["Status"] != null) { newListItem["Status"] = oListItem["Status"].ToString(); }
                                if (oListItem["Remarks"] != null) { newListItem["Remarks"] = oListItem["Remarks"].ToString(); }
                                if (oListItem["ContractorRate"] != null) { newListItem["ContractorRate"] = oListItem["ContractorRate"].ToString(); }
                                if (oListItem["GSLevel"] != null) { newListItem["GSLevel"] = oListItem["GSLevel"].ToString(); }
                                if (oListItem["Funding"] != null) { newListItem["Funding"] = oListItem["Funding"].ToString(); }
                                if (oListItem["GovLaborMonth"] != null) { newListItem["GovLaborMonth"] = oListItem["GovLaborMonth"].ToString(); }
                                if (oListItem["Employer"] != null) { newListItem["Employer"] = oListItem["Employer"].ToString(); }
                                if (oListItem["Contract"] != null) { newListItem["Contract"] = oListItem["Contract"].ToString(); }
                                if (oListItem["ContractFee"] != null) { newListItem["ContractFee"] = oListItem["ContractFee"].ToString(); }
                                if (oListItem["ContractTotal"] != null) { newListItem["ContractTotal"] = oListItem["ContractTotal"].ToString(); }
                                if (oListItem["AdditionalLineItem"] != null) { newListItem["AdditionalLineItem"] = oListItem["AdditionalLineItem"].ToString(); }
                                if (oListItem["MilitarySubTotal"] != null) { newListItem["MilitarySubTotal"] = oListItem["MilitarySubTotal"].ToString(); }
                                if (oListItem["Total"] != null) { newListItem["Total"] = oListItem["Total"].ToString(); }
                                if (oListItem["ContractsSubTotal"] != null) { newListItem["ContractsSubTotal"] = oListItem["ContractsSubTotal"].ToString(); }
                                if (oListItem["HoursPerYear"] != null) { newListItem["HoursPerYear"] = oListItem["HoursPerYear"].ToString(); }
                                if (oListItem["OTA"] != null) { newListItem["OTA"] = oListItem["OTA"].ToString(); }
                                if (oListItem["FY"] != null) { newListItem["FY"] = oListItem["FY"].ToString(); }

                                newListItem["OTASubmissionID"] = oListItem.ID.ToString(); 

                                web.AllowUnsafeUpdates = true;

                                newListItem.Update();

                            }

                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("collListItemsWS1Currentb", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        try
                        {

                            foreach (SPListItem oListItem in collListItemsWS2Currentb)
                            {
                                SPListItem newListItem = oList.Items.Add();
                                newListItem["ContentTypeId"] = oListItem.ContentTypeId;
                                newListItem["Title"] = oListItem["Title"].ToString();
                                newListItem["CONOPSApproval"] = "AO Recommendation";
                                newListItem["DateDraftSaved"] = oListItem["DateDraftSaved"];
                                newListItem["TimeDraftSaved"] = oListItem["TimeDraftSaved"];
                                newListItem["DraftSavedBy"] = oListItem["DraftSavedBy"];
                                newListItem["Author"] = currentUser;
                                newListItem["Editor"] = currentUser;

                                if (oListItem["Dates"] != null) { newListItem["Dates"] = oListItem["Dates"].ToString(); }
                                if (oListItem["People"] != null) { newListItem["People"] = oListItem["People"].ToString(); }
                                if (oListItem["EventLocation"] != null) { newListItem["EventLocation"] = oListItem["EventLocation"].ToString(); }
                                if (oListItem["EstTravel"] != null) { newListItem["EstTravel"] = oListItem["EstTravel"].ToString(); }
                                if (oListItem["EstLaborOvertime"] != null) { newListItem["EstLaborOvertime"] = oListItem["EstLaborOvertime"].ToString(); }
                                if (oListItem["Funding"] != null) { newListItem["Funding"] = oListItem["Funding"].ToString(); }
                                if (oListItem["Venue"] != null) { newListItem["Venue"] = oListItem["Venue"].ToString(); }
                                if (oListItem["VenueSubTotal"] != null) { newListItem["VenueSubTotal"] = oListItem["VenueSubTotal"].ToString(); }
                                if (oListItem["Total"] != null) { newListItem["Total"] = oListItem["Total"].ToString(); }
                                if (oListItem["OTA"] != null) { newListItem["OTA"] = oListItem["OTA"].ToString(); }
                                if (oListItem["FY"] != null) { newListItem["FY"] = oListItem["FY"].ToString(); }

                                newListItem["OTASubmissionID"] = oListItem.ID.ToString(); 
                                web.AllowUnsafeUpdates = true;

                                newListItem.Update();

                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("collListItemsWS2Currentb", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        try
                        {

                            foreach (SPListItem oListItem in collListItemsWS3Currentb)
                            {
                                SPListItem newListItem = oList.Items.Add();
                                newListItem["ContentTypeId"] = oListItem.ContentTypeId;
                                newListItem["Title"] = oListItem["Title"].ToString();
                                newListItem["CONOPSApproval"] = "AO Recommendation";
                                newListItem["DateDraftSaved"] = oListItem["DateDraftSaved"];
                                newListItem["TimeDraftSaved"] = oListItem["TimeDraftSaved"];
                                newListItem["DraftSavedBy"] = oListItem["DraftSavedBy"];
                                newListItem["Author"] = currentUser;
                                newListItem["Editor"] = currentUser;

                                if (oListItem["People"] != null) { newListItem["People"] = oListItem["People"].ToString(); }
                                if (oListItem["Dates"] != null) { newListItem["Dates"] = oListItem["Dates"].ToString(); }
                                if (oListItem["Remarks"] != null) { newListItem["Remarks"] = oListItem["Remarks"].ToString(); }
                                if (oListItem["Funding"] != null) { newListItem["Funding"] = oListItem["Funding"].ToString(); }
                                if (oListItem["Total"] != null) { newListItem["Total"] = oListItem["Total"].ToString(); }
                                if (oListItem["OTA"] != null) { newListItem["OTA"] = oListItem["OTA"].ToString(); }
                                if (oListItem["FY"] != null) { newListItem["FY"] = oListItem["FY"].ToString(); }

                                newListItem["OTASubmissionID"] = oListItem.ID.ToString(); 
                                web.AllowUnsafeUpdates = true;

                                newListItem.Update();

                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("collListItemsWS3Currentb", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        try
                        {

                            foreach (SPListItem oListItem in collListItemsWS4Currentb)
                            {
                                SPListItem newListItem = oList.Items.Add();
                                newListItem["ContentTypeId"] = oListItem.ContentTypeId;
                                newListItem["Title"] = oListItem["Title"].ToString();
                                newListItem["CONOPSApproval"] = "AO Recommendation";
                                newListItem["DateDraftSaved"] = oListItem["DateDraftSaved"];
                                newListItem["TimeDraftSaved"] = oListItem["TimeDraftSaved"];
                                newListItem["DraftSavedBy"] = oListItem["DraftSavedBy"];
                                newListItem["Author"] = currentUser;
                                newListItem["Editor"] = currentUser;

                                if (oListItem["Number"] != null) { newListItem["Number"] = oListItem["Number"].ToString(); }
                                if (oListItem["Remarks"] != null) { newListItem["Remarks"] = oListItem["Remarks"].ToString(); }
                                if (oListItem["Funding"] != null) { newListItem["Funding"] = oListItem["Funding"].ToString(); }
                                if (oListItem["Total"] != null) { newListItem["Total"] = oListItem["Total"].ToString(); }
                                if (oListItem["OTA"] != null) { newListItem["OTA"] = oListItem["OTA"].ToString(); }
                                if (oListItem["FY"] != null) { newListItem["FY"] = oListItem["FY"].ToString(); }

                                newListItem["OTASubmissionID"] = oListItem.ID.ToString(); 
                                web.AllowUnsafeUpdates = true;

                                newListItem.Update();

                            }


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("collListItemsWS4Currentb", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        



                    }
                }
            });
        }




        private void gotRow(NameValueCollection coll, string rowNum, Regex rgx, Regex rgx2, DateTime DateDraftSavedSnapShot, long TimeDraftSavedSnapShot, string wsList)
        {
            Dictionary<string, string> worksheetFieldsDictionary = new Dictionary<string, string>();
            string pattern = @"CONOPSDev";
            Regex rgx3 = new Regex(pattern);
            
            foreach (String s in coll.AllKeys)
            {
                string rrowNum = rgx.Replace(s, ""); // 3
                string sWithNoNum = rgx2.Replace(s, "");
                string sWithNoNumNoCONOPSDev = rgx3.Replace(sWithNoNum, "");
                if (sWithNoNum.StartsWith("CONOPSDev"))
                {
                    if (rowNum == rrowNum)
                    {
                        //Page.Response.Write("rowNum is: "+rowNum+"s: " + s + " coll[s]: " + coll[s] + "<br/>");
                        
                        //if Additional Line Item Title is blank
                        if (sWithNoNumNoCONOPSDev == "Title")
                        {
                            var traceInfo = "sWithNoNumNoCONOPSDev: " + sWithNoNumNoCONOPSDev + " coll[s]: " + coll[s];
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            if (coll[s] != "" && coll[s] !="0.00")
                            {
                                worksheetFieldsDictionary.Add(sWithNoNumNoCONOPSDev, coll[s]);
                            }

                        }
                        else { worksheetFieldsDictionary.Add(sWithNoNumNoCONOPSDev, coll[s]); }
                        //worksheetFieldsDictionary.Add(sWithNoNumNoCONOPSDev, coll[s]);

                    }



                }
            }
            updateWSList(wsList, worksheetFieldsDictionary, DateDraftSavedSnapShot, TimeDraftSavedSnapShot);
        }

        private void updateWSList(string wsList, Dictionary<string, string> worksheetFieldsDictionary, DateTime DateDraftSavedSnapShot, long TimeDraftSavedSnapShot)
        {
            string traceInfo = "";
           
            string ota = Page.Request.QueryString["ota"];
            string summaryfy = Page.Request.QueryString["summaryFY"];

            SPUser user;
            Guid siteID;


            using (SPSite oSite = new SPSite(Page.Request.Url.ToString()))
            {
                using (SPWeb oWeb = oSite.RootWeb)
                {
                    user = oWeb.CurrentUser;
                    siteID = oSite.ID;

                }

            }


            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb web = site.RootWeb)
                    {
                        try
                        {
                            SPFieldUserValue currentUser = new SPFieldUserValue(web, user.ID, user.Name);

                            SPList oList = web.Lists[wsList];
                            traceInfo = "got oList: " + oList.Title;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                            SPListItem oListItem = oList.Items.Add();

                            foreach (KeyValuePair<string, string> kvp in worksheetFieldsDictionary)
                            {
                                //
                                traceInfo = "Is " + kvp.Key + " null? kvp.Value: " + kvp.Value + " kvp.Value.GetType: " + kvp.Value.GetType() + " kvp.Value.ToString: " + kvp.Value.ToString();
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("KvpCONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //if (kvp.Value.Length > 0)
                                //{
                                //    traceInfo = "kvp.Value has length:  " + kvp.Value.Length;
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                //}


                                //if (kvp.Value != "" && kvp.Value != "null")
                                //{
                                //    traceInfo = "kvp.Value: " + kvp.Value + "kvp.Value.Length: |" + kvp.Value.Length + "|";
                                //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSaveKvp", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                //    oListItem[kvp.Key] = kvp.Value;
                                //}

                                //if (kvp.Value == "" || kvp.Value == "null" || kvp.Value.ToString() == "null")
                                //{
                                //    if(kvp.Key == "Title")
                                //    {
                                //        oListItem[kvp.Key] = "(None)";
                                //    }
                                //    else
                                //    {
                                //        oListItem[kvp.Key] = System.String.Empty;
                                //    }
                                    
                                //}
                                
                                
                                if (kvp.Key == "Title" && kvp.Value == "")
                                {
                                    //uncomment to allow for Additional Line Item Title with value of None and 0.00 for Additional Line Item (assuming it is required -- but why would it be?)
                                    //oListItem[kvp.Key] = "None"; //Additional Line Item Title 

                                    //No Title? No item created. 
                                }
                                else
                                {
                                    oListItem[kvp.Key] = kvp.Value;
                                }
                            }
                            oListItem["OTA"] = ota;
                            oListItem["FY"] = summaryfy;
                            oListItem["DateDraftSaved"] = DateDraftSavedSnapShot;
                            oListItem["Submitted"] = "No";

                            oListItem["TimeDraftSaved"] = TimeDraftSavedSnapShot;

                            string DraftSavedBy = user.ID + ";#" + user.LoginName;
                            oListItem["DraftSavedBy"] = DraftSavedBy;

                            oListItem["Author"] = currentUser;
                            oListItem["Editor"] = currentUser;


                            traceInfo = "Update WS list: " + wsList;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            web.AllowUnsafeUpdates = true;
                            
                            oListItem.Update();

                            traceInfo = "WS list updated: " + wsList;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        
                    }
                }
            });

            updateCONOPSDevProgress(); 



        }

        private void updateCONOPSDevProgress()
        {
            var traceInfo = "";
            bool IsListContributor = false;
            
            using (SPSite oSiteCollection = new SPSite(Page.Request.Url.ToString()))
            {
                traceInfo = "OpenWeb";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                using (SPWeb oWebsiteRoot = oSiteCollection.OpenWeb())
                {
                    try
                    {
                        string oUser = Page.User.Identity.Name;
                       
                        traceInfo = "oUser: " + oUser;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                        SPUser oSPUser = oWebsiteRoot.AllUsers[oUser];
                        traceInfo = "oSPUser.LoginName: " + oSPUser.LoginName + " oSPUser.ID: " + oSPUser.ID;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        traceInfo = "Get oSPUser.Groups";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        SPGroupCollection currentUsersGroups = oSPUser.Groups;

                        foreach (SPGroup group in currentUsersGroups)
                        {
                            string groupName = group.Name;
                            if (groupName.Contains("CONOPSDevSubmitters" + Page.Request.QueryString["ota"]) || groupName.Contains("CONOPSApproval") || groupName.Contains("DCAPXAO") || groupName.Contains("DCAPXOwners"))
                            {
                                IsListContributor = true;
                            }
                        }


                    }
                    catch (Exception ex)
                    {
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                    }
                }
            }
            if (IsListContributor)
            {
                traceInfo = "Current user is authorized to contribute to the CONOPSDevWS lists";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                Guid siteid;
                SPUser user;
                
                using (SPSite oSite = new SPSite(Page.Request.Url.ToString()))
                {
                    using (SPWeb oWeb = oSite.OpenWeb())
                    {
                        traceInfo = "Getting siteid.";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsGetSiteID", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        siteid = oSite.ID;
                        user = oWeb.CurrentUser;
                       
                    }

                }
                ///---------------- no need to update Author or Editor as these will be set when CONOPS are submitted
                SPSecurity.RunWithElevatedPrivileges(delegate()
                {
                    traceInfo = "Getting site collection: " + Page.Request.Url.ToString();
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                  
                    using (SPSite oSiteCollection = new SPSite(siteid))
                    {
                        traceInfo = "OpenWeb";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        using (SPWeb oWebsiteRoot = oSiteCollection.OpenWeb())
                        {
                            try
                            {
                                
                                SPFieldUserValue currentUser = new SPFieldUserValue(oWebsiteRoot, user.ID, user.Name);
                               
                                SPList CONOPSDevProgress = oWebsiteRoot.Lists["CONOPSDevProgress"];

                                traceInfo = "got CONOPSDevProgress: " + CONOPSDevProgress.Title;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                                oWebsiteRoot.AllowUnsafeUpdates = true;

                                bool review = false;

                                if (Page.Request.QueryString["review"] != null)
                                {
                                    if (Page.Request.QueryString["review"] == "true")
                                    {
                                        review = true;
                                    }
                                }
                                if (!review)
                                {
                                    if (Page.Request.Url.ToString().Contains("CONOPSDevWS1"))
                                    {
                                        SPListItem oListItem = CONOPSDevProgress.Items[Int32.Parse(Page.Request.QueryString["itemId"]) - 1]; // indexer so minus one
                                        oListItem["WS1Progress"] = "Draft Completed";
                                        oListItem["WS2Progress"] = "In Progress";
                                        oListItem["Editor"] = currentUser;
                                        
                                        oListItem.Update();
                                    }
                                    if (Page.Request.Url.ToString().Contains("CONOPSDevWS2"))
                                    {
                                        SPListItem oListItem = CONOPSDevProgress.Items[Int32.Parse(Page.Request.QueryString["itemId"]) - 1]; // indexer so minus one
                                        oListItem["WS2Progress"] = "Draft Completed";
                                        oListItem["WS3Progress"] = "In Progress";
                                        oListItem["Editor"] = currentUser;
                                        oListItem.Update();
                                    }
                                    if (Page.Request.Url.ToString().Contains("CONOPSDevWS3"))
                                    {
                                        SPListItem oListItem = CONOPSDevProgress.Items[Int32.Parse(Page.Request.QueryString["itemId"]) - 1]; // indexer so minus one
                                        oListItem["WS3Progress"] = "Draft Completed";
                                        oListItem["WS4Progress"] = "In Progress";
                                        oListItem["Editor"] = currentUser;
                                        oListItem.Update();
                                    }

                                    if (Page.Request.Url.ToString().Contains("CONOPSDevWS4"))
                                    {
                                        traceInfo = "WS4Progress to Draft Completed for " + Page.Request.QueryString["itemId"];
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                        SPListItem oListItem = CONOPSDevProgress.Items[Int32.Parse(Page.Request.QueryString["itemId"]) - 1]; // indexer so minus one
                                        oListItem["WS4Progress"] = "Draft Completed";
                                        oListItem["WSReview"] = "In Progress";
                                        oListItem["Editor"] = currentUser;
                                        oListItem.Update();
                                    }
                                } 

                                

                                if (Page.Request.Url.ToString().Contains("CONOPSDevReviewSubmitWorksheets"))
                                {
                                    SPListItem oListItem = CONOPSDevProgress.Items[Int32.Parse(Page.Request.QueryString["itemId"]) - 1];
                                    SPListItem oListItem2 = null;
                                    traceInfo = "try setting next row first column progress";
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    try
                                    {
                                        oListItem2 = CONOPSDevProgress.Items[Int32.Parse(Page.Request.QueryString["itemId"])]; // this would be plus one if it was not an indexer


                                    }
                                    catch { }

                                    if (oListItem2 != null)
                                    {
                                        string ota = Page.Request.QueryString["ota"];
                                        if (ota == oListItem2["OperationalTestAgency"].ToString())
                                        {
                                            //If there is one set next row first column to In Progress
                                            oListItem2["WS1Progress"] = "In Progress";
                                            oListItem["Editor"] = currentUser;
                                            oListItem2.Update();
                                        }

                                    }
                                    oWebsiteRoot.AllowUnsafeUpdates = true;
                                    //Previous row WSReview set to Draft Completed
                                    oListItem["WSReview"] = "Draft Completed";
                                    oListItem["Editor"] = currentUser;
                                    oListItem.Update();
                                }

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                        }
                    }
                });
                if (Page.Request.QueryString["review"] != null)
                {
                    if (Page.Request.QueryString["review"] == "true")
                    {
                        Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialogs1", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(\"OK\", \"Worksheet edited during review\");</script>"); // close dialog for worksheet

                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialogs1", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>"); // close dialog for worksheet
                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialogs1", "<script type=\"text/javascript\">SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>"); // close dialog for worksheet

                    
                }

            }
            else
            {
                traceInfo = "Current user is not authorized to contribute to the CONOPSDevWS lists";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("CONOPSDevEventsSave", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                Page.ClientScript.RegisterStartupScript(typeof(Page), "closeDialog", "<script type=\"text/javascript\">alert(\"Current user is not authorized to contribute to this CONOPSDevWS list\"); SP.UI.ModalDialog.commonModalDialogClose(null, 1);</script>");
            }


        }

    }
}
