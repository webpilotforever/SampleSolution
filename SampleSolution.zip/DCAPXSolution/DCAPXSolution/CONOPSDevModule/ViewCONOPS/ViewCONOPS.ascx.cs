﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace DCAPXSolution.CONOPSDevModule.ViewCONOPS
{
    [ToolboxItemAttribute(false)]
    public partial class ViewCONOPS : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public ViewCONOPS()
        {
            
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {

          
  
            
            //Web
            SPWeb oWeb = SPContext.Current.Web;

            //Current user OTA from ProgramContacts list
            SPUser usr = oWeb.CurrentUser;

            //CONOPSApprovalProgress
            SPList oListCONOPSApprovalProgress = oWeb.Lists["CONOPSApprovalProgress"];

            //ProgramContacts
            SPList oListProgramContacts = oWeb.Lists["ProgramContacts"];

            //CONOPSDevProgress
            SPList oListCONOPSDevProgress = oWeb.Lists["CONOPSDevProgress"];

            //query ProgramContacts
            SPQuery oQueryProgramContacts = new SPQuery();
            oQueryProgramContacts.Query = "<Where><Eq><FieldRef Name=\"Account\"/><Value Type=\"Integer\"><UserID /></Value></Eq></Where>";



           
            string usrOTA = ""; //ATEC

            try 
            {
                SPListItemCollection collListItems = oListProgramContacts.GetItems(oQueryProgramContacts);

                foreach(SPListItem oListItem in collListItems)
                {
                    usrOTA = oListItem["OperationalTestAgency"].ToString();
                }
            
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ViewCONOPSWebPartusrOTA", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }

            

            DateTime dCurrent = DateTime.Now;
            dCurrent = dCurrent.AddYears(1);
            int dCurrentYear = dCurrent.Year;
            string CurrentFYforAcceptingCONOPS = dCurrentYear.ToString().Substring(2); // 17
            
            var traceInfo = "CurrentFYforAcceptingCONOPS: " + CurrentFYforAcceptingCONOPS + " usrOTA: " + usrOTA;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ViewCONOPSWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string fy = CurrentFYforAcceptingCONOPS;




            //Annual Reset of CONOPS
            DCAPXSolution.sitesDCAPXRootWeb.CONOPSAnnualReset.resetCONOPSAnnually(oListCONOPSDevProgress, CurrentFYforAcceptingCONOPS, oWeb);
            DCAPXSolution.sitesDCAPXRootWeb.CONOPSAnnualReset.resetCONOPSAnnually(oListCONOPSApprovalProgress, CurrentFYforAcceptingCONOPS, oWeb);






            ViewCONOPSWebPartBtn.Text = "View FY " + fy + " CONOPS";
            
            Label1.Text = "Current FY for Accepting CONOPS: " + fy;


            if (usrOTA != "")
            {




                Label2.Visible = HasNoSubmittedCONOPSDevItems(oListCONOPSDevProgress, usrOTA, fy); // If has no submitted conopsdev items show Please submit message.

                if (!Page.Request.Url.AbsolutePath.Contains("CONOPSDevelopment.aspx"))
                {
                                    
                    conosdevlink.Visible = HasNoSubmittedCONOPSDevItems(oListCONOPSDevProgress, usrOTA, fy);

                }
                
                
                string pathToCONOPSDevelopmentModulePage = oWeb.ServerRelativeUrl + "/SitePages/CONOPSDevelopment.aspx";
                conosdevlink.Attributes.Add("href", pathToCONOPSDevelopmentModulePage);





                Dictionary<string, string> OTADictionary = new Dictionary<string, string>();
                OTADictionary.Add("AFOTEC", "Air Force Operational Test and Evaluation Center");
                OTADictionary.Add("ATEC", "Army Test and Evaluation Command");
                OTADictionary.Add("COTF", "Commander Operational Test and Evaluation Force");
                OTADictionary.Add("JITC", "Joint Interoperability Test Command");
                OTADictionary.Add("MCOTEA", "Marine Corps Operational Test and Evaluation Activity");

                //query CONOPSApprovalProgress
                SPQuery oQueryCONOPSApprovalProgress = new SPQuery();
                oQueryCONOPSApprovalProgress.Query = "<Where>" +
                    "<And><And><And>" +
                        "<Eq>" +
                            "<FieldRef Name='OperationalTestAgency'/>" +
                                "<Value Type='Choice'>" + usrOTA + "</Value>" +
                         "</Eq>" +
                         "<Eq>" +
                            "<FieldRef Name='Submitted'/>" +
                                "<Value Type='Text'>Yes</Value>" +
                            "</Eq>" +
                    "</And>" +
                        "<Eq>" +
                            "<FieldRef Name='SubmittedFY'/>" +
                                "<Value Type='Text'>" + fy + "</Value>" +
                            "</Eq>" +
                    "</And>" +

                        "<Eq>" +
                            "<FieldRef Name='CONOPSApproval'/>" +
                                "<Value Type='Choice'>Deputy Director Approval</Value>" +
                            "</Eq>" +
                    "</And>" +
                "</Where>";
                SPListItemCollection collListItemsApproval = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress);



                //query CONOPSApprovalProgress3
                SPQuery oQueryCONOPSApprovalProgress3 = new SPQuery();
                oQueryCONOPSApprovalProgress3.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\" /></OrderBy><Where>" +

                        "<Eq>" +
                            "<FieldRef Name='OperationalTestAgency'/>" +
                                "<Value Type='Choice'>" + usrOTA + "</Value>" +
                         "</Eq>" +

                "</Where>";
                SPListItemCollection collListItemsq3 = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress3);

                bool beingReviewed = false;



                if (collListItemsApproval.Count > 0)
                {
                    
                    ViewCONOPSWebPartBtn.Visible = true;

                    foreach (SPListItem oListItem in collListItemsq3)
                    {
                        if ((string)oListItem["Submitted"] != "Yes")
                        {
                            beingReviewed = true;
                        }
                    }


                    if (beingReviewed) { Label1.Text = "Submitted CONOPS for FY " + fy + " are being reviewed by DOT&E."; Label1.Visible = true; } else { Label1.Visible = false; }


                    string otaLong = OTADictionary[usrOTA];
                    string url1 = oWeb.ServerRelativeUrl;

                    traceInfo = "url1: " + url1 + " otaLong: " + otaLong + " fy: " + fy + " usrOTA: " + usrOTA;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ViewCONOPSWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    var linkhref = url1 + "/_layouts/DCAPXSolution/CONOPSDevelopment/ViewCONOPSWP.aspx?ota=" + SPHttpUtility.HtmlEncode(otaLong) + "&otashort=" + usrOTA + "&fy=" + fy;

                    traceInfo = "linkhref: " + linkhref;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ViewCONOPSWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    ViewCONOPSWebPartBtn.OnClientClick = "OpenPopUpPage('" + linkhref + "'); return(false);";

                    //Build table
                    TableRow rowHeader = new TableRow();
                    TableCell cell1Header = new TableCell();
                    //TableCell cell2Header = new TableCell();

                    //cell1Header.Text = "Worksheet";
                    //cell2Header.Text = "Approval Step";

                    //cell1Header.Style.Add("font-size", "10px");
                    //cell2Header.Style.Add("font-size", "10px");

                    cell1Header.Text = "FY " + fy + " CONOPS Worksheets Approval";
                    cell1Header.Style.Add("font-size", "10px");
                    cell1Header.Style.Add("text-align", "center");
                    cell1Header.ColumnSpan = 2;
                    cell1Header.Style.Add("border-bottom-style", "solid");
                    cell1Header.Style.Add("border-bottom-width", "1px");
                    cell1Header.Style.Add("border-bottom-color", "silver");

                    rowHeader.Cells.Add(cell1Header);
                    //rowHeader.Cells.Add(cell2Header);



                    Table1.Rows.Add(rowHeader);
                    //---end header


                    foreach (SPListItem oListItem in collListItemsq3)
                    {

                        TableRow row = new TableRow();
                        TableCell cell1 = new TableCell();
                        TableCell cell2 = new TableCell();

                        string wsPoundNumber = oListItem.Title;

                        wsPoundNumber = wsPoundNumber.Substring(2, 1); //1

                        cell1.Text = "WS #" + wsPoundNumber + " ";

                        cell1.Style.Add("border-right-style", "solid");
                        cell1.Style.Add("border-right-width", "1px");
                        cell1.Style.Add("border-right-color", "silver");
                        cell1.Style.Add("white-space", "nowrap");

                        cell2.Style.Add("white-space", "nowrap");
                        cell2.Style.Add("text-align", "left");
                        cell2.Style.Add("padding-left", "15px");
                        cell2.Style.Add("background-repeat", "no-repeat");
                        cell2.Style.Add("background-position", "3px 5px");


                        if ((string)oListItem["CONOPSApproval"] == "Deputy Director Approval")
                        {

                            cell2.Text = "Deputy Director Review and Approval";
                            cell2.Style.Add("background-image", "url(/_layouts/Images/DCAPXSolution/dd.gif)");

                        }
                        else if ((string)oListItem["CONOPSApproval"] == "PM Preapproval")
                        {

                            cell2.Text = "PM Review";
                            cell2.Style.Add("background-image", "url(/_layouts/Images/DCAPXSolution/pm.gif)");


                        }
                        else
                        {

                            cell2.Text = "AO Review";
                            cell2.Style.Add("background-image", "url(/_layouts/Images/DCAPXSolution/ao.gif)");


                        }


                        row.Cells.Add(cell1);
                        row.Cells.Add(cell2);

                        Table1.Rows.Add(row);


                    }
                    Table1.CellPadding = 2;
                    
                
                    Table1.Visible = beingReviewed;



                }
                else
                {
                    //query CONOPSApprovalProgress4
                    SPQuery oQueryCONOPSApprovalProgress4 = new SPQuery();
                    oQueryCONOPSApprovalProgress4.Query = "<OrderBy><FieldRef Name=\"ID\" Ascending=\"TRUE\" /></OrderBy><Where>" +
                        "<And>"+
                            "<Eq>" +
                                "<FieldRef Name='OperationalTestAgency'/>" +
                                    "<Value Type='Choice'>" + usrOTA + "</Value>" +
                             "</Eq>" +
                            "<Neq>" +
                                "<FieldRef Name='CONOPSApproval'/>" +
                                    "<Value Type='Choice'>Baseline OTA Submission</Value>" +
                             "</Neq>" +
                        "</And>"+
                    "</Where>";
                    SPListItemCollection collListItemsq4 = oListCONOPSApprovalProgress.GetItems(oQueryCONOPSApprovalProgress4);

                    traceInfo = "collListItemsq4.Count: " + collListItemsq4.Count;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("ViewCONOPSWebPart", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (collListItemsq4.Count > 0)
                    {
                        
                        
                        //show approving message
                        Label1.Text = "Submitted CONOPS for FY " + fy + " are being reviewed by DOT&E.";
                        Label1.Visible = true;
                    }
                }
            }
           
     

        }





        private bool HasNoSubmittedCONOPSDevItems(SPList oListCONOPSDevProgress, string usrOTA, string fy)
        {
            bool tOrF = true;

            //query CONOPSDevProgress
            SPQuery oQueryCONOPSDevProgress = new SPQuery();
            oQueryCONOPSDevProgress.Query = "<Where>" +
                "<And>" +
                    "<Eq>" +
                        "<FieldRef Name='OperationalTestAgency'/>" +
                            "<Value Type='Choice'>" + usrOTA + "</Value>" +
                     "</Eq>" +
                     "<Eq>" +
                        "<FieldRef Name='SubmittedFY'/>" +
                            "<Value Type='Text'>" + fy + "</Value>" +
                        "</Eq>" +
                "</And>" +
            "</Where>";
            SPListItemCollection collListItems = oListCONOPSDevProgress.GetItems(oQueryCONOPSDevProgress);
            if (collListItems.Count > 0) { tOrF = false; }

            return tOrF;
        }

      
    }
}
