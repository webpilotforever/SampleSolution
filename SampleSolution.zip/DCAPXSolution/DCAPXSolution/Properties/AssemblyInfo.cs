﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

// New WebApp? 
// Be sure to update port in the Site URL property of this Visual Studio project (click on DCAPXSolution in Solution Explorer).

// r-click on solution in Solution Explorer 
//  Retract
//  Deploy (adds to solution store)
// SharePoint Management Shell example follows
// install-spsolution -identity dcapxsolution.wsp -gacdeployment -force -webapplication http://dotersrcndapp5:2619/

//  (on siprnet use -allwebapplications instead)
// get-spsolution 
//  (dcapxsolution.wsp Deployed must be TRUE -- Takes about 30 seconds)
// browse to http://dotersrcndapp5:2619/_layouts/DCAPXSolution/DeploymentChecklist.aspx
//  (takes about 3 minutes)
// on siprnet browse to https://dcapx.dote.osd.smil.mil/



// Test environment 
// http://dotersrcndapp5:46689/_layouts/DCAPXSolution/DeploymentChecklist.aspx
//      Uninstall features if log shows error feature 'is not installed'. 
//      This will find missing features and uninstall them. Then run DeploymentChecklist to reinstall them.
//      Also do this before deleting site collection (but not webapp), and creating new webapp.
//          stsadm -o uninstallfeature -id a0ddea8f-e3de-41d5-889d-8f9401db024d -force
//          stsadm -o uninstallfeature -id 5bcfb281-b2f6-42da-874d-a267fb0ce0d5 -force
//          stsadm -o uninstallfeature -id d2536341-6d90-4c04-b30a-46700ba51ded -force
//  install-spsolution -identity dcapxsolution.wsp -gacdeployment -force -webapplication http://dotersrcndapp5:5164/


//When static views of worksheets for conopsdev are ready -- reveal links...
//CONOPSDevelopmentModule.js line 334; CONOPSDevProgressChart.cs lines 190-317


// Caution
//  Importing Fields module from a solution created from a site template 
//   too easy to overwrite standard columns with new version 
//   standard columns then become dependent on new feature
//   deactivating feature makes standard columns unavailable
//  Do not include ID in Field element when updating SiteColumns (custom SPFields) declaratavely. See notes in Feature2.EventReceiver.cs. 
//      ID is only used when authoring a SPField. Your xml should never have both an ID and Overwrite='TRUE' in Field element. 
//      A declarative update to a SPField would be done with both xml and code. Recommend just updating using code only.  
//      If the SPField is not already in use in Production and you want to keep things clean, just update the original xml (ie. a new choice for a choice field); deploy a new assembly version of DCAPXSolution;
//      then through Site Settings page go to Site Column (not through List Settings page), and click OK to Update all lists with the change.
//      Updates like this will be rare. Dev and Production will be in sync. 
//      To update a SPField already in use in Production use code only (see msdn 'SPField Class'). Use SPField.Update Method (Boolean) to propagate the changes to lists.
//  Do not update content type definition file once installed (see msdn 'Updating Content Types' and 'Updating Child Content Types')
//      "You cannot add columns to an existing site content type declaratively"
//      "SharePoint Foundation never writes changes that are made to a content type back to the content type definition fiile."
//      If the content type is not in use in Production you can make a new column added to the definition show up in list content types, by removing the column and adding it back again to the site content type through the browser with Update all content types inheriting set to Yes.
//      If content type is in use in Production, then make updates using code (see msdn 'SPContentType.Update Method (Boolean)'). 
//      see msdn 'Updating Child Content Types': changes to site content types may be pushed down to list content types.
//          see section 'Updating Child Content Types Through the Object Model'
            //using(SPWeb oWebsite = new SPSite(url).OpenWeb())
            //{
            //    SPList oList = oWebsite.GetList("MyWebSite/Lists/MyList");
            //    SPFieldCollection collFields = oWebsite.Fields;

            //    string strNewColumn = collFields.Add("MyNewColumn", SPFieldType.Text, false);
    
            //    SPFieldLink oFieldLink = new SPFieldLink(fields[strNewColumn]);
            //    SPContentType oContentType = oList.ContentTypes["Specification"];
            //    oContentType.FieldLinks.Add(oFieldLink);

            //    oContentType.Update(true);
            //}
//  ensure latest css displays in app pages by setting the Rev parameter to this assembly version
// Do not delete past test webapps
// Freeze working Features and create new ones instead of adding for example new fields into Feature2. Then in code condition replacement of Feature2 only if does not already exist.
// Or do not add Feature2 on any place other than sites/dcapxobjects

//Steps for applying a content type to a list
//A. DCAPXSolution.DeploymentChecklist.Page_Load()
//1. //===== Declare variables for content type buttons =====
//2. //===== WORKSHEET LIST CONTENT TYPE BUTTONS =====
//OR...
//2. //===== LIST CONTENT TYPE BUTTONS with Button to add Column to Content Type =====
//OR...
//2. //===== LIST CONTENT TYPE BUTTONS =====

//B. DCAPXSolution.DeploymentChecklist.objBtnControl_Command()
//1. //======= Declare variables for applying content types to lists ============
//2. //====== Set variables for applying content types to lists ========
//3. //----- Test for list -----
//      see Test for list under webs if this is for a subsite like the am site
//4. //----- Test for content type and set content type variable -----
//5. //========== APPLY CONTENT TYPE =================
//OR...
//5. //========== APPLY CONTENT TYPE with Add Column to Content Type =================

//find and replace using regex

//>\r\n<
//>" +\r\n"<

//Update all refrences to assembly version in ?Rev= parameter for js and css in DeploymentChecklist.aspx and DCAPX.master to prevent cached files from being rendered.

//If Deployment from Visual Studio gets stuck on adding CONOPSDevButtons.webpart, Stop and Start App Pool.

//If log shows Feature is not installed ['is not installed in this farm'] (checklist may abort at contenttypes -- Get-SPFeature) use SharePoint 2010 Management Shell Install-SPFeature DCAPXSolution_Feature2
//If Uninstall-SPFeature -id a0ddea8f-e3de-41d5-889d-8f9401db024d -force 
//cannot find feature on the farm, then try STSADM.
//STSADM does a better job at this: stsadm -o uninstallfeature -id a0ddea8f-e3de-41d5-889d-8f9401db024d -force
//(Feature1  stsadm -o uninstallfeature -id a0ddea8f-e3de-41d5-889d-8f9401db024d -force  )
//(Feature2  stsadm -o uninstallfeature -id 5bcfb281-b2f6-42da-874d-a267fb0ce0d5 -force  )
//(Feature3  stsadm -o uninstallfeature -id d2536341-6d90-4c04-b30a-46700ba51ded -force  )



//Everytime you create a new webapp and deploy to it, run the above stsadm to ensure that none of the custom features are still installed on the farm because when you remove it, it leaves an orphan.

//Steps for removing old webapp from dev / creating new webapp in dev:
//1. From /_layouts/DCAPXSolution/DeploymentChecklist.aspx click "Delete /sites/DCAPXObjects" button. 
    //Retract the solution 
        //Uninstall-spsolution -identity dcapxsolution.wsp -allwebapplications
    //Remove the solution
        //Remove-spsolution -identity dcapxsolution.wsp
//2. Uninstall features from SharePoint 2010 Management Shell:
    //stsadm -o uninstallfeature -id a0ddea8f-e3de-41d5-889d-8f9401db024d -force
    //stsadm -o uninstallfeature -id 5bcfb281-b2f6-42da-874d-a267fb0ce0d5 -force
    //stsadm -o uninstallfeature -id d2536341-6d90-4c04-b30a-46700ba51ded -force 
//3. Remove webapp from SharePoint 2010 Management Shell:
    //Remove-SPWebApplication http://dotersrcndapp5:16260 -Confirm -DeleteIISSite -RemoveContentDatabases
//4. From Central Admin create new webapp so new port number is assigned and authoring account is correctly indicated.(5164 formerly 46689). Close / reopen browser after operation has completed or errored out.
//5. From Central Admin create root site collection for the new webapp
//6. Close this AssemblyInfo and click on DCAPXSolution in Solution Explorer then update port number in properties. Tab out of properties and close / reopen Visual Studio.
//7. Update port number in home address for browser.
//8. Hit the new site for the first time http://dotersrcndapp5:5164 to establish all connections and create the masterpage. If error, just close and reopen browser. 
//9. Close/ reopen Visual Studio and Retract / Deploy / install this DCAPXSolution. 
//10. Go to Deployment Checklist /_layouts/DCAPXSolution/DeploymentChecklist.aspx and enter /sites/DCAPXObjects in TextBox1 then run the routine. 
//11. From /sites/DCAPXObjects deactivate DCAPXSolution_Feature 3, 2, then 1, and activate them again as 1, 2, 3. This avoids log errors like "Error loading and running event receiver DCAPXSolution".



//You cannot use RWEP and impersonation ( system account excepted ) to update lists. Best you can do is
//use SPFieldUserValue to set Author and Editor fields -- see CONOPSDevButtons.ascx.cs.

//Keep all contectual information out of methods using RWEP including anything with Page., this.Web., etc.

//Sometimes server can be so busy that changes to web.config made during deployment are interrupted. The package only deploys files upto the interruption. 
//Confirm solution is deployed (TRUE) using Get-SPSolution. 
//For more information on deployment errors, see CA. 
//CA may show that web.config file was interrupted. 
//Bob can easily restore the most recent web.config. 
//You can also try to reauthor the web.config by stopping/starting the Microsoft SharePoint Foundation Web Application service in CA. 
//If service gets stuck stopping in CA, use PowerShell to stop and start it. 
// Get-SPServiceInstance | Where-Object{$_.TypeName -eq "Microsoft SharePoint Foundation Web Application"} | select Status, Id
// copy the Id that is Unprovisioning (792e4613-e1ac-4c06-8b96-cf05525e7e66)



// Get-SPServiceInstance | Where-Object{$_.Id -eq "4ed9195c-b4d1-4971-aa89-e6c3372eae96"} | Stop-SPServiceInstance
// Get-SPServiceInstance | Where-Object{$_.Id -eq "4ed9195c-b4d1-4971-aa89-e6c3372eae96"} | Start-SPServiceInstance

//or

// Get-SPServiceInstance | Where-Object{$_.Id -eq "792e4613-e1ac-4c06-8b96-cf05525e7e66"} | Stop-SPServiceInstance
// Get-SPServiceInstance | Where-Object{$_.Id -eq "792e4613-e1ac-4c06-8b96-cf05525e7e66"} | Start-SPServiceInstance



//PS C:\Users\DanielNW-p.DOTEDRESOURCE> Get-SPServiceInstance | Where-Object{$_.Ty
//peName -eq "Microsoft SharePoint Foundation Web Application"} | select Status, I
//d

//                                 Status Id
//                                 ------ --
//                                 Online 792e4613-e1ac-4c06-8b96-cf05525e7e66
//                                 Online 4ed9195c-b4d1-4971-aa89-e6c3372eae96


//PS C:\Users\DanielNW-p.DOTEDRESOURCE>

//Indicator that changing port for this assembly caused Web Parts to not be listed as SafeControls and solution should be retracted and redeployed after retracting and rebuilding/redeploying in dev to rebuild package...
//...see CONOPS Development Module page produces alert "Error: Expected at least one Worksheet/Review Page to be 'In Progress'. " 
//...Web Parts were added to gallery but cannot be added to pages.
//Last Operation Result: Some of the files failed to copy during deployment of the solution. 
//Last Operation Details: DOTERSRCNDAPP6 : http://dotersrcndapp5:39365/ : DCAPXTEST- 39365 : Error: The web.config is invalid on this IIS Web Site: C:\inetpub\wwwroot\wss\VirtualDirectories\39365\web.config. 
//To avoid this, try removing solution from solution store on farm through ca and closing vs. Then open vs and update the properties to the new port, and close vs. Monitor through ca. Open vs and rebuild. Then deploy through vs.

//For the below error try rebooting app6 or restarting webapp service on app6. 
//Some of the files failed to copy during deployment of the solution. 
//Last Operation Details: DOTERSRCNDAPP6 : http://dotersrcndapp5:39365/ : DCAPXTEST- 39365 : Error: The web.config is invalid on this IIS Web Site: C:\inetpub\wwwroot\wss\VirtualDirectories\39365\web.config.
//DOTERSRCNDAPP5 : http://dotersrcndapp5:39365/ : The solution was successfully deployed. 
//Last Operation Time: 11/17/2015 12:54 PM 

 



//iTextSharp: must use version 4.1.6 which has LGPL license, so downloaded master solution and built dll
// without gacutil try this to add to GAC using SharePoint 2010 Management Shell
//Set-Location C:\Users\DanielNW-p.DOTEDRESOURCE\Documents\Visual Studio 2012\Projects\iTextSharp-4.1.6-master\bin\Debug\"
//[System.Reflection.Assembly]::Load("System.EnterpriseServices, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a")
//$publish = New-Object System.EnterpriseServices.Internal.Publish
//$publish.GacInstall("C:\Users\DanielNW-p.DOTEDRESOURCE\Documents\Visual Studio 2012\Projects\iTextSharp-4.1.6-master\bin\Debug\itextsharp.dll")
//iisreset

//then add reference to C:\Users\DanielNW-p.DOTEDRESOURCE\Documents\Visual Studio 2012\Projects\iTextSharp-4.1.6-master\bin\Debug\itextsharp.dll
//default for copy to local for dll in gac is false, so set it to true to ensure dll will port to prod
//rebuild and refresh solution explorer and see it in bin

//if itextsharp dll is not in gac in prod, try packaging it in a folder PDFs and adding it to gac using above commands or as post deployment commands in prod


[assembly: AssemblyTitle("DCAPXSolution")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Department of Defense")]
[assembly: AssemblyProduct("DCAPXSolution")]
[assembly: AssemblyCopyright("Copyright © Department of Defense 2016")] //(Lead Developer: Neal.W.Daniel.ctr@mail.mil Neal.Daniel@verizon.net)
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("0ae664d2-96f2-4d4d-885a-df366c8f6e40")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.8.2")]
[assembly: AssemblyFileVersion("1.0.0.0")]

