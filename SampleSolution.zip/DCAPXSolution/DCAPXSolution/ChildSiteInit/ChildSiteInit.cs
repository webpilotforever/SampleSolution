﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Administration;

namespace DCAPXSolution.ChildSiteInit
{
    /// <summary>
    /// Web Events
    /// </summary>
    public class ChildSiteInit : SPWebEventReceiver
    {
        /// <summary>
        /// A site was provisioned.
        /// </summary>

        public override void WebProvisioned(SPWebEventProperties properties)
        {
            
            var traceInfo = "Apply masterpage to childsite: MasterUrl";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXapplyMaster", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPWeb oSiteRootWeb = properties.Web.Site.RootWeb;
            properties.Web.MasterUrl = oSiteRootWeb.MasterUrl;
            properties.Web.CustomMasterUrl = oSiteRootWeb.CustomMasterUrl;
            properties.Web.AllowUnsafeUpdates = true;
            properties.Web.Update();

            if (oSiteRootWeb != null)
            {
                oSiteRootWeb.Dispose();
            }




            //traceInfo = "Apply masterpage to childsite: MasterUrl";
            //SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXapplyMaster", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            //SPWeb childSite = properties.Web;
            //SPWeb topSite = childSite.Site.RootWeb;
            ////Apply masterpage
            //childSite.MasterUrl = topSite.MasterUrl;
            //childSite.CustomMasterUrl = topSite.CustomMasterUrl;

            //childSite.AllowUnsafeUpdates = true;
            //childSite.Update();

            //if (topSite != null)
            //{
            //    topSite.Dispose();
            //}
            //if (childSite != null)
            //{
            //    childSite.Dispose();
            //}




     







            
        }


    }
}