﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DCAPXSolution.WebAppRootWeb.DCAPXSeal
{
    [ToolboxItemAttribute(false)]
    public class DCAPXSeal : WebPart
    {
        protected override void CreateChildControls()
        {
            this.Controls.Add(new LiteralControl("<div style=\"text-align:center\"><img alt=\"DCAPX Seal\" src=\"/_layouts/Images/DCAPXSolution/DCAPXseal.png\" style=\"margin:5px\" /></div>"));
        }
    }
}
