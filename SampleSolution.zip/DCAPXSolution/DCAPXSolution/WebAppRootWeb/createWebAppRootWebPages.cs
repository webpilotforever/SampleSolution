﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.WebPartPages;
using Microsoft.SharePoint;
using System.IO;
using Microsoft.SharePoint.Utilities;
using System.Xml;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint.Administration;

namespace DCAPXSolution.WebAppRootWeb
{
    class createWebAppRootWebPages
    {
        /// <summary>
        /// Create Web Part Page and add Web Part
        /// </summary>
        /// <param name="web">SPWeb object</param>
        /// <param name="WebAppRootWebPage">File name to create</param>
        /// <param name="webPart1Path">Web part file path</param>
        /// <param name="webPart2Path">Web part file path</param>
        public static void CreateWebPartPage(string webUrl, string WebAppRootWebPage, string webPart1Path, string webPart2Path, string featureName)
        {
            using (SPSite oSite = new SPSite(webUrl))
            {
                using(SPWeb web = oSite.OpenWeb())
                {
                    var traceInfo = "Get hive.";
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


                    string templateFilename = "spstd1.aspx";
                    //  C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\14\TEMPLATE\1033\STS\DOCTEMP\SMARTPGS
                    string hive = SPUtility.GetGenericSetupPath("TEMPLATE\\1033\\STS\\DOCTEMP\\SMARTPGS\\");

                    using (FileStream stream = new FileStream(hive + templateFilename, FileMode.Open))
                    {
                        string urlToSitePages = web.Url + "/SitePages";
                        traceInfo = "Get libraryFolder: /SitePages urlToSitePages: " + urlToSitePages;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        web.AllowUnsafeUpdates = true;


                        SPFolder SitePages = web.GetFolder(urlToSitePages);

                        SPFileCollection SitePagesFiles = SitePages.Files;
                        FileStream webPart1 = File.OpenRead(webPart1Path);
                        FileStream webPart2 = File.OpenRead(webPart2Path);
                        SPFile newSitePagesFile = SitePagesFiles.Add(WebAppRootWebPage, stream, true);

                        if (newSitePagesFile.CheckOutType == SPFile.SPCheckOutType.None)
                        {
                            newSitePagesFile.CheckOut();
                        }
                        SPLimitedWebPartManager wpmngr = newSitePagesFile.Web.GetLimitedWebPartManager(newSitePagesFile.ServerRelativeUrl, PersonalizationScope.Shared);

                        string error = string.Empty;
                        web.AllowUnsafeUpdates = true;

                        System.Web.UI.WebControls.WebParts.WebPart webpartWorksheet = wpmngr.ImportWebPart(XmlReader.Create(webPart1), out error);
                        wpmngr.AddWebPart(webpartWorksheet, "FullPage", 0);
                        web.AllowUnsafeUpdates = true;

                        System.Web.UI.WebControls.WebParts.WebPart webpartButton = wpmngr.ImportWebPart(XmlReader.Create(webPart2), out error);
                        wpmngr.AddWebPart(webpartButton, "FullPage", 1);
                        web.AllowUnsafeUpdates = true;

                        newSitePagesFile.CheckIn(string.Format("File added by '{0}' feature", featureName), SPCheckinType.MajorCheckIn);
                        //web.AllowUnsafeUpdates = true;
                        //try
                        //{

                        //    newSitePagesFile.Publish(string.Format("File published by '{0}' feature", featureName));
                        //    web.AllowUnsafeUpdates = true;

                        //    newSitePagesFile.Approve(string.Format("File published by '{0}' feature", featureName));
                        //}
                        //catch (Exception ex)
                        //{
                        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsDeploymentChecklist", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);

                        //}

                    }
                }
  
            }




            

        }
        /// <summary>
        /// This method will return Web Part Folder Path
        /// </summary>
        /// <param name="web">SPWeb object</param>
        /// <param name="rootDirectory">Feature folder path</param>
        /// <returns>Returns Web Part Folder Path</returns>
        public static string GetWebPartFolderPath(string webUrl, string rootDirectory, string webPartName, string featureName)
        {
            using (SPSite oSite = new SPSite(webUrl))
            {
                using (SPWeb web = oSite.OpenWeb())
                {
                    string[] folders = rootDirectory.Split(new char[] { '\\' });
                    var traceInfo = "Setting rootDirectory to this: " + rootDirectory;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsCreatePage", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    return string.Join("/", folders, 0, folders.Length - 1) + "/" + featureName + "/" + webPartName;

                }

            }
            
        }
    }
}
