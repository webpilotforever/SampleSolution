﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DCAPXSolution.RootWeb.HomeInfoPage
{
    [ToolboxItemAttribute(false)]
    public class HomeInfoPage : WebPart
    {
        protected override void CreateChildControls()
        {
            this.Controls.Add(new LiteralControl("<h1 class=\"ms-rteElement-H1B\"><span>Welcome to your site!</span></h1><p>Add a new image, change this welcome text or add new lists to this page by clicking the edit button above. You can click on Shared Documents to add files or on the calendar to create new team events. Use the links in the getting started section to share your site and customize its look.</p><p> </p>"));

        }
    }
}



