﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Administration;
using System.Collections.Generic;

namespace DCAPXSolution.EventReceivers.ProgramContactsEventReceiver
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class ProgramContactsEventReceiver : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            if (properties.ListTitle == "ProgramContacts")
            {
            
            
            var traceInfo = "";
            
            Guid siteID = properties.SiteId;

            SPListItem oListItem = properties.ListItem;

            Guid accntGuid = new Guid("5cb1701e-f4c8-4cf1-bf78-73a5c114510b");

            string accnt = "";

            try
            {
                accnt = oListItem[accntGuid].ToString();
                traceInfo = "accnt: " + accnt;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }


            int accntI = accnt.IndexOf(";#");
            accnt = accnt.Substring(0, accntI);
            int acctId = Int32.Parse(accnt);


            traceInfo = "acctId: " + acctId;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            string ota = oListItem["OperationalTestAgency"].ToString();

            traceInfo = "setting choiceField";
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            SPFieldMultiChoice choiceField = (SPFieldMultiChoice)properties.List.Fields.GetField("ModuleAccess");

            string rawValue = oListItem[choiceField.Id].ToString();

            SPFieldMultiChoiceValue typedValue = new SPFieldMultiChoiceValue(rawValue);

            string groupReaders = "CONOPSDevReaders" + ota;
            string groupSubmitters = "CONOPSDevSubmitters" + ota;

            string spgrouptextReaders = "";
            string spgrouptextSubmitters = "";
            for (int i = 0; i < typedValue.Count; i++)
            {
                traceInfo = "typedValue[i] " + typedValue[i];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                string typedValueText = typedValue[i];


                if (typedValueText.Contains("Readers"))
                {
                    spgrouptextReaders = "CONOPSDevReaders" + ota;
                }
                else if (typedValueText.Contains("Submitters"))
                {
                    spgrouptextSubmitters = "CONOPSDevSubmitters" + ota;
                }
            }

            traceInfo = "spgrouptextReaders " + spgrouptextReaders;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            traceInfo = "spgrouptextSubmitters " + spgrouptextSubmitters;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb oWebsite = site.RootWeb)
                    {
                        //Add user to CONOPSDevReaders or Submitters groups
                        traceInfo = "Add " + accnt + " to CONOPSDevReaders or Submitters groups";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        SPUser spuser = oWebsite.AllUsers.GetByID(acctId);
                        try
                        {

                            if (spgrouptextReaders != "")
                            {
                                SPGroup spgroupReaders = oWebsite.Groups[spgrouptextReaders];
                                spgroupReaders.AddUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupReaders.Update();
                            }

                            if (spgrouptextSubmitters != "")
                            {
                                SPGroup spgroupSubmitters = oWebsite.Groups[spgrouptextSubmitters];
                                spgroupSubmitters.AddUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupSubmitters.Update();
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        try
                        {

                            if (spgrouptextReaders == "")
                            {
                                SPGroup spgroupReaders = oWebsite.Groups[groupReaders];
                                spgroupReaders.RemoveUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupReaders.Update();
                            }

                            if (spgrouptextSubmitters == "")
                            {
                                SPGroup spgroupSubmitters = oWebsite.Groups[groupSubmitters];
                                spgroupSubmitters.RemoveUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupSubmitters.Update();
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        //end Add user to CONOPSDevReaders or Submitters groups



                        //Alert AOs-----------
                        SPAlertCollection collAlertsWeb = oWebsite.Alerts;

                        foreach (SPAlert oAlertWeb in collAlertsWeb)
                        {
                            string list = oAlertWeb.List.Title;
                            if (list == "ProgramContacts")
                            {
                                SPPropertyBag Properties = oAlertWeb.Properties;
                                foreach (KeyValuePair<string, string> kvp in Properties)
                                {
                                    traceInfo = "oAlertWeb Property: " + kvp.Key + " | " + kvp.Value;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }

                            }
                        }

                        SPUserCollection collUsers = oWebsite.Users;

                        foreach (SPUser oUser in collUsers)
                        {
                            SPAlertCollection collAlerts = oUser.Alerts;
                            int cnt = 0;
                            foreach (SPAlert oAlert in collAlerts)
                            {

                                //If user is member of DCAPXAO
                                bool IsAO = false;
                                try
                                {
                                    IsAO = oUser.Groups["DCAPXAO"].ContainsCurrentUser;

                                    if (IsAO && oAlert.List.Title == "ProgramContacts")
                                    {
                                        cnt = cnt + 1;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                            }
                            if (cnt < 1)
                            {

                                traceInfo = oUser.Name + " does not have an alert on the ProgramContacts list, so create one.";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                try
                                {
                                    Guid alertguid = collAlerts.Add(properties.List, SPEventType.All, SPAlertFrequency.Immediate, SPAlertDeliveryChannels.Email);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                            }
                        }
                        //end Alert AO-----
                    }
                }
            });
        }
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            if (properties.ListTitle == "ProgramContacts")
            {
            string traceInfo = "";

            Guid siteID = properties.SiteId;
            SPListItem oListItem = properties.ListItem;

            Guid accntGuid = new Guid("5cb1701e-f4c8-4cf1-bf78-73a5c114510b");

            string accnt = "";

            try
            {
                accnt = oListItem[accntGuid].ToString();
                traceInfo = "accnt: " + accnt;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
            }
            catch (Exception ex)
            {
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
            }
            int accntI = accnt.IndexOf(";#");
            accnt = accnt.Substring(0, accntI);
            int acctId = Int32.Parse(accnt);


            string ota = oListItem["OperationalTestAgency"].ToString();


            SPFieldMultiChoice choiceField = (SPFieldMultiChoice)properties.List.Fields.GetField("ModuleAccess");

            string rawValue = oListItem[choiceField.Id].ToString();

            SPFieldMultiChoiceValue typedValue = new SPFieldMultiChoiceValue(rawValue);

            string groupReaders = "CONOPSDevReaders" + ota;
            string groupSubmitters = "CONOPSDevSubmitters" + ota;

            string spgrouptextReaders = "";
            string spgrouptextSubmitters = "";
            for (int i = 0; i < typedValue.Count; i++)
            {
                traceInfo = "typedValue[i] " + typedValue[i];
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                string typedValueText = typedValue[i];


                if (typedValueText.Contains("Readers"))
                {
                    spgrouptextReaders = "CONOPSDevReaders" + ota;
                }
                else if (typedValueText.Contains("Submitters"))
                {
                    spgrouptextSubmitters = "CONOPSDevSubmitters" + ota;
                }
            }

            traceInfo = "spgrouptextReaders " + spgrouptextReaders;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

            traceInfo = "spgrouptextSubmitters " + spgrouptextSubmitters;
            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);


            SPSecurity.RunWithElevatedPrivileges(() =>
            {
                using (SPSite site = new SPSite(siteID))
                {
                    using (SPWeb oWebsite = site.RootWeb)
                    {
                        //Add user to CONOPSDevReaders or Submitters groups
                        traceInfo = "Updated";
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                        SPUser spuser = oWebsite.AllUsers.GetByID(acctId);
                        try
                        {
                            SPList ProgramContactsList = oWebsite.Lists["ProgramContacts"];
                            if (spgrouptextReaders != "")
                            {
                                traceInfo = "Added " + accnt + " to " + spgrouptextReaders;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPGroup spgroupReaders = oWebsite.Groups[spgrouptextReaders];
                                spgroupReaders.AddUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupReaders.Update();
                            }

                            if (spgrouptextSubmitters != "")
                            {
                                traceInfo = "Added " + accnt + " to " + spgrouptextSubmitters;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPGroup spgroupSubmitters = oWebsite.Groups[spgrouptextSubmitters];
                                spgroupSubmitters.AddUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupSubmitters.Update();
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        try
                        {

                            if (spgrouptextReaders == "")
                            {
                                traceInfo = "Removed " + accnt + " from " + groupReaders;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPGroup spgroupReaders = oWebsite.Groups[groupReaders];
                                spgroupReaders.RemoveUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupReaders.Update();
                            }

                            if (spgrouptextSubmitters == "")
                            {
                                traceInfo = "Removed " + accnt + " from " + groupSubmitters;
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                SPGroup spgroupSubmitters = oWebsite.Groups[groupSubmitters];
                                spgroupSubmitters.RemoveUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupSubmitters.Update();
                            }
                        }
                        catch (Exception ex)
                        {
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                        }
                        


                        //end Add user to CONOPSDevReaders or Submitters groups
                        //Alert AO------
                        SPAlertCollection collAlertsWeb = oWebsite.Alerts;

                        foreach (SPAlert oAlertWeb in collAlertsWeb)
                        {
                            string list = oAlertWeb.List.Title;
                            if (list == "ProgramContacts")
                            {
                                SPPropertyBag Properties = oAlertWeb.Properties;
                                foreach (KeyValuePair<string, string> kvp in Properties)
                                {
                                    traceInfo = "oAlertWeb Property: " + kvp.Key + " | " + kvp.Value;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                }

                            }
                        }

                        SPUserCollection collUsers = oWebsite.Users;

                        foreach (SPUser oUser in collUsers)
                        {
                            SPAlertCollection collAlerts = oUser.Alerts;
                            int cnt = 0;
                            foreach (SPAlert oAlert in collAlerts)
                            {

                                //If user is member of DCAPXAO
                                bool IsAO = false;
                                try
                                {
                                    IsAO = oUser.Groups["DCAPXAO"].ContainsCurrentUser;

                                    if (IsAO && oAlert.List.Title == "ProgramContacts")
                                    {
                                        cnt = cnt + 1;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }


                            }
                            if (cnt < 1)
                            {

                                traceInfo = oUser.Name + " does not have an alert on the ProgramContacts list, so create one.";
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                try
                                {
                                    Guid alertguid = collAlerts.Add(properties.List, SPEventType.All, SPAlertFrequency.Immediate, SPAlertDeliveryChannels.Email);
                                }
                                catch (Exception ex)
                                {
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                }
                            }
                        }
                        //end Alert AO------


                    }
                }
            });
        }
        }

        /// <summary>
        /// An item was deleted.
        /// </summary>
        public override void ItemDeleted(SPItemEventProperties properties)
        {
            base.ItemDeleted(properties);
            if (properties.ListTitle == "ProgramContacts")
            {
                string traceInfo = "";




                traceInfo = "ProgramContacts ItemDeleted";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                Guid siteID = properties.SiteId;

                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb oWebsite = site.RootWeb)
                        {
                            //Alert AOs-------
                            SPAlertCollection collAlertsWeb = oWebsite.Alerts;

                            foreach (SPAlert oAlertWeb in collAlertsWeb)
                            {
                                string list = oAlertWeb.List.Title;
                                if (list == "ProgramContacts")
                                {
                                    SPPropertyBag Properties = oAlertWeb.Properties;
                                    foreach (KeyValuePair<string, string> kvp in Properties)
                                    {
                                        traceInfo = "oAlertWeb Property: " + kvp.Key + " | " + kvp.Value;
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    }

                                }
                            }

                            SPUserCollection collUsers = oWebsite.Users;

                            foreach (SPUser oUser in collUsers)
                            {
                                SPAlertCollection collAlerts = oUser.Alerts;
                                int cnt = 0;
                                foreach (SPAlert oAlert in collAlerts)
                                {

                                    //If user is member of DCAPXAO
                                    bool IsAO = false;
                                    try
                                    {
                                        IsAO = oUser.Groups["DCAPXAO"].ContainsCurrentUser;

                                        if (IsAO && oAlert.List.Title == "ProgramContacts")
                                        {
                                            cnt = cnt + 1;
                                        }
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }


                                }
                                if (cnt < 1)
                                {

                                    traceInfo = oUser.Name + " does not have an alert on the ProgramContacts list, so create one.";
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    try
                                    {
                                        Guid alertguid = collAlerts.Add(properties.List, SPEventType.All, SPAlertFrequency.Immediate, SPAlertDeliveryChannels.Email);
                                    }
                                    catch (Exception ex)
                                    {
                                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                                    }
                                }
                            }
                            //end Alert AOs------
                        }
                    }
                });
            }
        }

        /// <summary>
        /// An item is being deleted
        /// </summary>
        public override void ItemDeleting(SPItemEventProperties properties)
        {
            base.ItemDeleting(properties);
            if (properties.ListTitle == "ProgramContacts")
            {
                string traceInfo = "";

                Guid siteID = properties.SiteId;

                SPListItem oListItem = properties.ListItem;

                Guid accntGuid = new Guid("5cb1701e-f4c8-4cf1-bf78-73a5c114510b");

                string accnt = "";

                try
                {
                    accnt = oListItem[accntGuid].ToString();
                    traceInfo = "accnt: " + accnt;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
                traceInfo = "Deleting " + accnt + " from ProgramContacts list, so removing user from groups";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                int accntI = accnt.IndexOf(";#");
                accnt = accnt.Substring(0, accntI);
                int acctId = Int32.Parse(accnt);


                traceInfo = "acctId: " + acctId;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                string ota = oListItem["OperationalTestAgency"].ToString();

                string groupReaders = "CONOPSDevReaders" + ota;
                string groupSubmitters = "CONOPSDevSubmitters" + ota;

                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb oWebsite = site.RootWeb)
                        {
                            SPUser spuser = oWebsite.AllUsers.GetByID(acctId);

                            traceInfo = "Remove " + accnt + " from " + groupReaders;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            try
                            {
                                SPGroup spgroupReaders = oWebsite.Groups[groupReaders];
                                spgroupReaders.RemoveUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupReaders.Update();

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }

                            traceInfo = "Remove " + accnt + " from " + groupSubmitters;
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                            try
                            {
                                SPGroup spgroupSubmitters = oWebsite.Groups[groupSubmitters];
                                spgroupSubmitters.RemoveUser(spuser);
                                oWebsite.AllowUnsafeUpdates = true;
                                spgroupSubmitters.Update();

                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }
                        }
                    }
                });
            }
        }

        /// <summary>
        /// An item is being updated
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
            if (properties.ListTitle == "ProgramContacts")
            {
                string traceInfo = "";

                Guid siteID = properties.SiteId;

                SPListItem oListItem = properties.ListItem;

                Guid accntGuid = new Guid("5cb1701e-f4c8-4cf1-bf78-73a5c114510b");

                string accnt = "";

                try
                {
                    accnt = oListItem[accntGuid].ToString();
                    traceInfo = "accnt: " + accnt;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }
                traceInfo = "Updating " + accnt + " from ProgramContacts list, so updating user groups";
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                int accntI = accnt.IndexOf(";#");
                accnt = accnt.Substring(0, accntI);
                int acctId = Int32.Parse(accnt);


                traceInfo = "acctId: " + acctId;
                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                //otaBefore
                string otaBeforeReaders = "";
                string otaBeforeSubmitters = "";


                string ota = properties.AfterProperties["OperationalTestAgency"].ToString();

                try
                {

                    string otaBefore = properties.ListItem["OperationalTestAgency"].ToString();

                    traceInfo = "otaBefore: " + otaBefore;
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("otaBefore", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                    if (ota != otaBefore)
                    {
                        //ota has changed, so must try to remove user from both submitters and readers groups for that ota
                        traceInfo = "ota has changed from: " + otaBefore + " to: " + ota;
                        SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("otaBefore", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                        otaBeforeReaders = "CONOPSDevReaders" + otaBefore;
                        otaBeforeSubmitters = "CONOPSDevSubmitters" + otaBefore;
                    }

                }
                catch (Exception ex)
                {
                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("otaBefore", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                }


                SPSecurity.RunWithElevatedPrivileges(() =>
                {
                    using (SPSite site = new SPSite(siteID))
                    {
                        using (SPWeb oWebsite = site.RootWeb)
                        {

                            traceInfo = "Updating";
                            SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);
                            SPUser spuser = oWebsite.AllUsers.GetByID(acctId);

                            try
                            {

                                if (otaBeforeReaders != "")
                                {
                                    traceInfo = "Removed " + accnt + " from " + otaBeforeReaders;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    SPGroup spotaBeforeReaders = oWebsite.Groups[otaBeforeReaders];
                                    spotaBeforeReaders.RemoveUser(spuser);
                                    oWebsite.AllowUnsafeUpdates = true;
                                    spotaBeforeReaders.Update();
                                }

                                if (otaBeforeSubmitters != "")
                                {
                                    traceInfo = "Removed " + accnt + " from " + otaBeforeSubmitters;
                                    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContactsER", TraceSeverity.Medium, EventSeverity.Information), TraceSeverity.Medium, traceInfo);

                                    SPGroup spotaBeforeSubmitters = oWebsite.Groups[otaBeforeSubmitters];
                                    spotaBeforeSubmitters.RemoveUser(spuser);
                                    oWebsite.AllowUnsafeUpdates = true;
                                    spotaBeforeSubmitters.Update();
                                }
                            }
                            catch (Exception ex)
                            {
                                SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory("DCAPXEventsProgramContacts", TraceSeverity.Unexpected, EventSeverity.Error), TraceSeverity.Unexpected, ex.Message, ex.StackTrace);
                            }





                        }
                    }
                });

            }




        }


    }
}



