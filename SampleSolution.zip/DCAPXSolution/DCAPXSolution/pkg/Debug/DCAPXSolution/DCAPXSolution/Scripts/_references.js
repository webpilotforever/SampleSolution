﻿/// <reference path="JQUERY.MIN2.js" />
/// <reference path="SP.UI.Dialog.debug.js" />
/// <reference path="MicrosoftAjax2.js" />
/// <reference path="~/Scripts/bootstrap-3.3.6-dist/js/bootstrap.js" />
/// <reference path="knockout-3.4.0.js" />
/// <reference path="~/Scripts/angular-1.5.7/angular.js" />
/// <reference path="kendo.all.min.js" />