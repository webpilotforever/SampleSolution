﻿/// <reference path="JQUERY.MIN.js" />
/// <reference path="SP.UI.Dialog.debug.js" />
/// <reference path="MicrosoftAjax.js" />